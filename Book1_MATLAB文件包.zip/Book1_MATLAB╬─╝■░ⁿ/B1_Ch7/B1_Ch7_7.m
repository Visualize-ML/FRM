% B1_Ch7_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = [-5:0.01:5];
mu_1 = 0; sigma_1 = 1; 
y_pdf_1 = normpdf(x,mu_1,sigma_1); 
 
mu_2 = mu_1 + 1;
y_pdf_2 = normpdf(x,mu_2, sigma_1);
 
sigma_3 = sigma_1 + 1;
y_pdf_3 = normpdf(x,mu_1, sigma_3);
 
sigma_4 = sigma_1 - 0.5;
mu_4 = mu_1 - 1
y_pdf_4 = normpdf(x,mu_4, sigma_4);
 
figure(1)
subplot(2,2,1)
plot(x,y_pdf_1)
xlabel('x'); ylabel('PDF'); ylim([0,0.8])
title('\mu = 0, \sigma = 1')
 
subplot(2,2,2)
plot(x,y_pdf_1,'--'); hold on; plot(x,y_pdf_2)
xlabel('x'); ylabel('PDF'); ylim([0,0.8])
title('\mu = 1, \sigma = 1')
 
subplot(2,2,3)
plot(x,y_pdf_1,'--'); hold on; plot(x,y_pdf_3)
xlabel('x'); ylabel('PDF'); ylim([0,0.8])
title('\mu = 0, \sigma = 2')
 
subplot(2,2,4)
plot(x,y_pdf_1,'--'); hold on; plot(x,y_pdf_4)
xlabel('x'); ylabel('PDF'); ylim([0,0.8])
title('\mu = -1, \sigma = 0.5')
