% B1_Ch7_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

N = 2000;
X = 5*randn(N,1)+10;
avg_X = mean (X); 
 
figure(1)
x = [1:length(X)];
plot(x,X,'x'); hold on
plot([0,N],[avg_X,avg_X],'--'); hold on
txt1 = '\uparrow Average';
text(15,avg_X-0.1,txt1)
 
xx =  [0:length(X)+1];
X_std = std (X);
lower_bound = avg_X*ones(1,length(xx)) - X_std;
upper_bound = avg_X*ones(1,length(xx)) + X_std;
 
h = patch([xx fliplr(xx)], [lower_bound fliplr(upper_bound)],'r')
alpha(0.3)
set(h,'EdgeColor','none')
hold off
xlim([0 N])
