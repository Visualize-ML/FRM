% B1_Ch7_12.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
data = 50 + 10*randn(1,1000); 
 
% Histograms with different numbers of bins
figure(1)
subplot(1,2,1)
bins = [10:10:100];
hist(data, bins) 
% predetermined locations of bins
xlabel('Data')
ylabel('Number of events')
y1=get(gca,'ylim')
x1=get(gca,'xlim')
 
subplot(1,2,2)
num_bins = 20;
hist(data,num_bins) 
% 20 is the number of bins
xlabel('Data')
ylabel('Number of events')
ylim([y1])
xlim([x1])
 
%% Histogram with a normal distribution fit
 
figure(2)
histfit(data,num_bins)
xlabel('Data')
ylabel('Number of events')
 
%% Histogram with 5% and 95% percentiles
figure(3)
 
hist(data,num_bins) 
Percentiles = prctile(data, [5, 95]);
y1=get(gca,'ylim')
hold on
p_5  = Percentiles(1)
p_95 = Percentiles(2)
plot([p_5 p_5],y1)
plot([p_95 p_95],y1)
 
txt1 = '5% percentile \rightarrow';
text(p_5-0.05,y1(2)*0.8,txt1,...
'HorizontalAlignment', 'right')
 
txt2 = '\leftarrow 95% percentile';
text(p_95+0.05,y1(2)*0.8,txt2,...
'HorizontalAlignment', 'left')
 
xlabel('Data')
ylabel('Number of events')
