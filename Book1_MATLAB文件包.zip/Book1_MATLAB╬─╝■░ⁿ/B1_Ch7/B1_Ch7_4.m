% B1_Ch7_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

earth_density = [5.5, 5.57, 5.42, 5.61, 5.53, 5.47, 4.88, ...
    5.62, 5.63, 4.07, 5.29, 5.34, 5.26, 5.44, 5.46, 5.55, ...
    5.34, 5.3, 5.36, 5.79, 5.75, 5.29, 5.1, 5.86, 5.58, ...
    5.27, 5.85, 5.65, 5.39];
% Dataset contains 29 measurements of the density of the earth,
% obtained by Henry Cavendish in 1798 using a torsion balance.
% Density is presented as a multiple of the density of water.
% Data can be downloaded from:
% http://lib.stat.cmu.edu/DASL/Datafiles/Cavendish.html
 
earth_density_avg = mean(earth_density)
 
earth_density_median = median(earth_density)
 
earth_density_mode = mode(earth_density)
 
earth_density_geomean = geomean(earth_density)
 
earth_density_max = max(earth_density)
 
earth_density_min = min(earth_density)
 
earth_density_range = range (earth_density) 
% max(x) - min(x)
 
figure(1)
 
plot([1:length(earth_density)],earth_density,'x'); hold on
 
plot([0,30],[earth_density_max,earth_density_max],'--'); hold on
txt1 = '\downarrow Max';
text(15,earth_density_max+0.1,txt1)
 
plot([0,30],[earth_density_min,earth_density_min],'--'); hold on
txt1 = '\uparrow Min';
text(15,earth_density_min-0.1,txt1)
 
plot([0,30],[earth_density_avg,earth_density_avg],'--'); hold on
txt1 = '\uparrow Average';
text(15,earth_density_avg-0.1,txt1)
 
plot([0,30],[earth_density_median,earth_density_median],'--'); hold on
txt1 = '\downarrow Median';
text(15,earth_density_median+0.1,txt1)
 
ylim([min(earth_density)*0.9,max(earth_density)*1.1])
xlabel('Data index')
ylabel('Earth density [g/cm�]')
 
%% plot the distribution
 
outlier_loc = isoutlier(earth_density);
outlier = earth_density(outlier_loc);
 

figure(2)
 
boxplot(earth_density,'Labels','All measurements')
ylabel('Earth density [g/cm^3]')


figure(3)
histfit(earth_density,10,'kernel'); hold on
 
plot([earth_density_avg,earth_density_avg],[0,11],'--'); hold on
txt1 = '\leftarrow Average';
text(earth_density_avg+0.05,10,txt1)
 
plot([earth_density_median,earth_density_median],[0,11],'--'); hold on
txt1 = 'Median \rightarrow';
text(earth_density_median-0.05,10,txt1,...
'HorizontalAlignment', 'right')
 
plot([outlier,outlier],[0,11],'--'); hold on
txt1 = 'Outlier \rightarrow';
text(outlier-0.05,10,txt1,'HorizontalAlignment', 'right')
 
ylim([0,11])
xlabel('Earth density [g/cm�]')
ylabel('Frequency')
