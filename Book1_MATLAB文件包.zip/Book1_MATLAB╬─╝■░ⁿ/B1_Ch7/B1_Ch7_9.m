% B1_Ch7_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

mu = 0;
sigma = 1;
pd = makedist('Normal',mu,sigma);
xs = [-3:3]; xmid = [-2.5:1:2.5];
 
xx = -5:0.01:5;
ys_cdf = cdf(pd,xs);
yy_cdf = cdf(pd,xx);
yy_pdf = normpdf (xx, mu, sigma);
ys_pdf = normpdf (xs, mu, sigma);
ys_cdf_interv = diff(ys_cdf);
 
figure(1)
subplot(2,1,1)
plot(xx,yy_pdf); hold on
stem(xs,ys_pdf,'o')
str = string(round(ys_cdf_interv,3));
textscatter(xmid,0.075*ones(size(xmid)),str);
 
grid off; box off;
xlabel('x'); ylabel('PDF')
 
subplot(2,1,2)
 
plot(xx,yy_cdf); hold on
stem(xs,ys_cdf,'o')
str = string(round(ys_cdf,4));
textscatter(xs,ys_cdf,str);
grid off; box off;
xlabel('x'); ylabel('CDF')
