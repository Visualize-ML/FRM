% B1_Ch7_14.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% number of tosses varies for each trial
% Head: 1; tail: 0
clc; clear all close all
 
NUMs_toss = [10:50:5000];
% Number of tosses in each trial increases
 
AVEs_toss = [];
for i = 1:length(NUMs_toss)
    
    num_toss = NUMs_toss(i);
    head_or_tail = randi([0,1],num_toss,1);
    num_heads = sum(head_or_tail);
    ave_head_tail = mean(head_or_tail);
    AVEs_toss = [AVEs_toss,ave_head_tail];
    
end
 
figure(1)
plot(NUMs_toss, AVEs_toss,'-x')
xlabel('Number of tosses for each trial')
ylabel('Average value'); ylim([0,0.75])
