% B1_Ch7_15.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Toss a dice
%  50 events in one trial

clc; close all; clear all
 
num_toss = 50;
% number of tosses in one trial
index_toss = 1:num_toss;
face_1_to_6 = randi([1,6],num_toss,1);
average_faces = mean(face_1_to_6);
% please convert the following to a loop
loc_1 = face_1_to_6; loc_1 (loc_1 ~= 1) = NaN;
loc_2 = face_1_to_6; loc_2 (loc_2 ~= 2) = NaN;
loc_3 = face_1_to_6; loc_3 (loc_3 ~= 3) = NaN;
loc_4 = face_1_to_6; loc_4 (loc_4 ~= 4) = NaN;
loc_5 = face_1_to_6; loc_5 (loc_5 ~= 5) = NaN;
loc_6 = face_1_to_6; loc_6 (loc_6 ~= 6) = NaN;
 
figure(1)
plot(index_toss,loc_1,'o'); hold on
plot(index_toss,loc_2,'x'); hold on
plot(index_toss,loc_3,'o'); hold on
plot(index_toss,loc_4,'x'); hold on
plot(index_toss,loc_5,'o'); hold on
plot(index_toss,loc_6,'x'); hold on
xlabel('Index of toss');
line1 = ['Total number of tosses in one trial: ',...
num2str(num_toss)];
line2 = ['Average value: ', num2str(average_faces)];
title({line1;line2}); ylabel('Face value')
ylim([-0.5,6.5]); xlabel('Index of toss for current trial')
