% B1_Ch7_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% buckets
r_buckets = [-0.3, -0.1, -0.05, 0, 0.05, 0.1, 0.3];
 
% frequency within each bucket
num_set = [16, 22, 73, 92, 34, 15];
num_interation = length(num_set);
r252 = [];
 
% generate fake returns with in buckets
 
for i = 1:num_interation
    
r_bucket = (r_buckets(i+1)-r_buckets(i)).*...
rand(num_set(i),1) + r_buckets(i);
    
    r252 = [r252; r_bucket];
    
end
 
figure(1)
subplot(1,2,1)
histogram(r252)
ylabel('Frequency')
xlabel('Return')
a=[cellstr(num2str(get(gca,'xtick')'*100))];
pct = char(ones(size(a,1),1)*'%');
new_xticks = [char(a),pct];
set(gca,'xticklabel',new_xticks)
 
subplot(1,2,2)
nbins = 10; % number of buckets or bins
h = histogram(r252,nbins)
h.Normalization = 'probability';
ylabel('Probability')
xlabel('Return')
a=[cellstr(num2str(get(gca,'xtick')'*100))];
pct = char(ones(size(a,1),1)*'%');
new_xticks = [char(a),pct];
set(gca,'xticklabel',new_xticks)
 
figure(2)
 
histogram(r252,'Normalization','CDF')
ylabel('Probability (%)')
xlabel('Return')
a=[cellstr(num2str(get(gca,'xtick')'*100))];
pct = char(ones(size(a,1),1)*'%');
new_xticks = [char(a),pct];
set(gca,'xticklabel',new_xticks)
a=[cellstr(num2str(get(gca,'ytick')'*100))];
pct = char(ones(size(a,1),1)*'%');
new_yticks = [char(a),pct];
set(gca,'yticklabel',new_yticks)
