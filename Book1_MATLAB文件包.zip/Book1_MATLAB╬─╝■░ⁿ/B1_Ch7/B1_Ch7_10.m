% B1_Ch7_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
CDFs = [0.2, 0.5, 0.6, 0.8];
mu = 0; sigma = 1;
pd = makedist('Normal','mu',mu,'sigma',sigma);
Xs = icdf(pd, CDFs);
 
figure(1)
 
for i = 1:length(Xs)
    x = Xs(i);
    subplot(2,2,i)
    cdf_pdf_plot(x)
end
 
function cdf_pdf_plot(x)
 
xx = [-5:0.01:5];
pdf_xx = normpdf(xx);
cdf_xx = normcdf(xx);
cdf_x  = normcdf(x);
xx_x = linspace(-5,x,100);
 
yyaxis left
 
plot(xx,pdf_xx); hold on
 
pdf_xx_x = normpdf(xx_x);
 
plot(xx_x,pdf_xx_x); hold on
 
curve1 = pdf_xx_x;
curve2 = zeros(size(pdf_xx_x));
x2 = [xx_x, fliplr(xx_x)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g'); hold on
plot(xx_x(end),pdf_xx_x(end),'ok')
box off; grid off;
xlabel('x'); ylabel('PDF')
ylim([0 1])
 
yyaxis right
plot(xx,cdf_xx); hold on
plot(x,cdf_x,'kx')
ylabel('CDF')
 
title(['CDF = ',num2str(cdf_x),'; x = ',num2str(x)])
end
