% B1_Ch7_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

figure(1)
subplot(2,2,1)
PT = plot_pt(3)
 
subplot(2,2,2)
PT = plot_pt(5)
 
subplot(2,2,3)
PT = plot_pt(7)
 
subplot(2,2,4)
PT = plot_pt(9)
 
function PT = plot_pt(n)
PT = pascal_triangle(n);
PT(PT == 0) = NaN;
c = imagesc(PT)
cb = colorbar;
set(c,'AlphaData',~isnan(PT))
set(gcf,'color','white')
colormap(cool)
title(['n = ',num2str(n)])
bar_ticks = [1:round(max(PT(:))/4):max(PT(:))-1,max(PT(:))];
set(cb, 'ticks', bar_ticks);
end
 
 
function A = pascal_triangle(n)
 
A=eye(n);
A(:,1)=1;
for i=2:n
    A(i,2:end)=A(i-1,1:end-1)+A(i-1,2:end);
end
 
end
