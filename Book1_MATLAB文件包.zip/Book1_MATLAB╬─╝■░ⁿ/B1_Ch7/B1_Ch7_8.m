% B1_Ch7_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
x_a = -1;
x_b = 1.5;
mu = 0; sigma = 1;

xx = [-5:0.01:5];
pdf_xx = normpdf(xx);
cdf_xx = normcdf(xx);

cdf_x_a  = normcdf(x_a);
cdf_x_b  = normcdf(x_b);
xx_ab = linspace(x_a, x_b,100);
prob_ab = cdf_x_b - cdf_x_a;
 
figure(1)
subplot(2,1,1)
 
plot(xx,pdf_xx); hold on
 
pdf_xx_ab = normpdf(xx_ab);
 
plot(xx_ab,pdf_xx_ab); hold on
 
curve1 = pdf_xx_ab;
curve2 = zeros(size(pdf_xx_ab));
x2 = [xx_ab, fliplr(xx_ab)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g'); hold on
plot(xx_ab(end),pdf_xx_ab(end),'ok'); hold on
plot(xx_ab(1),pdf_xx_ab(1),'ok')
box off; grid off;
xlabel('x'); ylabel('PDF')
title(['P(a<x<b) = ', num2str(prob_ab),...
    '; a = ',num2str(x_a),', b = ',num2str(x_b)])
 
subplot(2,1,2)
plot(xx,cdf_xx); hold on
plot(x_a,cdf_x_a,'kx'); hold on
plot(x_b,cdf_x_b,'kx'); hold on
xlabel('x'); ylabel('CDF')
box off; grid off; 
