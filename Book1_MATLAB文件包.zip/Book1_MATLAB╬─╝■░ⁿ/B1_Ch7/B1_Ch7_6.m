% B1_Ch7_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = [-5:0.01:5];
mu = 0; sigma = 1; 
y_pdf = normpdf(x,mu,sigma); 
% returns the pdf of the normal distribution 
% with mean mu and standard deviation sigma, 
% evaluated at the values in x
y_cdf = normcdf(x,mu,sigma); 
% p = normcdf(x,mu,sigma) returns the cdf 
% of the normal distribution with mean mu and 
% standard deviation sigma, evaluated at the values in x
 
figure(1)
subplot(2,1,1)
plot(x,y_pdf)
xlabel ('x'); ylabel ('Standard normal distribution, PDF')
 
subplot(2,1,2)
plot(x,y_cdf)
xlabel ('x'); ylabel ('Standard normal distribution, CDF')

