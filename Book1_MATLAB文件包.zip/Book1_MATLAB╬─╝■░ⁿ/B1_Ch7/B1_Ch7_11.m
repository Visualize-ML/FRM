% B1_Ch7_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
num_Qs = [3, 4, 5, 8, 10, 20, 50, 100];
 
for i = 1:length(num_Qs)
    figure(i)
    num_q = num_Qs(i);
    quantile_plot(num_q)
end
 
 
function quantile_plot(num_q)
 
quantiles = [1:num_q-1]./num_q;
% [num, dem] = rat(quantiles);
xx = [-5:0.01:5];
mu = 0; sigma = 1;
pd = makedist('Normal','mu',mu,'sigma',sigma);
x_Qs = icdf(pd,quantiles);
pdf_Xs = normpdf(x_Qs);
 
my_col = brewermap(length(x_Qs),'RdYlBu');
 
subplot(2,1,1)
plot(xx,normpdf(xx),'LineWidth',2); hold on
 
for i = 1:length(x_Qs)
    plot([x_Qs(i),x_Qs(i)], [0, pdf_Xs(i)],'color',my_col(i,:)); hold on
    plot(x_Qs(i), pdf_Xs(i),'o','color',my_col(i,:)); hold on
end
xlabel('x'); ylabel('PDF')
box off; grid off
 
subplot(2,1,2)
plot(xx,normcdf(xx),'LineWidth',2); hold on
 
for i = 1:length(x_Qs)
    plot([-5,x_Qs(i)], [quantiles(i), quantiles(i)],'color',my_col(i,:)); hold on
    plot(x_Qs(i), quantiles(i),'o','color',my_col(i,:)); hold on
end
 
denominator = num_q;
if length(quantiles) <= 10
    yticks(quantiles);
else
    yticks(quantiles(1:round(length(quantiles)/10):end));
end
 
existing_Y_Ticks = get(gca, 'YTick');
New_Y_Tick_Numerators = (existing_Y_Ticks * denominator);
 
for k = 1 : length(existing_Y_Ticks)
    y_tick_labels{k} = sprintf('%.f/%d', New_Y_Tick_Numerators(k), denominator);
end
% Apply our tick marks to the plot.
set(gca,'YTickLabel',y_tick_labels);
xlabel('x'); ylabel('CDF')
box off; grid off
 
end
