% B1_Ch7_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Results of one trial
% Head: 1; tail: 0
clc; close all; clear all
 
num_toss = 50; % number of tosses in one trial
index_toss = 1:num_toss;
head_or_tail = randi([0,1],num_toss,1);
loc_heads = head_or_tail;
loc_heads (loc_heads == 0) = NaN;
loc_tails = head_or_tail;
loc_tails (loc_tails == 1) = NaN;
 
num_heads = sum(head_or_tail);
 
figure(1)
plot(index_toss,loc_heads,'o'); hold on
plot(index_toss,loc_tails,'x')
xlabel('Index of toss');
line1 = ['Total number of tosses in one trial: ', num2str(num_toss)];
line2 = ['Number of heads: ', num2str(num_heads)];
title({line1;line2})
ylim([-0.5,1.5]); xlabel('Index of toss for current trial')
ylabel('Head: 1; tail: 0'); legend('Head','Tail')
