% B1_Ch7_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
n = input('n (an integer) in (x+a)^n is ');
a = input('a (an integer) in (x+a)^n is ');
Cy = ones(1,n+1);
 
j = 2:n+1;
Cy(1,j) = a.^(j-1);
 
% Pascals Triangle
Pascals_Triangle = zeros(100,100);
% Preallocating Pascals Triangle Matrix
Pascals_Triangle(:,1) = 1;
 
for i = 2:1:n+1
    for j = 2:1:n+1
        
        Pascals_Triangle(i,j) = (Pascals_Triangle(i-1,j-1)...
            + Pascals_Triangle(i-1,j));
        
    end
end
 
Cx = Pascals_Triangle(n+1,1:n+1);
p = Cy.*Cx;
answer = poly2sym(p);
 
formatSpec = '(x+%d)^%d = ';
X = sprintf(formatSpec,a,n);
disp(X)
disp(answer)
