% B1_Ch10_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Convexity vs coupon rate
 
clc; clear all; close all
 
ytm = 0.1; par = 100;
COUPON_r = [0:0.01:0.2];
 
for i = 1:length(COUPON_r)
    
    coupon_rate = COUPON_r(i);
    
    coupon = par*coupon_rate;
    CFs = [coupon coupon coupon coupon + par];
    PV(i) = pvvar([0 CFs], ytm);
    [D, D_m] = cfdur(CFs, ytm);
    C = cfconv(CFs, ytm);
    D_mod (i) = D_m; Conv(i) = C; 
    
end
 
figure(1)
subplot(3,1,1)
plot(COUPON_r, PV); hold on
xlabel('Coupon rate'); ylabel('Bond price [USD]')
plot(ytm, par, 'o')
 
subplot(3,1,2)
plot(COUPON_r,D_mod)
xlabel('Coupon rate'); ylabel('Modified duration')
 
subplot(3,1,3)
plot(COUPON_r,Conv)
xlabel('Coupon rate'); ylabel('Convexity')
