% B1_Ch10_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%%
clc; clear all; close all
 
Rates = [0.035; 0.042147; 0.047345; 0.052707];
Valuation_Date = 'Jan-1-2018';
Start_Dates = Valuation_Date;
End_Dates = {'Jan-1-2019'; 'Jan-1-2020'; 'Jan-1-2021'; 'Jan-1-2022'};
Compounding = 1;
ZeroRateSpec = intenvset('Rates', Rates, 'StartDates',Start_Dates,...
    'EndDates', End_Dates, 'Compounding', Compounding);

figure(1)
tenors = ZeroRateSpec.EndTimes;
Zero_Rates = ZeroRateSpec.Rates;
plot (tenors,Zero_Rates, 'o-')
xlabel ('Tenor nodes (year)')
ylabel('Rate')
 
xlim([0 max(tenors)])
ylim([0 max(Zero_Rates)])
set(gcf,'color','white')
 
Coupon_Rate = 0.1; % 10% coupon
analysis_date = Valuation_Date;
Maturity = 'Aug-01-2021';
Period = 2; % semi-annual coupon
Face = 100; % USD
[Price, DirtyPrice, CFlowAmounts, CFlowDates] = bondbyzero(...
    ZeroRateSpec, Coupon_Rate, analysis_date, Maturity, 'Period',...
    Period, 'Face', Face)
% Day count convention: actual/actual
 
figure(2)
bar(CFlowDates, CFlowAmounts)
datetick('x','mmm/yy','keeplimits')
x = CFlowDates;
y = CFlowAmounts;
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(y(i1),'%0.2f'),...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
 
xlabel('Date')
ylabel('Cash flow [USD]')
 
% analysis date is rolling
% assumption: the term structure is unchanged
 
formatIn = 'mmm-dd-yyyy';
analysis_date_num = datenum(Valuation_Date,formatIn);
Maturity_date_num = datenum(Maturity,formatIn);
analysis_date_series = analysis_date_num:5:Maturity_date_num;
 
for i = 1:length(analysis_date_series)
    
    analysis_date = analysis_date_series(i);
    [Clean_Price_series(i), Dirty_Price_series(i), CFlowAmounts, CFlowDates] = bondbyzero(...
    ZeroRateSpec, Coupon_Rate, analysis_date, Maturity, 'Period',...
    Period, 'Face', Face);
 
end
 
figure(3)
plot(analysis_date_series,Clean_Price_series); hold on
plot(analysis_date_series,Dirty_Price_series); hold on
datetick('x','mmm/yy','keeplimits')
ylim([50,max(Dirty_Price_series)])
legend('Clean price','Dirty price','Location','southwest')
 
xlabel('Date')
ylabel('Price [USD]')
