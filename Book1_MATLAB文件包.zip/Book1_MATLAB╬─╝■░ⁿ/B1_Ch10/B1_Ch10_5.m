% B1_Ch10_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
ytms  = 0:0.02:0.2;
ns = 2:2:14;
% ns = 2:4:6;
[YTMs, Ns] = meshgrid(ytms,ns);
 
% weight = n/(1 + ytm)^n
WEIGHTs = Ns./(1 + YTMs).^Ns;
W_n_1 = WEIGHTs(1,:);
W_N_1 = repmat(W_n_1,length(ns),1);
w_standardized = WEIGHTs./W_N_1;
 
% the above can be simplified as:
% W_normalized = Ns./(1 + YTMs).^(Ns-1);
 
figure(1)
subplot(1,2,1)
mesh(YTMs, Ns, w_standardized)
xlabel('YTM'); ylabel ('Year(s)'); 
zlabel('Standardized weight � time')
xlim([min(ytms) max(ytms)]); ylim([min(ns) max(ns)])
zlim([min(w_standardized(:)) max(w_standardized(:))])
 
subplot(1,2,2)
mesh(YTMs, Ns, w_standardized,'MeshStyle','column')
xlabel('YTM'); ylabel ('Year(s)'); 
zlabel('Standardized weight � time')
xlim([min(ytms) max(ytms)]); ylim([min(ns) max(ns)])
zlim([min(w_standardized(:)) max(w_standardized(:))])
 
W_sum = sum(w_standardized,1);
W_SUM = repmat(W_sum,length(ns),1);
 
W_normalized = w_standardized./W_SUM;
 
figure(2)
subplot(1,2,1)
mesh(YTMs, Ns, W_normalized)
xlabel('YTM'); ylabel ('Year(s)'); 
zlabel('Normalized weight � time')
xlim([min(ytms) max(ytms)]); ylim([min(ns) max(ns)])
zlim([min(W_normalized(:)) max(W_normalized(:))])
 
subplot(1,2,2)
mesh(YTMs, Ns, W_normalized,'MeshStyle','column')
xlabel('YTM'); ylabel ('Year(s)'); 
zlabel('Normalized weight � time')
xlim([min(ytms) max(ytms)]); ylim([min(ns) max(ns)])
zlim([min(W_normalized(:)) max(W_normalized(:))])
