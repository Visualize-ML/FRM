% B1_Ch10_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Duration vs YTM
clc; clear all; close all
 
coupon_rate = 0.1; 
par = 100;
coupon = par*coupon_rate;
CFs = [coupon coupon coupon coupon + par];
 
YTM = [0:0.01:0.2];
 
for i = 1:length(YTM)
    
    ytm = YTM(i);
    PV(i) = pvvar([0 CFs], ytm);
    [D, D_m] = cfdur(CFs, ytm);
    
    D_mod (i) = D_m; D_macl (i) = D;
    
end
 
figure(1)
 
subplot(3,1,1)
plot(YTM, PV); hold on
xlabel('Yield to maturity'); ylabel('Bond price [USD]')
plot(coupon_rate, par, 'o')
 
subplot(3,1,2)
plot(YTM,D_mod)
xlabel('Yield to maturity'); ylabel('Modified duration')

subplot(3,1,3)
plot(YTM,D_macl)
xlabel('Yield to maturity'); ylabel('Macauly duration')
