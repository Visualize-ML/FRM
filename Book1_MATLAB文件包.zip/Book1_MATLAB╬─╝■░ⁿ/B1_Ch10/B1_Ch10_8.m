% B1_Ch10_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Duration vs YTM vs coupon rate
 
clc; clear all; close all
T_interest = 3; % year 
par = 100;
COUPON_r = [0:0.01:0.2]; YTM = [0:0.01:0.2];
 
[XX,YY] = meshgrid(COUPON_r,YTM);
 
for i = 1:length(YTM)
    
    ytm = YTM(i);
        
    for j = 1:1:length(COUPON_r)
        
        coupon_rate = COUPON_r(j); coupon = par*coupon_rate;
        CFs = [coupon coupon coupon coupon + par];
        
        PV(i,j) = pvvar([0 CFs], ytm);
        [D, D_m] = cfdur(CFs, ytm); D_mod (i,j) = D_m;
        
    end
end
 
levels = [par,par];
[C,h] = contour(XX,YY, PV,levels,'ShowText','on','LineWidth',2);
 
figure(1)
 
mesh(XX,YY,PV)
xlabel('Coupon rate'); ylabel('Yield to maturity')
zlabel('Present value [USD]')
colorbar; hold on
PAR_height = par*ones(length(YTM), length(COUPON_r)); 
basemesh = mesh(XX, YY, PAR_height); hold on
set(basemesh, 'facecolor', 'none');
set(basemesh, 'edgecolor', 'k'); set(gca, 'box', 'on');
 
xxx = C(1,2:end); yyy = C(2,2:end); zzz = par*ones(1, length(yyy)); 
plot3(xxx,yyy,zzz,'LineWidth',2); view([-1, -1, 1])
 
figure(2)
contour(XX,YY,PV); hold on
xlabel('Coupon rate'); ylabel('Yield to maturity')
zlabel('Present value')
hold on colorbar;
levels = [par,par];
[C,h] = contour(XX,YY, PV,levels,'ShowText','on','LineWidth',2);
set(gcf,'color','white')
title('Present value [USD]')
 
figure(3)
 
mesh(XX,YY,D_mod); colorbar;
xlabel('Coupon rate'); ylabel('Yield to maturity')
zlabel('Modified duration')
hold on                
T_height = T_interest*ones(length(YTM), length(COUPON_r)); 
basemesh = mesh(XX, YY, T_height);
set(basemesh, 'facecolor', 'none');
set(basemesh, 'edgecolor', 'k'); set(gca, 'box', 'on');
view ([1,1,1])
 
figure(4)
contour(XX,YY,D_mod,'ShowText','on'); hold on
xlabel('Coupon rate'); ylabel('Yield to maturity')
title('Modified duration')
hold on colorbar;
set(gcf,'color','white')
