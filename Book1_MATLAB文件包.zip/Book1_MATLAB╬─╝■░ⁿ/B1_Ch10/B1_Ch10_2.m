% B1_Ch10_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Step 1: Download zero rates from FRED
%  Nodes: 1yr, 2yr, 3yr
%  Length: 2 actual years
%  Remove NaN from the data and calculate daily difference
%  Retrieve 250 data points
 
clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
startdate = '01/01/2015';
% beginning of date range for historical data
enddate = '11/18/2018'; % to be updated
% ending of date range for historical data
% please convert the following to a loop 
series = 'DGS2';
treasury_2_yr_data = fetch(c,series,startdate,enddate)
% display description of data structure
treasury_2_yr = treasury_2_yr_data.Data(:,2);
date_series = treasury_2_yr_data.Data(:,1);
 
series = 'DGS3';
treasury_3_yr_data = fetch(c,series,startdate,enddate)
treasury_3_yr = treasury_3_yr_data.Data(:,2);
 
series = 'DGS1';
treasury_1_yr_data = fetch(c,series,startdate,enddate)
treasury_1_yr = treasury_1_yr_data.Data(:,2);
 
treasury_rates = [treasury_1_yr, treasury_2_yr, treasury_3_yr];
 
treasury_rates_nan_removed = treasury_rates;
treasury_rates_nan_removed(any(isnan(treasury_rates),2),:) = [];
 
date_series_nan_removed = date_series;
date_series_nan_removed(any(isnan(treasury_rates),2)) = [];
%% Step 2: Bond Definition and Pricing
 
issue_date = '11/06/2015';
coupon_rate = 0.1; % 0, 0.01 (1%), 0.1 (10%)
mature_date = '11/06/2018';
coupon_per_yr = 2; % coupon frequency
 
date_index_start = find(datenum(date_series_nan_removed) == datenum(issue_date));
 
date_index_end = find(datenum(date_series_nan_removed) == datenum(mature_date));
 
for i = date_index_start:date_index_end-1
    
    analysis_date = date_series_nan_removed(i);
    CalWin = datenum(analysis_date);
    tenor_1yr = datestr(addtodate(CalWin, 1, 'year'));
    tenor_2yr = datestr(addtodate(CalWin, 2, 'year'));
    tenor_3yr = datestr(addtodate(CalWin, 3, 'year'));
    rates_tenors = [tenor_1yr; tenor_2yr; tenor_3yr];
    Rates = (treasury_rates_nan_removed(i,:)/100)';
    
    ZeroRateSpec = intenvset('Rates', Rates, 'StartDates',analysis_date,...
        'EndDates', rates_tenors, 'Compounding', 2);

    [clean_price, dirty_price, CFlowAmounts, CFlowDates] = bondbyzero(ZeroRateSpec,...
        coupon_rate, analysis_date, mature_date, coupon_per_yr);
    
    % Yield_series(i) = bndyield(clean_price, coupon_rate, analysis_date,...
    %         mature_date, coupon_per_yr, 1);
    
    CLEAN_PV (i) = clean_price;
    DIRTY_PV (i) = dirty_price;
    
end
 
index = 1;
figure(index)
index = index + 1;
plot(date_series_nan_removed(date_index_start:date_index_end-1), ...
    treasury_rates_nan_removed((date_index_start:date_index_end-1),1)); hold on
plot(date_series_nan_removed(date_index_start:date_index_end-1), ...
    treasury_rates_nan_removed((date_index_start:date_index_end-1),2)); hold on
plot(date_series_nan_removed(date_index_start:date_index_end-1), ...
    treasury_rates_nan_removed((date_index_start:date_index_end-1),3)); hold on
datetick('x','yyyy/mmm','keeplimits')
xlim([date_series_nan_removed(date_index_start),...
    date_series_nan_removed(date_index_end-1)])
xlabel('Time')
ylabel('Zero Rates [%]')
legend('1 year','2 year','3 year')
 
figure(index)
index = index + 1;
plot(date_series_nan_removed(date_index_start:date_index_end-1), ...
    DIRTY_PV(date_index_start:date_index_end-1));
 
datetick('x','yyyy/mmm','keeplimits')
xlim([date_series_nan_removed(date_index_start),...
    date_series_nan_removed(date_index_end-1)])
xlabel('Time')
ylabel('Dirty price [USD]')
 
figure(index)
index = index + 1;
 
plot(date_series_nan_removed(date_index_start:date_index_end-1), ...
    CLEAN_PV(date_index_start:date_index_end-1));
 
datetick('x','yyyy/mmm','keeplimits')
xlim([date_series_nan_removed(date_index_start),...
    date_series_nan_removed(date_index_end-1)])
xlabel('Time')
ylabel('Clean price [USD]')

