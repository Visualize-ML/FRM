% B1_Ch10_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Dirty/clean price versus YTM
 
Yield_series = [0:0.01:0.2]; 
CouponRate = 0.1; 
Settle = '18-Jan-2018'; 
Maturity = '18-Aug-2020'; 
Period = 2; 
Basis = 0; % day count convention
 
[Clean_Price, AccruedInt] = bndprice(Yield_series, ...
    CouponRate, Settle, Maturity, Period, Basis)
% covert yield to price
 
figure(1)
plot(Yield_series,Clean_Price,'o'); hold on
xlabel('Yield to maturity')
ylabel('Clean price [USD]')
 
dirty_price = Clean_Price + AccruedInt;
 
plot(Yield_series,dirty_price)
xlabel('Yield to maturity')
ylabel('Dirty price [USD]')
legend('Clean price','Dirty price')
 
%% Clean price to YTM
 
Clean_Price = [80:2:110]; 
CouponRate = 0.1; 
Settle = '18-Jan-2018'; 
Maturity = '18-Aug-2020'; 
Period = 2; 
Basis = 0; 
 
Yield = bndyield(Clean_Price, CouponRate, ...
    Settle, Maturity, Period, Basis)
% convert clean price to yield
 
% For SIA conventions, the Price and Yield are 
% related by the formula:
% Price + Accrued Interest = sum(Cash_Flow*(1+Yield/2)^(-Time))
 
figure(2)
plot(Yield, Clean_Price, 'o')
xlabel('Yield to maturity')
ylabel('Dirty price [USD]')
