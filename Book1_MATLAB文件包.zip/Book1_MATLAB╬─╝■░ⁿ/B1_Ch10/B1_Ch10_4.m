% B1_Ch10_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

Settle = datenum ('01-Jan-2020');
BondData = {'01-Jul-2020' 0.07000 99.95
            '01-Jan-2021' 0.07125 99.75
            '01-Jul-2021' 0.07250 99.32
            '01-Jan-2022' 0.07375 98.45
            '01-Jul-2022' 0.07500 97.71
            '01-Jan-2023' 0.08000 98.15};
 
tenors =datenum(strvcat(BondData{:,1}));
coupon_rates =[BondData{:,2}]';
bond_prices = [BondData{:,3}]';
Period = 2; 
% semi-annual coupon, compounding frequency = 2/yr
 
Zero_Rates = zbtprice([tenors coupon_rates], bond_prices, Settle);
 
Forward_Rates = zero2fwd (Zero_Rates, tenors, Settle);
 
% 'InputCompounding' � Compounding frequency of input zero rates
% 2 (default) | numeric values: 0,1, 2, 3, 4, 6, 12, 365, -1

Discount_Factors = zero2disc (Zero_Rates, tenors, Settle);
 
figure (1)
plot (tenors,Zero_Rates, 'o-', tenors,Forward_Rates,'x-')
xlabel ('Maturity (year)')
ylabel('Rate')
legend({'Zero rate curve','Forward rate curve'},'Location','northwest')
xlim([min(tenors) max(tenors)])
datetick x
set(gcf,'color','white')
 
figure (2)
plot (tenors,Discount_Factors, 'o-')
xlabel ('Maturity (year)')
ylabel('Discount factor')
xlim([min(tenors) max(tenors)])
datetick x
set(gcf,'color','white')
