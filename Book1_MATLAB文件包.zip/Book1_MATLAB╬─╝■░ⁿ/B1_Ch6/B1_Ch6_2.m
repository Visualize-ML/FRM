% B1_Ch6_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
n = 1:1:30;
 
sq_1 = 1./(2.^n); 
sum_sq_1 = cumsum(sq_1);
sq_2 = 1./(n.*(n+1));
sum_sq_2 = cumsum(sq_2);
sq_3 = 1./n;
sum_sq_3 = cumsum(sq_3);
sq_4 = (-1).^(n-1)./n;
sum_sq_4 = cumsum(sq_4);
% F = symsum(f,k,a,b) returns the sum of the series with
% terms that expression f specifies
 
figure(1)
subplot(2,2,1)
sq_plot(n,sum_sq_1)
 
subplot(2,2,2)
sq_plot(n,sum_sq_2)
 
subplot(2,2,3)
sq_plot(n,sum_sq_3)
 
subplot(2,2,4)
sq_plot(n,sum_sq_4)
 
function sq_plot(n,sum_sq)
plot(n,sum_sq,'-x');
xlabel('n'); ylabel('Sum of series')
set(gca, 'XAxisLocation', 'origin')
box off; grid off
xlim([min(n) max(n)])
end
