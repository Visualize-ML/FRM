% B1_Ch6_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
n = 1:1:40;
 
% convergent
sq_1 = 1./n;          % convergent
sq_2 = (1 + 1./n).^n; % convergent
sq_3 = (-1).^n./n;    % oscillating and convergent
sq_4 = sin(n).*exp(-n/10); % oscillating, convergent
 
figure(1)
subplot(2,2,1)
sq_plot(n,sq_1)
 
subplot(2,2,2)
sq_plot(n,sq_2)
 
subplot(2,2,3)
sq_plot(n,sq_3)
 
subplot(2,2,4)
sq_plot(n,sq_4)
 
sq_5 = (-1).^n;  % oscillating, bounded
sq_6 = (-1).^n.*(2*n.^2 + 1)./(n.^2 + n); % oscillating, bounded
sq_7 = (-1).^n.*(2*n.^2 + 1)./(n + 1); % oscillating, divergent
sq_8 = sin(n).*exp(n/10); % oscillating, exploding
 
figure(2)
subplot(2,2,1)
sq_plot(n,sq_5)
 
subplot(2,2,2)
sq_plot(n,sq_6)
 
subplot(2,2,3)
sq_plot(n,sq_7)
 
subplot(2,2,4)
sq_plot(n,sq_8)
 
function sq_plot(n,sq)
plot(n,sq,'-x');
xlabel('n'); ylabel('Sequence')
set(gca, 'XAxisLocation', 'origin')
box off; grid off
xlim([min(n) max(n)])
end
