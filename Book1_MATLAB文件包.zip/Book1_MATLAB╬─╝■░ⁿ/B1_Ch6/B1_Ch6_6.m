% B1_Ch6_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
fcn = @(x) x.*sin(x)/2 + 8;
% Original function
% Other candidates:
% fcn = @(x)-exp(-x).*sin(3*x)+ 3*exp(-x).*cos(3*x);
% fcn = @(x) sin(x).*x;
 
x_start = 2;
x_end = 10;
num_int_series = 10:10:1000;
 
for i = 1:length(num_int_series)
    
    num_int = num_int_series(i);
    
    x=linspace(x_start,x_end,num_int+1);
    
    F=fcn(x);
    h=x(2)-x(1);
    
    fcn_Forward=F(1:end-1);
    area_Forward(i)=sum(fcn_Forward.*h);
    
    fcn_Backward=F(2:end);
    area_Backward(i)=sum(fcn_Backward.*h);
    
    area_Central(i)=sum((fcn_Forward+fcn_Backward)/2.*h);
    
    area_analytical(i) = integral(fcn,x_start,x_end);
end
 
% Plot the original function and analytical integral
figure(1)
 
xx=linspace(x_start-2,x_end+2,101);
plot(xx,fcn(xx)); hold on
plot([x_start,x_start],[0,fcn(x_start)]); hold on
plot([x_end,x_end],[0,fcn(x_end)]); hold on
xxx = x_start:0.01:x_end;
curve1 = fcn(xxx);
curve2 = zeros(1,length(xxx));
x2 = [xxx, fliplr(xxx)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g');
xlabel('x')
ylabel('y')
box off
%% Numerical Approximations
 
num_show = 20; % to be updated, 5, 10, 20
xxxx = linspace(x_start,x_end,num_show+1);
F=fcn(xxxx);
h=xxxx(2)-xxxx(1);
fcn_Forward=F(1:end-1);
x_Forward = xxxx(1:end-1);
fcn_Backward=F(2:end);
x_Backward= xxxx(2:end);
 
 
% Forward
figure(2)
 
for i = 1:length(xxxx)-1
    
    curve1 = [fcn_Forward(i), fcn_Forward(i)];
    curve2 = [0, 0];
    
    x2 = [xxxx(i:i+1), fliplr(xxxx(i:i+1))];
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    
end
plot(xx,fcn(xx)); hold on
plot(x_Forward,fcn_Forward,'o');
xlabel('x')
ylabel('y')
box off
 
% Backward
figure(3)
 
for i = 1:length(xxxx)-1
    
    curve1 = [fcn_Backward(i), fcn_Backward(i)];
    curve2 = [0, 0];
    
    x2 = [xxxx(i:i+1), fliplr(xxxx(i:i+1))];
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    
end
plot(xx,fcn(xx)); hold on
plot(x_Backward,fcn_Backward,'o');
xlabel('x')
ylabel('y')
box off

% trapezoidal
figure(4)
 
for i = 1:length(xxxx)-1
    
    curve1 = [fcn_Forward(i), fcn_Backward(i)];
    curve2 = [0, 0];
    
    x2 = [xxxx(i:i+1), fliplr(xxxx(i:i+1))];
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    
end
plot(xx,fcn(xx));
plot(xxxx,F,'o');
 
xlabel('x')
ylabel('y')
box off

% study of convergence
figure(5)
plot(num_int_series,area_Forward); hold on
plot(num_int_series,area_Backward); hold on
plot(num_int_series,area_Central); hold on
 
xlabel('Number of bins')
ylabel('Approximation of integral')
legend('Forward','Backward','Central')
box off

% errors
figure(6)
plot(num_int_series,area_Forward - area_analytical); hold on
plot(num_int_series,area_Backward - area_analytical); hold on
plot(num_int_series,area_Central - area_analytical); hold on
 
xlabel('Number of bins')
ylabel('Error')
legend('Forward','Backward','Central')
set(gca, 'XAxisLocation', 'origin')
box off