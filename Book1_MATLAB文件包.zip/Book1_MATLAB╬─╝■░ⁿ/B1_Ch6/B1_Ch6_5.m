% B1_Ch6_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
fcn = @(x) exp(-x).*sin(3*x); 
% original function
d_fcn = @(x) -exp(-x).*sin(3*x)+ 3*exp(-x).*cos(3*x);
% analytical differential equation

x_start = -2; % starting point
x_end = 2;    % end point
x=linspace(x_start,x_end,21); 
% 20 steps
xx=linspace(x_start,x_end,101);
% 100 steps
F=fcn(x);

% approximated differential
h=x(2)-x(1);
 
x_Central=x(2:end-1);
df_Central=(F(3:end)-F(1:end-2))/(2*h);
 
x_Forward=x(2:end-1);
df_Forward=(F(3:end)-F(2:end-1))/h;
 
x_Backward=x(2:end-1);
df_FBackward=(F(2:end-1)-F(1:end-2))/h;
 
% calculate the errors
error_Central = df_Central - d_fcn(x_Central);
error_Forward = df_Forward - d_fcn(x_Central);
error_Backward = df_FBackward - d_fcn(x_Central);
 
% Plot the original function
figure(1)
title('Original function and first-order derivative')
subplot(2,1,1)
plot(xx,fcn(xx))
xlabel('x')
ylabel('f(x)')
set(gca, 'XAxisLocation', 'origin')
box off
 
subplot(2,1,2)
plot(xx,d_fcn(xx))
xlabel('x')
ylabel('f^/prime(x), df/dx')
set(gca, 'XAxisLocation', 'origin')
box off

% Plot the analytical and numerical differentials
figure(2)
plot(xx,d_fcn(xx)); hold on
plot(x_Central,df_Central,'o')
plot(x_Forward,df_Forward,'>');
plot(x_Backward,df_FBackward,'<');
legend('Analytic','Central','Forward','Backward')
xlabel('x')
ylabel('dy/dx and its approximations')
set(gca, 'XAxisLocation', 'origin')
title('Analytical and numerical first-order derivative')
box off

% Plot the errors
figure(3)
plot(x_Central,error_Central,'-o'); hold on
plot(x_Central,error_Forward,'->'); hold on
plot(x_Central,error_Backward,'-<'); hold on
legend('Central','Forward','Backward')
xlabel('x')
ylabel('Error')
set(gca, 'XAxisLocation', 'origin')
title('Errors')
box off