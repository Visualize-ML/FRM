% B1_Ch6_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Convex and concave functions
x = [0:0.05:2];
y1 = (x-1).^2; % convex
y2 = exp(x);   % convex
y3 = -(x-1).^2 + 2;  % concave
y4 = log(x);         % concave
 
figure(1)
subplot(2,2,1)
convex_plot(x,y1)
 
 
subplot(2,2,2)
convex_plot(x,y2)
 
 
subplot(2,2,3)
convex_plot(x,y3)
 
 
subplot(2,2,4)
convex_plot(x,y4)
 
function convex_plot(x,y)
 
plot(x,y,'LineWidth',2); hold on
xx = x(1:6:end);
yy = y(1:6:end);
plot(xx,yy,'x'); hold on
u = gradient(xx);
v = gradient(yy);
quiver(xx,yy,u,v);
xlabel('x'); ylabel('y'); zlabel('z')
end
