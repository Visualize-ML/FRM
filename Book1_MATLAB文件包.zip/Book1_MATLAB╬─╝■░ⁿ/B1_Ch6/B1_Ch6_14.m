% B1_Ch6_14.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
figure(1)
subplot(2,2,1)
delta_1 = 0.5; gamma_1 = 0.05;
delta_plot(delta_1,gamma_1)
 
subplot(2,2,2)
delta_2 = 0.5; gamma_2 = 0.2;
delta_plot(delta_2,gamma_2)
 
subplot(2,2,3)
delta_3 = -0.5; gamma_3 = -0.05;
delta_plot(delta_3,gamma_3)
 
subplot(2,2,4)
delta_4 = 0.5; gamma_4 = -0.2;
delta_plot(delta_4,gamma_4)
 
function delta_plot(delta,gamma)
delta_x = [-5:0.1:5];
delta_v_first = delta*delta_x;
delta_v_snd = delta*delta_x + 1/2*gamma*delta_x.*delta_x;
plot(delta_x,delta_v_first); hold on
plot(delta_x,delta_v_snd); hold on
plot(0,0,'ok')
xlabel('\Delta x');ylabel('\Delta V')
set(gca, 'XAxisLocation', 'origin')
title(['Delta = ',num2str(delta),'; Gamma = ',num2str(gamma)])
legend('First-order','Second-order','Location', 'Best')
box off; grid off
set(gca,'Xtick',-4:2:4); ylim([-5,5])
end

