% B1_Ch6_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Taylor expansion approximation
 
x = [0:0.01:5];
 
y = exp(x);
 
% please convert the following to a for loop
y_1 = x + 1;
y_2 = y_1 + x.^2./factorial(2);
y_3 = y_2 + x.^3./factorial(3);
y_4 = y_3 + x.^4./factorial(4);
y_5 = y_4 + x.^5./factorial(5);
y_6 = y_5 + x.^6./factorial(6);
 
my_col = brewermap(10,'Blues');
% brewermap can be downloaded from MATLAB community:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 45208-colorbrewer-attractive-and-distinctive-colormaps
 
figure(1)
 
plot(x,y_1,'color',my_col(4,:)); hold on
plot(x,y_2,'color',my_col(5,:)); hold on
plot(x,y_3,'color',my_col(6,:)); hold on
plot(x,y_4,'color',my_col(7,:)); hold on
plot(x,y_5,'color',my_col(9,:)); hold on
plot(x,y_6,'color',my_col(10,:)); hold on
plot(x,y,'k'); hold on
 
% ylim([-1.2, 1.2])
set(gca, 'XAxisLocation', 'origin')
xlabel('x'); ylabel('y, and its approximation')
legend('1st','2nd','3rd','4th','5th','6th','e^x')
