% B1_Ch6_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Taylor expansion approximation
 
x = [-2*pi:0.01:2*pi];
 
y = sin(x);
 
% please convert the following to a for loop

y_1 = x;
y_2 = y_1 - x.^3./factorial(3);
y_3 = y_2 + x.^5./factorial(5);
y_4 = y_3 - x.^7./factorial(7);
y_5 = y_4 + x.^9./factorial(9);
y_6 = y_5 - x.^11./factorial(11);
 
my_col = brewermap(10,'Blues');
% brewermap can be downloaded from MATLAB community:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 45208-colorbrewer-attractive-and-distinctive-colormaps
 
figure(1)
 
plot(x,y_1,'color',my_col(4,:)); hold on
plot(x,y_2,'color',my_col(5,:)); hold on
plot(x,y_3,'color',my_col(6,:)); hold on
plot(x,y_4,'color',my_col(7,:)); hold on
plot(x,y_5,'color',my_col(8,:)); hold on
plot(x,y_6,'color',my_col(9,:)); hold on
plot(x,y,'color',my_col(10,:)); hold on
 
set(gca,'Xtick',-2*pi:pi:2*pi)
xticklabels({'-2\pi','-\pi','0','\pi','-2\pi'})
xlim([-2.1*pi, 2.1*pi])
ylim([-1.2, 1.2])
set(gca, 'XAxisLocation', 'origin')
xlabel('x'); ylabel('y, and its approximation')
legend('1st','3rd','5th','7th','9th','11th','sin(x)')
box off