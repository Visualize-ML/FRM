% B1_Ch6_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% directional derivative
clc; close all; clear all
t = [0:0.2:4];
ts = [0.5,3.5];
[xx, yy] = meshgrid(t);
[xxs,yys] = meshgrid(ts);
 
x_p = 2; y_p = 2; 
% the x, y coordinates of the point
 
syms f(x,y)
f(x,y) = -(x-3)^2 - y^2 + x*y + 25;
% the function of the surface
 
f_xy = matlabFunction(f)
% convert it to a function
 
ff = feval(f_xy,xx,yy);
% Generate the data of the surface
 
f_p = feval(f_xy,x_p, y_p);
% the z coordinate of the point
% the_point = [x_p, y_p, f_p];
 
 
f_xy_x2 = matlabFunction(subs(f,[x,y],[x_p,y]))
ff_xy_x2 = feval(f_xy_x2,x_p*ones(length(t),1),t);
% repmat(x_p, num_row, num_col) is faster
% y = 2, parallel to x-z plane
 
f_xy_y2 = matlabFunction(subs(f,[x,y],[x,y_p]))
ff_xy_y2 = feval(f_xy_y2,t,y_p*ones(length(t),1));
% x = 2, parallel to y-z plane
 
% plot the surface
index = 1;
figure(index)
index = index + 1;
subplot(1,2,1)
meshc(xx,yy,ff); hold on     % the surface
stem3(x_p,y_p,f_p,'filled')  % Point P
xlabel('x'); ylabel('y'); zlabel('f')
 
subplot(1,2,2)
contour3(xx,yy,ff,[2:2:30]); hold on % the surface
stem3(x_p,y_p,f_p,'filled')
xlabel('x'); ylabel('y'); zlabel('f')
 
% plot the surface and the plane x = x_p
figure(index)
index = index + 1;
 
subplot(1,2,1)
mesh(xx,yy,ff); hold on
plot3(x_p,y_p,f_p,'ok'); hold on
 
xslice = [min(xx(:)) max(xx(:))];
yslice = [min(yy(:)) max(yy(:))];
zslice = [min(ff(:)) max(ff(:))];
 
[xxx,yyy,zzz] = meshgrid(xslice, yslice, zslice);
v=zeros(size(xxx)); 
 
x_checked = [x_p];
slice(xxx,yyy,zzz,v,x_checked,[],[]); hold on
% plot the plane, x = x_p
 
plot3(x_p*ones(length(t),1),t,ff_xy_x2,'k','LineWidth',3)
xlabel('x'); ylabel('y'); zlabel('f')
 
subplot(1,2,2)
mesh(xx,yy,ff); hold on
plot3(x_p,y_p,f_p,'ok'); hold on
 
y_checked = [y_p];
slice(xxx,yyy,zzz,v,[],y_checked,[]); hold on
plot3(t,y_p*ones(length(t),1),ff_xy_y2,'k','LineWidth',3)
xlabel('x'); ylabel('y'); zlabel('f')
 
df_x = matlabFunction(diff(f,x))
a_x = feval(df_x,x_p,y_p)
% a = subs(df_x,{x,y},{x_p, y_p})
z_tg_xp = a_x*(ts - x_p) + f_p;
 
figure(index)
index = index + 1;
 
subplot(1,2,1)
mesh(xx,yy,ff); hold on
plot3(x_p,y_p,f_p,'ok'); hold on
 
y_checked = [y_p];
 
slice(xxx,yyy,zzz,v,[],y_checked,[]); hold on
plot3(t,y_p*ones(length(t),1),ff_xy_y2,'k','LineWidth',2); hold on
plot3(ts,y_p*ones(length(ts),1),z_tg_xp,'r','LineWidth',2)
xlabel('x'); ylabel('y'); zlabel('f')
zl = zlim
 
subplot(1,2,2)
plot(t,ff_xy_y2,'k'); hold on
plot(ts,z_tg_xp,'r'); hold on
plot(y_p,f_p,'o')
xlabel('y'); ylabel('f')
ylim([zl])
 
 
df_y = matlabFunction(diff(f,y))
a_y = feval(df_y,x_p,y_p)
% a = subs(df_y,{x,y},{x_p, y_p})
z_tg_yp = a_y*(ts - y_p) + f_p;
 
figure(index)
index = index + 1;
 
subplot(1,2,1)
mesh(xx,yy,ff); hold on
plot3(x_p,y_p,f_p,'ok'); hold on
 
x_checked = [x_p];
 
slice(xxx,yyy,zzz,v,x_checked,[],[]); hold on
 
plot3(x_p*ones(length(t),1),t,ff_xy_x2,'k','LineWidth',3); hold on
plot3(x_p*ones(length(ts),1),ts,z_tg_yp,'r','LineWidth',2)
xlabel('x'); ylabel('y'); zlabel('f')
zl = zlim
 
subplot(1,2,2)
plot(t,ff_xy_x2,'k'); hold on
plot(ts,z_tg_yp,'r'); hold on
plot(x_p,f_p,'o')
xlabel('x'); ylabel('f')
ylim([zl])
 
% Plot surface + two curves and two tangents
 
figure(index)
index = index + 1;
 
mesh(xx,yy,ff); hold on
stem3(x_p,y_p,f_p,'filled'); hold on
 
plot3(x_p*ones(length(t),1),t,ff_xy_x2,'k','LineWidth',3); hold on
plot3(x_p*ones(length(ts),1),ts,z_tg_yp,'r','LineWidth',2); hold on
plot3(t,y_p*ones(length(t),1),ff_xy_y2,'k','LineWidth',2); hold on
plot3(ts,y_p*ones(length(ts),1),z_tg_xp,'r','LineWidth',2)
xlabel('x'); ylabel('y'); zlabel('f')
 
% Plot surface and tangent plane, and the point
 
figure(index)
index = index + 1;
 
% z_tg_yp = a_y*(ts - y_p) + f_p;
% z_tg_xp = a_x*(ts - x_p) + f_p;
z_tg_xyp = a_x*(xxs - x_p) + a_y*(yys - y_p) + f_p;
mesh(xx,yy,ff); hold on
surf(xxs,yys,z_tg_xyp); hold on
stem3(x_p,y_p,f_p,'filled'); hold on
xlabel('x'); ylabel('y'); zlabel('f')
% contours
 
figure(index)
index = index + 1;
subplot(1,2,1)
contour3(xx,yy,ff,20); hold on
contour3(xx,yy,ff,[f_p f_p],'LineWidth',2,'ShowText','on'); hold on
stem3(x_p,y_p,f_p,'filled'); hold on
plot3(x_p*ones(length(ts),1),ts,z_tg_yp,'r','LineWidth',1); hold on
plot3(ts,y_p*ones(length(ts),1),z_tg_xp,'r','LineWidth',1)
xlabel('x'); ylabel('y'); zlabel('f')
view(-135, 45); box off; grid off
 
subplot(1,2,2)
contour3(xx,yy,ff,[2:2:30]); hold on
contour3(xx,yy,ff,[f_p f_p],'LineWidth',2,'ShowText','on'); hold on
stem3(x_p,y_p,f_p,'filled'); hold on
plot3(x_p*ones(length(ts),1),ts,z_tg_yp,'r','LineWidth',1); hold on
plot3(ts,y_p*ones(length(ts),1),z_tg_xp,'r','LineWidth',1)
xlabel('x'); ylabel('y'); zlabel('f')
view(-45, 45); box off; grid off
 
figure(index)
index = index + 1;
contour(xx,yy,ff,20); hold on
contour(xx,yy,ff,[f_p f_p],'LineWidth',2,'ShowText','on'); hold on
plot3(x_p*ones(length(ts),1),ts,z_tg_yp,'r','LineWidth',1); hold on
plot3(ts,y_p*ones(length(ts),1),z_tg_xp,'r','LineWidth',1)
xlabel('x'); ylabel('y'); zlabel('f')
box off; grid off

