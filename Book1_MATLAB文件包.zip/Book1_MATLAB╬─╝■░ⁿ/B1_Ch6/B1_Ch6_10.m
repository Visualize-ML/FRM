% B1_Ch6_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
syms x
f1 = 1/(1+x);
ORDERs = 1:5;
xd = 2:0.01:6;
yd = subs(f1,x,xd);
x_a = 4; % expansion point
y_a = subs(f1,x,x_a);
my_col = brewermap(length(ORDERs)+3,'Blues');
 
figure(1)
txt = 'Original';
plot(xd, yd,'r','DisplayName',txt); hold on
txt = 'Expansion point';
plot(x_a,y_a,'ok','DisplayName',txt); hold on
 
for i = 1:length(ORDERs)
    
    order = ORDERs(i);
    txt = ['Order = ',num2str(order)];
    display(txt)
    t = taylor(f1, 'ExpansionPoint', x_a, 'Order', order)
    fplot(t, [min(xd), max(xd)], 'color',...
        my_col(i+3,:),'DisplayName',txt); hold on
    
end
 
set(gca, 'XAxisLocation', 'origin')
xlabel('x'); ylabel('y, and its approximation')
legend show; box off; grid off
