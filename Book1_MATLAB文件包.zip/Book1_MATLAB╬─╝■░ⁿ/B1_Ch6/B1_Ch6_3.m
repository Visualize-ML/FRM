% B1_Ch6_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
x_start = -4;
x_end = 3
x = linspace(x_start, x_end, 500);
y = x .^ 2 - 2;
% original function
 
figure(1)
% plot the curve of the original function
plot(x, y, 'b-', 'LineWidth', 2);
grid on; box off
 
xlabel('x'); ylabel('y');
Tangent_x = -1;
xx = linspace(-2.5+Tangent_x,2.5+Tangent_x,10);
slope = 2 * Tangent_x;
 
Tangent_y = Tangent_x .^ 2 - 2;
hold on;
plot(Tangent_x, Tangent_y, 'ro', 'LineWidth', 2,...
'MarkerSize', 6);
yTangentLine = slope * (xx - Tangent_x) + Tangent_y;
plot(xx, yTangentLine, 'k--');
grid off
ylim([-5,15]); xlim([x_start x_end])
 
figure(2)
% plot the curve of the original function
plot(x, y, 'b-', 'LineWidth', 2);
grid on;
 
xlabel('x'); ylabel('y');
 
Points_x = x_start+1:0.5:x_end-1;
 
for i = 1:length(Points_x)
    
    Tangent_x = Points_x(i);
    xx = linspace(-1.9+Tangent_x,1.9+Tangent_x,10);
    slope = 2 * Tangent_x;
    
    Tangent_y = Tangent_x .^ 2 - 2;
    hold on;
    plot(Tangent_x, Tangent_y, 'ro', 'LineWidth', ...
    2, 'MarkerSize', 6);
    yTangentLine = slope * (xx - Tangent_x) + Tangent_y;
    plot(xx, yTangentLine, 'k--'); hold on
end

grid off
ylim([-5,15]); xlim([x_start x_end])
box off