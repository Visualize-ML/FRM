% B1_Ch6_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
xx = [0:0.05:8];
 
syms x

functions = {expand((x-1)*(x-4)*(x-6));
    sin(x);
    exp(x/2);
    log(x+1);};

 
% expand(S) multiplies all parentheses in S,
% and simplifies inputs to functions such as
% cos(x + y) by applying standard identities.
 
for i = 1:length(functions)
    
    f_syms = cell2sym(functions(i));
    
    f = matlabFunction(f_syms)
    % g = matlabFunction(f) converts the
    % symbolic expression or function f to
    % a MATLAB function with handle g.
    
    figure(i)
    subplot(3,1,1)
    %     plot(xx,f(xx))
    ezplot(f_syms, xx)
    %     fplot() can also be used
    xlabel('x')
    ylabel('f(x)')
    set(gca, 'XAxisLocation', 'origin')
    
    df_dx_syms = diff(f_syms)
    df_dx = matlabFunction(df_dx_syms)
    box off;
    
    subplot(3,1,2)
    %     plot(xx,df_dx(xx))
    ezplot(df_dx_syms, xx)
    xlabel('x')
    ylabel('df/dx')
    set(gca, 'XAxisLocation', 'origin')
    box off;
    
    df2_dx2_syms = diff(f_syms,2)
    
    subplot(3,1,3)
    %     plot(xx,df2_dx2(xx))
    ezplot(df2_dx2_syms, xx)
    xlabel('x')
    ylabel('d^2f/dx^2')
    set(gca, 'XAxisLocation', 'origin')
    box off;
    
end
