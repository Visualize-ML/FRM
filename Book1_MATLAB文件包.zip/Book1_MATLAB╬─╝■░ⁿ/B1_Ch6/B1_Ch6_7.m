% B1_Ch6_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x
% syms var1 ... varN creates symbolic variables var1 ... varN. 
% Separate variables by spacesrule
original_fcn = 1/(x+1);
% Original function
xmin = 2;
xmax = 6;
x0 = 4; 
% [2,4] x0 = 3; [2,6] x0 = 4;
highest_order_series = 0:3;
order_length = length(highest_order_series);
x_range = xmin:0.01:xmax;
original_y = subs(original_fcn,x,x_range);
% subs(s,old,new) returns a copy of s,
% replacing all occurrences of old with new, 
% and then evaluates s
 
figure(1)
 
plot(x_range, original_y, 'k-', 'LineWidth',2); hold on
plot(x0,subs(original_fcn,x,x0),'o'); hold on
 
% fplot(f,xinterval) plots over the specified interval.
% Specify the interval as a two-element vector of 
% the form [xmin xmax]
hold on
 
for i = 1:order_length
    
    highest_order = highest_order_series(i);
    
    taylor_approxi = taylor(original_fcn, 'ExpansionPoint', ...
        x0, 'Order', highest_order+1)
    
    fplot(taylor_approxi, [xmin, xmax],'--'); hold on
    
end
 
title('Taylor approximation vs. actual function')
legend('Original function','x_0')
xlim ([xmin,xmax])
ylim ([0.1,0.3])
xlabel ('x')
ylabel ('Original/approximate')
set(gcf,'color','white')
box off
%% Plot errors
figure (2)
subplot(1,3,1)
y_1 = 9/25 - x_range/25;
plot (x_range,y_1,'--'); hold on
plot (x_range,original_y, 'k','LineWidth',2); hold on
plot(x0,subs(original_fcn,x,x0),'o'); hold on
fill([x_range,fliplr(x_range)],[double(original_y),...
fliplr(y_1)],'c')
xlabel('x')
ylabel ('Original/approximate')
xlim([xmin,xmax])
ylim([0.1, 0.35])
 
subplot(1,3,2)
y_2 = (x_range - 4).^2/125 - x_range/25 + 9/25; 
plot (x_range,y_2,'--'); hold on
plot (x_range,original_y, 'k','LineWidth',2); hold on
plot(x0,subs(original_fcn,x,x0),'o'); hold on
fill([x_range,fliplr(x_range)],[double(original_y),...
fliplr(y_2)],'c')
xlabel('x')
ylabel ('Original/approximate')
xlim([xmin,xmax])
ylim([0.1, 0.35])
 
subplot(1,3,3)
y_3 =- (x_range - 4).^3/625 + (x_range - 4).^2/125 - ...
x_range/25 + 9/25; 
plot (x_range,y_3,'--'); hold on
plot (x_range,original_y, 'k','LineWidth',2); hold on
plot(x0,subs(original_fcn,x,x0),'o'); hold on
fill([x_range,fliplr(x_range)],[double(original_y),...
fliplr(y_3)],'c')
xlabel('x')
ylabel ('Original/approximate')
xlim([xmin,xmax])
ylim([0.1, 0.35])
set(gcf,'color','white')
 
%% Plot absolute errors
figure (3)
subplot(1,3,1)
y_1 = 9/25 - x_range/25;
diff_1 = abs(original_y - y_1);
plot (x_range,diff_1)
fill([x_range,fliplr(x_range)],[zeros(1,length(x_range)),...
fliplr(diff_1)],'c')
xlabel('x')
ylabel('Abs error')
xlim([xmin,xmax])
ylim([0,0.05])
 
subplot(1,3,2)
y_2 = (x_range - 4).^2/125 - x_range/25 + 9/25; 
diff_2 = abs(original_y - y_2);
plot (x_range,diff_2)
fill([x_range,fliplr(x_range)],[zeros(1,length(x_range)),...
fliplr(diff_2)],'c')
xlabel('x')
ylabel('Abs error')
xlim([xmin,xmax])
ylim([0,0.05])
 
subplot(1,3,3)
y_3 =- (x_range - 4).^3/625 + (x_range - 4).^2/125 ...
- x_range/25 + 9/25; 
diff_3 = abs(original_y - y_3);
plot (x_range,diff_3)
fill([x_range,fliplr(x_range)],[zeros(1,length(x_range)),...
fliplr(diff_3)],'c')
xlabel('x')
ylabel('Abs error')
 
xlim([xmin,xmax])
ylim([0,0.05])
set(gcf,'color','white')
