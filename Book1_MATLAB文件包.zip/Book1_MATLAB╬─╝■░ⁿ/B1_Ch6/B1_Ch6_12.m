% B1_Ch6_12.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Convex and concave functions with norms
clc; close all; clear all
x = [0:0.02:2];
y1 = (x-1).^2;
y2 = -(x-1).^2 + 2;
y3 = exp(x);
y4 = log(x);
 
figure(1)
subplot(2,1,1)
convex_plot(x,y1)
daspect([1 1 1])
 
subplot(2,1,2)
convex_plot(x,y2)
daspect([1 1 1])
 
figure(2)
subplot(1,2,1)
convex_plot(x,y3)
daspect([1 1 1])
 
subplot(1,2,2)
convex_plot(x,y4)
daspect([1 1 1])
function convex_plot(x,y1)
 
 
plot(x,y1,'LineWidth',2); hold on
xx = x(1:5:end);
yy = y1(1:5:end);
plot(xx,yy,'x'); hold on
kk = [1, 2, 3]';
xxx = repmat(xx,3,1);
yyy = repmat(kk, 1,length(xx));
zzz = repmat(yy,3,1);
[U,V,W] = surfnorm(xxx,yyy,zzz);
quiver(xx,yy,U(1,:),W(1,:));
xlabel('x'); ylabel('y'); zlabel('z')
 
end
