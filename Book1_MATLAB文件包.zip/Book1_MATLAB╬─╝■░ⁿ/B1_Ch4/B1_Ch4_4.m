% B1_Ch4_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url); % fred requires Datafeed Toolbox
% fred returns a FRED connection to the FRED data server 
% using the default URL 'https://fred.stlouisfed.org/'.
series = 'FEDFUNDS';
startdate = '01/01/1954'; 
% beginning of date range for historical data
enddate = '11/18/2018'; % to be updated
% ending of date range for historical data
 
d = fetch(c,series,startdate,enddate)
% display description of data structure
 
%% Plot
FEDFUNDS = d.Data(:,2);
date_series = d.Data(:,1);
 
figure(1)
plot(date_series, FEDFUNDS)
datetick('x','yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([0,max(FEDFUNDS)*1.1])
xlabel('Year')
ylabel('Effective Federal Funds Rate [%]')
set(gcf,'color','white')
