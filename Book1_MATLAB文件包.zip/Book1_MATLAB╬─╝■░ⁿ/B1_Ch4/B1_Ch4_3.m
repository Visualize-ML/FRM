% B1_Ch4_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

y = 0.05;
% y: rate of return (simple compounding), annualized IR
% A simple compounding interest rate is discretely compounded
% whenever it is calculated and added to the principal
% at specific intervals (such as annually, monthly or weekly)
 
r = y;
% r: continuous compounding rate
% Continuous compounding uses a natural log-based formula
% to calculate and add back accrued interest
% at the smallest possible intervals.
 
m = [1, 2, 4, 12, 52, 365];
% m: number of periods based on compounding frequency
% eg. annual compounding has a compounding frequency of 1
% eg. monthly compounding has a compounding frequency of 12
 
T = 5;
% T: number of years
FV = 300;
% FV: future value of the cash flow
 
% Calculation of present value using simple compounding
PV = FV.*(1 + y./m).^(-T.*m);
% PV = FV*(1 + y/m).^(-T*m);
 
% Calculation of present value using continuous compounding
PV_cont = FV*exp(-r*T);
 
figure(1)
PV = [PV, PV_cont];
bar(PV, 0.5)
c = {'m = 1','m = 2','m = 4','m = 12','m = 52','m = 365', ' e^{-rT}'};
set(gca,'xticklabel',c)
ylim ([220, 236])
ylabel ('Present value [USD]')
xlabel ('Cases')
set(gcf,'color','w');
