% B1_Ch9_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
pd = makedist('Normal')
 
x = icdf(pd,[.025,.975]) % CI: two-sided, 0.95
p = normspec(x,0,1,'outside')
 
x = icdf(pd,[.05,.95])   % CI: two-sided, 0.90
p = normspec(x,0,1,'inside')
 
x = icdf(pd,[0,.95])     % CI: right-tailed, 0.95
p = normspec(x,0,1,'outside')
 
x = icdf(pd,[0.05,1])    % CI: left-tailed, 0.95
p = normspec(x,0,1,'inside')

