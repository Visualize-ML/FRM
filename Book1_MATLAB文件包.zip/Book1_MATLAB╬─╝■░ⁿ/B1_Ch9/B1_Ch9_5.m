% B1_Ch9_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% distribution with two peaks
%  central limit theorem
clc; close all; clear all
 
num_peak_1 = 20000;
num_peak_2 = 80000;
X_1 = -2 + randn(1,num_peak_1);
X_2 = 2 + randn(1,num_peak_2);
 
nbins = 40;
X = [X_1, X_2];
% The population, 0.1 million data points
true_mean = mean(X);
 
figure(1)
histfit(X,nbins,'kernel')
xlabel('x'); ylabel('Frequency')
 
%% Resample from the population
 
% y = randsample(population,k) returns a vector of
% k values sampled uniformly at random, without replacement,
% from the values in the vector population.
 
num_draws   = 1000;  % number of draws performed
num_samples = 100;   % number of samples in each draw
alpha = 0.05;        % 95% two-sided
alpha_up = 1 - alpha/2;
alpha_low = alpha/2;
upp = tinv(alpha_up, num_samples - 1);
low = tinv(alpha_low, num_samples - 1);
 
MEANS = []; CI_UPPs = []; CI_LOWs = [];
P_5s  = [];
P_95s = [];
SAMPLEs = [];
 
for i = 1:num_draws
    
    samples_each_draw = randsample(X,num_samples);
    SAMPLEs = [SAMPLEs; samples_each_draw];
    sample_mean = mean(samples_each_draw);
    % compute the standard error of the mean
    % pretend population mean and std are unknown
    % use t table
    
    ySEM = std(samples_each_draw)/sqrt(num_samples);
    MEANS = [MEANS, sample_mean];
    % compute bounaries of confidence intervals, CIs
    CI_upp = sample_mean + upp*ySEM;
    CI_low = sample_mean + low*ySEM;
    CI_UPPs = [CI_UPPs; CI_upp];
    CI_LOWs = [CI_LOWs; CI_low];
    
    Percentiles = prctile(samples_each_draw, [5, 95]);
    
    p_5_each_draw  = Percentiles(1);
    p_95_each_draw = Percentiles(2);
    P_5s  = [P_5s, p_5_each_draw];
    P_95s = [P_95s, p_95_each_draw];
    
end
 
%% explain central limit theorem
 
figure(2)
nbins = 10;
histfit(MEANS,nbins)
% [N,edges] = histcounts(X,nbins);
% % [N,edges] = histcounts(X,nbins) uses a number of bins
% % specified by the scalar, nbins.
xlabel('Mean of samples'); ylabel('Frequency')
line1 = ['Number of draws: ', num2str(num_draws)];
line2 = ['Number of samples in each draw: ', num2str(num_samples)];
title({line1; line2})
 
%% Plot only 4 random distributions of samples
 
figure(3)
 
selected_4_draws = randsample(1:num_draws,4);
selected_samples = SAMPLEs(selected_4_draws,:);
x_min = min(selected_samples(:));
x_max = max(selected_samples(:));
 
for i = 1:4
    
    subplot(2,2,i)
    index = selected_4_draws(i);
    random_samples = SAMPLEs(index,:);
    random_mean = mean(random_samples);
    histfit(random_samples,nbins,'kernel'); hold on
    xlim([x_min-1,x_max+1])
    line1= ['Draw index: ', num2str(index)];
    line2 = ['Sample mean: ', num2str(random_mean)];
    title({line1; line2})
    y1=get(gca,'ylim')
    plot([random_mean random_mean],y1)
    txt1 = 'Sample mean \rightarrow';
    text(random_mean-0.05,y1(2)*0.8,txt1,...
        'HorizontalAlignment', 'right')
    
end
 
 
%% visualize confidence levels
% plot only ~30 confidence levels, evenly spaced
x_cases = 1:length(MEANS);
 
indices_selected = 2:round(length(MEANS)/30):length(MEANS);
 
figure(4)
plot([1,length(MEANS)],ones(2,1)*true_mean); hold on
 
for ii = 1:length(indices_selected)
    
    xx = x_cases(indices_selected(ii));
    plot([xx, xx],[CI_LOWs(indices_selected(ii)),...
        CI_UPPs(indices_selected(ii))],'r','LineWidth',2); 
        hold on
    plot(xx,MEANS(indices_selected(ii)),'xk'); hold on
    plot(xx,CI_UPPs(indices_selected(ii)),'vk'); hold on
    plot(xx,CI_LOWs(indices_selected(ii)),'^k'); hold on
    legend('Population mean','95% two-sided',...
        'Sample mean','Upper 97.5%','Lower 2.5%')
    
end
 
xlabel('Draw index'); ylabel('95% two-sided CI')
ylim([0, 2.5])
