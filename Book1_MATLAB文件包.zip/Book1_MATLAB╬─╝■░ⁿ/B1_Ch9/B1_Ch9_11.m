% B1_Ch9_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

X = [10.0  8.04  10.0  9.14  10.0  7.46  8.0  6.58
8.0  6.95  8.0  8.14  8.0  6.77  8.0  5.76
13.0  7.58  13.0  8.74  13.0  12.74   8.0  7.71
9.0  8.81  9.0  8.77  9.0  7.11  8.0  8.84
11.0  8.33  11.0  9.26  11.0  7.81  8.0  8.47
14.0  9.96  14.0  8.10  14.0  8.84  8.0  7.04
6.0  7.24  6.0  6.13  6.0 6.08  8.0  5.25
4.0  4.26  4.0  3.10  4.0 5.39  19.0  12.50
12.0  10.84   12.0  9.13  12.0  8.15  8.0  5.56
7.0   4.82  7.0 7.26  7.0  6.42  8.0  7.91
5.0  5.68  5.0 4.74  5.0  5.73  8.0  6.89];
 
 
figure(1)
subplot(2,2,1)
plot(X(:,1),X(:,2),'o')
hold on
F1 = [ones(size(X(:,1))),X(:,1)];
b1 = regress(X(:,2),F1);
x_fine = [0:0.1:20];
y_regressed1 = b1(1) + b1(2)*x_fine;
plot(x_fine,y_regressed1)
xlim([0,20])
ylim([0,15])
xlabel ('x'); ylabel('y')
 
subplot(2,2,2)
plot(X(:,3),X(:,4),'o')
hold on
F1 = [ones(size(X(:,1))),X(:,3)];
b1 = regress(X(:,4),F1);
x_fine = [0:0.1:20];
y_regressed1 = b1(1) + b1(2)*x_fine;
plot(x_fine,y_regressed1)
xlim([0,20])
ylim([0,15])
xlabel ('x'); ylabel('y')
 
subplot(2,2,3)
plot(X(:,5),X(:,6),'o')
hold on
F1 = [ones(size(X(:,1))),X(:,5)];
b1 = regress(X(:,6),F1);
x_fine = [0:0.1:20];
y_regressed1 = b1(1) + b1(2)*x_fine;
xlim([0,20])
ylim([0,15])
plot(x_fine,y_regressed1)
xlabel ('x'); ylabel('y')
 
subplot(2,2,4)
plot(X(:,7),X(:,8),'o')
hold on
F1 = [ones(size(X(:,1))),X(:,7)];
b1 = regress(X(:,8),F1);
x_fine = [0:0.1:20];
y_regressed1 = b1(1) + b1(2)*x_fine;
xlim([0,20])
ylim([0,15])
plot(x_fine,y_regressed1)
xlabel ('x'); ylabel('y')
