% B1_Ch9_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Two sided confidence interval, known std
% significance level, alpha
 
clc; clear all; close all
x = [-5:0.01:5]; mu = 0; sigma = 1;
CI = 0.95; % confidence level
alpha = (1 - CI); % significance level
dfs = [2, 4, 6, 10];
 
% One-sided (left-tailed test) confidence interval, known std
 
figure(1)
 
for i = 1:length(dfs)
    
    subplot(2,2,i)
    
    % pdf of standard normal distribution
    Z_left = norminv(alpha)
    N_pdf = normpdf(x,mu,sigma);
    plot(x,N_pdf,'b');  hold on
    xx = [Z_left:(5 - Z_left)/100:5];
    NN_pdf = normpdf(xx,mu,sigma);
    x2 = [xx, fliplr(xx)];
    curve1 = zeros(1,length(xx)); curve2 = NN_pdf;
    inBetween = [curve1, fliplr(curve2)];
    h = fill(x2, inBetween, 'b'); hold on
    set(h,'facealpha',.25)
    
    nu = dfs(i);
    T_left = tinv(alpha,nu);
    
    T_pdf = tpdf(x,nu);
    plot(x,T_pdf,'r');  hold on
    xx = [T_left:(5 - T_left)/100:5];
    TT_pdf = tpdf(xx,nu);
    x2 = [xx, fliplr(xx)];
    curve1 = zeros(1,length(xx)); curve2 = TT_pdf;
    inBetween = [curve1, fliplr(curve2)];
    h = fill(x2, inBetween, 'r'); hold on
    set(h,'facealpha',.25)
    
    plot([0, 0], [0, 0.5]); ylim([0, 0.5])
    xlabel('Critical value'); ylabel('PDF')
    line1 = ['N: ', num2str(Z_left),'; \alpha = ',num2str(alpha)];
    line2 = ['T: ', num2str(T_left),...
        '; df = ', num2str(nu)];
 
    title({line1;line2})
    xticks([-5 T_left 0 5])
    xticklabels({'-5',num2str(round(T_left, 3)),'0', '5'})
    
end

