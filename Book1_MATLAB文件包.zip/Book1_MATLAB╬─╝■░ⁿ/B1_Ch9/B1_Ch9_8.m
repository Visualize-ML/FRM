% B1_Ch9_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
x = linspace (0,2,10);
x = x';
y = sin(x);
 
% linear regression
F1 = [ones(size(x)),x];

b1 = regress(y,F1);
 
x_fine = [0:0.01:2];
y_regressed1 = b1(1) + b1(2)*x_fine;
 
figure(1)
subplot(1,2,1)
plot(x,y,'o'); hold on 
plot(x_fine,y_regressed1)
xlabel('x')
ylabel('y')
 
% probola
 
F2 = [ones(size(x)),x, x.^2];

b2 = regress(y,F2);
 
y_regressed2 = b2(1) + b2(2)*x_fine + b2(3)*x_fine.^2;
 
subplot(1,2,2)
plot(x,y,'o'); hold on 
plot(x_fine,y_regressed2)
xlabel('x')
ylabel('y')
