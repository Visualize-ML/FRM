% B1_Ch9_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
% two regressors
 
N = 100;
x1 = 2*rand (N,1);
x2 = 3*rand (N,1);
y = 2 + 2*x1 - 1.5*x2 + 0.1*x1.^2 + ...
    0.2*x2.^2 + 0.5*randn(N,1);
 
% Linear surface
 
F = [ones(size(x1)), x1, x2];
 
p = regress (y, F)
[x1_grid, x2_grid] = meshgrid([0:0.1:2],[0:0.2:3]);
y_grid = p(1) + p(2)*x1_grid + p(3)*x2_grid;
 
 
figure(1)
plot3 (x1 , x2 , y , 'ok')
hold on
mesh(x1_grid, x2_grid, y_grid)
xlabel('x_{1}');
ylabel('x_{2}');
zlabel('y');
grid on
 
% Quadratic surface
 
F = [ones(size(x1)), x1, x2, x1.^2, x2.^2];
 
p = regress (y, F)
 
y_grid = p(1) + p(2)*x1_grid + p(3)*x2_grid + ...
    p(4)*x1_grid.^2 + p(5)*x2_grid.^2;
 
figure(2)
plot3 (x1 , x2 , y , 'ok')
hold on
mesh(x1_grid, x2_grid, y_grid)
xlabel('x_{1}');
ylabel('x_{2}');
zlabel('y');
grid on
