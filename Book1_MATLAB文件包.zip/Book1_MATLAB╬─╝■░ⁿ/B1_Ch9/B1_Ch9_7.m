% B1_Ch9_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% Extract data of exam grades
load examgrades
x = grades(:,1);
 
% Two-tail Chai-squared test
variance=20;
[h7, p7, ci7, stats7]=vartest(x, variance, ...
   'Tail','Both','Alpha',0.01)
 
% Right-tail Chai-squared test
variance=25;
[h8, p8, ci8, stats8]=vartest(x, variance, ...
   'Tail','Right','Alpha',0.01)
 
% Left-tail Chai-squared test
variance=15;
[h9, p9, ci9, stats9]=vartest(x, variance, ...
   'Tail','Left','Alpha',0.01)
