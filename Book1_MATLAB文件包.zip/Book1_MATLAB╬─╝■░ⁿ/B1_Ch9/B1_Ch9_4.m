% B1_Ch9_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
NUMs_toss = [500:2000:40000];
% NUMs_toss = [50:100:1500];
% Number of tosses in each trial increases
 
MEANS = []; CI_UPPs = []; CI_LOWs = [];
 
figure(1)
 
for i = 1:length(NUMs_toss)
    
    num_toss = NUMs_toss(i);
    alpha = 0.05;        % 95% two-sided
    alpha_up = 1 - alpha/2;
    alpha_low = alpha/2;
    upp = tinv(alpha_up, num_toss - 1);
    low = tinv(alpha_low, num_toss - 1);
    
    face_1_to_6 = randi([1,6],num_toss,1);
    average_faces = mean(face_1_to_6);
    ySEM = std(face_1_to_6)/sqrt(num_toss);
    % compute bounaries of confidence intervals, CIs
    CI_upp = average_faces + upp*ySEM;
    CI_low = average_faces + low*ySEM;
    
    MEANS = [MEANS, average_faces];
    CI_UPPs = [CI_UPPs; CI_upp];
    CI_LOWs = [CI_LOWs; CI_low];
    
    
    plot([num_toss,num_toss],[CI_low,CI_upp],'r','LineWidth',2);
    hold on
    plot(num_toss,average_faces,'xk'); hold on
    plot(num_toss,CI_upp,'vk'); hold on
    plot(num_toss,CI_low,'^k'); hold on
    legend('95% two-sided','Sample mean',...
        'Upper 97.5%','Lower 2.5%')
    
end
 
% plot(NUMs_toss,MEANS,'k'); hold on
xlabel('Number of tosses for each trial')
ylim_up = (round(max(CI_UPPs(:))/0.25) + 1)*0.25;
ylim_down = (round(min(CI_LOWs(:))/0.25) - 1)*0.25;
ylabel('Average value');ylim([ylim_down ylim_up])
