% B1_Ch9_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% Extract data of exam grades
load examgrades
x = grades(:,1);
 
% Plot data
figure
histogram(x)
ylabel('Frequency')
xlabel('Grades')
 
% Two-tail z test
miu0=76;
sigma=9;
 
[h1,p1,ci1,zval1]=ztest(x,miu0,sigma)
