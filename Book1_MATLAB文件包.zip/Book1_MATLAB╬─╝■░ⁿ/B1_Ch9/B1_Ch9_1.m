% B1_Ch9_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Two sided confidence interval, known std
% significance level, alpha
 
clc; clear all; close all
x = [-5:0.01:5];
mu = 0; sigma = 1;
 
CIs = [0.8, 0.9, 0.95, 0.99]; % confidence levels
ALPHAs = (1 - CIs); % significance levels
figure(1)
for i = 1:length(ALPHAs)
    
    subplot(2,2,i)
    alpha = ALPHAs(i);
    Zs = norminv([alpha/2 1-alpha/2])
    Z_left = Zs(1);
    Z_right = Zs(2);
    y = normpdf(x,mu,sigma);
    plot(x,y,'k');  hold on
    xx = [Z_left:(Z_right - Z_left)/100:Z_right];
    yy = normpdf(xx,mu,sigma);
    x2 = [xx, fliplr(xx)];
    curve1 = zeros(1,length(xx));curve2 = yy;
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    xlabel('Critical value'); ylabel('PDF')
    line1 = ['Central area, 1-\alpha: ', num2str(1-alpha)];
    line2 = ['Tail area,\alpha/2: ', num2str(alpha/2)];
    text(0,0.2,['CI: ', num2str((1-alpha)*100),'%'],...
        'FontSize',10, 'HorizontalAlignment','center')
    title({line1;line2}); xticks([-5 Z_left 0 Z_right 5])
    xticklabels({'-5',num2str(round(Z_left, 3)),...
        '0',num2str(round(Z_right, 3)),'5'})
    plot([0, 0], [0, 0.5])
    ylim([0, 0.5])
end
 
 
%% One-sided (right-tailed test) confidence interval, known std
 
figure(2)
for i = 1:length(ALPHAs)
    
    subplot(2,2,i)
    alpha = ALPHAs(i);
    Z_right = norminv([1-alpha])
    y = normpdf(x,mu,sigma);
    plot(x,y,'k');  hold on
    xx = [-5:(Z_right + 5)/100:Z_right];
    yy = normpdf(xx,mu,sigma);
    x2 = [xx, fliplr(xx)];
    curve1 = zeros(1,length(xx)); curve2 = yy;
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    plot([0, 0], [0, 0.5]); ylim([0, 0.5])
    xlabel('Critical value'); ylabel('PDF')
    text(0,0.2,['CI: ', num2str((1-alpha)*100),'%'],...
        'FontSize',10, 'HorizontalAlignment','center')
    line1 = ['Left area, 1-\alpha: ', num2str(1-alpha)];
    line2 = ['Right tail area, \alpha: ', num2str(alpha)];
    title({line1;line2})
    xticks([-5 0 Z_right 5])
    xticklabels({'-5', '0',num2str(round(Z_right, 3)),'5'})
    
end
 
%% One-sided (left-tailed test) confidence interval, known std
 
figure(3)
for i = 1:length(ALPHAs)
    
    subplot(2,2,i)
    alpha = ALPHAs(i);
    Z_left = norminv([alpha])
    y = normpdf(x,mu,sigma); plot(x,y,'k');  hold on
    xx = [Z_left:(5 - Z_left)/100:5];
    yy = normpdf(xx,mu,sigma); x2 = [xx, fliplr(xx)];
    curve1 = zeros(1,length(xx)); curve2 = yy;
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    plot([0, 0], [0, 0.5]); ylim([0, 0.5])
    xlabel('Critical value'); ylabel('PDF')
    text(0,0.2,['CI: ', num2str((1-alpha)*100),'%'],...
        'FontSize',10,'HorizontalAlignment','center')
    line1 = ['Right area, 1-\alpha: ', num2str(1-alpha)];
    line2 = ['Left tail area, \alpha: ', num2str(alpha)];
    title({line1;line2})
    xticks([-5 Z_left 0 5])
    xticklabels({'-5',num2str(round(Z_left, 3)),'0', '5'})
    
end
