% B1_Ch9_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all;
num_rand = 50;
x = [1:10:10*num_rand];
y = sin(x/50)./x + 0.005 * rand(1,num_rand);
 
figure(1)
subplot(1,2,1)
plot(x,y,'.')
 
p = polyfit(x,y,5);
hold on
plot(x,polyval(p,x),'k')
xlabel('x'); ylabel('y')
ylim([min(y)*1.5,max(y)*1.2])
y1=get(gca,'ylim')
xlim([1,max(x)])
 
subplot(1,2,2)
[p,s] = polyfit(x,y,5);

% p = polyfit(x,y,n) returns the coefficients for 
% a polynomial p(x) of degree n that is a best fit 
% (in a least-squares sense) for the data in y. 
% The coefficients in p are in descending powers, 
% and the length of p is n+1

[y_fit, delta] = polyval(p,x,s);
% delta is an estimate of the standard deviation of the error 
% in predicting a future observation at x by p(x)
% range of 4 deltas with center at mu
% correspond roughtly to the 95% confidence level
 
curve1 = y_fit + 2*delta;
curve2 = y_fit - 2*delta;
x2 = [x, fliplr(x)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g'); hold on
plot(x,y,'.'); hold on
plot(x,y_fit,'k'); hold on
plot(x,y_fit + 2*delta,'b'); hold on
plot(x,y_fit - 2*delta,'b'); hold on
xlabel('x'); ylabel('y')
ylim([y1]); xlim([1,max(x)])
