% B1_Ch2_16.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% change the plot appearance
 
% axis on or axis off [default � on]
% box on or box off [default � on]
% grid on or grid off [default � off
x = [0:0.01:2*pi];
linear_y = x;
sq_y = x.^2;
sin_y = sin(x);
cos_y = cos(x);
 
figure(1)
subplot(2,2,1)
plot(x,linear_y)
grid on
 
subplot(2,2,2)
plot(x,sq_y)
axis off
 
subplot(2,2,3)
plot(x,sin_y)
box off
set(gca, 'XAxisLocation', 'origin')
 
subplot(2,2,4)
plot(x,cos_y)
set(gcf,'color','white')
set(gca, 'XAxisLocation', 'top')
