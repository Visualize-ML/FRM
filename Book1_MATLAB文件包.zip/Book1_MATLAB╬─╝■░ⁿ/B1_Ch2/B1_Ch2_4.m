% B1_Ch2_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = 0:pi/20:2*pi;
plot(x,sin(x),'-.r*')
hold on
plot(x,sin(x-pi/2),'--mo')
 
plot(x,sin(x-pi),':bs')
hold off
