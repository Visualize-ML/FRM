% B1_Ch2_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = 1:10;
y = x + randn(1,10);
figure(1)
scatter(x,y,25,'b','o')
% Superimpose a least-squares line on the scatter plot
refline
mu = mean(y);
% Add a horizontal reference line at the mean of the scatter plot
hline = refline([0 mu]);
hline.Color = 'r';
xlabel('x'); ylabel('y')
