% B1_Ch2_17.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = linspace(-pi,pi);
y_cos = cos(x); plot(x,y_cos);
% Original function
y_poly = 1 - x.^2./2 + x.^4./24;
% Taylor series approximation
 
figure(1)
subplot(2,2,1); % Top left
plot(x,y_cos,'b');
xlim([min(x),max(x)]) % scale x label from min to max
xlabel('x'); ylabel('y')
 
subplot(2,2,3); % Bottom left
plot(x,y_poly,'r');
xlim([min(x),max(x)])
xlabel('x'); ylabel('y')
 
subplot(2,2,[2,4]); % Half right
plot(x,y_cos,'b',x,y_poly,'r');
xlim([min(x),max(x)])
xlabel('x'); ylabel('y')
