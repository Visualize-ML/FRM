% B1_Ch2_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Add legend
 
y1 = rand(3);
 
figure(1)
ax1 = subplot(2,1,1); 
plot(y1,'o--')
 
y2 = rand(5);
ax2 = subplot(2,1,2); 
plot(y2,'x:')
 
legend(ax1,{'Line 1','Line 2','Line 3'})
% add legend to the first subplot only
% can be used for 2018a only
 
legend(ax2, {'Line 1','Line 2','Line 3', 'Line 4'}, ... 
'Location', 'northwest', 'NumColumns',2)
% add legend to the second subplot only
