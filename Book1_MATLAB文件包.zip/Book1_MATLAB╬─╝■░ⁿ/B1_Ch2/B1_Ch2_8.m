% B1_Ch2_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% draw straight line
 
figure(1)
subplot(2,2,1)
plot([0, 10], [2, 2]) % ([x1, x2], [y1, y2])
% 'linewidth',3
 
subplot(2,2,2)
plot([2, 2], [0, 2])
 
subplot(2,2,3)
plot([0, 10], [0, 2])
 
subplot(2,2,4)
plot([10, 2], [0, 2])
