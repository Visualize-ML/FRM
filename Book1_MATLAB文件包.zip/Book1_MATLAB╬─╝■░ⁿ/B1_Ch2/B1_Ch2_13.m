% B1_Ch2_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% display texts
 
% text(x,y,txt) adds a text description to one or more data 
% points in the current axes using the text specified by txt. 
% To add text to one point, specify x and y as scalars in data 
% units. To add text to multiple points, specify x and y 
% as vectors with equal length
 
x = linspace(0, 4, 100);
figure(1)
plot(x, x, 'k--', x, (x-2).^2, 'k', [1, 1], [0, 4], 'k--')
xlabel ('x')
ylabel ('Value of functions')
title ('Visualization of two intersecting curves')
text (1.1, 2, '\leftarrow x = 1')
text (2, 0.4, '\downarrow y = (x-2)^2')
text (3, 3.4, 'y = x \rightarrow')
legend('x', '(x-2)^2', 'Location', 'SouthWest')
