% B1_Ch2_31.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

theta = linspace(0,720,100);
rho = 0.005*theta/10;
 
figure(1)
theta_radians = deg2rad(theta);
polarplot(theta_radians,rho)
