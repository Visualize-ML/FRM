% B1_Ch2_22.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

X = linspace(0,2*pi,20)';
Y = [cos(X), 0.5*sin(X)];
 
figure(1)
subplot(2,1,1)
stem(X,Y)
xlim([0,2*pi])
 
subplot(2,1,2)
stem(X,Y,'--','filled')
xlim([0,2*pi])
