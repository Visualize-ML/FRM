% B1_Ch2_28.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

matrix_data = randi(10,5);
 
figure(1)
subplot(1,2,1)
heatmap(matrix_data);

 
subplot(1,2,2)
imagesc(matrix_data);
colorbar

