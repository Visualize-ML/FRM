% B1_Ch2_26.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = linspace(0,10);
y1 = 4 + sin(x).*exp(0.1*x);
y2 = 4 + cos(x).*exp(0.1*x);
% Create semitransparent area plots
figure(1)
plot(x,y1,'b','LineWidth',1.5); hold all
plot(x,y2,'r','LineWidth',1.5); 
area(x,y1,'FaceColor','b','FaceAlpha',.3,'EdgeAlpha',0)
area(x,y2,'FaceColor','r','FaceAlpha',.3,'EdgeAlpha',0)
hold off
xlabel('x'); ylabel('y'); box off
