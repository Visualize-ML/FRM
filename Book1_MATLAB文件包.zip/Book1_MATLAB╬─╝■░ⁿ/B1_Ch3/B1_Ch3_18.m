% B1_Ch3_18.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

t = linspace(0,2*pi,1000); 
x = cos(t); 
perturbation = 0.1*exp((-(t-3*pi/2).^2)/.01).*sin(200*t); 
signal = x+perturbation; 
 
figure(1)
plot(t,x+perturbation)
xlabel('Time');
ylabel('Signal');
 
% create a zoomed-in inside
axes('position',[.35 .5 .3 .3])
box on 
% put box around new pair of axes
 
zoomIn = (t < 4.9) & (t > 4.5); 
% range of t near perturbation
 
plot(t(zoomIn),signal(zoomIn)) 
% plot on new axes
axis tight % sets the axis limits to the range of the data
