% B1_Ch3_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
x = [-10:0.1:10]; y = x;
[xx,yy] = meshgrid(x,y);
% two functions:
zz1 = xx.^2 + yy.^2; 
zz2 = xx + 2*yy;
 
figure(1)
subplot(2,3,1)
contour(xx,yy,zz1,[25,50,100],'ShowText','on')
% [25,50,100] defines the heights of the contours
% 'ShowText','on' allows contour() to show values of contours
caxis([min(zz2(:)) max(zz1(:))])
% caxis defines the color levels of the contours
 
 
subplot(2,3,4)
contour(xx,yy,zz2,[-30:10:30],'ShowText','on')
caxis([min(zz2(:)) max(zz1(:))])
 
subplot(2,3,[2,3,5,6])
contour(xx,yy,zz1,[25,50,100]); hold on
contour(xx,yy,zz2,[-30:10:30]); hold on
[~,c1] = contour(xx,yy,zz1,[50 50],'ShowText','on'); hold on
% [50 50] defines the level of 50
[~,c2] = contour(xx,yy,zz2,[0 0],'ShowText','on'); hold on
c1.LineWidth = 3; c2.LineWidth = 3;
% outputs, c1 and c2 defines the handles of the contours
caxis([min(zz2(:)) max(zz1(:))])
colorbar; xlabel('x'); ylabel('y')
 
figure(2)
[M1,c1] = contour(xx,yy,zz1,[50 50],'ShowText','on'); hold on
[M2,c2] = contour(xx,yy,zz2,[0 0],'ShowText','on'); hold on
x1 = M1(1,2:end); y1 = M1(2,2:end); 
x2 = M2(1,2:end); y2 = M2(2,2:end); 
[xi,yi] = polyxpoly(x1,y1,x2,y2);
% [xi,yi] = polyxpoly(x1,y1,x2,y2) returns the intersection points 
% of two polylines in a planar, Cartesian system, with vertices 
% defined by x1, y1, x2 and y2. The output arguments, xi and yi, 
% contain the x- and y-coordinates of each point at which a segment 
% of the first polyline intersects a segment of the second. 
plot(xi,yi,'xk','MarkerSize',20)
c1.LineWidth = 3; c2.LineWidth = 3;
caxis([min(zz2(:)) max(zz1(:))])
colorbar; xlabel('x'); ylabel('y')
