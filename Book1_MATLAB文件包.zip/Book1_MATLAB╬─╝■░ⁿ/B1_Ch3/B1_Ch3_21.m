% B1_Ch3_21.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = [2014 2015 2016 2017 2018];
Product_A = [37 39 46 56 67]; 
w1 = 0.5; 
bar(x,Product_A,w1,'FaceColor',[0.2 0.2 0.5])
Product_B = [22 24 32 41 50];
w2 = .25;
hold on
bar(x,Product_B,w2,'FaceColor',[0 0.7 0.7])
hold off
grid off
ylabel('Sale')
legend({'Product A','Product B'},'Location','northwest')
