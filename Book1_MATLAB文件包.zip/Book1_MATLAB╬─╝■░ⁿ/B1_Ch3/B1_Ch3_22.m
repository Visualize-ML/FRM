% B1_Ch3_22.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

Y = rand(30,1);
figure(1)
bar_handle = bar(Y);
bl = bar_handle.BaseLine

bl.BaseValue = 0.5;
bl.Color = 'red';
bl.LineWidth = 1;

xlabel('x'); ylabel('y')
box off; grid off
