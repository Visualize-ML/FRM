% B1_Ch3_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% 3D surface, mesh, contours, etc.
 
x = linspace(-2*pi,2*pi,40); y = linspace(0,4*pi,40);
[X,Y] = meshgrid(x,y); Z = sin(X)+cos(Y);
 
i = 1
figure(i)
surf(X,Y,Z)
% surf(X,Y,Z) creates a three-dimensional surface plot
xlabel('x'); ylabel('y'); zlabel('sin(x) + sin(y)')
 
i = i+1;
figure(i)
mesh(X,Y,Z)
% mesh(X,Y,Z) draws a wireframe mesh with color determined by Z
xlabel('x'); ylabel('y'); zlabel('sin(x) + sin(y)')
 
i = i+1;
figure(i)
contour(X,Y,Z,'ShowText','on')
% contour(Z) draws a contour plot of matrix Z, 
% where Z is interpreted as heights with respect to the x-y plane
xlabel('x'); ylabel('y');
xlim([-2*pi,2*pi]); ylim([0,4*pi])
 
i = i+1;
figure(i)
contourf(X,Y,Z,'ShowText','on')
% contourf(Z) draws a filled contour plot of matrix Z
xlabel('x'); ylabel('y');
xlim([-2*pi,2*pi]); ylim([0,4*pi])
 
i = i+1;
figure(i)
meshc(X,Y,Z)
% meshc(X,Y,Z) draws a wireframe mesh and 
% a contour plot under it with color determined by Z
xlabel('x'); ylabel('y'); zlabel('sin(x) + sin(y)') 
 
i = i+1;
figure(i)
meshz(X,Y,Z)
% meshz(X,Y,Z) draws a curtain around the wireframe mesh 
% with color determined by Z
xlabel('x'); ylabel('y'); zlabel('sin(x) + sin(y)')
xlim([-2*pi,2*pi]); ylim([0,4*pi]) 
 
i = i+1;
figure(i)
contour3(X,Y,Z,20)
% contour3 creates a 3-D contour plot of a surface 
% defined on a rectangular grid
xlabel('x'); ylabel('y'); zlabel('sin(x) + sin(y)')
xlim([-2*pi,2*pi]); ylim([0,4*pi]) 
