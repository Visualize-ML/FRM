% B1_Ch3_27.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = randn(1000,1); 
% generate 1000 random numbers
 
figure(1)
subplot(1,2,1)
histogram(x)
ylabel('Frequency')
 
subplot(1,2,2)
nbins = 10;
h = histogram(x,nbins)
h.Normalization = 'probability';
ylabel('Probability')
