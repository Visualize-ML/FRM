% B1_Ch3_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% 3D plot
 
x = 0:pi/50:2*pi; n_series = 1:5;
n_length = length(n_series);
 
for i = 1:n_length
    
    n = n_series(i);
    y = sin(n*x);
    plot3(n*ones(1,length(x)),x,y); hold on
    
end
hold off; grid off
xlabel('n'); ylabel('x'); zlabel('sin(nx)')
