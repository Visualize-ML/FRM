% B1_Ch3_19.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Bar charts
 
x = 1900:20:2000;
x_labels = {'A year','B year','C year',...
    'D year','E year','F year'}
y = [75 91 105 123.5 131 150];
 
figure(1)
subplot(3,1,1)
bar(x,y)
ytickformat('usd')
% yttickformat was not defined in MATLAB 2016a
% Tick label to be rotated by 45 degrees clockwise
set(gca,'XTickLabelRotation',45)

subplot(3,1,2)
bar(x,y,.4) 
% .4 is the width
ytickformat('$%,.0f')
set(gca,'XTickLabelRotation',-45)
set(gca,'XTickLabel',x_labels) 
 
subplot(3,1,3)
barh(x,y)
xtickformat('usd')
