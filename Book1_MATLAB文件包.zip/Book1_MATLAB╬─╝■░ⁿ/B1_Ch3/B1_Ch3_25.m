% B1_Ch3_25.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

Y = randi(10,8,3);
figure(1)
subplot(1,2,1)
bar3(Y); box off; grid off
 
subplot(1,2,2)
bar3(Y,'stacked'); box off; grid off
