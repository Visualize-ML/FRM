% B1_Ch3_31.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
y = 0:0.01:4;
z = y/4.*cos(12*y) + 2;
x = y/4.*sin(12*y) + 2;
 
h = figure(1)
plot3(x,y,z,'LineWidth',2); hold all
xlim([0,max(y)]); ylim([0,max(y)]); zlim([0,max(y)])
xlabel('x'); ylabel('y'); zlabel('z')

hAxis = gca;
hAxis.XRuler.FirstCrossoverValue  = 0; % X crossover with Y axis
hAxis.YRuler.FirstCrossoverValue  = 0; % Y crossover with X axis
hAxis.ZRuler.FirstCrossoverValue  = 0; % Z crossover with X axis
hAxis.ZRuler.SecondCrossoverValue = 0; % Z crossover with Y axis
hAxis.XRuler.SecondCrossoverValue = 0; % X crossover with Z axis
hAxis.YRuler.SecondCrossoverValue = 0; % Y crossover with Z axis

% [az,el] = view([0,0,1])  % az = 0;   el = 90;
% [az,el] = view([0,1,0])  % az = 180; el = 0;
% [az,el] = view([1,0,0])  % az = 90;  el = 0;
% [az,el] = view([-1,0,0]) % az = -90; el = 0;
% [az,el] = view([0,-1,0])  % az = 0; el = 0;
% [az,el] = view([0,0,-1])  % az = 0;   el = -90;
% [az,el] = view([1,1,0])    % az = 135; el = 0;
% [az,el] = view([1,1,1])    % az = 135; el = 35.2644;
% [az,el] = view(3)    % az = -37.5000; el = 30;
