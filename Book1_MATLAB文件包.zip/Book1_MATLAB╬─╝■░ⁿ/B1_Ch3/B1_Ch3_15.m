% B1_Ch3_15.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Create two axes objects ax1 and ax2
% By default, the values are normalized to the figure
 
figure(1)
ax1 = axes('Position',[0.1 0.1 0.7 0.7]);
% ax1 has a lower left corner at the point (0.1 0.1) 
% ax1 has a width and height of 0.7
 
ax2 = axes('Position',[0.65 0.65 0.28 0.28]);
% ax2 has a lower left corner at the point (0.65 0.65)
% ax2 a width and height of 0.28
 
contour(ax1,peaks(20))
 
surf(ax2,peaks(20))
