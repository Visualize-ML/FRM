% B1_Ch3_26.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

fruits = [12,24,48];
 
figure(1)
subplot(1,2,1)
explode = [1 0 0];
pie(fruits, explode)
labels = {'Apple','Orange','Banana'};
legend(labels,'Location','southoutside',...
    'Orientation','horizontal')
 
subplot(1,2,2)
p = pie(fruits);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
txt = {'Apple: ';'Orange: ';'Banana: '};
combinedtxt = strcat(txt,percentValues);
 
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
