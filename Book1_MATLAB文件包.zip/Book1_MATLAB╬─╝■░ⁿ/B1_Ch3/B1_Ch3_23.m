% B1_Ch3_23.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
Y = rand(30,1);
level = 0.5;
figure(1)
aboveLine = (Y >= level);
 
bottomLine = Y;
topLine = Y;
 
bottomLine(aboveLine) = NaN;
topLine(~aboveLine) = NaN;

bar_handle = bar(bottomLine,'r'); hold on
bar(topLine,'b')
bl = bar_handle.BaseLine
bl.BaseValue = 0.5;
bl.Color = 'green';
bl.LineWidth = 1;
xlabel('x'); ylabel('y')
box off; grid off
