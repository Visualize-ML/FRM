% B1_Ch8_19.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
syms x y
Ks = [0, 1, 2, 4];
 
figure(1)
subplot(1,2,1)
 
for i = 1:length(Ks)
    
    k = Ks(i);
    f = x.^2 + y.^2 + k*x.*y;
    fcontour(f,'LevelList',[9]); hold on
end
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin'); box off
 
Ks = [-4, -2, -1, 0];
subplot(1,2,2)
for i = 1:length(Ks)
    
    k = Ks(i);
    f = x.^2 + y.^2 + k*x.*y;
    fcontour(f,'LevelList',[9]); hold on
end
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin'); box off
