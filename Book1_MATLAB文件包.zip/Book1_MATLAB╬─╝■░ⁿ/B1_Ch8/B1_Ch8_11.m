% B1_Ch8_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% multiple trials, toss coins
clc; clear all; close all
 
NUMs_trials = [20,200,2000,20000];
% four experiments, each has different number of trials
num_toss = 100;
% number of tosses in each trial is fixed
NUMs_heads = [];
x_lims = [0,0];
% numbers of heads in each trial for the experiment
figure(1)
 
for i = 1:length(NUMs_trials)
    
    num_trials = NUMs_trials(i);
    
    for j = 1:num_trials
        
        head_or_tail = randi([0,1],num_toss,1);
        num_heads = sum(head_or_tail);
        NUMs_heads = [NUMs_heads,num_heads];
        
    end
    
    subplot(2,2,i)
    nbins = 20; histfit(NUMs_heads,nbins)
    x1=get(gca,'xlim')
    if x1(2)>x_lims(2)
        x_lims = x1;
    end
    xlim(x_lims)
    xlabel(['Number of heads in ',num2str(num_toss),' tosses'])
    ylabel('Number of events')
    line1 = ['Total trials: ',num2str(num_trials)];
    line2 = ['Tosses in each trials: ',num2str(num_toss)];
    title({line1;line2})
    
end
