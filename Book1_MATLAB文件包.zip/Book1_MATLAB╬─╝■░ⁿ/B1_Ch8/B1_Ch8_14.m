% B1_Ch8_14.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
N = 400;
 
particle_disp = struct();
 
particle_disp.x = randn(N, 1);
particle_disp.y = randn(N, 1);
 
figure(1)
 
correl_series = [1, 0.75, 0.5, 0.25, 0, -0.25, -0.5, -0.75, -1];
index = length(correl_series);
 
figure (1)
 
for i = 1:index
    
    correl = correl_series(i);
    
    subplot(3,3,i)
    
    % Generate correlated random numbers
    particle_disp.z = correl*particle_disp.x +...
        sqrt(1-correl^2)*particle_disp.y;
    
    plot(particle_disp.x, particle_disp.z,'o');
    PCC = corrcoef(particle_disp.x,particle_disp.z)
    xlabel('X');
    ylabel('Z');
    title (['PCC = ', num2str(PCC(2,1))])
    
end
 
set(gcf,'color','w');
