% B1_Ch8_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
x = linspace(-0.5,1.5,50);
A = 0;
B = 1;
pdf_uniform = unifpdf(x,A,B);

cdf_uniform = unifcdf(x,A,B);
 
figure(1)
 
plot(x,pdf_uniform,'--'); hold on
plot(x,cdf_uniform)
legend('PDF','CDF'); xlabel('x')
title('Uniform distribution')
ylim([0 1.1])
