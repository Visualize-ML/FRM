% B1_Ch8_18.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
RHOs = [-0.6, 0, 0.6];
% Correlations
 
mean_1 = 0; mean_2 = 0;
MEANs = [mean_1 mean_2];
var_1 = 1; var_2 = 1;
 
for i = 1:length(RHOs)
    rho = RHOs(i)
    
    cov_1_2 = rho*var_1^0.5*var_2^0.5;
    COV_Matrix = [var_1,   cov_1_2;
                  cov_1_2, var_2];
    
    x_1 = linspace(-3+mean_1,3+mean_1,30);
    x_2 = linspace(-3+mean_2,3+mean_2,30);
    
    [xx1,xx2] = meshgrid(x_1,x_2);
    X = [xx1(:), xx2(:)];
    
    pmvt = mvnpdf(X,MEANs,COV_Matrix);
    joint_pdf = reshape(pmvt,length(xx2),length(xx1));
    
    figure(i)
    subplot(1,2,1)
    mesh(xx1,xx2,joint_pdf);
    xlabel('x_1'); ylabel('x_2'); zlabel('PDF')
    line1 = ['mean(x_1) = ',num2str(mean_1),'; var(x_1) = ',num2str(var_1)];
    line2 = ['mean(x_2) = ',num2str(mean_2),'; var(x_2) = ',num2str(var_2)];
    line3 = ['correlation(x_1,x_2) = ',num2str(rho)];
    title({line1;line2;line3})
    
    subplot(1,2,2)
    contour(xx1,xx2,joint_pdf,10);
    xlabel('x_1'); ylabel('x_2');
    title('2-D normal distribution PDF')
%     sgtitle can be used for MATLAB 2018b and after
    
end
