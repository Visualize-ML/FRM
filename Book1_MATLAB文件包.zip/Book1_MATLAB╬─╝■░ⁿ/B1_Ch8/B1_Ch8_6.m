% B1_Ch8_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all;
mu = 0;
% mu: mean of the associated normal distribution
sigma = 1;
% sigma: standard deviation of the 
% associated normal distribution
x_norm = (0.01:0.01:10);
pdf_norm = lognpdf(x_norm,mu,sigma);
 
figure(1)
plot(x_norm,pdf_norm)
xlabel ('x in a lognormal distribution')
ylabel ('Probability')
ylim ([0, 0.8])
xlim ([0, 10])
set(gcf,'color','w');
 
x_logn = (log(x_norm) - mu)/sigma;
pdf_logn = pdf_norm.*x_norm;
% z: standard normal variable
x = [-3:0.01:3];
y = normpdf(x,mu,sigma) 
 
figure(2)
plot(x_logn, pdf_logn); hold on
plot(x,y,'--')
hold off
xlabel ('s, x in a normal distribution')
ylabel ('Probability')
ylim ([0, 0.5])
xlim ([-3, 3])
set(gcf,'color','w');
