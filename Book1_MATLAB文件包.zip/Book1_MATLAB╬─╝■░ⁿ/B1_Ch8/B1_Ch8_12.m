% B1_Ch8_12.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
NUMs = [10, 10, 20];
LAMBDAs = [1, 4, 10];
 
figure(1)
 
for i = 1:length(NUMs)
    
    num = NUMs(i);
    lambda = LAMBDAs(i);
    x = 0:num;
    poisson_pdf = poisspdf(x,lambda); 
    % better if it is named poisspmf()
    poisson_cdf = poisscdf(x,lambda);
    
    subplot(3,1,i)
    stem(x,poisson_pdf); hold on
    stairs(x,poisson_cdf)
    title(['Poisson distribution, n = ',num2str(num),...
        ', \lambda = ', num2str(lambda)])
    legend('PMF','CDF', 'location','northwest'); hold off
    
end
