% B1_Ch8_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
X2 = linspace(0,20,200);
mu = 0; sigma = 1;
logn_pdf = lognpdf(X2,mu,sigma);
X1 = linspace(-3,3,200);
norm_pdf = normpdf(X1,mu,sigma);
 
e_x1 = exp(X1);
XX2 = exp([-2:2]);
XX2_logn_cdf = logncdf(XX2,mu,sigma);
XX1_inv = norminv(XX2_logn_cdf);
 
XXX2 = [2,5:5:20];
XXX2_logn_cdf = logncdf(XXX2,mu,sigma);
XXX1_inv = norminv(XXX2_logn_cdf);
 
figure(1)
 
subplot(4,4,[2:4 6:8 10:12]); % Top right square
 
plot(XX1_inv,XX2,'x'); hold on
plot(XXX1_inv,XXX2,'o'); hold on
plot(X1,e_x1,'r'); ylim([0,20])
y1=get(gca,'ylim'); x1=get(gca,'xlim')
 
subplot(4,4,[1 5 9]); % Top left
plot(X2,logn_pdf,'b'); hold on
plot(XX2,lognpdf(XX2,mu,sigma),'x'); hold on
plot(XXX2,lognpdf(XXX2,mu,sigma),'o')
view(90,-90); box off
xlim(y1); ylabel('PDF, logN(0,1)')
 
subplot(4,4,[14:16]); % Btm right
plot(X1,norm_pdf,'b'); hold on
plot(XX1_inv,normpdf(XX1_inv,mu,sigma),'x'); hold on
plot(XXX1_inv,normpdf(XXX1_inv,mu,sigma),'o')
box off; xlim(x1); ylabel('PDF, N(0,1)')
