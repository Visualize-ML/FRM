% B1_Ch8_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x = linspace(-3,3);
pdf_1 = tpdf(x,1);
pdf_2 = tpdf(x,2);
pdf_10 = tpdf(x,10);

pdf_n = normpdf(x,0,1);
 
figure(1)
plot(x,pdf_1,'--'); hold on
plot(x,pdf_2,'--'); hold on
plot(x,pdf_10,'--'); hold on
plot(x,pdf_n); hold on
xlabel('x'); ylabel('pdf(x)'); 
legend('\nu = 1','\nu = 2','\nu = 10','standard normal')
