% B1_Ch8_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Studies of Skewness and Kurtosis
 
clc; close all; clear all
num_seeds = 4000;
mu = 0; sigma = 1;
nbins = 20;
 
SKEWS = [0,   0,   0.6, -0.6];
KURTS = [5, 2.5,   3,      3];
 
figure(1)
y_lims = [0 0];
 
for i = 1:length(SKEWS)
    
    subplot(2,2,i)
    skew = SKEWS(i); kurt = KURTS(i);
    x_rand = pearsrnd(mu,sigma,skew,kurt,num_seeds,1);
    
    x_skew = skewness (x_rand);
    
    x_kurtosis = kurtosis (x_rand);
    
    histfit(x_rand,nbins,'kernel'); hold on
    yt = get(gca, 'YTick');
    y_ticks = round(yt/numel(x_rand),2);
    y1 = get(gca,'ylim')
    
    if y_lims(2) < y1(2)
        y_lims = y1;   
    end
    
    ylim([y_lims])
    set(gca, 'YTick', yt, 'YTickLabel', y_ticks)
    
    first_line  = ['Skewness = ', num2str(x_skew)];
    second_line = ['Kurtosis = ', num2str(x_kurtosis)];
    title({first_line;second_line})
    xlabel('Data'); ylabel('Probability')
    
end
