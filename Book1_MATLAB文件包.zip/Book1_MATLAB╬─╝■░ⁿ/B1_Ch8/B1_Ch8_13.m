% B1_Ch8_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% QQ plots
 
clc; close all; clear all
 
num_seeds = 500;
 
for i = 1:4
    n = i;
    
    switch n
        case 1
            % Uniformly distributed
            x_rand = rand(num_seeds,1);
            nbins = 5;
            title_i = 'Uniform distribution';
            
        case 2
            % Student's t
            nu = 3;
            x_rand = trnd(nu,num_seeds,1);
            nbins = 20;
            title_i = 'Student''s t';
            
        case 3
            % Positively skewed
            mu = 0; sigma = 1;
            skew = 0.6; kurt = 3.5;
            x_rand = pearsrnd(mu,sigma,skew,kurt,num_seeds,1);
            nbins = 20;
            title_i = 'Positive skew';
            
        case 4
            % Negatively skewed
            mu = 0; sigma = 1;
            skew = -0.65; kurt = 3.5;
            x_rand = pearsrnd(mu,sigma,skew,kurt,num_seeds,1)
            nbins = 20;
            title_i = 'Negative skew';
    end
    
    figure(i)
    subplot(2,2,1)
    ecdf(x_rand)
    title(title_i)
    
    subplot(2,2,2)
    x = [-5:0.01:5];
    mu = 0; sigma = 1;
    % x = [min(x_uniform):0.01:max(x_uniform)];
    % mu = mean(x_uniform);
    % sigma = std(x_uniform);
    y_cdf = normcdf(x,mu,sigma);
    plot(x,y_cdf)
    title('Standard normal')
    
    subplot(2,2,3)
    % h = histogram(x_uniform,nbins); hold on
    % h.Normalization = 'probability';
    % ylabel('Probability')
    histfit(x_rand,nbins,'kernel')
    
    subplot(2,2,4)
    qqplot(x_rand)
    
end
