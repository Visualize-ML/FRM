% B1_Ch8_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
num = 9; % updated to 80
x = 0:num+1;
p = 0.8; % updated to 0.5
binomial_pdf = binopdf(x,num,p);
binomial_cdf = binocdf(x,num,p);
 
figure(1)
stem(x,binomial_pdf); hold on
stairs(x,binomial_cdf)
title(['Binomial distribution, n = ',num2str(num),...
', p = ', num2str(p)])
legend('PMF','CDF', 'location', 'northwest')
ylim([0 1.1])
