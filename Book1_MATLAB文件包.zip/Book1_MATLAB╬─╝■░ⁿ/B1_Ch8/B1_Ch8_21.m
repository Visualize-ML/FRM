% B1_Ch8_21.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
rho=0.66; ave_1=0; ave_2=0;
var1=1^2; var2=2^2;
cov12=rho*(var1*var2)^0.5;
num_sims = 1000;
 
AVEs=[ave_1 ave_2];
COV_Mtx=[var1  cov12;
    cov12 var2];
X = mvnrnd(AVEs,COV_Mtx,num_sims);
X1=X(:,1); X2=X(:,2);
 
figure(1)
scatterhist(X1,X2,'Location','NorthWest',...
    'Direction','out','Marker','.');
 
figure(2)
scatterhist(X1,X2,'Location','NorthEast',...
    'Direction','out','Kernel','on','Marker','.');
 
[bin_counts,Xedges,Yedges] = histcounts2(X1,X2,20);
X_centers = Xedges(1:end-1) + (Xedges(2) - Xedges(1))/2;
Y_centers = Yedges(1:end-1) + (Yedges(2) - Yedges(1))/2;
[XX,YY] = meshgrid(X_centers, Y_centers);
 
figure(3)
imagesc(X_centers,Y_centers,bin_counts)
set(gca,'YDir','normal')
xlabel('X1'); ylabel('X2')
colorbar
 
figure(4)
heatmap(X_centers,Y_centers,bin_counts)
xlabel('X1'); ylabel('X2')
colorbar
