% B1_Ch8_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

freedoms = 1:4;
x = 0:0.01:4;
 
figure(1)
 
subplot(1,2,1)
for i = 1:length(freedoms)
    k = freedoms(i);
    x_pdf = chi2pdf(x,k);
    %     Y = exppdf(X,mu) returns the pdf of the exponential distribution
    %     with mean parameter mu, evaluated at the values in X
    plot(x,x_pdf); hold on
end
legend('k = 1','k = 2','k = 3','k = 4')
xlabel('x'); ylabel('pdf(x)')
box off; grid off
ylim([0 1])
 
subplot(1,2,2)
for i = 1:length(freedoms)
    k = freedoms(i);
    x_cdf = chi2cdf(x,k);
    plot(x,x_cdf); hold on
end
legend('k = 1','k = 2','k = 3','k = 4')
xlabel('x'); ylabel('cdf(x)')
box off; grid off
