% B1_Ch8_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

X = linspace(0,4,100);
Y_1 = lognpdf(X,0,1); Y_2 = lognpdf(X,0,0.5);
Y_3 = lognpdf(X,0,0.25);
 
figure(1)
plot(X,Y_1); hold on
plot(X,Y_2); hold on
plot(X,Y_3); hold on
 
legend('\sigma = 1, \mu = 0',...
    '\sigma = 0.5, \mu = 0', ...
    '\sigma = 0.25, \mu = 0')
