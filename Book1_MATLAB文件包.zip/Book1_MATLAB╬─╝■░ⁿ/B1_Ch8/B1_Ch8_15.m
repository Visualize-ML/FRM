% B1_Ch8_15.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
N = 50;
time = 1:1:N;
 
particle_disp = struct();
 
x_original = 20;
z_original = 15;
x_returns = randn(N, 1);

y_returns = randn(N, 1);
 
correl_series = [0.75, -0.75];
index = length(correl_series);
 
for i = 1:index
    figure (i)
    correl = correl_series(i);
    
    % Simulate two correlated timeseries of returns
    z_returns = correl*x_returns +...
        sqrt(1-correl^2)*y_returns;
    
    % convert return (difference) to price
    x_prices = cumsum(x_returns) + x_original;
    z_prices = cumsum(z_returns) + z_original;
    prices_max = max(max(x_prices(:)),max(z_prices(:)))
    prices_min = min(min(x_prices(:)),z_prices(:))
    
    subplot(2,2,1)
    plot(time,x_prices)
    xlabel('Days'); ylabel('Price of x')
    xlim([1,N])
    
    subplot(2,2,2)
    plot(time,z_prices)
    xlabel('Days'); ylabel('Price of z')
    xlim([1,N])
    
    subplot(2,2,3)
    plot(time,x_returns,'.')
    xlabel('Days'); ylabel('Return of x')
    set(gca, 'XAxisLocation', 'origin')
    xlim([0,N])
    
    subplot(2,2,4)
    plot(time,z_returns,'.')
    xlabel('Days'); ylabel('Return of z')
    set(gca, 'XAxisLocation', 'origin')
    xlim([1,N])
    
    disp('Covariance matrix =')
    cov(x_returns,z_returns)
    disp('Correlation coefficients =')
    corrcoef(x_returns,z_returns)
    
end
