% B1_Ch8_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

LAMBDAs = [0.5, 1, 1.5];
MUs     = 1./LAMBDAs;
x = 0:0.01:4;
 
figure(1)
 
subplot(1,2,1)
for i = 1:length(MUs)
    mu = MUs(i);
    x_pdf = exppdf(x,mu);
    %     Y = exppdf(X,mu) returns the pdf of the exponential distribution
    %     with mean parameter mu, evaluated at the values in X
    plot(x,x_pdf); hold on
end
legend('\lambda = 0.5','\lambda = 1','\lambda = 1.5')
xlabel('x'); ylabel('pdf(x)')
box off; grid off
 
subplot(1,2,2)
for i = 1:length(LAMBDAs)
    mu = MUs(i);
    x_cdf = expcdf(x,mu);
    plot(x,x_cdf); hold on
end
legend('\lambda = 0.5','\lambda = 1','\lambda = 1.5')
xlabel('x'); ylabel('cdf(x)')
box off; grid off
