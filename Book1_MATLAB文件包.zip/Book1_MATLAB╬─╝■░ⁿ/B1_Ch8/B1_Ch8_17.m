% B1_Ch8_17.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
mean_1 = 0; mean_2 = 0;
MEANs = [mean_1 mean_2];
var_1 = 1; var_2 = 1; cov_1_2 = 0; 
% to be updated, 0, 0.3
COV_Matrix = [var_1,   cov_1_2 ; 
              cov_1_2, var_2];
 
x_1 = linspace(-3+mean_1,3+mean_1,30);
x_2 = linspace(-3+mean_2,3+mean_2,30);
 
[xx1,xx2] = meshgrid(x_1,x_2);
X = [xx1(:), xx2(:)];
     
pmvt = mvnpdf(X,MEANs,COV_Matrix);
joint_pdf = reshape(pmvt,length(xx2),length(xx1));
 
pmvt_2 = mvncdf(X,MEANs,COV_Matrix);
joint_cdf = reshape(pmvt_2,length(xx2),length(xx1));
 
figure(1)
subplot(2,2,1)
mesh(xx1,xx2,joint_pdf);
xlabel('x_1'); ylabel('x_2'); zlabel('PDF')
title('2-D normal distribution PDF')
 
subplot(2,2,2)
contour(xx1,xx2,joint_pdf,10);
xlabel('x_1'); ylabel('x_2');
title('2-D normal distribution PDF')
 
subplot(2,2,3)
mesh(xx1,xx2,joint_cdf);
xlabel('x_1'); ylabel('x_2'); zlabel('CDF')
title('2-D normal distribution CDF')
 
subplot(2,2,4)
contour(xx1,xx2,joint_cdf,10);
xlabel('x_1'); ylabel('x_2');
title('2-D normal distribution CDF')
