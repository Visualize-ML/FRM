% B1_Ch8_16.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
N = 400;
 
particle_disp = struct();
 
particle_disp.x = randn(N, 1);
particle_disp.y = randn(N, 1);
xp = linspace(-4,4,20);
 
correl = 0.5;
particle_disp.z = correl*particle_disp.x +...
    sqrt(1-correl^2)*particle_disp.y;
intersept = mean(particle_disp.z);
 
PCC = corr(particle_disp.x,particle_disp.z,...
    'Type', 'Pearson')
% rho = corr(X) returns a matrix of the pairwise 
% linear correlation coefficient
% between each pair of columns in the input matrix X.
 
SCC = corr(particle_disp.x,particle_disp.z,...
    'Type', 'Spearman')
 
KCC = corr(particle_disp.x,particle_disp.z,...
    'Type', 'Kendall')
 
PCC_yp = PCC*xp + intersept;
SCC_yp = SCC*xp + intersept;
KCC_yp = KCC*xp + intersept;
original_yp = correl*xp + intersept;
 
figure(1)
subplot(2,2,1)
plot(particle_disp.x, particle_disp.z,'.'); hold on
plot(xp, original_yp); box off
set(gcf,'color','w'); xlabel('X'); ylabel('Z');
title(['Original \rho = ', num2str(correl)])
daspect([1 1 1]); xlim([-4,4]); ylim([-4,4])
 
subplot(2,2,2)
plot(particle_disp.x, particle_disp.z,'.'); hold on
plot(xp, PCC_yp)
set(gcf,'color','w'); xlabel('X'); ylabel('Z');
title(['PCC = ', num2str(PCC)]); box off
daspect([1 1 1]); xlim([-4,4]); ylim([-4,4])
 
subplot(2,2,3)
plot(particle_disp.x, particle_disp.z,'.'); hold on
plot(xp, SCC_yp)
set(gcf,'color','w'); xlabel('X'); ylabel('Z');
title(['SCC = ', num2str(SCC)]); box off
daspect([1 1 1]); xlim([-4,4]); ylim([-4,4])
 
subplot(2,2,4)
plot(particle_disp.x, particle_disp.z,'.'); hold on
plot(xp, KCC_yp)
set(gcf,'color','w'); xlabel('X'); ylabel('Z');
title(['KCC = ', num2str(KCC)]); box off
daspect([1 1 1]); xlim([-4,4]); ylim([-4,4])
