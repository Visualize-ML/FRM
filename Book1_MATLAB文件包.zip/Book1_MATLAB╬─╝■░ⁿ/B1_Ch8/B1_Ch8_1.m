% B1_Ch8_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Use [p,type,coefs] = pearspdf(X,mu,sigma,skew,kurt)
%  The function pearspdf can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange
% /26516-pearspdf
 
% Plot pdf curves with different kurtosis
clc; close all; clear all
 
X = [-3:0.01:3];
mu = 0; sigma = 1;
skew = 0;
KURTs = [1.8:0.4:5];
PDFs = [];
% my_col = brewermap(length(KURTs),'Blues');
figure(1)
for i = 1:length(KURTs)
    
    kurt = KURTs(i);
    [p,type,coefs] = pearspdf(X,mu,sigma,skew,kurt);
    PDFs = [PDFs;p];
%     plot(X,PDFs(i,:),'color',my_col(i,:)); hold on
end
 
plot(X, PDFs)
xlabel('x'); ylabel('PDF')
 
figure(2)
 
for i = 1:length(KURTs)
    kurt = KURTs(i);
    plot3(kurt*ones(1,length(X)),X,PDFs(i,:)); hold on
    
end
grid on
xlabel('Kurtosis'); ylabel('x'); zlabel('PDF')
