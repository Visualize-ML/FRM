% B1_Ch12_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Option trading strategies
 
clc; clear all; close all
 
STOCK = [20:0.5:90];
Strikes = [40, 50, 60, 70]; % OTM, ATM, ITM, ITM
stock_0 = 50; % Starting price
TIME = [0,0.25:0.25:2];
Vol_const = 0.2; % constant vol.
Vol = Vol_const;
 
option_type = 'put';
% two types: 'call', call option; 'put', put option
early_exercise = false;
if early_exercise
    Type_str = 'Am';
else
    Type_str = 'Euro';
end
 
% Vol. smile
% Vol_K1 = 0.4; Vol_K3 = 0.3; Vol_K2 = 0.2;
time = max(TIME);   % Initial time to maturity
Flag = 0;   % put option
 
Increment = time/20;
 
Rate = 0.03;
 
for i = 1:length(Strikes)
    [Call_K_0(i),Put_K_0(i)] = blsprice(stock_0,Strikes(i),Rate,time,Vol);
    if early_exercise
        % [~,OptionValue] = binprice(stock_0,K1,Rate,time,Increment,Vol_K1,Flag);
        [OptionValue,~,~] = Binomial_CRR(stock_0, K1,...
            Rate,time, Increment, Vol,option_type,early_exercise);
        
        Put_K_0(i) = OptionValue(1,1); % Update Am put price
    else
    end
end
 
 
RATES = linspace(0.2,0.3,5);
for iii = 1:length(Strikes)
    for j = 1:length(TIME)
        time = TIME(j);
        %     Rate = RATES(j);
        for i = 1:length(STOCK)
            stock = STOCK(i);
            
            [Call,Put] = blsprice(stock,Strikes(iii),Rate,time,Vol);
            if early_exercise
                % [~,OptionValue] = binprice(stock,K1,Rate,time,Increment,Vol_K1,Flag);
                [OptionValue,~,~] = Binomial_CRR(stock, Strikes(iii),...
                    Rate,time, Increment, Vol,option_type,early_exercise);
                Put = OptionValue(1,1); % Update Am put price
            else
            end
            CALL_K(i,j,iii) = Call - Call_K_0(iii);
            PUT_K(i,j,iii) = Put - Put_K_0(iii);
            
        end
    end
end
 
CALL_K1 = CALL_K(:,:,1); PUT_K1 = PUT_K(:,:,1);
CALL_K2 = CALL_K(:,:,2); PUT_K2 = PUT_K(:,:,2);
CALL_K3 = CALL_K(:,:,3); PUT_K3 = PUT_K(:,:,3);
CALL_K4 = CALL_K(:,:,4); PUT_K4 = PUT_K(:,:,4);
 
 
index = 1;
 
my_col = brewermap(length(TIME),'RdYlBu');
continue_sign = true;
 
while continue_sign == true
    n = input('Enter a case number: ');
    
    switch n
        
        case 1
            % Covered call: short a call at K2 + long stock
            syn_p = -CALL_K2 + repmat (STOCK, length(TIME),1)' - stock_0;
            title_temp = 'Covered call: short a call + long stock';
            %
        case 2
            % Covered put: short a put at K2 + short stock
            
            syn_p = -PUT_K2 - repmat (STOCK, length(TIME),1)' +  stock_0;
            title_temp = 'Covered put: short a put at K2 + short stock';
            
        case 3
            % Protective call: long a call at K2 + short stock
            syn_p = CALL_K2 - repmat (STOCK, length(TIME),1)' + stock_0;
            title_temp = 'Protective call: long a call at K2 + short stock';
            
        case 4
            
            % Protective put: long a put at K2 + long stock
            syn_p = PUT_K2 + repmat (STOCK, length(TIME),1)' - stock_0;
            title_temp = 'Protective put: long a put at K2 + long stock';
            
        case 5
            
            % Bull spread with two calls, long a call at K1 + short a call at K3
            
            syn_p = CALL_K1 - CALL_K3;
            title_temp = 'Bull spread with two calls: long a call at K1 + short a call at K3';
            
        case 6
            
            % Bull spread with two puts, long a put at K1 + short a put at K3
            
            syn_p = PUT_K1 - PUT_K3;
            title_temp = 'Bull spread with two puts: long a put at K1 + short a put at K3';
            
        case 7
            % Bear spread with two calls: short a call at K1 + long a call at K3
            syn_p = -CALL_K1 + CALL_K3;
            title_temp = 'Bear spread with two calls: short a call at K1 + long a call at K3';
            
        case 8
            
            % Bear spread with two puts: short a put at K1 + long a put at K3
            
            syn_p = -PUT_K1 + PUT_K3;
            title_temp = 'Bear spread with two puts: short a put at K1 + long a put at K3';
            
        case 9
            
            % long butterfly with four calls: long a call at K1 + long a call at K3 + short two calls at K2
            
            syn_p = CALL_K1 + CALL_K3 - 2*CALL_K2;
            title_temp = 'long butterfly with four calls: long a call at K1 + long a call at K3 + short two calls at K2';
            
        case 10
            
            % long butterfly with four puts: long a put at K1 + long a put at K3 + short two puts at K2
            syn_p = PUT_K1 + PUT_K3 - 2*PUT_K2;
            title_temp = 'long butterfly with four puts: long a put at K1 + long a put at K3 + short two puts at K2';
            
        case 11
            
            % short butterfly: long a call at K1 + long a call at K3 + short two calls at K2
            
            syn_p = -CALL_K1 - CALL_K3 + 2*CALL_K2;
            title_temp = 'short butterfly: long a call at K1 + long a call at K3 + short two calls at K2';
            
        case 12
            
            % long butterfly: short a put at K1 + short a put at K3 + long two puts at K2
            syn_p = -PUT_K1 - PUT_K3 + 2*PUT_K2;
            title_temp = 'long butterfly: short a put at K1 + short a put at K3 + long two puts at K2';
            
        case 13
            
            % long straddle: long a put at K2 + long a call at K2
            
            syn_p = PUT_K2 + CALL_K2;
            title_temp = 'long straddle: long a put at K2 + long a call at K2';
            
        case 14
            
            % short straddle: short a put with K2 + put a call with K2
            
            syn_p = -PUT_K2 - CALL_K2;
            title_temp = 'short straddle: short a put with K2 + put a call with K2';
            
        case 15
            
            % long strangle: long a call at K3 + long a put at K1
            syn_p = CALL_K3 + PUT_K1;
            title_temp = 'long strangle: long a call at K3 + long a put at K1';
            
        case 16
            
            % short strangle: short a call at K3 + short a put at K1
            syn_p = -CALL_K3 - PUT_K1;
            title_temp = 'short strangle: short a call at K3 + short a put at K1';
            
        case 17
            
            % Strip: long a call at K2 + long two puts at K2
            
            syn_p = CALL_K2 + 2*PUT_K2;
            title_temp = 'Strip: long a call at K2 + long two puts at K2';
            
        case 18
            % Strap: long two calls at K2 + long a put at K2
            syn_p = 2*CALL_K2 + PUT_K2;
            title_temp = 'Strap: long two calls at K2 + long a put at K2';
            
        case 19
            % long condor: long call at K1, short call at K3, short call at K2, and long call at K4
            syn_p = CALL_K1 - CALL_K3 - CALL_K2 + CALL_K4;
            title_temp = 'long condor: long two calls (K1, K4) + short two calls (K3, K2)';
            
        case 20
            % short condor: short call at K1, long call at K3, long call at K2, and short call at K4
            syn_p = -CALL_K1 + CALL_K3 + CALL_K2 - CALL_K4;
            title_temp = 'long condor: short two calls (K1, K4) + long two calls (K3, K2)';
            
        case 21
            % Call ratio spread: long call at K1 + short 2 calls at K3
            syn_p = CALL_K1 -2*CALL_K3;
            title_temp = 'Call ratio spread: long call at K1 + short 2 calls at K3';
            
        case 22
            % Put ratio spread: long put at K3 + short 2 puts at K1
            syn_p = -2*PUT_K1 + PUT_K3;
            title_temp = 'Put ratio spread: long put at K3 + short 2 puts at K1';
            
        case 23
            % Call ratio backspread: short call at K1 + long 2 calls at K3
            syn_p = -CALL_K1 +2*CALL_K3;
            title_temp = 'Call ratio backspread: short call at K1 + long 2 calls at K3';
            
        case 24
            % Put ratio backspread: long 2 puts at K1 + short put at K3
            syn_p = 2*PUT_K1 - PUT_K3;
            title_temp = 'Put ratio backspread: long 2 puts at K1 + short put at K3';
            
        case 25
            % Long Call Ladder: long a call at K1 + short a call at K2 + short a call at K3
            syn_p = CALL_K1 - CALL_K2 - CALL_K3;
            title_temp = 'Long Call Ladder: long a call at K1 + short a call at K2 + short a call at K3';
            
        case 26
            % Short Call Ladder: short a call at K1 + long a call at K2 + long a call at K3
            syn_p = -CALL_K1 + CALL_K2 + CALL_K3;
            title_temp = 'Short Call Ladder: short a call at K1 + long a call at K2 + long a call at K3';
            
        case 27
            % Long put Ladder: long a put at K3 + short a put at K2 + short a put at K1
            syn_p = -PUT_K1 - PUT_K2 + PUT_K3;
            title_temp = 'Long put Ladder: long a put at K3 + short a put at K2 + short a put at K1';
            
        case 28
            % Short put Ladder: short a put at K3 + long a put at K2 + long a put at K1
            syn_p = +PUT_K1 + PUT_K2 - PUT_K3;
            title_temp = 'Long put Ladder: long a put at K3 + short a put at K2 + short a put at K1';
            
        case 29
            % Box: long a call at K1 + short a call at K3 + short a put at K1 +
            % long a put at K3
            syn_p = +CALL_K1 - CALL_K3 - PUT_K1 + PUT_K3;
            title_temp = 'Box: long a call at K1 + short a call at K3 + short a put at K1 + long a put at K3';
            
            
    end
    
    figure(index)
    index = index + 1;
    
    for jj = 1:length(TIME)
        plot(STOCK,syn_p(:,jj),'color',my_col(jj,:)); hold on
    end
    plot(Strikes(1),0,'ok'); hold on
    plot(Strikes(2),0,'ok'); hold on
    plot(Strikes(3),0,'ok'); hold on
    plot(Strikes(4),0,'ok'); hold on
    set(gca, 'XAxisLocation', 'origin')
    xlabel('Stock price [USD]')
    ylabel('PnL [USD]')
    title(title_temp)
    daspect([1 1 1]); box off
    
    continue_sign = input('Type true to continue (ENTER to stop): ');
    
end
 
%%
function [oPrice,Second_Tree_option,First_Tree_Stock] = Binomial_CRR(S0, X_strike,...
    interest_r,time, dt, sigma,option_type,early_exercise)
 
steps = time/dt;
a = exp(interest_r*dt);
u = exp(sigma*sqrt(dt));
% Cox Ross Rubinstein
d = 1/u;
prob = (a-d)/(u-d);
 
First_Tree_Stock = nan(steps+1,steps+1);
First_Tree_Stock(1,1) = S0;
 
% Calculate values for the nodes on the first tree, stock tree
 
for idx = 2:steps+1
    First_Tree_Stock(1:idx-1,idx) = First_Tree_Stock(1:idx-1,idx-1)*u;
    First_Tree_Stock(idx,idx) = First_Tree_Stock(idx-1,idx-1)*d;
end
 
% Calculate the value at expiry
Second_Tree_option = nan(size(First_Tree_Stock));
switch option_type
    case 'put'
        Second_Tree_option(:,end) = max(X_strike-First_Tree_Stock(:,end),0);
    case 'call'
        Second_Tree_option(:,end) = max(First_Tree_Stock(:,end)-X_strike,0);
end
 
% Loop backwards to get values at the earlier times
steps = size(First_Tree_Stock,2)-1;
 
for idx = steps:-1:1
    Second_Tree_option(1:idx,idx) = ...
        exp(-interest_r*dt)*(prob*Second_Tree_option(1:idx,idx+1) ...
        + (1-prob)*Second_Tree_option(2:idx+1,idx+1));
    if early_exercise
        
        switch option_type
            case 'put'
                Second_Tree_option(1:idx,idx) = ...
                    max(X_strike-First_Tree_Stock(1:idx,idx),...
                    Second_Tree_option(1:idx,idx));
            case 'call'
                Second_Tree_option(1:idx,idx) = ...
                    max(First_Tree_Stock(1:idx,idx)-X_strike,...
                    Second_Tree_option(1:idx,idx));
        end
    end
end
 
% Output the option price
oPrice = Second_Tree_option(1);
end

