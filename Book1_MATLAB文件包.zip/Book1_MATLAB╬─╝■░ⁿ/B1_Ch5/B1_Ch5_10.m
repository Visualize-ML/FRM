% B1_Ch5_10.m
 
%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

[xx,yy] = meshgrid(-5:0.5:5);
figure(1)
subplot(2,2,1)
% paraboloid: a quadric surface
zz = -(xx.^2 + yy.^2); 
mesh(xx,yy,zz)
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off 
 
% Quadric conical surface
subplot(2,2,2)
zz = sqrt(xx.^2 + yy.^2);
mesh(xx,yy,zz)
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off 
 
% saddle surface
subplot(2,2,3)
zz = xx.*yy;
mesh(xx,yy,zz)
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off
 
% wavy surface
subplot(2,2,4)
zz = sin(xx).*cos(yy/2)+2;
mesh(xx,yy,zz)
xlabel('x'); ylabel('y'); zlabel('z')
zlim([0,4])
grid off; box off
