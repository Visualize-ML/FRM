% B1_Ch5_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Degree 2 � quadratic
 
x = [-10:0.1:10];

p2 = [1 6 -16];
% x^2 - 6x - 16 = 0 gives the roots
r2 = roots(p2)
y2 = polyval(p2,x);
figure(2)
plot(x,y2); hold on
plot(r2(1),0,'o',r2(2),0,'o')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlabel('x')
ylabel('y')
box off
