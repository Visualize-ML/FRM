% B1_Ch5_11.m
 
%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

[xx,yy] = meshgrid(-5:0.5:5);
figure(1)
zz = -(xx.^2 + yy.^2);
subplot(2,2,1)
meshc(xx,yy,zz)
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off
 
subplot(2,2,2)
contour3(xx,yy,zz,15)
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off
 
subplot(2,2,3)
mesh(xx,yy,zz,'MeshStyle','column')
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off
 
subplot(2,2,4)
mesh(xx,yy,zz,'MeshStyle','row')
xlabel('x'); ylabel('y'); zlabel('z')
grid off; box off
