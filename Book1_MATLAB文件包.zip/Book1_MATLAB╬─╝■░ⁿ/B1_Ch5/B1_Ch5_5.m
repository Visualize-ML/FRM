% B1_Ch5_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Degree 3 � cubic
 
x = [-10:0.1:10];

p3 = [4 -4 -100 -100];
% 4x^3 - 4x^2 -100x -100 = 0 gives the roots
r3 = roots(p3)
y3 = polyval(p3,x);
 
figure(3)
plot(x,y3); hold on
plot(r3(1),0,'o',r3(2),0,'o',r3(3),0,'o')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlabel('x')
ylabel('y')
box off