% B1_Ch5_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Polynomials
% Degree 1 � linear
 
p1 = [1 5];
% x + 5 = 0 gives the root
r1 = roots(p1)
x = [-10:0.1:10];
 
figure(1)
y1 = polyval(p1,x);
plot(x,y1); hold on
plot(r1,0,'o')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlabel('x')
ylabel('y')
box off; daspect([1,1,1])
