% B1_Ch11_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
option_type = 'call';
% two types: 'call', call option; 'put', put option
early_exercise = false;
if early_exercise
    Type_str = 'Am';  
else
    Type_str = 'Euro';
end
% false = Euro; true = American
X_strike = 50; 
%strike: strike price
S0 = 60;
% S0: current stock price
interest_r = 0.1;
% interest_r: risk-free interest rate
sigma = 0.35;
% sigma: volatility
delta_t = 1/250;
% delta_t: size of time steps
steps = 10;
% steps: number of time steps
 
a = exp(interest_r*delta_t);
u = exp(sigma*sqrt(delta_t)); 
% Cox Ross Rubinstein
d = 1/u;
prob = (a-d)/(u-d);
 
First_Tree_Stock = nan(steps+1,steps+1);
First_Tree_Stock(1,1) = S0;
 
% Calculate values for the nodes on the first tree, stock tree
 
for idx = 2:steps+1
    First_Tree_Stock(1:idx-1,idx) = First_Tree_Stock(1:idx-1,idx-1)*u;
    First_Tree_Stock(idx,idx) = First_Tree_Stock(idx-1,idx-1)*d;
end
 
% Calculate the value at expiry
Second_Tree_option = nan(size(First_Tree_Stock));
switch option_type
    case 'put'
        Second_Tree_option(:,end) = max(X_strike-First_Tree_Stock(:,end),0);
    case 'call'
        Second_Tree_option(:,end) = max(First_Tree_Stock(:,end)-X_strike,0);
end
 
node_series = [0:1:steps];
binomial_f = factorial(steps)./factorial(node_series)./factorial(steps - node_series);
prob_series = [binomial_f.*prob.^(steps - node_series).*(1-prob).^node_series];
Euro_option_price = sum(Second_Tree_option(:,end)'.*prob_series)*exp(-interest_r*delta_t*steps)
Second_Tree_option(1)=Euro_option_price;
 
figure (1)
c = imagesc (First_Tree_Stock);
% set(gca,'YDir','normal')
colorbar;
%  caxis([0 max(max(priceTree))])
% colormap winter; colorbar;
 
set(c,'AlphaData',~isnan(First_Tree_Stock))
 
xlabel('Number of steps'); ylabel('Number of nodes')
title (['First tree for stock price. X: $',num2str(X_strike),'; Stock: $',num2str(S0),'.'])
set(gcf,'color','white')
 
figure (2)
 
c = imagesc (Second_Tree_option);
% set(gca,'YDir','normal')
 
colorbar;
% caxis([0 max(max(priceTree))])
% colormap winter; colorbar;
set(c,'AlphaData',~isnan(Second_Tree_option))
 
xlabel('Number of steps'); ylabel('Number of nodes')
title (['Second tree option value. X: $',num2str(X_strike),'; Stock: $',num2str(S0),'.'])
set(gcf,'color','white')
