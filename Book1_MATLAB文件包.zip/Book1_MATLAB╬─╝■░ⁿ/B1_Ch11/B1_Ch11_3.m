% B1_Ch11_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
option_type = 'call';
% two types: 'call', call option; 'put', put option
early_exercise = false;
if early_exercise
    Type_str = 'Am';
    
else
    Type_str = 'Euro';
    
end
% false = Euro; true = American
X_strike = 50;
%strike: strike price
S0_series = [0:1:100];
interest_r = 0.1;
% interest_r: risk-free interest rate
sigma = 0.35;
% sigma: volatility
T = 2;
% T: time to maturity
delta_t = 1/250;
% delta_t: size of time steps
steps = round(T/delta_t);
% steps: number of time steps
 
figure(1)
 
a = exp(interest_r*delta_t);
u = exp(sigma*sqrt(delta_t));
% Cox Ross Rubinstein
d = 1/u;
prob = (a-d)/(u-d);
 
S0_length = length (S0_series);
 
Euro_option_price_series = [];
 
for i = 1:S0_length
    
    S0 = S0_series(i);
    % S0: current stock price
    
    First_Tree_Stock = nan(steps+1,steps+1);
    First_Tree_Stock(1,1) = S0;
    
    % Calculate values for the nodes on the first tree, stock tree
    
    for idx = 2:steps+1
        First_Tree_Stock(1:idx-1,idx) = First_Tree_Stock(1:idx-1,idx-1)*u;
        First_Tree_Stock(idx,idx) = First_Tree_Stock(idx-1,idx-1)*d;
    end
    
    % Calculate the value at expiry
    Second_Tree_option = nan(size(First_Tree_Stock));
    switch option_type
        case 'put'
            Second_Tree_option(:,end) = max(X_strike-First_Tree_Stock(:,end),0);
        case 'call'
            Second_Tree_option(:,end) = max(First_Tree_Stock(:,end)-X_strike,0);
    end
    
    for idx = steps:-1:1
        
        Second_Tree_option(1:idx,idx) = ...
            exp(-interest_r*delta_t)*(prob*Second_Tree_option(1:idx,idx+1) ...
            + (1-prob)*Second_Tree_option(2:idx+1,idx+1));
        % This computational process can be simplfied for European
        % options; However, the identical process is used in the
        % American option pricing.
        
    end
    
    % Output the option price
    Euro_option_price = Second_Tree_option(1);
    Euro_option_price_series = [Euro_option_price_series,Euro_option_price];
    
end
 
plot (S0_series,Euro_option_price_series);
xlim ([0,100])
xlabel('Stock price [USD]');
ylabel([Type_str, ' ', option_type,' option price [USD]']);
title([Type_str, ' ', option_type,' option price versus time to maturity']);
set(gcf,'color','white')
