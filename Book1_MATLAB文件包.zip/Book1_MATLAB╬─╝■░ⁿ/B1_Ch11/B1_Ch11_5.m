B1_Ch11_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
X_strike = 50;
%strike: strike price
S0_series = [0:1:100];
interest_r = 0.08;
% interest_r: risk-free interest rate
sigma = 0.3;
% sigma: volatility
Flag = 1; % 0 = put
T_series = [0.1:0.2:2];
Num_step = 200;
T = 1; % year
% T: time to maturity
T_length = length(T_series);
 
S0_length = length (S0_series);
 
Am_put_series = [];
Am_call_series = [];
 
for i = 1:S0_length
    
    S0 = S0_series(i);
    % S0: current stock price
    delta = T/T_length;
    Flag = 0;
    [~, Am_put_Price] = binprice(S0, X_strike, interest_r, ...
        T, delta, sigma, Flag);
    Flag = 1;
    [~, Am_call_Price] = binprice(S0, X_strike, interest_r, ...
        T, delta, sigma, Flag);
    % binprice: Binomial put and call American option pricing using Cox-Ross-Rubinstein model
    
    Am_put_series = [Am_put_series,Am_put_Price(1,1)];
    Am_call_series = [Am_call_series,Am_call_Price(1,1)];
    
end
 
figure(1)
 
plot (S0_series,Am_call_series,'b-'); hold on
plot (S0_series,Am_put_series,'r-'); hold on
plot (S0_series,Am_call_series - Am_put_series,'g-');
 
xlim ([0,100])
xlabel('Stock price [USD]');
ylabel(['Am. call/put price and price difference [USD]']);
legend('Am. call', 'Am. put', 'Difference')
set(gcf,'color','white')
 
figure(2)
 
plot (S0_series,Am_call_series - Am_put_series,'g'); hold on
plot (S0_series, S0_series - X_strike*exp(-interest_r*T),'b--'); hold on
plot (S0_series, S0_series - X_strike,'r--'); hold on
legend('Difference','Upper boundary', 'Lower boundary')
xlim ([0,100])
xlabel('Stock price [USD]');
ylabel(['Price difference [USD]']);
set(gcf,'color','white')
