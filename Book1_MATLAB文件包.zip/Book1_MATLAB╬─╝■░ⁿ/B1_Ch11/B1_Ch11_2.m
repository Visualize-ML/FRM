% B1_Ch11_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
S0 = 50; strike = 50;
r = 0.1; sigma = 0.3;
T = 1; Num_steps = 8;
 
dt=T/Num_steps;
N=(Num_steps)+1;
u=1+sigma*sqrt(dt);
d=1-sigma*sqrt(dt);
diff=u-d;
PV=exp(r*dt);
 
figure(1)
 
for j=N:-1:1
    for i=1:1:j
        ss(i)=S0*(d^(i-1))*(u^(j-i));
        if j==N
            Am_Call(i)=max(ss(i)-strike,0);
        else
            Am_Call(i)=max((Am_Call(i)-Am_Call(i+1))/diff+(u*Am_Call(i+1)-d*Am_Call(i))/(diff*PV),ss(i)-strike);
        end
    end
    
    subplot(2,1,1)
    scatter((j-1)*ones(j,1),ss(1:j))
    xlabel('Time Steps')
    ylabel('Stock price [USD]')
    hold on; box off
    subplot(2,1,2)
    scatter((j-1)*ones(j,1),Am_Call(1:j))
    xlabel('Time Steps')
    ylabel('Am. call price [USD]')
    ylim([0,100])
    hold on; box off
end
 
 
figure(2)
 
for j=N:-1:1
    for i=1:1:j
        ss(i)=S0*(d^(i-1))*(u^(j-i));
        if j==N
            Am_Put(i)=max(strike-ss(i),0);
        else
            Am_Put(i)=max((Am_Put(i)-Am_Put(i+1))/diff+(u*Am_Put(i+1)-d*Am_Put(i))/(diff*PV),strike-ss(i));
        end
    end
    
    subplot(2,1,1)
    scatter((j-1)*ones(j,1),ss(1:j))
    xlabel('Time Steps')
    ylabel('Stock price [USD]')
    hold on; box off
    
    subplot(2,1,2)
    scatter((j-1)*ones(j,1),Am_Put(1:j))
    xlabel('Time Steps')
    ylabel('Am. put price [USD]')
    hold on; box off
    ylim([0,100])
end

