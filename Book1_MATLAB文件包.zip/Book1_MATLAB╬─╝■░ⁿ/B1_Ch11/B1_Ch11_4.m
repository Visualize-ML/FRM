% B1_Ch11_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 1  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
spot_price_range = 0.01:1:100;
strike_price = 50;    % strike price
interest_rate = 0.1;  % risk-free interest rate
volatility = 0.35;    % annualized volatility
spot_price_length = length(spot_price_range);
maturity_range = [36, 24, 12, 6]; % month
maturity_length = length(maturity_range);
maturity_matrix = maturity_range(ones(spot_price_length,1),:)'/12;
 
maturity_range_holder = ones(length(maturity_range),1);
spot_price_matrix = spot_price_range(maturity_range_holder,:);
all_one_matrix = ones(size(maturity_matrix));
 
[call_option_price_matrix,put_option_price_matrix]  ...
    = blsprice(spot_price_matrix, ...
    strike_price*all_one_matrix, interest_rate*all_one_matrix,...
    maturity_matrix, volatility*all_one_matrix);
 
call_payoff_value = max(0, spot_price_range - strike_price);
put_payoff_value = max(0, strike_price - spot_price_range);
% Intrinsic value
 
% European call option
% Plot time value, intrinsic value versus stock price
 
figure (1)
 
for i = 1:maturity_length
    
    subplot(2,2,i)
    
    time_v_call = call_option_price_matrix(i,:) - call_payoff_value;
    x = spot_price_range;
    curve1 = time_v_call;
    curve2 = zeros(1,length(x));
    x2 = [x, fliplr(x)];
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    
    plot(spot_price_range, call_option_price_matrix(i,:)); hold on
    plot(spot_price_range, call_payoff_value); hold on
    
    legendCell{i} = num2str(maturity_range(i),'T = %-d months');
    plot (spot_price_range, time_v_call); hold on
    
    xlabel('Stock price [USD]');
    ylabel('Call option price [USD]');
    set(gcf,'color','white'); daspect([1 1 1])
    box off; set(gca, 'XAxisLocation', 'origin')
    ylim([0 80])
    title(['T - t = ', num2str(maturity_range(i)),' months'])
end
 
% European put option
% Plot time value, intrinsic value versus stock price
 
 
figure (2)
 
for i = 1:maturity_length
    
    subplot(2,2,i)
    
    time_v_put = put_option_price_matrix(i,:) - put_payoff_value;
    x = spot_price_range;
    curve1 = time_v_put;
    curve2 = zeros(1,length(x));
    x2 = [x, fliplr(x)];
    inBetween = [curve1, fliplr(curve2)];
    fill(x2, inBetween, 'g'); hold on
    
    plot(spot_price_range, put_option_price_matrix(i,:)); hold on
    plot(spot_price_range, put_payoff_value); hold on
    
    legendCell{i} = num2str(maturity_range(i),'T = %-d months');
    plot (spot_price_range, time_v_put); hold on
    
    xlabel('Stock price [USD]');
    ylabel('Put option price [USD]');
    set(gcf,'color','white'); daspect([1 1 1])
    box off; set(gca, 'XAxisLocation', 'origin')
    ylim([-20, 60])
    title(['T - t = ', num2str(maturity_range(i)),' months'])
end
