% B5_Ch9_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
%% Data input 
T = readtable('FactorModel_example.xlsx','Sheet','OneFactor');
 
%% Extract data
Date = T.Date;
Ticker = T.Properties.VariableNames(2:end-1)';
singlename_ExcessRet = T(:,2:end-1).Variables;
 
%% Calculate covariance
singlename_Covariance = cov(singlename_ExcessRet); 
 
%% Plot selected singlenames' historical value
figure(1)
subplot(2,1,1)
PriceLevel_raw = ret2price(singlename_ExcessRet(:,[10,16,25,28,36]),100);
plot(Date,PriceLevel_raw(2:end,:)); hold off;
xlabel('Date');
ylabel('Value');
title('EQ Excess Return Curve - Raw (selected names)');
legend(Ticker([10,16,25,28,36]),...
    'Location','bestoutside','Interpreter', 'none');
 
%% Traditional way to calculate GMVP
Weight_traditional = quadprog(singlename_Covariance,[],[],[],...
    ones(1,size(singlename_ExcessRet,2)),1,...
    zeros(size(singlename_ExcessRet,2),1),...
    ones(size(singlename_ExcessRet,2),1));
 
%% GMVP by traditional way
subplot(2,1,2)
bar(Weight_traditional(Weight_traditional > 0.001)'*100, 'BarWidth', 0.4)
set(gca,'xticklabel',Ticker(Weight_traditional > 0.001));
title('Allocation(%) - traditional approach')
text(1:length(Weight_traditional(Weight_traditional > 0.001)),...
    Weight_traditional(Weight_traditional > 0.001)'*100,...
    num2str(Weight_traditional(Weight_traditional > 0.001)*100, '%0.1f')...
,'vert','bottom','horiz','center');
box off
 
 
%% PCA analysis
[Factor_Loading_F,Factor_Ret_F,latent_F,tsq_F,explained_F,mu_F]...
    = pca(singlename_ExcessRet);
% Factor_Loading
% Factor_Ret: Principal Component scores
% latent: Principal Component variances
% tsquared: T-squared statistic for each observation
% explained: the percentage of the total variance explained by each PC
% mu: the estimated mean of each variable
figure(2)
subplot(2,1,1)
bar(explained_F,0.8)
title('The percentage of the total variance explained by each PC')
text(1:length(explained_F),explained_F,...
    num2str(explained_F, '%0.1f'),'vert','bottom','horiz','center');
box off
 
subplot(2,1,2)
bar(cumsum(explained_F),0.4)
title('The cumulative % of the total variance explained by PC')
text(1:length(explained_F),cumsum(explained_F),...
    num2str(cumsum(explained_F), '%0.0f'),...
    'vert','bottom','horiz','center');
box off
 
%% Plot the first four PC's weights
figure(3)
for i=1:4
    subplot(2,2,i)
    bar(categorical(Ticker),Factor_Loading_F(:,i)*100,0.4)
    title(['Weights (%) assigned for PC ',num2str(i)])
    text(1:size(Factor_Loading_F,1),Factor_Loading_F(:,i)*100,...
        num2str(Factor_Loading_F(:,i)*100, '%0.0f'),...
        'vert','bottom','horiz','center');
    box off
end
 
%% for 1, 10, 20 number of PCs, conduct GMVP calculation
for m = [1 10 20]
    [Factor_Loading,Factor_Ret,latent,tsq,explained,mu]...
        = pca(singlename_ExcessRet, 'NumComponents', m);
 
    FactorExplained_Ret = Factor_Ret*Factor_Loading' + mu;
    Residual_Ret = singlename_ExcessRet - FactorExplained_Ret;
 
    % Plot selected singlenames' historical value by PCA
    figure
    subplot(2,1,1)
    PriceLevel_pca = ret2price(FactorExplained_Ret(:,[10,16,25,28,36]),100);
    plot(Date,PriceLevel_pca(2:end,:)); hold off;
    xlabel('Date');
    ylabel('Value');
    title(['Factor Explained Excess Return Curve with ',...
        num2str(m), ' principal components (selected names)']);
    legend(Ticker([10,16,25,28,36]), 'Location','bestoutside');
 
    % calculate covariance using PCA model
    PCA_model_cov = Factor_Loading*cov(Factor_Ret)*Factor_Loading'...
        + diag(diag(cov(Residual_Ret)));
 
    % Factor approach to calculate GMVP
    Weight_factor = quadprog(PCA_model_cov,[],[],[],...
        ones(1,size(singlename_ExcessRet,2)),1,...
        zeros(size(singlename_ExcessRet,2),1),...
        ones(size(singlename_ExcessRet,2),1));
 
    % GMVP allocation
    subplot(2,1,2)
    bar(Weight_factor(Weight_factor > 0.001)'*100, 'BarWidth', 0.4)
    set(gca,'xticklabel',Ticker(Weight_factor > 0.001));
    title(['Allocation(%) - PCA approach with ', num2str(m),...
        ' principal components'])
    text(1:length(Weight_factor(Weight_factor > 0.001)),...
        Weight_factor(Weight_factor > 0.001)'*100,...
        num2str(Weight_factor(Weight_factor > 0.001)*100, '%0.1f')...
    ,'vert','bottom','horiz','center');
    box off
 
end
 
%% Plot Min Variance Portfolio Excess Return Curve
MinVar_Port_TR_raw = singlename_ExcessRet*Weight_traditional;
 
figure
MinVar_Port_TR_Curve_raw = ret2price(MinVar_Port_TR_raw,100);
plot(Date,MinVar_Port_TR_Curve_raw(2:end,:)); hold off;
xlabel('Date');
ylabel('Value');
title('Min Variance Portfolio Excess Return Curve');
 
%% Plot Min Variance Portfolio Excess Return Curve with # of PC from 1 to all
MinVar_Port_TR_PCA = zeros(size(singlename_ExcessRet));
 
for k = 1:size(MinVar_Port_TR_PCA,2)
    [Factor_Loading,Factor_Ret,latent,tsq,explained,mu]...
        = pca(singlename_ExcessRet, 'NumComponents', k);
    FactorExplained_Ret = Factor_Ret*Factor_Loading' + mu;
    Residual_Ret = singlename_ExcessRet - FactorExplained_Ret;
    PCA_model_cov = Factor_Loading*cov(Factor_Ret)*Factor_Loading'...
        + diag(diag(cov(Residual_Ret)));
 
    Weight_factor = quadprog(PCA_model_cov,[],[],[],...
        ones(1,size(singlename_ExcessRet,2)),1,...
        zeros(size(singlename_ExcessRet,2),1),...
        ones(size(singlename_ExcessRet,2),1));
 
    MinVar_Port_TR_PCA(:,k) = singlename_ExcessRet*Weight_factor;
end
 
MinVar_Port_TR_Curve_PCA = ret2price(MinVar_Port_TR_PCA,100);
 
 
figure
subplot(2,2,[1,3])
mesh(1:size(MinVar_Port_TR_PCA,2),Date, MinVar_Port_TR_Curve_PCA(2:end,:)...
    ,'MeshStyle','both'); hold off
xlabel('Number of Principal Components');
ylabel('Date');
title('Min Variance Portfolio Excess Return Curve with # of PC from 1 to all');
grid off
view([0.5,-0.5,0.3])
 
subplot(2,2,2)
mesh(1:size(MinVar_Port_TR_PCA,2),Date, MinVar_Port_TR_Curve_PCA(2:end,:)...
    ,'MeshStyle','row'); hold off
xlabel('Number of Principal Components');
ylabel('Date');
grid off
view([0,1,0])
 
subplot(2,2,4)
mesh(1:size(MinVar_Port_TR_PCA,2),Date, MinVar_Port_TR_Curve_PCA(2:end,:)...
    ,'MeshStyle','column'); hold off
xlabel('Number of Principal Components');
ylabel('Date');
grid off
view([1,0,0])
