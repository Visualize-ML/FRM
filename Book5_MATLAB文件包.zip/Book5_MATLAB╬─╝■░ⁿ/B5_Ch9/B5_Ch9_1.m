% B5_Ch9_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
%% Data input 
T = readtable('FactorModel_example.xlsx','Sheet','OneFactor');
 
%% Extract data
Ticker = T.Properties.VariableNames(2:end-1)';
singlename_ExcessRet = T(:,2:end-1).Variables;
Mkt_ExcessRet = T(:,end).Variables;
 
%% Calculate covariance, singlename volatilty (standard deviation) 
singlename_Covariance = cov(singlename_ExcessRet); 
singlename_Correlation = corrcoef(singlename_ExcessRet);
 
% calculate singlename volatility
singlename_std = sqrt(diag(singlename_Covariance))*sqrt(12); % annualized
 
% calculate MKT volatility
Mkt_std=std(Mkt_ExcessRet)*sqrt(12);
 
%% calculate beta, R_sqr, Systematic Risk, Idiosyncratic Risk
cross_Cov = ((singlename_ExcessRet'*Mkt_ExcessRet)/(size(Mkt_ExcessRet,1)-1)...
    - mean(singlename_ExcessRet)'*mean(Mkt_ExcessRet))';
 
beta_array  = (cov(Mkt_ExcessRet)\cross_Cov)';
 
%% calculate Residual covariance & correlation
ResidualRet = singlename_ExcessRet - Mkt_ExcessRet*beta_array';
Residual_Covariance = cov(ResidualRet);
Residual_Correlation = corrcoef(ResidualRet);
 
%% calculate R_sqr, Systematic Risk, Idiosyncratic Risk
rho_array = diag(corr(singlename_ExcessRet,Mkt_ExcessRet*beta_array'));
R_sqr_array = rho_array.^2;
Sys_Risk = R_sqr_array;
Idio_Risk = 1- Sys_Risk;
 
%% calculate covariance using one-factor market model
Mkt_model_Covariance = beta_array *cov(Mkt_ExcessRet)*beta_array' + diag(diag(Residual_Covariance));
Mkt_model_Correlation = Mkt_model_Covariance./(singlename_std*singlename_std');
 
%% Traditional way to calculate GMVP
Weight_traditional = quadprog(singlename_Covariance,[],[],[],...
    ones(1,size(singlename_ExcessRet,2)),1,...
    zeros(size(singlename_ExcessRet,2),1),ones(size(singlename_ExcessRet,2),1));
 
%% One-factor approach to calculate GMVP
Weight_factor = quadprog(Mkt_model_Covariance,[],[],[],...
    ones(1,size(singlename_ExcessRet,2)),1,...
    zeros(size(singlename_ExcessRet,2),1),ones(size(singlename_ExcessRet,2),1));
 
%% GMVP allocation
figure
 
subplot(2,1,1)
bar(Weight_traditional(Weight_traditional > 0.001)'*100, 'BarWidth', 0.4)
set(gca,'xticklabel',Ticker(Weight_traditional > 0.001));
ylabel('Allocation(%) - traditional approach')
text(1:length(Weight_traditional(Weight_traditional > 0.001)),...
    Weight_traditional(Weight_traditional > 0.001)'*100,...
    num2str(Weight_traditional(Weight_traditional > 0.001)*100, '%0.3f')...
,'vert','bottom','horiz','center');
box off
 
subplot(2,1,2)
bar(Weight_factor(Weight_factor > 0.001)'*100, 'BarWidth', 0.4)
set(gca,'xticklabel',Ticker(Weight_factor > 0.001));
ylabel('Allocation(%) - factor approach')
text(1:length(Weight_factor(Weight_factor > 0.001)),...
    Weight_factor(Weight_factor > 0.001)'*100,...
    num2str(Weight_factor(Weight_factor > 0.001)*100, '%0.3f')...
,'vert','bottom','horiz','center');
box off
