% B5_Ch11_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
rng('default') % For reproducibility
syms x1 x2
 
N = 1500;
% X = [mvnrnd([-2 0],[1.5,0.5;0.5,1.5],N/3); ...
%     mvnrnd([3 -3],[1,0;0,1],N/3); ...
%     mvnrnd([3 3],[1,-0.6;-0.6,1],N/3)];
 
mu = [-2, 0; 3 -3; 3 3];
% three mean values
 
sigma = cat(3,[1.5,0.5;0.5,1.5],[1,0;0,1],[1,-0.6;-0.6,1]);
% three covariance matrices
 
alpha = [1/3, 1/3, 1/3];
% mixing proportions
fig_i = 1;
 
GMM = gmdistribution(mu,sigma,alpha);
properties(GMM)
 
%% simulate random numbers
num_data = 1000;
X_data = random(GMM,num_data);
 
figure(fig_i)
fig_i = fig_i + 1;
 
h1 = scatter(X_data(:,1),X_data(:,2),40,'.');
h1.MarkerEdgeColor = [0.4,0.4,0.4];
xlabel('x1');ylabel('x2');
axis square; grid off; box off
xlim([-6,6]);ylim([-6,6]);
%% plot the contour of GMM PDF
 
gmPDF = @(x,y)reshape(pdf(GMM,[x(:) y(:)]),size(x));
 
figure(fig_i)
fig_i = fig_i + 1;
 
subplot(1,2,1)
h_mesh = fmesh(gmPDF,[-6 6]);
h_mesh.FaceAlpha = 0;
xlabel('x1');ylabel('x2');
grid off; box off
xlim([-6,6]);ylim([-6,6]);view(-30,60)
 
% plot the contour of GMM CDF
subplot(1,2,2)
gmCDF = @(x,y)reshape(cdf(GMM,[x(:) y(:)]),size(x));
 
h_mesh = fmesh(gmCDF,[-6 6]);
h_mesh.FaceAlpha = 0;
xlabel('x1');ylabel('x2');
grid off; box off
xlim([-6,6]);ylim([-6,6]);view(-30,60)
 
%% Choices of different numbers of clusters
 
options = statset('MaxIter',1000);
 
for j = 1:3
    GMModels{j} = fitgmdist(X_data,j,'Options',options);
    fprintf('\n GM Mean for %i Component(s)\n',j)
    Mu = GMModels{j}.mu
end
 
[X1, X2] = meshgrid(-6:.2:6,-6:.2:6);
 
for j = 1:3
    figure(fig_i)
    fig_i = fig_i + 1;
    h1 = scatter3(X_data(:,1),X_data(:,2),0*X_data(:,2),40,'.');
    h1.MarkerEdgeColor = [0.4,0.4,0.4];
    
    hold on
    
    gmPDF = @(x1,x2)arrayfun(@(x1,x2)pdf(GMModels{j},[x1(:) x2(:)]),x1,x2);
    F  = feval(gmPDF,X1,X2);
    
    h = mesh(X1,X2,F);
    
    h.FaceAlpha = 0;
    
    title(sprintf('GM Model - %i Component(s)',j));
    xlabel('x1'); ylabel('x2');
    axis tight; grid off; box off
    view(-30,60); xlim([-6,6]);ylim([-6,6]);
    
    figure(fig_i)
    fig_i = fig_i + 1;
    h1 = scatter(X_data(:,1),X_data(:,2),40,'.');
    h1.MarkerEdgeColor = [0.4,0.4,0.4];
    h = gca;
    hold on
    gmPDF = @(x1,x2)arrayfun(@(x1,x2)pdf(GMModels{j},[x1(:) x2(:)]),x1,x2);
    % f = matlabFunction(gmPDF);
    F  = feval(gmPDF,X1,X2);
    h = contour(X1,X2,F,15);
    
    title(sprintf('GMM - %i component(s)',j));
    xlabel('x1'); ylabel('x2');
    axis square; grid off; box off
    xlim([-6,6]);ylim([-6,6]);
    
end
 
%% Compute the posterior probabilities of three components.
 
posterior_C = posterior(GMM,X_data);
% P(i,j) is the posterior probability of the jth
% Gaussian mixture component given observation i.
 
figure(fig_i)
fig_i = fig_i + 1;
 
subplot(2,2,1)
 
h1 = scatter(X_data(:,1),X_data(:,2),20,'.');
h1.MarkerEdgeColor = [0.4,0.4,0.4];
xlabel('x1');ylabel('x2');
axis square; grid off; box off
xlim([-6,6]);ylim([-6,6]);
 
for i = 1:3
    subplot(2,2,i+1)
    scatter(X_data(:,1),X_data(:,2),20,posterior_C(:,i),'.')
    hold on
    plot(mu(:,1),mu(:,2),'xr','MarkerSize',12,'LineWidth',2)
    colorbar
    title(['Posterior, p(C_',num2str(i),' | x)'])
    xlabel('x1');ylabel('x2');
    axis square; grid off; box off
    xlim([-6,6]);ylim([-6,6]);
end
 
%% plot posterior grid
XX1 = X1(:);
XX2 = X2(:);
posterior_Grid = posterior(GMM,[XX1,XX2]);
posterior_Grid_C1 = reshape(posterior_Grid(:,1),size(X1));
posterior_Grid_C2 = reshape(posterior_Grid(:,2),size(X1));
posterior_Grid_C3 = reshape(posterior_Grid(:,3),size(X1));
 
figure(fig_i)
fig_i = fig_i + 1;
hold all
h = mesh(X1,X2,posterior_Grid_C1);
h.FaceAlpha = 0;
h = mesh(X1,X2,posterior_Grid_C2);
h.FaceAlpha = 0;
h = mesh(X1,X2,posterior_Grid_C3);
h.FaceAlpha = 0;
 
contour3(X1,X2,posterior_Grid_C1,[0.5,0.5],'r','LineWidth',1);
contour3(X1,X2,posterior_Grid_C2,[0.5,0.5],'r','LineWidth',1);
contour3(X1,X2,posterior_Grid_C3,[0.5,0.5],'r','LineWidth',1);
xlabel('x1');ylabel('x2');
grid off; box off
xlim([-6,6]);ylim([-6,6]);view(-30,60)
xticks([-5,0,5]);yticks([-5,0,5]);
%% partition the data into three clusters
 
idx = cluster(GMM,X_data);
 
figure(fig_i)
fig_i = fig_i + 1;
gscatter(X_data(:,1),X_data(:,2),idx);
xlabel('x1');ylabel('x2');
axis square; grid off; box off
xlim([-6,6]);ylim([-6,6]);
 
idx = cluster(GMM,[XX1,XX2]);
 
figure(fig_i)
fig_i = fig_i + 1;
gscatter(XX1,XX2,idx);
xlabel('x1');ylabel('x2');
axis square; grid off; box off
xlim([-6,6]);ylim([-6,6]);
