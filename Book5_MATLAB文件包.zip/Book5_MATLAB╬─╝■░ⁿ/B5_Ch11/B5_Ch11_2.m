% B5_Ch11_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
X(:,1) = X(:,1)/1000;
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
colors = [0,153,219; 146,208,80;]/255; % labels: -1, 1
h = gscatter(X(:,1),X(:,2),Y,colors,'.');
xlabel('Sepal length'); ylabel('Sepal width');
hold off; axis square; legend off;
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
xlim([min(X(:,1)),max(X(:,1))]); ylim([min(X(:,2)),max(X(:,2))])
 
%% Decision tree
 
x1range = min(X(:,1)):1:max(X(:,1));
x2range = min(X(:,2)):25:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
 
MdlDefault = fitctree(X,Y);
 
view(MdlDefault)
view(MdlDefault,'mode','graph')
 
predictedspecies = predict(MdlDefault,XGrid);
 
figure(i_fig)
i_fig = i_fig + 1;
contour(x1Grid,x2Grid,reshape(predictedspecies,size(x1Grid)),[0 0],'r','LineWidth',1.25);
hold on
h = gscatter(X(:,1),X(:,2),Y,colors,'.');
h1 = h(1); h1.MarkerSize = 8;
h2 = h(2); h2.MarkerSize = 8;
xlim([min(X(:,1)),max(X(:,1))])
ylim([min(X(:,2)),max(X(:,2))])
hold off; axis square; legend off
legend off;
hold off; axis square
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
legend off;
 
function [X,Y] = generate_rnd(num)
% num = 100; % test only
rng(1); % For reproducibility
mu1 = [25000 450]; % income, credit score
mu2 = [85000 700];
sigma1 = [15000, 0; 0, 100] *[1 0.3;0.3 1]*[15000, 0; 0, 100];
sigma2 = [20000, 0; 0, 75]*[1 0.2;0.2 1]*[20000, 0; 0, 75];
 
X = [mvnrnd(mu1,sigma1,ceil(num*0.6));
    mvnrnd(mu2,sigma2,num - ceil(num*0.6))];
mask1 = (or((X(:,2) >= 900),(X(:,2) <= 300)));
X(mask1,:)= nan;
mask2 = (X(:,1) <= 0);
X(mask2,:)= nan;
masks = (X == nan);
mask = or(masks(:,1),masks(:,2));
 
Y = -ones(num,1);
Y(ceil(num*0.6) + 1:end) = 1; % Labels
Y(mask) = nan;
end
