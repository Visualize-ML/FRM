% B5_Ch11_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
% Generate training data set
num = 100; % half of the data size in dataset
% [X,Y] = linear_div_rnd(num);
% [X,Y] = circular_rnd(num);
% [X,Y] = crescent_rnd(num);
[X,Y] = quadrant_rnd(num);
 
Y_plus = nan(size(Y));
masks = (Y == 1);
Y_plus(masks) = 1;
X_plus = X;
X_plus (~masks,:) = NaN;
 
Y_minus(~masks) = -1;
X_minus = X;
X_minus (masks,:) = NaN;
 
figure(1)
hold on
plot(X_plus(:,1),X_plus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_minus(:,1),X_minus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
 
axis equal; hold off
xlabel('x_1'); ylabel('x_2')
legend({'+1','-1'});
% set(gca,'xtick',[]); set(gca,'xticklabel',[])
% set(gca,'ytick',[]); set(gca,'yticklabel',[])
 
 
%% Choose one SVM kernel function
% linear:
cl = fitcsvm(X,Y,'KernelFunction','linear',...
    'BoxConstraint',1,'ClassNames',[-1,1]);
 
% polynomial:
% cl = fitcsvm(X,Y,'KernelFunction','polynomial',...
%     'BoxConstraint',1,'ClassNames',[-1,1]);
 
% Gaussian
% cl = fitcsvm(X,Y,'KernelFunction','rbf',...
%     'BoxConstraint',1,'ClassNames',[-1,1]);
 
% Sigmoid, self-defined
% cl = fitcsvm(X,Y,'KernelFunction','sigmoid2',...
%     'Standardize',true);
 
% Predict scores over the grid
step_size = 0.02;
[x1Grid,x2Grid] = meshgrid(min(X(:,1)):step_size:max(X(:,1)),...
    min(X(:,2)):step_size:max(X(:,2)));
xGrid = [x1Grid(:),x2Grid(:)];
[~,scores] = predict(cl,xGrid);
 
%% Plot the data and the decision boundary
 
figure(2)
hold on
plot(X_plus(:,1),X_plus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
plot(X_minus(:,1),X_minus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
plot(X(cl.IsSupportVector,1),X(cl.IsSupportVector,2),'ko')
contour(x1Grid,x2Grid,reshape(scores(:,2),size(x1Grid)),[0 0],'r','LineWidth',1.25);
% xlabel('x_1'); ylabel('x_2')
 
legend({'+1','-1','Support Vectors','Hyperplane'});
axis equal; hold off
set(gca,'xtick',[]); set(gca,'xticklabel',[])
set(gca,'ytick',[]); set(gca,'yticklabel',[])
 
%% Demonstrate kernel function
 
step_size = 0.1;
[x1Grid,x2Grid] = meshgrid(min(X(:,1)):step_size:max(X(:,1)),...
    min(X(:,2)):step_size:max(X(:,2)));
xGrid = [x1Grid(:),x2Grid(:)];
[~,scores] = predict(cl,xGrid);
[~,scores_X] = predict(cl,X);
kernel_y = scores_X(:,2);
kernel_y_plus = kernel_y;
kernel_y_plus (~masks,:) = NaN;
kernel_y_minus = kernel_y;
kernel_y_minus (masks,:) = NaN;
kernel_Grid = reshape(scores(:,2),size(x1Grid));
 
 
figure(3)
mesh(x1Grid(1:2:end,1:2:end),x2Grid(1:2:end,1:2:end),...
    kernel_Grid(1:2:end,1:2:end),'FaceAlpha',0); hold on
 
plot3(X_plus(:,1),X_plus(:,2),kernel_y_plus,...
    'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
plot3(X_minus(:,1),X_minus(:,2),kernel_y_minus,...
    'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
plot3(X(cl.IsSupportVector,1),X(cl.IsSupportVector,2),kernel_y(cl.IsSupportVector),'ko')
 
contour3(x1Grid,x2Grid,reshape(scores(:,2),size(x1Grid)),[0 0],'r','LineWidth',1.25);
grid off
% set(gca,'xtick',[]); set(gca,'xticklabel',[])
% set(gca,'ytick',[]); set(gca,'yticklabel',[])
% set(gca,'ztick',[]); set(gca,'zticklabel',[])
xlabel('x_1'); ylabel('x_2'); zlabel('Kernel')
xlim([min(x1Grid(:)),max(x1Grid(:))])
ylim([min(x2Grid(:)),max(x2Grid(:))])
zlim([min(kernel_Grid(:)),max(kernel_Grid(:))])
view(-45,30)
% view([0,0,1])
% view([0,1,0])
 
figure(4)
contour(x1Grid,x2Grid,reshape(scores(:,2),size(x1Grid)),20); hold on
 
plot(X_plus(:,1),X_plus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
plot(X_minus(:,1),X_minus(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
plot(X(cl.IsSupportVector,1),X(cl.IsSupportVector,2),'ko')
contour(x1Grid,x2Grid,reshape(scores(:,2),size(x1Grid)),[0 0],'r','LineWidth',1.25);
axis equal; hold off
xlabel('x_1'); ylabel('x_2');
axis equal
xlim([min(x1Grid(:)),max(x1Grid(:))])
ylim([min(x2Grid(:)),max(x2Grid(:))])
% set(gca,'xtick',[]); set(gca,'xticklabel',[])
% set(gca,'ytick',[]); set(gca,'yticklabel',[])
