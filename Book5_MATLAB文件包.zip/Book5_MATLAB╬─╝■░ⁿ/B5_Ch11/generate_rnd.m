function [X,Y] = generate_rnd(num)
% num = 100; % test only
rng(1); % For reproducibility
mu1 = [30000 450]; % income, credit score
mu2 = [70000 650];
sigma1 = [15000, 0; 0, 100] *[1 0.3;0.3 1]*[15000, 0; 0, 100];
sigma2 = [20000, 0; 0, 75]*[1 0.2;0.2 1]*[20000, 0; 0, 75];
 
X = [mvnrnd(mu1,sigma1,ceil(num*0.6));
    mvnrnd(mu2,sigma2,num - ceil(num*0.6))];
mask1 = (or((X(:,2) >= 900),(X(:,2) <= 300)));
X(mask1,:)= nan;
mask2 = (X(:,1) <= 0);
X(mask2,:)= nan;
masks = (X == nan);
mask = or(masks(:,1),masks(:,2));
 
Y = -ones(num,1);
Y(ceil(num*0.6) + 1:end) = 1; % Labels
Y(mask) = nan;
end
