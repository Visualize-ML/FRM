% B5_Ch11_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc

num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
X(:,1) = X(:,1)/1000;

i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
colors = [0,153,219; 146,208,80;]/255; % labels: -1, 1
h = gscatter(X(:,1),X(:,2),Y,colors,'.');
xlabel('Sepal length'); ylabel('Sepal width');
hold off; axis square; legend off;
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
xlim([min(X(:,1)),max(X(:,1))]); ylim([min(X(:,2)),max(X(:,2))])

%% Types of classifiers

x1range = min(X(:,1)):1:max(X(:,1));
x2range = min(X(:,2)):5:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];

classifier_name = {'Naive Bayes','Discriminant Analysis',...
    'Classification Tree','Nearest Neighbor'};

% Train a naive Bayes model.
classifier{1} = fitcnb(X,Y);
% Default: Gaussian

% Train a discriminant analysis classifier.
classifier{2} = fitcdiscr(X,Y);
% Default: linear

% Train a classification decision tree.
classifier{3} = fitctree(X,Y,'MaxNumSplits',5);

% Train a k-nearest neighbor classifier.
classifier{4} = fitcknn(X,Y,'NumNeighbors',20);

figure(i_fig)
i_fig = i_fig + 1;

for i = 1:numel(classifier)
    
    predictedspecies = predict(classifier{i},XGrid);
    subplot(2,2,i)
    contour(x1Grid,x2Grid,reshape(predictedspecies,size(x1Grid)),[0 0],'r','LineWidth',1.25);
    hold on
    h = gscatter(X(:,1),X(:,2),Y,colors,'.');
    h1 = h(1); h1.MarkerSize = 8;
    h2 = h(2); h2.MarkerSize = 8;
    xlim([min(X(:,1)),max(X(:,1))])
    ylim([min(X(:,2)),max(X(:,2))])
    hold off; axis square; legend off
    legend off;
    hold off; axis square
    xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
    legend off;
    
    title(classifier_name{i})
    
end

%% Confusion Matrix Charts

for i = 1:numel(classifier)
    figure(i_fig)
    i_fig = i_fig + 1;
    
    predictedY = resubPredict(classifier{i});
    cm = confusionchart(Y,predictedY);
    cm.RowSummary = 'row-normalized';
    cm.ColumnSummary = 'column-normalized';
    sortClasses(cm,[1,-1])
    title(classifier_name{i})
    
end

%% ROC curves

AUCs = ones(numel(classifier),1);

for i = 1:numel(classifier)
    
    [~,scores1] = resubPredict(classifier{i});
    classifier{i}.ClassNames
    
    [x1,y1,~,auc1] = perfcurve(Y,scores1(:,2),1);
    ROC_x{i}= x1;
    ROC_y{i}= y1;
    SCORES{i}= scores1;
    
    AUCs(i) = auc1;
    
end

figure(i_fig)
i_fig = i_fig + 1;
hold on
for i = 1:numel(classifier)
    
    plot(ROC_x{i},ROC_y{i});
    
end

legend(classifier_name)
xlabel('FPR, false positive rate');
ylabel('TPR, true positive rate');

figure(i_fig)
i_fig = i_fig + 1;

labels = categorical(classifier_name);
labels = reordercats(labels,classifier_name);

barh(labels,AUCs,0.5)
xlim([0.8,1])
box off; grid off
xlabel('AUC')

function [X,Y] = generate_rnd(num)
% num = 100; % test only
rng(1); % For reproducibility
mu1 = [30000 450]; % income, credit score
mu2 = [70000 650];
sigma1 = [15000, 0; 0, 100] *[1 0.3;0.3 1]*[15000, 0; 0, 100];
sigma2 = [20000, 0; 0, 75]*[1 0.2;0.2 1]*[20000, 0; 0, 75];

X = [mvnrnd(mu1,sigma1,ceil(num*0.6));
    mvnrnd(mu2,sigma2,num - ceil(num*0.6))];
mask1 = (or((X(:,2) >= 900),(X(:,2) <= 300)));
X(mask1,:)= nan;
mask2 = (X(:,1) <= 0);
X(mask2,:)= nan;
masks = (X == nan);
mask = or(masks(:,1),masks(:,2));

Y = -ones(num,1);
Y(ceil(num*0.6) + 1:end) = 1; % Labels
Y(mask) = nan;
end


