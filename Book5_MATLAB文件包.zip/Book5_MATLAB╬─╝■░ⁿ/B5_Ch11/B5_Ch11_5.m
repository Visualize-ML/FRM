% B5_Ch11_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch11_5_A.m

clear all; close all; clc
rng('default') % For reproducibility
syms x1 x2
 
N = 1500;
% X = [mvnrnd([-2 0],[1.5,0.5;0.5,1.5],N/3); ...
%     mvnrnd([3 -3],[1,0;0,1],N/3); ...
%     mvnrnd([3 3],[1,-0.6;-0.6,1],N/3)];
 
mu = [-2, 0; 3 -3; 3 3];
% three mean values
 
sigma = cat(3,[1.5,1;1,1.5],[1,0.5;0.5,3],[1,-0.1;-0.1,0.2]);
% three covariance matrices
 
alpha = [0.4, 0.35, 0.25];
% mixing proportions

colors = [0,153,219; 146,208,80; 255,153,255]/255;
GMM = gmdistribution(mu,sigma,alpha);
 
% simulate random numbers
num_data = 400;
X_data = random(GMM,num_data);
 
num_C = 3; % Number of GMM components
options = statset('MaxIter',1000);
 
sigma_spec = {'diagonal','full'}; 
% Options for covariance matrix type
nSigma = numel(sigma_spec);
 
SharedCovariance = {true,false}; 
% Indicator for identical or nonidentical covariance matrices
SCtext = {'true','false'};
nSC = numel(SharedCovariance);
 
num_grid = 500; % Grid length
x1 = linspace(min(X_data(:,1))-2, max(X_data(:,1))+2, num_grid);
x2 = linspace(min(X_data(:,2))-2, max(X_data(:,2))+2, num_grid);
[x1grid,x2grid] = meshgrid(x1,x2);
X_grid = [x1grid(:) x2grid(:)];
 
threshold = sqrt(chi2inv(0.99,2));
% confidence region

figure
count = 1;
for i = 1:nSigma
    for j = 1:nSC
        gmfit = fitgmdist(X_data,num_C,'CovarianceType',sigma_spec{i}, ...
            'SharedCovariance',SharedCovariance{j},'Options',options); % Fitted GMM
        cluster_X_data = cluster(gmfit,X_data); % Cluster index of X
        cluster_X_grid = cluster(gmfit,X_grid); % Cluster index
        mahalDist = mahal(gmfit,X_grid); % Distance from each grid point to each GMM component
        % Draw ellipsoids over each GMM component and show clustering result.
        subplot(2,2,count);
        h1 = gscatter(X_data(:,1),X_data(:,2),cluster_X_data,colors,'.',5);
        hold on
        for m = 1:num_C
            contour(x1grid,x2grid,reshape(mahalDist(:,m),size(x1grid)),[threshold,threshold],'k')
        end
        contour(x1grid,x2grid,reshape(cluster_X_grid,size(x1grid)),[1.5,1.5],'r')
        contour(x1grid,x2grid,reshape(cluster_X_grid,size(x1grid)),[2.5,2.5],'r')
        plot(gmfit.mu(:,1),gmfit.mu(:,2),'kx','LineWidth',2,'MarkerSize',10)
        title(sprintf('Sigma is %s\nShared covariance = %s',sigma_spec{i},SCtext{j}),'FontSize',8)
        legend off; hold off; axis square
        count = count + 1; xlabel('x_1'); ylabel('x_2')
        xlim([-6,6]); ylim([-6,6]); box off; grid off
    end
end

% B5_Ch11_5_B.m

%% Tune Gaussian model
nK = 6;
CK = 1:nK;
gm = cell(nK,nSigma,nSC);
aic = zeros(nK,nSigma,nSC);
bic = zeros(nK,nSigma,nSC);
converged = false(nK,nSigma,nSC);
 
% Fit all models
for m = 1:nSC
    for j = 1:nSigma
        for i = 1:nK
            gm{i,j,m} = fitgmdist(X_data,CK(i),...
                'CovarianceType',sigma_spec{j}, ...
                'SharedCovariance',SharedCovariance{m},...
                'Options',options);
            
            aic(i,j,m) = gm{i,j,m}.AIC;
            bic(i,j,m) = gm{i,j,m}.BIC;
        end
    end
end
 
 
figure
bar(reshape(aic,nK,nSigma*nSC));
xlabel('Number of clusters'); ylabel('AIC');
legend({'Diagonal-shared','Full-shared','Diagonal-unshared',...
    'Full-unshared'},'Location', 'best');
ylim([3100,3900])
legend('boxoff'); box off
 
figure
bar(reshape(bic,nK,nSigma*nSC));
xlabel('Number of clusters'); ylabel('BIC');
legend({'Diagonal-shared','Full-shared','Diagonal-unshared',...
    'Full-unshared'},'Location', 'best');
ylim([3100,3900])
legend('boxoff'); box off
