% B5_Ch3_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% test_callableBond2
clc; close all; clear all;
ZeroRates0 = [ 0.035;0.04;0.045];
Compounding = 1;
StartDates = ['jan-1-2007';'jan-1-2008';'jan-1-2009'];
EndDates   = ['jan-1-2008';'jan-1-2009';'jan-1-2010'];
ValuationDate = 'jan-1-2007';
 
Rates_temp =  (-0.025:0.001:0.01 )';
% Rates_temp = 0.0;
PriceCallBondHW=zeros (length (Rates_temp ),1 );
PriceBondHW=zeros (length (Rates_temp ),1 );
Rate=zeros (length (Rates_temp ),1 );
for i = 1:length (Rates_temp )
ZeroRates=ZeroRates0-Rates_temp (i );
Rate (i )=ZeroRates (1 );
RateSpec = intenvset ('Rates', ZeroRates, 'StartDates', ValuationDate, 'EndDates', ...
EndDates, 'Compounding', Compounding, 'ValuationDate', ValuationDate );
 
VolDates = ['jan-1-2008';'jan-1-2009';'jan-1-2010'];
VolCurve = 0.01;
AlphaDates = 'jan-1-2010';
AlphaCurve = 0.1;
HWVolSpec = hwvolspec (ValuationDate, VolDates, VolCurve, AlphaDates, AlphaCurve );
 
HWTimeSpec = hwtimespec (ValuationDate, EndDates, Compounding );
 
HWTree = hwtree (HWVolSpec, RateSpec, HWTimeSpec );
 
BondSettlement = 'jan-1-2007';
BondMaturity   = 'jan-1-2010'; 
CouponRate = 0.0525;
Period = 1;
OptSpec = 'put'; 
Strike = [100];  
ExerciseDates = {'jan-1-2008' '01-Jan-2010'}; 
AmericanOpt = 1;
 
PriceCallBondHW (i ) = optembndbyhw (HWTree, CouponRate, BondSettlement, BondMaturity,...
'call', Strike, ExerciseDates,'Period', 1, 'AmericanOpt', 1 );

PriceBondHW (i ) = bondbyhw (HWTree, CouponRate, BondSettlement, BondMaturity,...
    'Period', 1 );
 
end
figure;
 
plot (Rate*100,PriceCallBondHW );
hold on;
plot (Rate*100,PriceBondHW );
 
xlabel ('Interest rate  (% )' );
ylabel ('Bond price ' );
% title ('Time to maturity = 0~1 year' )
 
grid off; box off
set (gca, 'FontName', 'Times New Roman','fontsize',10 )
% axis equal
 
xlim ([2 6.5] );
ylim ([94 106] );
