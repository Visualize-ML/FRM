% B5_Ch3_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all;
Settle = ' Jan-21-2018';
Reset = 4;
Principal = 1000;
MarketStrike = [0.0590; 0.0790];
MarketMat = {'21-Mar-2018';   
'21-Jun-2018'; 
'21-Sep-2018';  
'21-Dec-2018';  
'21-Mar-2019';  
'21-Jun-2019';  
'21-Sep-2019';  
'21-Dec-2019';  
'21-Mar-2020';  
'21-Jun-2020';  
'21-Sep-2020';  
'21-Dec-2020'};
MarketMat = datenum(MarketMat);
MarketVol = [0.1533 0.1731 0.1727 0.1752 0.1809 0.1800 0.1805 0.1802 0.1735 0.1757 ... 
             0.1755 0.1755 ; % First row in table corresponding to Strike1 
             0.1526 0.1730 0.1726 0.1747 0.1808 0.1792 0.1797 0.1794 0.1733 0.1751 ... 
             0.1750 0.1745 ]; % Second row in table corresponding to Strike2
        
Rates= [0.0627;
0.0657;
0.0691;
0.0717;
0.0739;
0.0755;
0.0765;
0.0772;
0.0779;
0.0783;
0.0786;
0.0789];
 
[AllMaturities,AllStrikes] = meshgrid(MarketMat,MarketStrike);
 
figure(1);
mesh(AllMaturities,AllStrikes,MarketVol);
datetick;
xlabel('Maturity');
ylabel('Strike');
zlabel('Volatility');
title('Market Volatility Data');
 
 
ValuationDate = '21-Jan-2018';
EndDates = {'21-Mar-2018';'21-Jun-2018';'21-Sep-2018';'21-Dec-2018';...
            '21-Mar-2019';'21-Jun-2019';'21-Sep-2019';'21-Dec-2019';....
            '21-Mar-2020';'21-Jun-2020';'21-Sep-2020';'21-Dec-2020'};
Compounding = 4;
Basis = 0;
 
RateSpec = intenvset('ValuationDate', ValuationDate, ...
'StartDates', ValuationDate, 'EndDates', EndDates, ...
'Rates', Rates, 'Compounding', Compounding, 'Basis', Basis);
 
o=optimoptions('lsqnonlin','TolFun',100*eps);
 
[Alpha, Sigma] = hwcalbycap(RateSpec, MarketStrike, MarketMat, MarketVol,...
'Reset', Reset, 'Basis',... 
Basis, 'OptimOptions', o);
 
BlkPrices1  = capbyblk(RateSpec,AllStrikes(1,:), Settle, AllMaturities(1,:),...
    MarketVol(1,:),'Reset',Reset,'Basis',Basis);
 
BlkPrices2  = capbyblk(RateSpec,AllStrikes(2,:), Settle, AllMaturities(2,:),...
    MarketVol(2,:),'Reset',Reset,'Basis',Basis);
 
VolDates    = EndDates;
VolCurve    = Sigma*ones(numel(EndDates),1);
AlphaDates  = EndDates;
AlphaCurve  = Alpha*ones(numel(EndDates),1);
HWVolSpec   = hwvolspec(Settle, VolDates, VolCurve, AlphaDates, AlphaCurve);
 
HWTimeSpec  = hwtimespec(Settle, EndDates, Compounding);
HWTree = hwtree(HWVolSpec, RateSpec, HWTimeSpec, 'Method', 'HW2000');
 
HWPrices1 = capbyhw(HWTree, AllStrikes(1,:), Settle, AllMaturities(1,:), Reset, Basis);

HWPrices2 = capbyhw(HWTree, AllStrikes(2,:), Settle, AllMaturities(2,:), Reset, Basis);
 
figure(2);
plot(AllMaturities(1,:), BlkPrices1, 'or', AllMaturities(1,:), HWPrices1, '-b');
hold on;
plot(AllMaturities(2,:), BlkPrices2, 'or', AllMaturities(2,:), HWPrices2, '-b');
 
datetick('x', 2)
xlabel('Maturity');
ylabel('Price');
title('Black and Calibrated (HW) Prices');
legend('Black Price', 'Calibrated HW Tree Price','Location', 'NorthWest');
 
figure(3);
 
plot(AllMaturities(1,:), -BlkPrices1 + HWPrices1, '-b');
hold on;
plot(AllMaturities(2,:), -BlkPrices2 + HWPrices2, '-b');
 
datetick('x', 2)
xlabel('Maturity');
ylabel('Error');
ylim([-2 2]);
 
grid off;box off; set(gcf,'color','white')
