% B5_Ch3_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear; close all;
a = 0.5;
sigma = 0.2;
b =0.1;
r0 = [-0.06 0.02 0.07 0.15];
Maturity =[1/12 3/12 6/12 1:1:10 20 30]';
T = Maturity;
B=(1-exp(-a*T))/a;

A=(b-sigma^2/(2*a^2)).*(B-T)-(sigma^2*B.^2)/(4*a);
 
figure;
xlabel('Time to maturity');
ylabel('Yield');
 
for i = 1:length(r0)
    hold on;
    ZCBPrice = exp(A-B*r0(i));
    Yield = -log(ZCBPrice)./T;
    plot(T,Yield);
end
 
legend('normal','humped','humped','inverse');
