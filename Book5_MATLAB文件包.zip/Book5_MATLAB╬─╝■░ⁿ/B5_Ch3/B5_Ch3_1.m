% B5_Ch3_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
r0 =.03;
% r0: current short rate at time 0
a =.3;
% a: the speed of mean reversion
b =.04;
% b: long-term mean of the short rate
sigma =.03;
% sigma: the volatility of the short rate
numSim = 10;
dt = 7.0/365; % weekly frequency
t = (0:dt:0.5)'; % 6 months horizon
T = .5; % in 6 months
S = .75; % in 9 months
L = 1000; % Notional
Rk = .0318; % fixed rate
r = zeros(length(t),numSim); % short rate 
 
r(1,:) = r0;
 
for i = 1:length(t)-1
    dr = a*(b-r(i))*dt + sigma*sqrt(dt)*randn(1,numSim);
    r(i+1,:) = r(i,:) + dr;
end
 
B_T = (1-exp(-a*(T-t)))/a;
B_S = (1-exp(-a*(S-t)))/a;    
A_T = (B_T-(T-t)).*(b-sigma^2/(2*a^2))-(sigma^2*B_T.^2)/(4*a);
A_S = (B_S-(S-t)).*(b-sigma^2/(2*a^2))-(sigma^2*B_S.^2)/(4*a);    
P_T = exp(A_T-B_T.*r);
P_S = exp(A_S-B_S.*r);
    
Rf = 1/(S-T)*(P_T./P_S-1);
FRA = L*(S-T)*(Rk-Rf)./(1+Rf.*(S-T));
FRA_discount = L*(S-T)*(Rk-Rf)./(1+Rf.*(S-T)).*B_T; 
 
figure(1)
plot(t,Rf);hold on
xlabel('t'); ylabel('Forward rate')
box off; set(gcf,'color','white')
 
figure(2)
plot(t,FRA_discount);hold on
xlabel('t'); ylabel('Discount FRA')
 
box off; set(gcf,'color','white')
