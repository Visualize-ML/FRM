% B5_Ch8_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch8_1_A.m

clc; close all; clear all
 
AssetList = {'AAPL','COST','FB',...
    'MSCI','PFE','QCOM','TSLA','YUM'};
 
price_assets = hist_stock_data('08092018','08082020',AssetList);
 
dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
num_assets = length(AssetList);
num_Bdays_year = 482;
Price_levels = extractfield(price_assets,'AdjClose');
Price_levels = reshape(Price_levels,num_Bdays_year,num_assets);
Returns = price2ret(Price_levels);
 
RETURN = 252*mean(Returns);
SIGMA = 252*cov(Returns);
 
try chol(SIGMA)
    disp('Matrix is symmetric positive definite.')
catch ME
    disp('Matrix is not symmetric positive definite')
end
 
figure
heatmap(AssetList,AssetList,SIGMA);
 
%% Equal weight portfolio, EWP
 
weights_0 = ones(1,num_assets)/num_assets;
% equal weights, also initial condition
 
figure
title_text = 'Equal weight';
RC_EWP = risk_contri(weights_0,SIGMA);
 
[sigma_p_EWP,return_p_EWP] = plotbar(weights_0,RC_EWP,SIGMA,RETURN,title_text, AssetList)

% B5_Ch8_1_B.m

%% Min variance portfolio, MVP
 
options = optimoptions(@fmincon,'Display','iter','Algorithm','interior-point');
options.TolFun = 1e-20;
 
A = []; b = [];
 
A_eq = ones(1,num_assets);
b_eq = 1;
% linear constraint
 
LB = zeros(1,num_assets);
UB = ones(1,num_assets);
 
obj_fcn_min_variance = @(weights2) min_variance_obj(weights2,SIGMA);
% handle of objective function: min variance
 
[w_min_variance,obj_value_min_var] = fmincon(obj_fcn_min_variance,weights_0,A,b,A_eq,b_eq,LB,UB,[],options);
 
figure
title_text = 'Min variance';
RC_MVP = risk_contri(w_min_variance,SIGMA);
 
[sigma_p_MVP,return_p_MVP] = plotbar(w_min_variance,RC_MVP,SIGMA,RETURN,title_text, AssetList)

% B5_Ch8_1_C.m

%% risk budgeting portfolio, RBP
 
budget_b = [0.05,0.05,0.1,0.1,0.15,0.15,0.2,0.2];
% budget_b = ones(1,num_assets)/num_assets;
 
obj_fcn_risk_budget = @(x) risk_budget_obj(x,SIGMA,budget_b);
% handle of objective function: risk budget
 
x_0 = ones(1,num_assets)/num_assets;
% initial condition
 
A = []; b = [];
 
A_eq = [];
b_eq = [];
% linear constraint
 
LB = zeros(1,num_assets);
UB = [];
 
[w_risk_budget,obj_value_risk_budget] = fmincon(obj_fcn_risk_budget,x_0,A,b,A_eq,b_eq,LB,UB,[],options);
 
w_risk_budget = w_risk_budget/sum(w_risk_budget);
 
figure
title_text = 'Risk budgeting';
RC_RBP = risk_contri(w_risk_budget,SIGMA);
 
[sigma_p_RBP,return_p_RBP] = plotbar(w_risk_budget,RC_RBP,SIGMA,RETURN,title_text, AssetList);

% B5_Ch8_1_D.m
%%  Risk parity portfolio, RPP
 
A = []; b = [];
 
A_eq = ones(1,num_assets);
b_eq = 1;
% linear constraint
 
LB = zeros(1,num_assets);
UB = ones(1,num_assets);

obj_fcn_risk_parity = @(weights) risk_parity_obj(weights,SIGMA);
% handle of objective function: risk parity
 
[w_risk_parity,obj_value_risk_parity] = fmincon(obj_fcn_risk_parity,weights_0,A,b,A_eq,b_eq,LB,UB,[],options);
 
figure
title_text = 'Risk parity';
RC_RPP = risk_contri(w_risk_parity,SIGMA);
 
[sigma_p_RPP,return_p_RPP] = plotbar(w_risk_parity,RC_RPP,SIGMA,RETURN,title_text, AssetList)

% B5_Ch8_1_E.m

%% naive risk parity portfolio, NRPP
 
sigma_vector = diag(SIGMA);
sigma_vector = sigma_vector';
w_naive_risk_parity = 1./sigma_vector/sum(1./sigma_vector);
 
figure
title_text = 'Naive risk parity';
RC_NRPP = risk_contri(w_naive_risk_parity,SIGMA);
 
[sigma_p_NRPP,return_p_NRPP] = plotbar(w_naive_risk_parity,RC_NRPP,SIGMA,RETURN,title_text, AssetList)

%% Hierarchical risk parity
title_text = 'Hierarchical risk parity';

w_H_risk_parity = allocByBisectHRP(SIGMA);

RC_HRPP = risk_contri(w_H_risk_parity',SIGMA);
[sigma_p_HRPP,return_p_HRPP] = plotbar(w_H_risk_parity',RC_HRPP,SIGMA,RETURN,title_text, AssetList);


% B5_Ch8_1_F.m

%% Compare portfolios
 
portfolio_names = {'EWP','MVP','RBP','RPP','NRPP','HRPP'};
sigma_p_compare = [sigma_p_EWP;sigma_p_MVP;sigma_p_RBP;sigma_p_RPP;sigma_p_NRPP;sigma_p_HRPP];
return_p_compare = [return_p_EWP;return_p_MVP;return_p_RBP;return_p_RPP;return_p_NRPP;return_p_HRPP];
 
figure
subplot(1,2,1)
b_handle = barh(sigma_p_compare,0.6);
set(gca,'yticklabel',portfolio_names)
xlabel('\sigma_p (annualized)'); box off; grid off
xtips1 = b_handle.YData - 0.08;
ytips1 = b_handle.XData;
labels1 = string(b_handle.YData);
text(xtips1,ytips1,labels1,'VerticalAlignment','middle')
 
subplot(1,2,2)
b_handle = barh(return_p_compare,0.6);
set(gca,'yticklabel',portfolio_names)
xlabel('r_p (annualized)'); box off; grid off
xtips1 = b_handle.YData - 0.08;
ytips1 = b_handle.XData;
labels1 = string(b_handle.YData);
text(xtips1,ytips1,labels1,'VerticalAlignment','middle')
 
figure 
 
RC_stacked = [RC_EWP'; RC_MVP'; RC_RBP'; RC_RPP'; RC_NRPP'; RC_HRPP'];
barh(RC_stacked,0.6,'stacked')
legend(AssetList)
set(gca,'yticklabel',portfolio_names)
xlabel('Risk contribution')
box off; grid off
 
figure 
 
RRC_stacked = RC_stacked./sigma_p_compare;
barh(RRC_stacked,0.6,'stacked')
legend(AssetList)
set(gca,'yticklabel',portfolio_names)
xlabel('Relative risk contribution')
box off; grid off
 
p = Portfolio('AssetList',AssetList);
 
p = setDefaultConstraints(p);
% no shorting, 100% investment in risky assets
 
p = estimateAssetMoments(p,Returns,'missingdata',false);
 
efficient_frontier_w = estimateFrontier(p, 30);
% Estimate weights
 
[p_sigma, p_r] = estimatePortMoments(p, efficient_frontier_w);
 
figure
sigma_i = sqrt(diag(SIGMA));
scatter(sigma_i, RETURN, 6, 'b', 'Filled');
hold on
 
for k = 1:length(AssetList)
    text(sigma_i(k) + 0.005, RETURN(k), AssetList{k}, 'FontSize', 8);
end
 
plot(sigma_p_compare,return_p_compare,'rx','MarkerSize',8);
 
for k = 1:length(portfolio_names)
    text(sigma_p_compare(k) + 0.005, return_p_compare(k), portfolio_names{k}, 'FontSize', 8);
end
 
plot(sqrt(252)*p_sigma, 252*p_r, 'b-');
xlabel('\sigma_p (annualized)');
ylabel('r_p (annualized)');
grid off; box off;

%% sub-functions
 
function obj = risk_parity_obj(weights,SIGMA)
 
risk_contribution = risk_contri(weights,SIGMA);
 
[xx,yy] = meshgrid(risk_contribution);
 
temp = sqrt(abs(xx - yy).^2);
obj = sum(temp(:))./2;
 
end
 
function risk_contribution = risk_contri(weights,SIGMA)
 
risk_contribution = (weights').*SIGMA*weights'/sqrt(weights*SIGMA*weights');
 
end
 
function variance = min_variance_obj(weights,SIGMA)
 
variance = weights*SIGMA*weights';
 
end
 
function cost_fcn = risk_budget_obj(x,SIGMA,budget_b)
 
cost_fcn = 1/2*x*SIGMA*x' - budget_b*log(x');
 
end
 
function [sigma_p,return_p] = plotbar(weights,RC,SIGMA,RETURN,title_text,txt)
subplot(1,3,1)
bar(weights,0.6)
xlabel('Asset'); ylabel('Weight, w_i');
box off; grid off; ylim([0,0.5])
title(title_text)
 
subplot(1,3,2)
bar(RC,0.6,'r')
sigma_p = sqrt(min_variance_obj(weights,SIGMA));
return_p = weights*RETURN';
title(['\sigma_p = ',num2str(sigma_p)])
xlabel('Asset'); ylabel('Risk contribution, RC_i');
box off; grid off; ylim([0,0.12])
 
RRC = RC/sigma_p;
 
subplot(1,3,3)
 
p = pie(RRC);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
combinedtxt = strcat(txt',{': '}, percentValues);
 
for i = 1:length(percentValues)
    pText(i).String = combinedtxt(i);
end
 
xlabel('Asset'); title('Relative isk contribution, RRC_i');
box off; grid off;
 
end
