% B5_Ch4_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
AssetPrice = 590;
% Strike = 590;
Rate = 0.06;
DividendYield = 0.0262;
Settle = '01-Jan-2018';
% ExerciseDates = '01-Jan-2020';
 
Maturity = ["06-Mar-2018" "05-Jun-2018" "12-Sep-2018" "10-Dec-2018" "01-Jan-2019" ...
"02-Jul-2019" "01-Jan-2020" "01-Jan-2021" "01-Jan-2022" "01-Jan-2023"];
TimeToMaturity = yearfrac(Settle,Maturity,3);
 
ExercisePrice = AssetPrice.*[0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40];
 
ImpliedVol = [...
    0.190; 0.168; 0.133; 0.113; 0.102; 0.097; 0.120; 0.142; 0.169; 0.200; ...
    0.177; 0.155; 0.138; 0.125; 0.109; 0.103; 0.100; 0.114; 0.130; 0.150; ...
    0.172; 0.157; 0.144; 0.133; 0.118; 0.104; 0.100; 0.101; 0.108; 0.124; ...
    0.171; 0.159; 0.149; 0.137; 0.127; 0.113; 0.106; 0.103; 0.100; 0.110; ...
    0.171; 0.159; 0.150; 0.138; 0.128; 0.115; 0.107; 0.103; 0.099; 0.108; ...
    0.169; 0.160; 0.151; 0.142; 0.133; 0.124; 0.119; 0.113; 0.107; 0.102; ...
    0.169; 0.161; 0.153; 0.145; 0.137; 0.130; 0.126; 0.119; 0.115; 0.111; ...
    0.168; 0.161; 0.155; 0.149; 0.143; 0.137; 0.133; 0.128; 0.124; 0.123; ...
    0.168; 0.162; 0.157; 0.152; 0.148; 0.143; 0.139; 0.135; 0.130; 0.128; ...
    0.168; 0.164; 0.159; 0.154; 0.151; 0.147; 0.144; 0.140; 0.136; 0.132];
 
nTerm = length(TimeToMaturity);
nStrike = length(ExercisePrice);
ImpVolSurface = reshape(ImpliedVol,[nStrike, nTerm])'; % nTerm, nStrike
 
[Strikes,Terms] = meshgrid(ExercisePrice,TimeToMaturity);
figure(1)
mesh(Terms,Strikes,ImpVolSurface);
xlabel('Option Expiry (years)');
ylabel('Strikes');
box off; grid off
axis tight
view(-45,15)
 
total_var = ImpVolSurface.^2.*Terms;
refined_maturity = (TimeToMaturity(1) - 0.1:0.25: TimeToMaturity(end) + 0.1)';
 
refined_total_var = zeros(length(refined_maturity),nStrike);
 
for i = 1:nStrike
    refined_total_var(:,i) = interp1(TimeToMaturity,total_var(:,i),refined_maturity,'linear','extrap');
end    
refined_maturity_ = repmat(refined_maturity,1,nStrike);
refined_vol_tenor = sqrt(refined_total_var./refined_maturity_);
 
refined_strike = (ExercisePrice(1)-10:15: ExercisePrice(end) + 10)';
 
refined_vol = zeros(length(refined_maturity),length(refined_strike));
for i = 1:length(refined_maturity)
    refined_vol(i,:) = interp1(ExercisePrice,refined_vol_tenor(i,:),refined_strike,'spline','extrap');
end 
 
[Strikes,Terms] = meshgrid(refined_strike,refined_maturity);
figure(2)
mesh(Terms,Strikes,refined_vol);
xlabel('Option Expiry (years)');
ylabel('Strikes');
box off; grid off
axis tight
view(-45,15)
 
tic;
 
[X_grid, T_grid, LocalVolSurface ]  = genlocalvol(AssetPrice, Rate, DividendYield, refined_strike, refined_maturity,  refined_vol);
 
[Terms,Strike] = meshgrid( T_grid, X_grid);
figure(3)
mesh( Strike, Terms, LocalVolSurface ); 
xlabel('S');
ylabel('Time (years)');
box off; grid off
axis tight
view(-20,35)
 
nTerm = length(Maturity);
nStrike = length(ExercisePrice);
Call_bls = zeros(nTerm,nStrike);
Call_lv = zeros(nTerm,nStrike);
 
for i = 1:length(TimeToMaturity)
    for j =  1:length(ExercisePrice)
    Call_bls(i,j) = blsprice(AssetPrice,ExercisePrice(j),Rate,TimeToMaturity(i),ImpVolSurface(i,j),DividendYield);

    Call_lv(i,j) =  mcprice(AssetPrice,ExercisePrice(j),Rate, DividendYield,TimeToMaturity(i),X_grid, T_grid, LocalVolSurface);
    end
end
toc;
 
[Strikes,Terms] = meshgrid(ExercisePrice,TimeToMaturity);
 
figure(4)
h1 = mesh(Terms(1:1:end,:),Strikes(1:1:end,:),Call_bls(1:1:end,:));
h1.FaceColor = [0,0,0];
h1.FaceAlpha = 0;
h1.EdgeColor = [1,0,0];
hold on;
h2 = mesh(Terms(1:1:end,:),Strikes(1:1:end,:),Call_lv(1:1:end,:));
h2.FaceColor = [0,0,0];
h2.FaceAlpha = 0;
h2.EdgeColor = [0,0,1];
xlabel('Option Expiry (years)');
ylabel('Strikes');
% view(-112,34);
box off; grid off
axis tight
 
figure(5)
mesh( Terms, Strikes, Call_lv - Call_bls); 
xlabel('Option Expiry (years)');
ylabel('Strikes');
zlim([-10 10])
box off; grid off
axis tight
view(-112,35)
 
function [K_grid, T_grid, LocalVSurface] = genlocalvol(AssetPrice, Rate, DividendYield, K, T, VolSurf)
    
    nTerm = length(unique(T));
    nStrike = length(unique(K));
 
    if nTerm ~= size(VolSurf,1) || nStrike ~= size(VolSurf,2)
        warning('check the size of the implied vol data');
    end 
 
    V_grid = VolSurf'; % change to k, t 
 
    K_grid = K(2:end-1);
    T_grid = T(2:end-1)';
    dT = T(2)-T(1);
    dK = K(2) - K(1);
    V    = V_grid(2:end-1,2:end-1);

    V_t  = (V_grid(2:end-1,3:end) - V_grid(2:end-1,1:end-2))./2./dT;

    V_k  = (V_grid(3:end,2:end-1) - V_grid(1:end-2,2:end-1))./2./dK;

    V_kk = (V_grid(1:end-2,2:end-1) - 2.*V_grid(2:end-1,2:end-1) + V_grid(3:end,2:end-1))./dK.^2;
 
    d1 = (log(AssetPrice./K_grid) + (Rate-DividendYield+V.^2/2).*T_grid)./V./sqrt(T_grid);
 
    LocalV = (V.^2 +2.*T_grid.*V.*V_t + 2.*(Rate-DividendYield).*K_grid.*T_grid.*V.*V_k)./...
        ((1+K_grid.*d1.*sqrt(T_grid).*V_k).^2 + K_grid.^2.*T_grid.*V.*(V_kk-d1.*V_k.^2.*sqrt(T_grid)));
 
    LocalV(1,:) = LocalV(2,:);
    LocalV(:,1) = LocalV(:,2);
    LocalV(LocalV<0) = 0.01;
 
    LocalVSurface = sqrt(LocalV);
end
 
function call_price_mc = mcprice(AssetPrice,ExercisePrice,Rate,DividendYield,TimeToMaturity,X_grid, T_grid, LocalVolSurface)
nPath = 50000;
dT = 1/365;
nSteps = round(TimeToMaturity/dT,0);
S = zeros(nPath,nSteps);
S(:,1) = AssetPrice;
 
for t = 2:nSteps   
    sigma_mc = extractVol(S(:,t-1), t*dT, X_grid,T_grid,LocalVolSurface);
    S(:,t) = S(:,t-1).*(exp((Rate - DividendYield-0.5.*sigma_mc.^2).*dT + sigma_mc.*sqrt(dT).*randn(nPath,1))); 
end    
 
call_payoff = max(S(:,end) - ExercisePrice,0);
call_price_mc = mean(call_payoff)*exp(-Rate*TimeToMaturity); 
 
end  
 
function sigma = extractVol(x,t,X_grid,T_grid,Vol)
 
if t < T_grid(1)
    idx = 1;
elseif t > T_grid(end)
    idx = length(T_grid);
else
    idx = t >= T_grid;
end
 
vol_slice = Vol(:,idx);
vol_slice = vol_slice(:,end);
sigma = interp1(X_grid,vol_slice,x,'linear',0.2);    
 
end
