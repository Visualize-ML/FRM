% B5_Ch4_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all;
AssetPrice = (80:1:120)';
Strike = 100;
 
Rate = 0.05;
DividendYield = 0.01;
OptSpec = 'call';
 
V0 = 0.09;
ThetaV = 0.2;
Kappa = 1.0;
SigmaV = 0.3;
RhoSV_minus = -0.75;
RhoSV_plus =   0.75;
Settle = datenum('29-Jun-2017');
Maturity = datemnth(Settle, 12*[1/12 0.25 (0.5:0.5:3)]');
Time = yearfrac(Settle, Maturity);
 
Call_Heston_minus_rho = zeros(length(AssetPrice),length(Maturity));
Call_Heston_plus_rho = zeros(length(AssetPrice),length(Maturity));
Call_bls = zeros(length(AssetPrice),length(Maturity));
 
for t = 1:length(Maturity)
 
Call_Heston_minus_rho(:,t) = optByHestonNI(Rate, AssetPrice, Settle, Maturity(t), OptSpec, Strike, ...
    V0, ThetaV, Kappa, SigmaV, RhoSV_minus, 'DividendYield', DividendYield,'ExpandOutput',true);
 
Call_Heston_plus_rho(:,t) = optByHestonNI(Rate, AssetPrice, Settle, Maturity(t), OptSpec, Strike, ...
    V0, ThetaV, Kappa, SigmaV, RhoSV_plus, 'DividendYield', DividendYield,'ExpandOutput',true);
 
end
% plot(AssetPrice',Call_Heston_minus_rho,AssetPrice',Call_Heston_plus_rho,AssetPrice',Call_bls);
[X,Y] = meshgrid(Time,AssetPrice/Strike);
% 
close all
figure(1);
h1 = mesh(X(1:3:end,:),Y(1:3:end,:),Call_Heston_minus_rho(1:3:end,:));
h1.FaceColor = [0,0,0];
h1.FaceAlpha = 0;
h1.EdgeColor = [1,0,0];
hold on;
h2 = mesh(X(1:3:end,:),Y(1:3:end,:),Call_Heston_plus_rho(1:3:end,:));
h2.FaceColor = [0,0,0];
h2.FaceAlpha = 0;
h2.EdgeColor = [0,0,1];
xlabel('Years to Option Expiry');
ylabel('Moneyness');
% view(-112,34);
box off; grid off
axis tight
view(-45,15)
%%
figure(2);
h1 = mesh(X(1:3:end,:),Y(1:3:end,:),Call_Heston_minus_rho(1:3:end,:),'MeshStyle','column');
h1.FaceColor = [0,0,0];
h1.FaceAlpha = 0;
h1.EdgeColor = [1,0,0];
hold on;
h2 = mesh(X(1:3:end,:),Y(1:3:end,:),Call_Heston_plus_rho(1:3:end,:),'MeshStyle','column');
h2.FaceColor = [0,0,0];
h2.FaceAlpha = 0;
h2.EdgeColor = [0,0,1];
xlabel('Years to Option Expiry');
ylabel('Moneyness');
% view(-112,34);
box off; grid off
axis tight
