% B5_Ch4_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear; close all
ForwardRate = 5;
% Strike = 0.03;
Strike = 0.5:0.1:12;
Alpha = 0.295;
Beta = 0.5;
Rho = -0.25;
Nu = 0.2;
  
Settle = datenum('15-Sep-2013');
ExerciseDate = datenum('15-Sep-2023');
 
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
% figure1
figure;
plot(Strike,ComputedVols)
hold on
Alpha = 0.325;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
plot(Strike,ComputedVols)
xlabel('Strike');
ylabel('Volatility');
legend('Alpha = 0.295', 'Alpha = 0.325');
box off;
 
figure;
% figure2
plot(Strike,ComputedVols);
Beta = 0;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
 
Beta = 1;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
xlabel('Strike');
ylabel('Volatility');
legend('Beta = 0.5', 'Beta = 0', 'Beta = 1');
box off;
 
% figure3
figure;
plot(Strike,ComputedVols);
Rho = 0;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
 
Rho = -0.5;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
xlabel('Strike');
ylabel('Volatility');
legend('Rho = 0.5', 'Rho = 0', 'Rho = -0.5');
box off;
 
% figure4
figure;
plot(Strike,ComputedVols);
Nu = 0.4;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
 
Nu = 0.6;
ComputedVols = blackvolbysabr(Alpha, Beta, Rho, Nu, Settle, ...
ExerciseDate, ForwardRate, Strike);
hold on;
plot(Strike,ComputedVols);
xlabel('Strike');
ylabel('Volatility');
legend('Nu = 0.2', 'Nu = 0.4', 'Nu = 0.6');
box off;
