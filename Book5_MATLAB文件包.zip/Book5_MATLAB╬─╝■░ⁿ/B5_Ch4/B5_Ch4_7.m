% B5_Ch4_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear; close all
 
Settle = '12-Jun-2014' ;
ExerciseDate =  '12-Jun-2016' ;
 
t=  yearfrac(Settle, ExerciseDate, 1);
MarketStrikes = [0.505000000000000,1.50500000000000,2.00500000000000,2.40500000000000,2.50500000000000,2.60500000000000,3.00500000000000,3.50500000000000,4.50500000000000,5.00500000000000]'/100;
MarketVolatilities = [63.6500000000000,40.2100000000000,34.7800000000000,31.8700000000000,31.3000000000000,30.7900000000000,29.2600000000000,28.2500000000000,27.9200000000000,28.1400000000000]'/100;
 
CurrentForwardValue = MarketStrikes(5);
ATMVolatility = MarketVolatilities(5);
f0=CurrentForwardValue;
Strike = MarketStrikes ;
Sigma1= MarketVolatilities;
Sigma2= MarketVolatilities;
df=1;
T=t;
price1 = floorlet(f0,Strike,Sigma1,T,df);
MarketPrice=price1;
myfun= @(sigma,K,price) price-floorletN(f0,K,sigma,T,df);
 
for i=1:length(Sigma1) 
    K =Strike(i);
    price=price1(i);
    fun=@(sigma)myfun(sigma,K,price);
    Sigma2(i) = fzero(fun,Sigma1(i));
end
 
MarketVolatilities2=Sigma2;
floorletN(f0,Strike,Sigma2,T,df)
 
% Year fraction from Settle to option maturity
T = yearfrac(Settle, ExerciseDate, 1);
 
% This function solves the SABR at-the-money volatility equation as a
% polynomial of Alpha
alpharoots = @(Beta,Rho,Nu) roots([...
    (1 - Beta)^2*T/24/CurrentForwardValue^(2 - 2*Beta) ...
    Rho*Beta*Nu*T/4/CurrentForwardValue^(1 - Beta) ...
    (1 + (2 - 3*Rho^2)*Nu^2*T/24) ...
    -ATMVolatility*CurrentForwardValue^(1 - Beta)]);
 
% This function converts at-the-money volatility into Alpha by picking the smallest positive real root 
atmVol2SabrAlpha = @(Beta,Rho,Nu) min(real(arrayfun(@(x) ...
    x*(x>0) + realmax*(x<0 || abs(imag(x))>1e-6), alpharoots(Beta,Rho,Nu))));
 
% Calibrate Rho and Nu (while converting at-the-money volatility into Alpha
% using atmVol2SabrAlpha)
objFun = @(X) MarketVolatilities - ...
    blackvolbysabr(atmVol2SabrAlpha(X(3),X(1), X(2)), ...
    X(3), X(1), X(2), Settle, ExerciseDate, CurrentForwardValue, ...
    MarketStrikes);
 
X = lsqnonlin(objFun, [0 0.5 0.5 ], [-1 0 0], [1 Inf 1]);
 
Rho2 = X(1);
Nu2 = X(2);
Beta2 =X(3);
% Obtain final Alpha from at-the-money volatility using calibrated parameters
Alpha2 = atmVol2SabrAlpha(Beta2,Rho2, Nu2);
PlottingStrikes = (0.05:0.1:5.50)'/100;
 
% Compute volatilities for model calibrated by Method 1
ComputedVols1 = blackvolbysabr(Alpha2, Beta2, Rho2, Nu2, Settle, ...
   ExerciseDate, CurrentForwardValue, PlottingStrikes);
 
ComputedVols2 = blacknormalvolbysabr(Alpha2, Beta2, Rho2, Nu2, t, CurrentForwardValue, PlottingStrikes);
 
figure;
plot(MarketStrikes,Sigma1,'xk',...
    PlottingStrikes,ComputedVols1,'b');
xlim([0.01 0.06]);
ylim([0.15 0.5]);
xlabel('Strike', 'FontWeight', 'bold');
ylabel('Lognormal Black Volatility', 'FontWeight', 'bold');
legend('Market Lognormal Volatilities', 'SABR Lognormal Model');
box off;
 
figure;
plot(MarketStrikes,Sigma2,'xk',...
    PlottingStrikes,ComputedVols2' ,'b');
xlim([0.01 0.06]);
 
xlabel('Strike', 'FontWeight', 'bold');
ylabel('Normal Black Volatility', 'FontWeight', 'bold');
legend('Market Normal Volatilities', 'SABR Normal Model');
box off;
 
 
f0=CurrentForwardValue;
strike = PlottingStrikes';
sigma1= ComputedVols1' ;
sigma2= ComputedVols2 ;
df=1;
T=t;
price1=floorlet(f0,strike,sigma1,T,df);
 
price2=floorletN(f0,strike,sigma2,T,df);
 
 
figure;
plot(  PlottingStrikes,price1,'-', PlottingStrikes,price2,':',MarketStrikes,MarketPrice,'*');
xlim([0.01 0.06]);
xlabel('Strike', 'FontWeight', 'bold');
ylabel('Option Price' );
legend('Lognormal SABR', 'Normal SABR', 'Market Price' );
box off;
 
function  [floorlet_] = floorlet(f0,strike,sigma,T,df)
 
dmin_1= (log(f0./strike)+0.5* sigma.^2.*T)./(sigma.*sqrt(T));
dmin_2= dmin_1 - sigma.*sqrt(T);
 
floorlet_ =   (-f0.* normcdf(-dmin_1) + strike.* normcdf(-dmin_2)).*df;  
end 
 
function  [floorletN_] = floorletN(f0,strike,sigma,T,df)
 
dmin_1= (f0-strike)./(sigma.*sqrt(T));
floorletN_ =   ( -1*( f0 - strike).* normcdf(-1*dmin_1) + sigma.*sqrt(T).* normpdf(dmin_1)).*df;
end
 
function outVol = blacknormalvolbysabr(alpha, beta, rho, nu, t, f, K)
 
fav=sqrt(f*K);
c=fav.^beta;
gamma1=beta/fav;
gamma2=beta*(beta-1)/fav.^2;
z=nu/alpha.*(f-K)./c;
x=log((sqrt(1-2*rho*z+z.^2)+z-rho)/(1-rho));
outVol=(alpha*(f-K)*(1-beta)./(f^(1-beta)-K.^(1-beta)+eps).*(z+eps)./(x+eps) )'.*(1+((2*gamma2-gamma1.^2)*alpha^2*c.^2/24+rho*nu*alpha*gamma1.*c.'/4 ...
        +(2-3*rho^2)*nu^2/24)*t);
end
