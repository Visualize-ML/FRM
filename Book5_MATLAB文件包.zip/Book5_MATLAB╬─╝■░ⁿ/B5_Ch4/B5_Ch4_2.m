% B5_Ch4_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
SPX = xlsread('SPX_VOL.xlsx',2,'b2:f7600');
S0 = 2853;
r=0.66/100;
 
Maturity = SPX(:,3);          % maturity
Strike = SPX(:,1);            % strike
CallPrice = SPX(:,2);         % option prices
 
tic;
IV  = blsimpv(S0, Strike, r, Maturity, CallPrice);%(S, X, r, T, value)
 
toc;
 
ind = ~isnan(IV);
IV = IV(ind);
Strike = Strike(ind);
Maturity = Maturity(ind);
CallPrice = CallPrice(ind);
[CallDelta_calc, PutDelta_calc] = blsdelta(S0, Strike, r, Maturity, CallPrice);
 
figure(1)
unique_Maturity = unique(Maturity);
for i = 1:1:10
    ind = find (Maturity ==unique_Maturity(i+1));  
    Maturity_1d = Maturity(ind);
    plot(abs(PutDelta_calc(ind)),IV(ind)*100);hold on
end
 
xlabel('Delta'); ylabel('Implied Vol %')
xticks([0.1 0.25 0.5 0.75 0.9])
xticklabels({'10P','25P','ATM','25C','10C'})
xlim([0.01 0.99]);
ylim([15 30]);
box off; set(gcf,'color','white')
 
figure(2);
for i = 1:1:10
    ind2 = find (Maturity ==unique_Maturity(i+1));
    Maturity_1d = Maturity(ind2);
    plot(abs(PutDelta_calc(ind2)),Strike(ind2));hold on
end
 
xlabel('Delta'); ylabel('Strike');
xticks([0.1 0.25 0.5 0.75 0.9])
xticklabels({'10P','25P','ATM','25C','10C'})
xlim([0.01 0.99]);
ylim([2700 3500]);
box off; set(gcf,'color','white')
