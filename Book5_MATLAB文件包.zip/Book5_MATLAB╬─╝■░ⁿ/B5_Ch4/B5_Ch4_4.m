% B5_Ch4_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc;clear all;close all
market_data = xlsread('heston_market_data_cooked.xlsx',1,'A2:E35');
 
NumberOfOptions = size(market_data,1);
mid_price = market_data(:,5);
r = market_data(:,1);
T = market_data(:,2);
S0= market_data(:,3);
K = market_data(:,4);
 
x0 = [6.5482 0.0731 0.2 -0.4176 0.04];
 
lb = [0 0 0 -1 0];
ub = [20 1 5 0 1];
 
IntegrationRange = [1.00000000000000e-09 100];
AbsTol = 1.00000000000000e-10;
RelTol = 1.00000000000000e-06;
options = optimset('MaxFunEvals',20000);
 
tic;
 
HestonDifferences = @(X) mid_price - ...
    HestonCallQuad((X(1)+X(3).^2)./(2.*X(2)), ...
    X(2), X(3), X(4), X(5), ...
    r, T, S0, K,IntegrationRange, AbsTol, RelTol);
 
X = lsqnonlin(HestonDifferences,x0,lb,ub,options);
 
toc;
 
HestonCall = HestonCallQuad((X(1)+X(3).^2)./(2.*X(2)), ...
    X(2), X(3), X(4), X(5), ...
    r, T, S0, K,IntegrationRange, AbsTol, RelTol);
 
unique_Ts = unique(T);
 
for i = 1:length(unique_Ts)
 
index = market_data(:,2)==unique_Ts(i);
plot(mid_price(index),'ob');
hold on;
plot(HestonCall(index),'xr');
 
end 
 
% xlabel('Strike');
ylabel('Price');
title('Market and Calibrated (Heston model ) Prices');
legend('Market Price', 'Calibrated (Heston model) Price','Location', 'NorthEast');
box off;
 
function call = HestonCallQuad(kappa,theta,sigma,rho,v0,r,T,...
s0,K, IntegrationRange, AbsTol, RelTol)
    warning off;
      
    fun_f1 = @(x)CharacteristicFcn(x,kappa,theta,sigma,rho,v0,r,T,s0,1);

    p1 = 0.5 + HestonIntegral(fun_f1, K, IntegrationRange, AbsTol, RelTol);
    
%     fun_f2 = @(x)CharacteristicFcn(x, AssetPrice, Rate, DividendYield, Times, Param);
    fun_f2 = @(x)CharacteristicFcn(x,kappa,theta,sigma,rho,v0,r,T,s0,2);

    p2 = 0.5 + HestonIntegral(fun_f2, K, IntegrationRange, AbsTol, RelTol);
    
    call = s0.*p1 - ...
    K.*exp(-r.*T).*p2;
 
end
 
function Out = HestonIntegral(IntegFun, Strike, IntegrationRange, AbsTol, RelTol)
 
Out = 1./pi.*integral(...
    @(Phi)real(exp(-1i.*Phi.*log(Strike)).*IntegFun(Phi)./(1i.*Phi)),...
    IntegrationRange(1),IntegrationRange(2),'AbsTol',AbsTol,'RelTol',RelTol,'ArrayValued',true);
 
end
 
function f = CharacteristicFcn(phi,kappa,theta,sigma,rho,v0,r,T,s0,type)
    if type == 1
        u = 0.5;
        b = kappa - rho*sigma;
    else
        u = -0.5;
        b = kappa;
    end
  
    a = kappa.*theta; 
    x = log(s0);

    d = sqrt((b-rho.*sigma.*1i.*phi).^2-sigma.^2.*(2.*u.*1i.*phi-phi.^2));
    
    g = (b - rho.*sigma.*1i.*phi + d)./(b - rho.*sigma.*1i.*phi - d);
    
    C = r.*phi.*1i.*T + a./sigma.^2.*((b- rho.*sigma.*phi.*1i + d).*T - ...
    2.*log((1-g.*exp(d.*T))./(1-g)));

    D = (b - rho.*sigma.*1i.*phi + d)./sigma.^2.*((1-exp(d.*T))./ ...
    (1-g.*exp(d.*T)));
    
    f = exp(C + D.*v0 + 1i.*phi.*x);
end
