% B5_Ch7_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
AssetList = {'AAPL','COST','FB',...
    'MSCI','PFE','QCOM','TSLA','YUM'};
 
price_assets = hist_stock_data('08092018','08082020',AssetList);
 
dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
num_assets = length(AssetList);
num_Bdays_year = 482;
Price_levels = extractfield(price_assets,'AdjClose');
Price_levels = reshape(Price_levels,num_Bdays_year,num_assets);
Returns = price2ret(Price_levels);
 
ExpReturn = 252*mean(Returns);
 
ExpCovariance = 252*cov(Returns);
        
num_scenarios = 40;
RisklessRate  = 0.03;
BorrowRate    = RisklessRate;
port = Portfolio('AssetMean',ExpReturn,'AssetCovar',ExpCovariance,'RiskFreeRate',BorrowRate);
 
port = setDefaultConstraints(port);
PortWts = port.estimateFrontier(num_scenarios);
PortRisk = port.estimatePortStd(PortWts);
PortReturn = port.estimatePortReturn(PortWts);
PortWts = PortWts';
% [PortRisk, PortReturn, PortWts] = portopt(ExpReturn,... 
% ExpCovariance);
 
figure
RiskAversion  = 2; % 2, 3, 4

portalloc (PortRisk, PortReturn, PortWts, RisklessRate,... 
BorrowRate, RiskAversion);
grid off; box off
