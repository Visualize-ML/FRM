% B5_Ch7_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Maximize information ration 
clc; close all; clear all
 
% import historical price levels for the assets
AssetList = {'AAPL','COST','FB',...
    'MSCI','PFE','QCOM','TSLA','YUM','^IXIC'};
 
% Nasdaq Composite (^IXIC) is used as the benchmark
 
price_assets = hist_stock_data('08092018','08082020',AssetList);
 
dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
num_assets = length(AssetList);
num_Bdays_year = 482;
Price_levels = extractfield(price_assets,'AdjClose');
Price_levels = reshape(Price_levels,num_Bdays_year,num_assets);
AssetScenarios = price2ret(Price_levels);
 
benchPrice = Price_levels(:,9);
assetNames = AssetList(1:end-1);
assetPrice = Price_levels(:,1:8);
 
assetP = assetPrice./assetPrice(1, :);  
benchmarkP = benchPrice / benchPrice(1);
%% Visualize normalized price levels for stocks and benchmark
AssetNames = AssetList;
AssetNames{9} = 'NASDAQ';
 
figure
plot(dates,assetP); hold on;
plot(dates,benchmarkP,'LineWidth',1,'Color','k');
datetick('x','mmm/yyyy')
xlim([dates(1),dates(end)])
ylabel('Normalized price level');
grid off; box off;
legend(AssetNames,'Location','Best')
%% Expected return and volatility
 
benchReturn = tick2ret(benchPrice);
assetReturn = tick2ret(assetPrice);
 
benchRetn = mean(benchReturn);
benchRisk =  std(benchReturn);
assetRetn = mean(assetReturn);
assetRisk =  std(assetReturn);
 
annualize_scale = 252; 
 
assetRiskR = sqrt(annualize_scale) * assetRisk; % annualize risk
benchRiskR = sqrt(annualize_scale) * benchRisk; % annualize risk
assetReturnR = annualize_scale * assetRetn;     % annualize return
benchReturnR = annualize_scale * benchRetn;     % annualize risk
 
figure;
 
scatter(assetRiskR, assetReturnR, 6, 'b', 'Filled');
hold on
scatter(benchRiskR, benchReturnR, 6, 'r', 'Filled');
for k = 1:length(assetNames)
    text(assetRiskR(k) + 0.005, assetReturnR(k), assetNames{k}, 'FontSize', 8);
end
text(benchRiskR + 0.005, benchReturnR, 'Benchmark (NASDAQ)', 'Fontsize', 8);
hold off;
 
xlabel('Annualized volatility');
ylabel('Annualized return');
grid off; box off; 
%% Set Up a Portfolio Optimization for active returns
 
p = Portfolio('AssetList',assetNames);
 
p = setDefaultConstraints(p); 
% no shorting, 100% investment in risky assets
 
activReturn = assetReturn - benchReturn;
% Calculate active return
 
pAct = estimateAssetMoments(p,activReturn,'missingdata',false)
 
pwgtAct = estimateFrontier(pAct, 30); 
% Estimate weights
 
[portRiskAct, portRetnAct] = estimatePortMoments(pAct, pwgtAct); 
% Get risk and return
 
% Extract asset moments & names
[assetActRetnDaily, assetActCovarDaily] = getAssetMoments(pAct);
assetActRiskDaily = sqrt(diag(assetActCovarDaily));
assetNames = pAct.AssetList;
 
% Rescale
assetActRiskAnnual = sqrt(annualize_scale) * assetActRiskDaily;
portRiskAnnual  = sqrt(annualize_scale) * portRiskAct;
assetActRetnAnnual = annualize_scale * assetActRetnDaily;
portRetnAnnual = annualize_scale * portRetnAct;
 
figure;
 
plot(portRiskAnnual, portRetnAnnual, 'bx-', 'MarkerFaceColor', 'b');
 
hold on;
scatter(assetActRiskAnnual, assetActRetnAnnual, 6, 'b', 'Filled');
for k = 1:length(assetNames)
    text(assetActRiskAnnual(k) + 0.005, assetActRetnAnnual(k), assetNames{k}, 'FontSize', 8);
end
 
hold off;
 
xlabel('\sigma_{active} (annualized)');
ylabel('r_{active} (annualized)');
grid off; box off
 
figure;
 
plot(portRiskAnnual(1:end-1), diff(portRetnAnnual)./diff(portRiskAnnual), 'bx-', 'MarkerFaceColor', 'b');
 
xlabel('\sigma_{active} (annualized)');
ylabel('\Delta r_{active}/\Delta \sigma_{active}');
grid off; box off
 
figure;
plot(portRiskAnnual, portRetnAnnual./portRiskAnnual, 'bx-', 'MarkerFaceColor', 'b');
ylabel('Information ratio');
xlabel('\sigma_{active} (annualized)');
grid off; box off
 
figure;
plot(portRetnAnnual, portRetnAnnual./portRiskAnnual, 'bx-', 'MarkerFaceColor', 'b');
ylabel('Information ratio');
xlabel('r_{active} (annualized)');
grid off; box off
 
%% Perform Information Ratio Maximization 
% objective: maximizes the information ratio 
% = minimizes a negative information ratio.
% variable: target risk
 
objFun = @(targetRisk) -infoRatioTargetRisk(targetRisk,pAct);
options = optimset('TolX',1.0e-8);
[optPortrisk, ~, exitflag] = fminbnd(objFun,0,max(portRiskAct),options);
 
% Get weights, information ratio, and risk return for the optimal portfolio.
 
[optInfoRatio,optWts] = infoRatioTargetRisk(optPortrisk,pAct);
optPortReturn = estimatePortReturn(pAct,optWts) 
% Plot the Optimal Portfolio
 
optPortRiskAnnual = sqrt(annualize_scale) * optPortrisk;
optPortReturnAnnual = annualize_scale * optPortReturn;
 
figure;
subplot(2,1,1);
 
scatter(assetActRiskAnnual, assetActRetnAnnual, 6, 'b', 'Filled');
hold on
for k = 1:length(assetNames)
    text(assetActRiskAnnual(k) + 0.005,assetActRetnAnnual(k),assetNames{k},'FontSize',8);
end
plot(portRiskAnnual,portRetnAnnual,'bx-','MarkerSize',4,'MarkerFaceColor','b');
plot(optPortRiskAnnual,optPortReturnAnnual,'rx','MarkerSize',8);
hold off;
 
xlabel('\sigma_{active} (annualized)');
ylabel('r_{active} (annualized)');
grid off
 
subplot(2,1,2);
plot(portRiskAnnual,portRetnAnnual./portRiskAnnual,'bx-','MarkerSize',4,'MarkerFaceColor','b');
hold on
plot(optPortRiskAnnual,optPortReturnAnnual./optPortRiskAnnual,'rx','MarkerSize',8);
hold off;
 
xlabel('\sigma_{active} (annualized)');
ylabel('Information Ratio');
grid off; box off
 
%% objective function
 
function [infoRatio,wts] = infoRatioTargetRisk(targetRisk,portObj)
% Calculate information ratio for a target-return portfolio along the
% efficient frontier
wts = estimateFrontierByRisk(portObj,targetRisk);
active_return = estimatePortReturn(portObj,wts);
infoRatio = active_return/targetRisk;
end
