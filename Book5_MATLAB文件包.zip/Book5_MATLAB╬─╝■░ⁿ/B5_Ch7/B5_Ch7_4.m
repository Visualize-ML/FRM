% B5_Ch7_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
%% Data input 
T = readtable('BL_example.xlsx','Sheet','BL_example');
W = readtable('BL_example.xlsx','Sheet','MktWeight');
 
%% Extract data
Ticker = T.Properties.VariableNames(2:end-1)';
singlename_ExcessRet = T(:,2:end-1).Variables;
Mkt_ExcessRet = T(:,end).Variables;
MktWeight = W.Variables';
 
%% Calculate individual sectors covariance, correlation matrix
n = length(MktWeight);
singlename_Covariance = cov(singlename_ExcessRet); 
singlename_Correlation = corrcoef(singlename_ExcessRet);
 
%% Reverse Optimization to calculate the equilibrium return pi
 
% Market vol
vol_mkt = std(Mkt_ExcessRet);
% Market average return
mean_mkt = mean(Mkt_ExcessRet);
% Sharpe Ratio
SR = mean_mkt/vol_mkt;
% Risk aversion coefficient -- this is just one way to calculate
A = SR/vol_mkt;
% equilibrium return pi
Pi = A*singlename_Covariance*MktWeight;
 
% Specify tau
tau = 0.0275; % there are many ways to specify
 
% C = tau*Cov
C = tau*singlename_Covariance;
 
%% Investor's views
k = 3;  % number of views
 
% View 1: Information Technology sector's absolute return is 3%
% View 2: Energy sector's absolute return is -3%
% View 3: Industrials sector return is higher than Utilities sector return
% by 1%
 
% Specify P
P = zeros(k, n);
P(1, Ticker=="InformationTechnology") = 1; 
P(2, Ticker=="Energy") = 1; 
P(3, Ticker=="Industrials") = 1; 
P(3, Ticker=="Utilities") = -1; 
 
% Specify q
q = [0.02; 0.005; 0.002];
 
% Specify Omega
Omega = diag([1e-3;1e-3;1e-3]);
 
%% Revised return based on Black-Litterman framework
 
M = inv(inv(C)+P'*(Omega\P));
mu = (inv(C)+P'*(Omega\P))\(C\Pi + P'*(Omega\q));
 
%% Maximize Sharpe Ratio
port0 = Portfolio('NumAssets', n, 'lb', 0, 'budget', 1);
port0 = setAssetMoments(port0, Pi, singlename_Covariance);
Port0Weights = estimateMaxSharpeRatio(port0);
 
portBL = Portfolio('NumAssets', n, 'lb', 0, 'budget', 1);
portBL = setAssetMoments(portBL, mu, singlename_Covariance);  
PortRevisedWeights = estimateMaxSharpeRatio(portBL);
 
%%
figure(1) 
bar([Pi mu]*100, 'BarWidth', 0.8)
set(gca,'xticklabel',Ticker);
ylabel('Expected Excess Return(%) - Black-Litterman')
text(1:length(Pi),Pi*100,...
    num2str(Pi*100, '%0.2f'),'vert','bottom','horiz','right');
text(1:length(mu),mu*100,...
    num2str(mu*100, '%0.2f'),'vert','bottom','horiz','left');
box off
legend({'Expected Excess Return(%) - Current',...
    'Expected Excess Return(%) - Black-Litterman'})
%%
figure(2)
bar([Port0Weights PortRevisedWeights]*100, 'BarWidth', 0.8)
set(gca,'xticklabel',Ticker);
ylabel('Allocation(%) - Black-Litterman')
text(1:length(Port0Weights),Port0Weights*100,...
    num2str(Port0Weights*100, '%0.1f'),'vert','bottom','horiz','right');
text(1:length(PortRevisedWeights),PortRevisedWeights*100,...
    num2str(PortRevisedWeights*100, '%0.1f'),'vert','bottom','horiz','left');
box off
legend({'Allocation(%) - Current','Allocation(%) - Black-Litterman'})
