% B5_Ch7_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% download stock prices for past two years
 
clc; close all; clear all
 
AssetList = {'AAPL','COST','FB',...
    'MSCI','PFE','QCOM','TSLA','YUM'};
 
price_assets = hist_stock_data('08092018','08082020',AssetList);
 
dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
num_assets = length(AssetList);
num_Bdays_year = 482;
Price_levels = extractfield(price_assets,'AdjClose');
Price_levels = reshape(Price_levels,num_Bdays_year,num_assets);
AssetScenarios = price2ret(Price_levels);
 
%% Volatility (standard deviation) as risk proxy
 
p_vol = Portfolio('AssetList',AssetList);
p_vol = estimateAssetMoments(p_vol, AssetScenarios);
p_vol = setDefaultConstraints(p_vol);
 
figure
plotFrontier(p_vol); box off; grid off
 
%% MAD as risk proxy
num_scenarios = 40;
 
p_MAD = PortfolioMAD('AssetList',AssetList);
p_MAD = setScenarios(p_MAD, AssetScenarios);
p_MAD = setDefaultConstraints(p_MAD);
p_MAD_weights = p_MAD.estimateFrontier(num_scenarios);
p_MAD_std = p_MAD.estimatePortStd(p_MAD_weights);
p_MAD_returns = p_MAD.estimatePortReturn(p_MAD_weights);
 
figure
plotFrontier(p_MAD); box off; grid off
 
figure
hold on
plotFrontier(p_vol); box off; grid off
plot(p_MAD_std,p_MAD_returns,'r')
legend('Variance','MAD')
%% CVaR (ES) as risk proxy
 
p_CVaR = PortfolioCVaR('AssetList',AssetList);
p_CVaR = setScenarios(p_CVaR, AssetScenarios);
p_CVaR = setDefaultConstraints(p_CVaR);
p_CVaR = setProbabilityLevel(p_CVaR, 0.95);
 
p_CVaR_weights = p_CVaR.estimateFrontier(num_scenarios);
p_CVaR_std = p_CVaR.estimatePortStd(p_CVaR_weights);
p_CVaR_returns = p_CVaR.estimatePortReturn(p_CVaR_weights);
 
figure
 
plotFrontier(p_CVaR); hold on
 
box off; grid off
 
figure
hold on
plotFrontier(p_vol); box off; grid off
plot(p_CVaR_std,p_CVaR_returns,'r')
legend('Variance','CVaR')
 
%% Compare components
 
p_vol_weights = p_vol.estimateFrontier(num_scenarios);
p_vol_std = p_vol.estimatePortStd(p_CVaR_weights);
p_vol_returns = p_vol.estimatePortReturn(p_CVaR_weights);
my_col = brewermap(num_assets,'RdYlBu');
 
figure
 
subplot(1,3,1)
h = area(p_vol_weights');
for i = 1:num_assets
    h(i).FaceColor = my_col(i,:);
end
 
title('Variance'); xlabel('Scenario'); ylabel('Weight')
xlim([1,num_scenarios]); ylim([0,1])
 
subplot(1,3,2)
h = area(p_MAD_weights');
for i = 1:num_assets
    h(i).FaceColor = my_col(i,:);
end
title('MAD'); xlabel('Scenario'); ylabel('Weight')
xlim([1,num_scenarios]); ylim([0,1])
 
subplot(1,3,3)
h = area(p_CVaR_weights');
for i = 1:num_assets
    h(i).FaceColor = my_col(i,:);
end
title('CVaR'); xlabel('Scenario'); ylabel('Weight')
xlim([1,num_scenarios]); ylim([0,1])
legend(p_CVaR.AssetList)
 
%% Plot ES for a certain portfolio on the efficient frontier
 
portNum = 10;
figure
plotCVaRHist(p_CVaR, p_CVaR_weights, AssetScenarios, portNum, 80)
 
portNum = 20;
figure
plotCVaRHist(p_CVaR, p_CVaR_weights, AssetScenarios, portNum, 80)
 
portNum = 30;
figure
plotCVaRHist(p_CVaR, p_CVaR_weights, AssetScenarios, portNum, 80)
%% Sub-functions
 
function plotCVaRHist(p, w, ret, portNum, nBin)

% portfolio returns given portNum
portRet = ret*w(:,portNum);
alpha = p.ProbabilityLevel;
% Calculate VaR and CVaR of the portfolios.
VaR = estimatePortVaR(p,w(:,portNum));
CVaR = estimatePortRisk(p,w(:,portNum));
 
% Convert positive number to negative number
VaR = -VaR;
CVaR = -CVaR;
 
% Plot main histogram
h1 = histogram(portRet,nBin);
 
figure;
h = histfit(portRet,nBin); hold on
xlabel('Daily returns')
ylabel('Frequency')
hold on;
 
% Highlight bins with lower edges < VaR level in red
edges = h1.BinEdges;
counts = h1.Values.*(edges(1:end-1) < VaR);
h2 = histogram('BinEdges',edges,'BinCounts',counts);
h2.FaceColor = 'r';
 
% Add CVaR line
plot([CVaR;CVaR],[0;max(h1.BinCounts)*0.80],'r')
plot([mean(portRet);mean(portRet)],[0;max(h1.BinCounts)*0.80],'r')
plot([std(portRet);std(portRet)],[0;max(h1.BinCounts)*0.80],'r')
plot([mean(portRet)-std(portRet);mean(portRet)-std(portRet)],[0;max(h1.BinCounts)*0.80],'r')
plot([VaR;VaR],[0;max(h1.BinCounts)*0.80],'r')
% Add CVaR text
title({[num2str(round(alpha*100)),'% VaR = ' num2str(round(-VaR,4)),';',...
    num2str(round(alpha*100)),'% CVaR = ' num2str(round(-CVaR,4))],...
    ['\mu = ',num2str(mean(portRet)),'; \sigma = ' num2str(std(portRet))]})
box off; grid off
hold off;
end
