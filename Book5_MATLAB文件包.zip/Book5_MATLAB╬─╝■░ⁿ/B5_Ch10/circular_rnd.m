function [X,Y] = circular_rnd(num)
rng(1); % For reproducibility
r = sqrt(rand(num,1)); % Radius
t = 2*pi*rand(num,1);  % Angle
X1 = [r.*cos(t), r.*sin(t)]; % Points

r2 = sqrt(3*rand(num,1)+1); % Radius
t2 = 2*pi*rand(num,1);      % Angle
X2 = [r2.*cos(t2), r2.*sin(t2)]; % points

X = [X1; X2];        % Predictors
Y = ones(2*num,1);
Y(num + 1:end) = -1; % Labels

end