% B5_Ch10_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
Income = X(:,1);
Rating = X(:,2);
 
income_range = 0:1000:160000;
rating_range = 300:5:900;
 
Y_C1 = nan(size(Y));
masks = (Y == 1);
Y_C1(masks) = 1;
X_C1 = X;
X_C1 (~masks,:) = NaN;
 
Y_C2(~masks) = -1;
X_C2 = X;
X_C2 (masks,:) = NaN;
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
ax = gca;
ax.XAxis.Exponent = 0;
hold off
xlabel('Income (k$)'); ylabel('Credit score')
legend({'Good loan, C_1','Bad loan, C_2'},'location','best');
 
 
figure(i_fig)
i_fig = i_fig + 1;
P_C1 = nansum(Y_C1)/length(Y);
P_C2 = nansum(-Y_C2)/length(Y);
Prob_C = [P_C1,P_C2];
Freq_C = [sum(Y==1),sum(Y==-1)];

labels = categorical({'P(C_1)','P(C_2)'});
labels = reordercats(labels,{'P(C_1)','P(C_2)'});
 
subplot(1,2,1)
bar(labels,Freq_C,0.5)
text([1:length(Freq_C)], Freq_C', num2str(Freq_C','%0.0f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
box off; ylabel('Frequency')
 
subplot(1,2,2)
bar(labels,Prob_C,0.5)
text([1:length(Prob_C)], Prob_C', num2str(Prob_C','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
box off; ylabel('Probability')
 
%% Naive Bayes
 
% distribution default: normal; Gaussian Naive Bayes
Mdl = fitcnb(X,Y,'ClassNames',[-1,1]);
 
% Kernel Naive Bayes
% Mdl = fitcnb(X,Y,'ClassNames',[-1,1],'DistributionNames','kernel');
x1range = min(X(:,1)):1000:max(X(:,1));
x2range = min(X(:,2)):5:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
[~,scores] = predict(Mdl,XGrid);
 
%% contour plot, for normal distribution only!!!
 
figure(i_fig)
i_fig = i_fig + 1;
hold all
 
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
 
Params = cell2mat(Mdl.DistributionParameters);
Mu = Params(2*(1:2)-1,1:2); % Extract the means
Sigma = zeros(2,2,2); % correlation = 0
 
for j = 1:2
    Sigma(:,:,j) = diag(Params(2*j,:)).^2;
    % Create diagonal covariance matrix
    
    pdf = reshape(mvnpdf(XGrid,Mu(j,:),Sigma(:,:,j)),size(x1Grid));
    contour(x1Grid/1000,x2Grid,reshape(pdf,size(x1Grid)),25)
    
    % Draw contours for the multivariate normal distributions
end
 
title('Naive Bayes Classifier')
xlabel('Petal Length (cm)')
ylabel('Petal Width (cm)')
legend('setosa','versicolor','virginica')
hold off
ax = gca;
ax.XAxis.Exponent = 0;
hold off; axis square
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
legend({'Good loan, C_1','Bad loan, C_2'},'location','best');
%% Plot decision boundary
 
figure(i_fig)
i_fig = i_fig + 1;
hold on
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
 
contour(x1Grid/1000,x2Grid,reshape(scores(:,2),size(x1Grid)),...
    [0.5 0.5],'r','LineWidth',1.25);
 
ax = gca;
ax.XAxis.Exponent = 0;
hold off
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
legend({'Good loan, C_1','Bad loan, C_2'},'location','best');
axis square
 
%% Plot posterior probability distribution for each class
 
figure(i_fig)
i_fig = i_fig + 1;
 
mesh(x1Grid/1000,x2Grid,reshape(scores(:,1),size(x1Grid)));
 
ax = gca;
ax.XAxis.Exponent = 0;
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
view(-30,60); title('Posterior, p(C_1 | x)'); axis tight;
 
figure(i_fig)
i_fig = i_fig + 1;
 
mesh(x1Grid/1000,x2Grid,reshape(scores(:,2),size(x1Grid)));
 
ax = gca;
ax.XAxis.Exponent = 0;
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
view(-30,60); title('Posterior, p(C_2 | x)'); axis tight;
 
%% Sample data generator
 
function [X,Y] = generate_rnd(num)
% num = 100; % test only
rng(1); % For reproducibility
mu1 = [25000 450]; % income, credit score
mu2 = [85000 700];
sigma1 = [15000, 0; 0, 100] *[1 0.3;0.3 1]*[15000, 0; 0, 100];
sigma2 = [20000, 0; 0, 75]*[1 0.2;0.2 1]*[20000, 0; 0, 75];
 
X = [mvnrnd(mu1,sigma1,ceil(num*0.6));
    mvnrnd(mu2,sigma2,num - ceil(num*0.6))];
mask1 = (or((X(:,2) >= 900),(X(:,2) <= 300)));
X(mask1,:)= nan;
mask2 = (X(:,1) <= 0);
X(mask2,:)= nan;
masks = (X == nan);
mask = or(masks(:,1),masks(:,2));
 
 
Y = -ones(num,1);
Y(ceil(num*0.6) + 1:end) = 1; % Labels
Y(mask) = nan;
end
