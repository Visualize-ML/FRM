% B5_Ch10_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
Income = X(:,1);
Rating = X(:,2);
 
 
income_range = 0:1000:160000;
rating_range = 300:5:900;
 
 
Y_C1 = nan(size(Y));
masks = (Y == 1);
Y_C1(masks) = 1;
X_C1 = X;
X_C1 (~masks,:) = NaN;
 
Y_C2(~masks) = -1;
X_C2 = X;
X_C2 (masks,:) = NaN;
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
ax = gca;
ax.XAxis.Exponent = 0;
hold off; axis square
xlabel('Income (k$)'); ylabel('Credit score')
legend({'Good loan, C_1','Bad loan, C_2'},'location','best');
 
 
figure(i_fig)
i_fig = i_fig + 1;
P_C1 = nansum(Y_C1)/length(Y);
P_C2 = nansum(-Y_C2)/length(Y);
Prob_C = [P_C1,P_C2];
Freq_C = [sum(Y==1),sum(Y==-1)];
labels = categorical({'P(C_1)','P(C_2)'});
labels = reordercats(labels,{'P(C_1)','P(C_2)'});
 
subplot(1,2,1)
bar(labels,Freq_C,0.5)
text([1:length(Freq_C)], Freq_C', num2str(Freq_C','%0.0f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
box off; ylabel('Frequency')
 
subplot(1,2,2)
bar(labels,Prob_C,0.5)
text([1:length(Prob_C)], Prob_C', num2str(Prob_C','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
box off; ylabel('Probability')
 
%% Discriminant Analysis
 
% same diagonal covariance; boundary: linear
Mdl = fitcdiscr(X,Y,'ClassNames',[-1,1],'DiscrimType','diaglinear');

b = Mdl.Coeffs(2,1).Const;
w = Mdl.Coeffs(2,1).Linear;
mu1 = Mdl.Mu(1,:);
mu2 = Mdl.Mu(2,:);
% [x1, x2]w + b = 0; % decision boundary
f = @(x1,x2)b + w(1)*x1*1000 + w(2)*x2;
% function of linear decision boundary
 
% same non-diagonal covariance; boundary: linear
Mdl = fitcdiscr(X,Y,'ClassNames',[-1,1],'DiscrimType','linear');
b = Mdl.Coeffs(2,1).Const;
w = Mdl.Coeffs(2,1).Linear;
mu1 = Mdl.Mu(1,:);
mu2 = Mdl.Mu(2,:);
% [x1, x2]w + b = 0; % decision boundary
f = @(x1,x2)b + w(1)*x1*1000 + w(2)*x2;
% function of linear decision boundary
 
% varying diagonal covariance; boundary: quadratic, no x1x2 term
Mdl = fitcdiscr(X,Y,'ClassNames',[-1,1],'DiscrimType','diagquadratic');
b = Mdl.Coeffs(1,2).Const;
w = Mdl.Coeffs(1,2).Linear;
Q = Mdl.Coeffs(1,2).Quadratic;
mu1 = Mdl.Mu(1,:);
mu2 = Mdl.Mu(2,:);
% [x1^2, x2^2]q + [x1, x2]w + b = 0; % decision boundary
f = @(x1,x2)b + w(1)*x1*1000 + w(2)*x2 + Q(1)*x1^2*1000^2 + Q(2)*x2^2;
% function of quadratic decision boundary
 
% varying non-diagonal covariance; boundary: quadratic
Mdl = fitcdiscr(X,Y,'ClassNames',[-1,1],'DiscrimType','quadratic');
b = Mdl.Coeffs(1,2).Const
w = Mdl.Coeffs(1,2).Linear
Q = Mdl.Coeffs(1,2).Quadratic
mu1 = Mdl.Mu(1,:);
mu2 = Mdl.Mu(2,:);
% [x1^2, x2^2]q + [x1, x2]w + b = 0; % decision boundary
f = @(x1,x2)b + w(1)*x1*1000 + w(2)*x2 + ...
    q(1,1)*x1^2*1000^2 + (Q(2,1) + Q(1,2))*x1.*x2*1000 + Q(2,2)*x2^2;
% function of quadratic of quadratic decision boundary
 
figure(i_fig)
i_fig = i_fig + 1;
hold on
 
 
h2 = fimplicit(f,[0 160 300 900]);
h2.Color = 'r';
h2.LineWidth = 1.5;
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
 
plot(mu1(1,1)/1000,mu1(1,2),'xk','MarkerSize',12')
plot(mu2(1,1)/1000,mu2(1,2),'xk','MarkerSize',12')
 
ax = gca;
ax.XAxis.Exponent = 0;
hold off; axis square
xlabel('Income, x1 (k$)'); ylabel('Credit score, x2')
legend({'Decision boundary','Good loan, C_1','Bad loan, C_2'},'location','best');
 
%% contour plot, for normal distribution only
x1range = min(X(:,1)):1000:max(X(:,1));
x2range = min(X(:,2)):5:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
[~,scores] = predict(Mdl,XGrid);
 
% Plot decision boundary using contour()
 
figure(i_fig)
i_fig = i_fig + 1;
% gscatter(xx1(:), xx2(:), predictedspecies,'rgb');
hold on
contour(x1Grid/1000,x2Grid,reshape(scores(:,2),size(x1Grid)),[0.5 0.5],'r','LineWidth',1.25);
 
plot(X_C1(:,1)/1000,X_C1(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[146,208,80]/255,...
    'MarkerEdgeColor','w')
 
plot(X_C2(:,1)/1000,X_C2(:,2),'LineStyle', 'none',...
    'Marker','o','MarkerFaceColor',[0,153,219]/255,...
    'MarkerEdgeColor','w')
 
ax = gca; ax.XAxis.Exponent = 0; hold off
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
legend({'Decision boundary','Good loan, C_1','Bad loan, C_2'},'location','best');
axis square; ylim([300,900]); xlim([0,160]);
 
%% Generate random data
 
function [X,Y] = generate_rnd(num)
% num = 100; % test only
rng(1); % For reproducibility
mu1 = [25000 450]; % income, credit score
mu2 = [85000 700];
sigma1 = [15000, 0; 0, 100] *[1 0.3;0.3 1]*[15000, 0; 0, 100];
sigma2 = [20000, 0; 0, 75]*[1 0.2;0.2 1]*[20000, 0; 0, 75];
 
X = [mvnrnd(mu1,sigma1,ceil(num*0.6));
    mvnrnd(mu2,sigma2,num - ceil(num*0.6))];
mask1 = (or((X(:,2) >= 900),(X(:,2) <= 300)));
X(mask1,:)= nan;
mask2 = (X(:,1) <= 0);
X(mask2,:)= nan;
masks = (X == nan);
mask = or(masks(:,1),masks(:,2));

Y = -ones(num,1);
Y(ceil(num*0.6) + 1:end) = 1; % Labels
Y(mask) = nan;
end
