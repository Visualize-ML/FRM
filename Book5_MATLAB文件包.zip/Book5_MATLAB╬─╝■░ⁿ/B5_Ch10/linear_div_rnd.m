
function [X,Y] = linear_div_rnd(num)
rng(1); % For reproducibility
X = [randn(num,2)*0.75+ones(num,2);
    randn(num,2)*0.75-ones(num,2)];
Y = ones(2*num,1);
Y(num + 1:end) = -1; % Labels

end