% B5_Ch10_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
% Generate training data set
num = 100; % half of the data size in dataset
[X,Y] = linear_div_rnd(num);
% [X,Y] = circular_rnd(num);
% [X,Y] = crescent_rnd(num);
% [X,Y] = quadrant_rnd(num);
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
colors = [146,208,80;0,153,219;]/255;
h = gscatter(X(:,1),X(:,2),Y,colors,'.');
hold off; axis square
xlabel('x_1'); ylabel('x_2')
query_point = [0 0];
line(query_point(1),query_point(2),'marker','x','color','k',...
    'markersize',10,'linewidth',2)
legend off
%% k-nearest neighbors
 
% same diagonal covariance; boundary: linear
num_NNs = 3:3:12;
 
figure(i_fig)
i_fig = i_fig + 1;
 
 
for i = 1:length(num_NNs)
    subplot(2,2,i)
    Mdl = KDTreeSearcher(X);
    [loc_query_NN,d] = knnsearch(Mdl,query_point,'k',num_NNs(i));
    line(X(loc_query_NN,1),X(loc_query_NN,2),'color',[.5 .5 .5],'marker','o',...
        'linestyle','none','markersize',8)
    freq_y = tabulate(Y(loc_query_NN(1,:)))
    
    hold on
    line(query_point(1),query_point(2),'marker','x','color','k',...
        'markersize',10,'linewidth',2)
    h = gscatter(X(:,1),X(:,2),Y,colors,'.');
    
    h1 = h(1); h1.MarkerSize = 8;
    h2 = h(2); h2.MarkerSize = 8;
    ctr = query_point - d(end);
    diameter = 2*d(end);
    % Draw a circle around the nearest neighbors.
    h = rectangle('position',[ctr,diameter,diameter],...
        'curvature',[1 1]);
    h.LineStyle = ':';
    h.EdgeColor = 'r';
    xlim([-0.75,0.75]); xticks([-0.5:0:0.5])
    ylim([-0.75,0.75]); yticks([-0.5:0:0.5])
    hold off; axis square
    title_text = {['k = ',num2str(num_NNs(i))],...
        ['-1 = ',num2str(freq_y(1,3)),' %'],...
        ['+1 = ',num2str(freq_y(2,3)),' %']};
    
    legend off; title(title_text)
    
end
