% B5_Ch10_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
% Generate training data set
num = 100; % half of the data size in dataset
[X,Y] = linear_div_rnd(num);
% [X,Y] = circular_rnd(num);
% [X,Y] = crescent_rnd(num);
% [X,Y] = quadrant_rnd(num);
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
colors = [0,153,219; 146,208,80;]/255; % -1, 1
h = gscatter(X(:,1),X(:,2),Y,colors,'.');
xlabel('Sepal length'); ylabel('Sepal width');
hold off; axis square
xlabel('x_1'); ylabel('x_2')
legend off; xticks([-2,0,2]); yticks([-2,0,2]);
%% k-nearest neighbors
 
% same diagonal covariance; boundary: linear
num_NNs = 1:2:7;
x1range = min(X(:,1)):0.01:max(X(:,1));
x2range = min(X(:,2)):0.01:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
 
figure(i_fig)
i_fig = i_fig + 1;
 
 
for i = 1:length(num_NNs)
    subplot(2,2,i)
    Mdl = fitcknn(X,Y,'NumNeighbors',num_NNs(i));
%     Mdl = fitcknn(X,Y,'NumNeighbors',num_NNs(i),'DistanceWeight','inverse');
    
    % 'DistanceWeight' � Distance weighting function
    % Options: 'equal' (default) | 'inverse' | 'squaredinverse'
    %
    % 'Distance' � Distance metric
    % Options: 'cityblock' | 'chebychev' | 'correlation' | 'cosine' |
    % 'euclidean' ...
    
    predictedspecies = predict(Mdl,XGrid);
    
    contour(x1Grid,x2Grid,reshape(predictedspecies,size(x1Grid)),[0 0],'r','LineWidth',1.25);
    hold on
    h = gscatter(X(:,1),X(:,2),Y,colors,'.');
    h1 = h(1); h1.MarkerSize = 8;
    h2 = h(2); h2.MarkerSize = 8;
    xlim([min(X(:,1)),max(X(:,1))])
    ylim([min(X(:,2)),max(X(:,2))])
    hold off; axis square; legend off
    title(['k = ',num2str(num_NNs(i))])
    legend off; xticks([-2,0,2]); yticks([-2,0,2]);
    xlabel('x_1'); ylabel('x_2')
end

