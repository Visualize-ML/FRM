function [X,Y] = crescent_rnd(num)
rng(1); % For reproducibility
r1 = sqrt(3*rand(num,1)+1); % Radius
t1 = pi*rand(num,1)*1.4 - 0.2*pi;      % Angle
X1 = [r1.*cos(t1), r1.*sin(t1)]; % points

r2 = sqrt(3*rand(num,1)+1); % Radius
t2 = -pi*rand(num,1)*1.4 + 0.2*pi;      % Angle
X2 = [r2.*cos(t2) + 3/2, r2.*sin(t2)]; % points

X = [X1; X2];        % Predictors
Y = ones(2*num,1);
Y(num + 1:end) = -1; % Labels

end