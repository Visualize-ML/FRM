% B5_Ch2_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
N = 1000;
Dim = 50;
 
gn =  lhsdesign(N, Dim);
 
figure
scatter(gn(:,25), gn(:,26), 5, ...
    'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',1)
xlabel(strcat('Dimension 25'))
ylabel(strcat('Dimension 26'))
