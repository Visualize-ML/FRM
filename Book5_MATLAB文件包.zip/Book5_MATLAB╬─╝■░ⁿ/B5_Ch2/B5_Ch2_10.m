% B5_Ch2_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch2_10_A.m

close all; clear all; clc

% Fetch interest rate(IR) data from FRED
url = 'https://fred.stlouisfed.org/';
c = fred(url);

% Define time horizon
startdate = '01/01/2014';
enddate = '01/01/2020';

% Define data scope
DataIR = [];
series_nodes = {'DGS1MO'; 'DGS3MO'; 'DGS6MO';...
    'DGS1'; 'DGS2'; 'DGS3'; 'DGS5';...
    'DGS10'; 'DGS30';};

% Number of IR variables
NumIRs = length(series_nodes);

for i = 1:NumIRs
    series = series_nodes(i);
    DATA = fetch(c,series,startdate,enddate);
    DataIR(:,i) = DATA.Data(:,2);
end

% Remove missing values
DataIR(any(isnan(DataIR),2),:) = [];

% B5_Ch2_10_B.m

% Compute difference
DataIRDiff = diff(DataIR);

% Normalize IR data
for i = 1:NumIRs
    Average(i) = mean(DataIRDiff(:, i));
    Deviation(i) = std(DataIRDiff(:, i));
    
    DataIRDiff(:, i) =...
        (DataIRDiff(:, i)-Average(i))/Deviation(i);
    
end

% Convert daily standard deviation to
% 10-day standard deviation to
% match the VaR period using square-root-of-time rule
Deviation = Deviation*sqrt(10);

% B5_Ch2_10_C.m

% Compute principal components
var_weights = 1./var(DataIRDiff);

[wcoeff, score, latent, tsquared, explained] = ...
    pca(DataIRDiff, 'VariableWeights', var_weights);

coefforth = inv(diag(std(DataIRDiff)))*wcoeff;

% plotting
figure(1)
original_dim = 1:NumIRs;
xticks(original_dim)
xticklabels({'1M','3M','6M','1Yr','2Yr',...
    '3Yr','5Yr','10Yr','30Yr'})

plot(original_dim, coefforth(:,1),'r');
hold on
plot(original_dim, coefforth(:,2), 'color', [0,200,75]./255);
hold on
plot(original_dim, coefforth(:,3),'b')

legend('PC1','PC2','PC3')
box off
xlabel('Tenors')
ylabel('First 3 Principal Components')
legend boxoff

% B5_Ch2_10_D.m

% eigs if Vi is an eigenvector.
[V, E] = eigs(cov(DataIRDiff),3);

% First three principal components
PC1 = V(:,1);
PC2 = V(:,2);
PC3 = V(:,3);

% B5_Ch2_10_E.m

% Set up bond parameters
% Bond 1
W1 = 0.25;
FaceValue1 = 1e3;
% Annual coupon rate
CouponRate1 = 6e-2;
Coupon1 = FaceValue1*CouponRate1/2;

% Bond 2
W2 = 1 - W1;
FaceValue2 = 1e3;
% Annual coupon rate
CouponRate2 = 8e-2;
Coupon2 = FaceValue2*CouponRate2/2;

% Record current rates
CurrentRates = DataIR(size(DataIR,1),:);

M6 = CurrentRates(1, 3);  % 6-month spot rate
Y1 = CurrentRates(1, 4);  % 1-year spot rate
Y2 = CurrentRates(1, 5);  % 2-year spot rate
Y3 = CurrentRates(1, 6);  % 3-year spot rate
Y5 = CurrentRates(1, 7);  % 5-year spot rate
Y10 = CurrentRates(1, 8); % 10-year spot rate

% Linear interpolation
Y1_5 = (Y1 + Y2)/2;        % 1.5-year spot rate
Y2_5 = (Y2 + Y3)/2;        % 2.5-year spot rate
Y3_5 = (3*Y3 + Y5)/4;      % 3.5-year spot rate
Y4 = (Y3 + Y5)/2;          % 4-year spot rate
Y4_5 = (3*Y5 + Y3)/4;      % 4.5-year spot rate
Y5_5 = (9*Y5 + Y10)/10;    % 5.5-year spot rate
Y6 = (8*Y5 + 2*Y10)/10;    % 6-year spot rate
Y6_5 = (7*Y5 + 3*Y10)/10;  % 6.5-year spot rate
Y7 = (6*Y5 + 4*Y10)/10;    % 7-year spot rate

% Compute current individual bond price
CurrentPrice1 = Coupon1/(1+M6)^0.5 +...
    Coupon1/(1+Y1)^1 +...
    Coupon1/(1+Y1_5)^1.5 +...
    Coupon1/(1+Y2)^2 +...
    (FaceValue1+Coupon1)/(1+Y2_5)^2.5;

CurrentPrice2 = Coupon2/(1+M6)^0.5 +...
    Coupon2/(1+Y1)^1 +...
    Coupon2/(1+Y1_5)^1.5 +...
    Coupon2/(1+Y2)^2 +...
    Coupon2/(1+Y2_5)^2.5 +...
    Coupon2/(1+Y3)^3 +...
    Coupon2/(1+Y3_5)^3.5 +...
    Coupon2/(1+Y4)^4 +...
    Coupon2/(1+Y4_5)^4.5 +...
    Coupon2/(1+Y5)^5 +...
    Coupon2/(1+Y5_5)^5.5 +...
    Coupon2/(1+Y6)^6 +...
    Coupon2/(1+Y6_5)^6.5 +...
    (FaceValue2+Coupon2)/(1+Y7)^7;

% Compute current portfolio price
CurrentPortPrice = W1*CurrentPrice1+W2*CurrentPrice2;

% B5_Ch2_10_F.m

% Generate random paths
% Number of simulations
Nsim = 1000;

u1 = zeros(Nsim,1);
u2 = zeros(Nsim,1);

% Quasi random numbers
b1 = 3;
b2 = 5;

% Choose the RNG
Flag = 1;

switch Flag
    
    case 1
        % Quasi random number
        for i = 1:Nsim
            u1(i) = norminv(VanDerCorput(i, b1));
            u2(i) = norminv(VanDerCorput(i, b2));
        end
    case 2
        % Normal random number
        rng('default')
        u1 = randn(Nsim, 1);
        u2 = randn(Nsim, 1);
end

% B5_Ch2_10_G.m

% Create spot-rate matrix
IRs = zeros(NumIRs, Nsim);

for i = 1:NumIRs
    for j = 1:Nsim
        
        IRs(i, j) = CurrentRates(1, i)+ ...
            Deviation(i)*...
            (sign(V(1,1))*V(i,1)*sqrt(E(1,1))*u1(j,1)+...
            sign(V(1,2))*V(i,2)*sqrt(E(2,2))*u2(j,1));
        
    end
end

% B5_Ch2_10_H.m

% Loop computing the possible evolution of the portfolio�s price.
for i = 1:Nsim
    
    % Recompute IRs
    M6 = IRs(3, i);  % 6-month spot rate
    Y1 = IRs(4, i);  % 1-year spot rate
    Y2 = IRs(5, i);  % 2-year spot rate
    Y3 = IRs(6, i);  % 3-year spot rate
    Y5 = IRs(7, i);  % 5-year spot rate
    Y10 = IRs(8, i); % 10-year spot rate
    
    % Linear interpolation
    Y1_5 = (Y1 + Y2)/2;        % 1.5-year spot rate
    Y2_5 = (Y2 + Y3)/2;        % 2.5-year spot rate
    Y3_5 = (3*Y3 + Y5)/4;      % 3.5-year spot rate
    Y4 = (Y3 + Y5)/2;          % 4-year spot rate
    Y4_5 = (3*Y5 + Y3)/4;      % 4.5-year spot rate
    Y5_5 = (9*Y5 + Y10)/10;    % 5.5-year spot rate
    Y6 = (8*Y5 + 2*Y10)/10;    % 6-year spot rate
    Y6_5 = (7*Y5 + 3*Y10)/10;  % 6.5-year spot rate
    Y7 = (6*Y5 + 4*Y10)/10;    % 7-year spot rate
    
    % Recompute individual bond price
    Price1 = Coupon1/(1+M6)^0.5 +...
        Coupon1/(1+Y1)^1 +...
        Coupon1/(1+Y1_5)^1.5 +...
        Coupon1/(1+Y2)^2 +...
        (FaceValue1+Coupon1)/(1+Y2_5)^2.5;
    
    Price2 = Coupon2/(1+M6)^0.5 +...
        Coupon2/(1+Y1)^1 +...
        Coupon2/(1+Y1_5)^1.5 +...
        Coupon2/(1+Y2)^2 +...
        Coupon2/(1+Y2_5)^2.5 +...
        Coupon2/(1+Y3)^3 +...
        Coupon2/(1+Y3_5)^3.5 +...
        Coupon2/(1+Y4)^4 +...
        Coupon2/(1+Y4_5)^4.5 +...
        Coupon2/(1+Y5)^5 +...
        Coupon2/(1+Y5_5)^5.5 +...
        Coupon2/(1+Y6)^6 +...
        Coupon2/(1+Y6_5)^6.5 +...
        (FaceValue2+Coupon2)/(1+Y7)^7;
    
    %Computation of the portfolio�s price for this scenario
    PortPrice(i,1) = W1*Price1+W2*Price2;
    
end

% VaR computation
% Significance level alpha
alpha = 0.01;

% Sort the price in ascending order
PortPrice = sort(PortPrice);

% Plot of PnL disctribution
% Profit is positive and Loss is negative
PnL = PortPrice - CurrentPortPrice;

% Find VaR value
VaR = -(PnL(floor(alpha*Nsim)))

function gn = VanDerCorput(n,b)
% Generate the Van Der Corput sequence
% n: Beginning point to generate the sequence
% b: base of the sequence

% The n-th element in base b
gn = 0;
% k represents the powers of b in the decomposition of n
k = 0;

while n~=0
    gn = gn + mod(n,b)/b^(k+1);
    
    n = floor(n/b);
    
    k = k+1;
end

end
