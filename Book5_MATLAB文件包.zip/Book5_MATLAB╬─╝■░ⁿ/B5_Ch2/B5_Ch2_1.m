% B5_Ch2_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
% Set up random number generator
rng(19)
 
% Set up parameters of stock
S0 = 50;
mu = 0.25;
sigma = 0.1;
musig = mu - 0.5*sigma^2;
 
% Set up time horizon
time = 10;
steps = 500;
dt = time/steps;
sqrt_dt = sqrt(dt);
 
% Set up Poisson Jump Process
% Rate of jumps per year
lambda = 0.5;
% Max Jump Down, Up
Qa = -1.4;
Qb = 0.6;
 
% Expected Jump size to last stock price E[J(Q)]
JQExpect = (exp(Qb)-exp(Qa))/(Qb-Qa) - 1;

% Set up starting point t = 0;
% Uniform-distribution jump
S_Udist(1) = S0;
DeltaS_Udist(1) = 0;
SExpect_Udist(1) = S0;
 
% One-size/Constant jump
S_OneSize(1) = S0;
DeltaS_OneSize(1) = 0;
SExpect_OneSize(1) = S0;
 
% Count total numbe of jumps
jumptot = 0;
 
% Simulation starts
for i = 2:steps
    
    % Compute expectation of S_t+1 based on S_t
    SExpect_Udist(i) = ...
        SExpect_Udist(i-1)*exp(mu*dt + JQExpect*lambda*dt);
    
    SExpect_OneSize(i) = ...
        SExpect_OneSize(i-1)*exp(mu*dt + JQExpect*lambda*dt);
    
    % Poisson process is determined by comparing
    % lambda*dt and the random number
    RandNumberA = rand;
    
    % Normal-distribution random number for diffusion
    RandNumberB = randn;
    
    % There is a JUMP when the "if" condition satisified
    if (lambda*dt > RandNumberA)
        jumptot = jumptot + 1;
        
        % Uniform-distribution jump
        RandNumberC = rand;
        Q = Qa+(Qb-Qa)*RandNumberC;
        
        S_Udist(i) = S_Udist(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB + Q);
        
        DeltaS_Udist(i) = S_Udist(i-1)*(exp(Q)-1);
        
        % One-size Jump
        S_OneSize(i) = S_OneSize(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB + ...
            JQExpect);
        
        DeltaS_OneSize(i) = S_OneSize(i-1)*(exp(JQExpect)-1);
        
    else
        % There is NO JUMP
        % For the case of Uniform-distribution jump
        S_Udist(i) = S_Udist(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB);
        
        DeltaS_Udist(i) = 0;
        
        % For the case of One-size Jump
        S_OneSize(i) = S_OneSize(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB);
        
        DeltaS_OneSize(i) = 0;
        
    end
    
end
 
xax = (1:steps)*dt;
 
% Plotting
figure
plot(xax,SExpect_Udist,':',xax,S_Udist,xax, DeltaS_Udist,'--')
legend('Expected {\itS}_{\itt}', '{\itS}_{\itt}', '\Delta{\itS}_{\itt}',...
    'Location', 'NorthWest')
title('{\itS}_{\itt} with Distributed Jump')
xlabel('Years')
ylabel('{\itS}_{\itt}')
axis tight
 
figure
plot(xax, SExpect_OneSize, ':', xax, S_OneSize, xax, DeltaS_OneSize,'--')
legend('Expected {\itS}_{\itt}', '{\itS}_{\itt}', '\Delta{\itS}_{\itt}',...
    'Location', 'NorthWest')
title('{\itS}_{\itt} with One-Size Jump')
xlabel('Years')
ylabel('{\itS}_{\itt}')
axis tight


close all; clear all; clc
 
% Set up random number generator
rng(19)
 
% Set up parameters of stock
S0 = 50;
mu = 0.25;
sigma = 0.1;
musig = mu - 0.5*sigma^2;
 
% Set up time horizon
time = 10;
steps = 500;
dt = time/steps;
sqrt_dt = sqrt(dt);
 
% Set up Poisson Jump Process
% Rate of jumps per year
lambda = 0.5;
% Max Jump Down, Up
Qa = -1.4;
Qb = 0.6;
 
% Expected Jump size to last stock price E[J(Q)]
JQExpect = (exp(Qb)-exp(Qa))/(Qb-Qa) - 1;

% Set up starting point t = 0;
% Uniform-distribution jump
S_Udist(1) = S0;
DeltaS_Udist(1) = 0;
SExpect_Udist(1) = S0;
 
% One-size/Constant jump
S_OneSize(1) = S0;
DeltaS_OneSize(1) = 0;
SExpect_OneSize(1) = S0;
 
% Count total numbe of jumps
jumptot = 0;
 
% Simulation starts
for i = 2:steps
    
    % Compute expectation of S_t+1 based on S_t
    SExpect_Udist(i) = ...
        SExpect_Udist(i-1)*exp(mu*dt + JQExpect*lambda*dt);
    
    SExpect_OneSize(i) = ...
        SExpect_OneSize(i-1)*exp(mu*dt + JQExpect*lambda*dt);
    
    % Poisson process is determined by comparing
    % lambda*dt and the random number
    RandNumberA = rand;
    
    % Normal-distribution random number for diffusion
    RandNumberB = randn;
    
    % There is a JUMP when the "if" condition satisified
    if (lambda*dt > RandNumberA)
        jumptot = jumptot + 1;
        
        % Uniform-distribution jump
        RandNumberC = rand;
        Q = Qa+(Qb-Qa)*RandNumberC;
        
        S_Udist(i) = S_Udist(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB + Q);
        
        DeltaS_Udist(i) = S_Udist(i-1)*(exp(Q)-1);
        
        % One-size Jump
        S_OneSize(i) = S_OneSize(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB + ...
            JQExpect);
        
        DeltaS_OneSize(i) = S_OneSize(i-1)*(exp(JQExpect)-1);
        
    else
        % There is NO JUMP
        % For the case of Uniform-distribution jump
        S_Udist(i) = S_Udist(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB);
        
        DeltaS_Udist(i) = 0;
        
        % For the case of One-size Jump
        S_OneSize(i) = S_OneSize(i-1)*...
            exp(musig*dt + sigma*sqrt_dt*RandNumberB);
        
        DeltaS_OneSize(i) = 0;
        
    end
    
end
 
xax = (1:steps)*dt;
 
% Plotting
figure
plot(xax,SExpect_Udist,':',xax,S_Udist,xax, DeltaS_Udist,'--')
legend('Expected {\itS}_{\itt}', '{\itS}_{\itt}', '\Delta{\itS}_{\itt}',...
    'Location', 'NorthWest')
title('{\itS}_{\itt} with Distributed Jump')
xlabel('Years')
ylabel('{\itS}_{\itt}')
axis tight
 
figure
plot(xax, SExpect_OneSize, ':', xax, S_OneSize, xax, DeltaS_OneSize,'--')
legend('Expected {\itS}_{\itt}', '{\itS}_{\itt}', '\Delta{\itS}_{\itt}',...
    'Location', 'NorthWest')
title('{\itS}_{\itt} with One-Size Jump')
xlabel('Years')
ylabel('{\itS}_{\itt}')
axis tight
