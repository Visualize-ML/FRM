% B5_Ch2_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
N = [1e1, 1e2, 1e3, 1e4];
b = 3;
VDC_Seq = [];
 
for i = 1:length(N)
    
    for n = 1:N(i)
        VDC_Seq(n, i) = VanDerCorput(n, b);
    end
    
end
 
figure
nbins = 50;

for i = 1:length(N)    
subplot(4,1,i)

    histogram(VDC_Seq(1:N(i), i), nbins, ...
        'Normalization','probability')

    xlim([0,1])
    ylabel('Probability')
title(strcat('Simple Size N = ', string(N(i))))
end

function gn = VanDerCorput(n,b)
% Generate the Van Der Corput sequence
% n: Beginning point to generate the sequence
% b: base of the sequence
 
% The n-th element in base b
gn = 0;
% k represents the powers of b in the decomposition of n
k = 0;
 
while n~=0
gn = gn + mod(n,b)/b^(k+1);

    n = floor(n/b);

    k = k+1;
end
 
end
