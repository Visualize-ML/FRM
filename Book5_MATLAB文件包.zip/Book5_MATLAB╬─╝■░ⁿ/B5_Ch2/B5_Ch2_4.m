% B5_Ch2_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
N = 1e3;
Dim = 2;
 
% Using haltonset() function
Halobj = haltonset(Dim)
 
Hal_Seq = net(Halobj, N);
 
 
figure
scatter(Hal_Seq(:, 2), Hal_Seq(:, 1), 5, ...
    'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',1)
xlabel(strcat('Dimension 1'))
ylabel(strcat('Dimension 2'))
