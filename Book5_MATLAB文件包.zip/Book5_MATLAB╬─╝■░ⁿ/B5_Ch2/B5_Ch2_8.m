% B5_Ch2_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
range('default')

N = 1000;
Dim = 2;
 
gn =  LatinHypercube(N, Dim);

figure
scatter(gn(:,1), gn(:,2), 5, ...
    'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',1)
xlabel(strcat('Dimension 1'))
ylabel(strcat('Dimension 2'))
axis square

function gn = LatinHypercube(N, Dim)
% Generate Latin Hypercube sequence
% N: Number of points to generate
% Dim: Dimension of the sample
 
Matrix = rand(N, Dim);
 
for j = 1:Dim
shuffle = randperm(N);

Matrix(:,j) = (shuffle'-1+Matrix(:,j))/N;

end
 
gn = Matrix;
 
end
