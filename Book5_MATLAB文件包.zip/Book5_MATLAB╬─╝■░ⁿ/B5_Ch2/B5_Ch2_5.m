% B5_Ch2_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
N = 1000;
b = 3;
Dim = 2;
 
gn = Faure(N, b, Dim);
 
figure
scatter(gn(:,1), gn(:,2), 5, ...
    'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],...
              'LineWidth',1)
xlabel(strcat('Dimension 1, b1 = ', string(b)))
ylabel(strcat('Dimension 2, b2 = ', string(b)))
axis square

function output = decompose(n, b)
% Decompose a number in the given base
% n: number to be decomposed
% b: base of the sequence
 
i = 1;
while n~=0
output(i, 1) = mod(n,b);

n = floor(n/b);

    i = i+1;
end

end

function gn = Faure(N, b, Dim)
% Generate Faure sequence
% N: Number of elements
% b: base of the sequence
% Dim: Number of dimensions
 
gn = zeros(N,Dim);
 
% Loop of sequency elements
for n = 1:N
    %% decompose n in base b
    dk = decompose(n,b);
    m = size(dk,1);
    
    %% update matrix between dimensions
    MatTrans = zeros(m,m);
    
    for j = 1:m
        for i = j:m
            MatTrans(j,i) = nchoosek(i-1,j-1);
        end
    end
    
    %% Loop of dimension
    for p = 1:Dim
        % Update dk
        dk_adj = mod(MatTrans^(p-1)*dk, b);
        
        % Loop of dk
        for k = 1:m
            gn(n,p) = gn(n,p)+dk_adj(k,1)/b^(k);
        end        

    end
    
end
 
end
