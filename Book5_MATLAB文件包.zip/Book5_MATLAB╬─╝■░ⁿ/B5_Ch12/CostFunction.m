function [FunValue Grad] = CostFunction(Wbs, ...
    InputLayerNodes, ...
    HiddenLayerNodes, ...
    OutputLayerNodes, ...
    X, Y, lambda)

%% Preparation
% Reshape Wbs back into the parameters Wb1 and Wb2
Wb1 = reshape(Wbs(1:HiddenLayerNodes * (InputLayerNodes + 1)), ...
    HiddenLayerNodes, (InputLayerNodes + 1));

Wb2 = reshape(Wbs((1+(HiddenLayerNodes * (InputLayerNodes + 1))):end), ...
    OutputLayerNodes, (HiddenLayerNodes + 1));

m = size(X, 1);

% Initialize output variables
FunValue = 0;

Wb1_grad = zeros(size(Wb1));
Wb2_grad = zeros(size(Wb2));


%% Apply forward propagation through the neural network

%  Calculate the cost function with regularization
for i = 1:m
    
    % Here, "1" is for the bias item
    xi = [1; X(i, :)'];
    
    % Set the respective output yi to be "1" 
    % based on the actual number
    ylabel_i = Y(i);
    yi = zeros(size(Wb2, 1), 1);
    yi(ylabel_i) = 1;
    
    % Apply the activiation function
    y_hat = sigmoid(Wb2*[1; sigmoid(Wb1*xi)]);
    
    % Apply the cost function formula
    FunValue_i = sum(-yi.*log(y_hat)-(1-yi).*log(1-y_hat));
    
    FunValue = FunValue + FunValue_i/m;
    
end

% Add the regularization part to the cost function
FunValueReg = (sum(sum(Wb1(:, 2:end).^2))+ ...
    sum(sum(Wb2(:, 2:end).^2)))*lambda/2/m;

FunValue = FunValue + FunValueReg;


%% Apply backpropagation to compute the Gradients without regularization
D2 = zeros(size(Wb2));
D1 = zeros(size(Wb1));

for i = 1:m
    % Input layer
    a_1 = [1; X(i, :)'];
    
    % Hidden layer
    Z_2 = Wb1*a_1;
    a_2 = [1; sigmoid(Z_2)];
    
    % Output layer
    Z_3 = Wb2*a_2;
    a_3 = sigmoid(Z_3);
    ylabel_i = Y(i);
    yi = zeros(size(Wb2, 1), 1);
    yi(ylabel_i) = 1;
    
    delta_3 = a_3-yi;
    
    delta_2 = (Wb2'*delta_3).*[0; sigmoidGradient(Z_2)];
    
    D2 = D2+delta_3*a_2';
    
    D1 = D1+delta_2(2:end)*a_1';
    
end

D1 = D1/m;
D2 = D2/m;

Wb1_grad = D1;
Wb2_grad = D2;


%% Adjust grediants based on regularization term

Wb1_grad_reg = Wb1;
Wb1_grad_reg(: , 1) = 0;
Wb1_grad = Wb1_grad + lambda*Wb1_grad_reg/m;

Wb2_grad_reg = Wb2;
Wb2_grad_reg(: , 1) = 0;
Wb2_grad = Wb2_grad + lambda*Wb2_grad_reg/m;

% Output gradients
Grad = [Wb1_grad(:); Wb2_grad(:)];

end
