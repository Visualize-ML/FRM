function f = sigmoid(x)
% sigmoid() computes Logisitic functoon
% f(x) = 1/(1+exp(x)) 
f = 1.0 ./ (1.0 + exp(-x));
end
