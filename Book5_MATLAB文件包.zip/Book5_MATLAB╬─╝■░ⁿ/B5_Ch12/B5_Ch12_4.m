% B5_Ch12_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear ; close all; clc

rng(1)

%% Plot training data
load('traindata.mat');

% Randomly pick X samples for plotting
Ns = 100;
index = randperm(size(Xtrain, 1), Ns);
Xplot = Xtrain(index, :);

% Set up plot width and height of plots and subplots
subplotwidth = round(sqrt(size(Xplot, 2)));
subplotheight = subplotwidth;

plotheight = sqrt(Ns);
plotwidth = plotheight;

margin = 1;

% Initialize plot array
plotarray = -ones(margin+plotheight*(subplotheight+margin), ...
    margin + plotwidth * (subplotwidth + margin));

% Fill in plot array using data in Xplot
curr_ex = 1;

for j = 1:plotheight
    for i = 1:plotwidth
        
        if curr_ex > Ns
            break;
        end
        
        % Get the max value of the patch
        max_val = max(abs(Xplot(curr_ex, :)));
        
        array_u = margin+(j-1)*(subplotheight+margin)+...
            (1:subplotheight);
        
        array_v = margin+(i-1)*(subplotwidth+margin)+ ...
            (1:subplotwidth);
        
        plotarray(array_u, array_v) =...
            reshape(Xplot(curr_ex, :), ...
            subplotheight, subplotwidth)/max_val;
        
        curr_ex = curr_ex + 1;
    end
    
    if curr_ex > Ns
        break;
    end
    
end

% Flip and rotate display array if necessary
plotarray = flipud(plotarray);

plotarray = rot90(plotarray, 3);

% Plotting
figure(1)
imagesc(plotarray);
colormap(bone);
axis image off


%% Define the neural network structure
InputLayerNodes  = 784;   % 28x28 Input Images of Digits
HiddenLayerNodes = 28;    % 28 neurons
OutputLayerNodes = 10;    % 10 labels, from 1 to 10


%% Initializing network parameters W and b
Wbinit = 0.12;

initial_Wb1 = rand(HiddenLayerNodes, ...
    1 + InputLayerNodes)*2*Wbinit-Wbinit;

initial_Wb2 = rand(OutputLayerNodes, ...
    1 + HiddenLayerNodes)*2*Wbinit-Wbinit;

% Reshape parameters W into one vector for optimization later
initial_Wbs = [initial_Wb1(:); initial_Wb2(:)];


%% Build cost function
lambda = 1;

[FunValue Grad] = CostFunction(initial_Wbs, ...
    InputLayerNodes, ...
    HiddenLayerNodes, ...
    OutputLayerNodes, ...
    Xtrain, Ytrain, lambda);

FunValue


%% Configure the optimization problem and train the neural network
ObjFunction = @(Wbs) CostFunction(Wbs, ...
    InputLayerNodes, ...
    HiddenLayerNodes, ...
    OutputLayerNodes, ...
    Xtrain, Ytrain, lambda);

options = optimset('PlotFcns','optimplotfval', 'Display','iter', ...
    'MaxIter', 100);

% Start training
[opt_Wbs, cost] = fmincg(ObjFunction, initial_Wbs, options);

% Training results
opt_Wbs1 = ...
    reshape(opt_Wbs(1:HiddenLayerNodes * ...
    (InputLayerNodes + 1)), ...
    HiddenLayerNodes, (InputLayerNodes + 1));

opt_Wbs2 = ...
    reshape(opt_Wbs((1 + (HiddenLayerNodes * ...
    (InputLayerNodes + 1))):end), ...
    OutputLayerNodes, (HiddenLayerNodes + 1));

% Plotting
figure(2)
plot(cost, '-o')
xlabel('Iterations')
ylabel('Cost Function')
set(gcf, 'color', 'w')


%% Check training error rate
Ytrain_pred = PredictY(opt_Wbs1, opt_Wbs2, Xtrain);

fprintf('\nTraining Error Rate: %.2f%%\n', ...
    100 - mean(double(Ytrain_pred == Ytrain)) * 100);



%% Repeat the training with integrating validation data
load('validationdata.mat');

ItrMax = 5000;

last_Wbs = initial_Wbs;

cost = [];
train_accuracy = [];
validation_accuracy = [];

for i = 1:ItrMax
    
    options = optimset('PlotFcns','optimplotfval', ...
        'Display','iter', 'MaxIter', 1);
    
    fprintf('Iteration : %d\n', i);
    
    [opt_Wbs, costtmp] = fmincg(ObjFunction, last_Wbs, options);
    
    last_Wbs = opt_Wbs;
    
    cost(i) = costtmp;
    
    % Training results
    opt_Wbs1 = reshape(opt_Wbs(1:HiddenLayerNodes * (InputLayerNodes + 1)), ...
        HiddenLayerNodes, (InputLayerNodes + 1));
    
    opt_Wbs2 = reshape(opt_Wbs((1 + (HiddenLayerNodes * (InputLayerNodes + 1))):end), ...
        OutputLayerNodes, (HiddenLayerNodes + 1));
    
    % Training accuracy
    Ytrain_pred = PredictY(opt_Wbs1, opt_Wbs2, Xtrain);
    train_accuracy(i) = mean(double(Ytrain_pred == Ytrain));
    
    % Validation accuracy
    Yval_pred = PredictY(opt_Wbs1, opt_Wbs2, Xval);
    validation_accuracy(i) = mean(double(Yval_pred == Yval));
    
end

% Plotting 
figure(3)

subplot(2,1,1)
P = 200;
yyaxis left
plot(1 - train_accuracy(1:P), '-b')
hold on
plot(1 - validation_accuracy(1:P), '-g')
hold off
xlabel('Iterations')
ylabel('Error Rate')
title('First 200 iterations')

yyaxis right
plot(cost(1:P))
ylabel('Cost Function')
legend('Train Error', 'Validation Error', 'Cost Function')


subplot(2,1,2)
P = ItrMax;
yyaxis left
plot(1 - train_accuracy(1:P), '-b')
hold on
plot(1 - validation_accuracy(1:P), '-g')
hold off
xlabel('Iterations')
ylabel('Error Rate')
title('All 5000 iterations')

yyaxis right
plot(cost(1:P))
ylabel('Cost Function')

legend('Train Error', 'Validation Error', 'Cost Function')


