% B5_Ch12_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
% Define 8 data points
 
X = [1,6; 4,6; 1,5; 6,0; 2,8; 7,3; 4,1; 3,5];
num_C = 2;
 
labels = {'a','b','c','d','e','f','g','h'};
 
% plot random data X
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
 
scatter(X(:,1),X(:,2),30,'filled')
xlabel('x_1'); ylabel('x_2')
labelpoints(X(:,1),X(:,2),labels)
axis square; box off; grid on
xlim([0,8]);ylim([0,8]);
 
% Calculate pairwise distance between any two observations
 
dist_temp = pdist(X);
dist = squareform(dist_temp);
 
figure(fig_i)
fig_i = fig_i + 1;
% heatmap(fliplr(flipud(dist)))
heatmap(labels,labels,dist)
title('Pairwise distance, Z')
 
tree = linkage(X);
 
figure(fig_i)
fig_i = fig_i + 1;
dendrogram(tree,'Labels',labels)
ylim([0,5])
ylabel('Distance and linkage')
xlabel('Data point')
 
% Find a maximum of two clusters in the data.
max_C = 2;
 
figure(fig_i)
fig_i = fig_i + 1;
cutoff = median([tree(end - max_C + 1,3) tree(end - max_C + 2,3)]);
dendrogram(tree,'ColorThreshold',cutoff,'Labels',labels)
ylim([0,5])
title(['Number of clusters = ',num2str(max_C)])
ylabel('Distance and linkage')
xlabel('Data point')
 
% Find a maximum of three clusters in the data.
max_C = 3;
 
figure(fig_i)
fig_i = fig_i + 1;
cutoff = median([tree(end - max_C + 1,3) tree(end - max_C + 2,3)]);
dendrogram(tree,'Orientation','right','ColorThreshold','default','Labels',labels);
title(['Number of clusters = ',num2str(max_C)])
xlabel('Distance and linkage')
ylabel('Data point')
