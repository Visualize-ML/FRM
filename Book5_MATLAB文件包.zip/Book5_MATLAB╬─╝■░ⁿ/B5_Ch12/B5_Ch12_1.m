% B5_Ch12_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
X(:,1) = X(:,1)/1000;
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
 
scatter(X(:,1),X(:,2),'.k')
fig_dec(X)
 
%% k-means and silhouette plot
% colors = [0,153,219; 146,208,80;]/255; % labels: 1, 2
colors = [0,153,219; 146,208,80; 255, 153, 255]/255; % labels: 1, 2, 3
 
% [idx3,C,sumdist3] = kmeans(X,2,'Distance','cityblock','Display','final');

[idx3,centers,sumdist3] = kmeans(X,3,'Distance','cityblock','Display','final');
 
figure(i_fig)
i_fig = i_fig + 1;
hold all
 
plot(X(idx3==1,1),X(idx3==1,2),'LineStyle','none','color',...
    colors(1,:),'Marker','.','MarkerSize',12)
 
plot(X(idx3==2,1),X(idx3==2,2),'LineStyle','none','color',...
    colors(2,:),'Marker','.','MarkerSize',12)
 
plot(X(idx3==3,1),X(idx3==3,2),'LineStyle','none','color',...
    colors(3,:),'Marker','.','MarkerSize',12)
plot(centers(:,1),centers(:,2),'rx',...
    'MarkerSize',15,'LineWidth',3)
scatter(X(:,1),X(:,2),'.k')
 
C1_X = X(idx3==1,:);
C2_X = X(idx3==2,:);
C3_X = X(idx3==3,:);
 
k = boundary(C1_X(:,1),C1_X(:,2));
plot(C1_X(k,1),C1_X(k,2),'r:');
k = boundary(C2_X(:,1),C2_X(:,2));
plot(C2_X(k,1),C2_X(k,2),'r:');
k = boundary(C3_X(:,1),C3_X(:,2));
plot(C3_X(k,1),C3_X(k,2),'r:');
fig_dec(X); legend off
 
 
figure(i_fig)
i_fig = i_fig + 1;
 
[silh3,h] = silhouette(X,idx3,'cityblock');
xlabel('Silhouette value'); ylabel('Cluster')
box off
%% Classify the test data set using the existing clusters.
%  Find the nearest centroid from each test data point by using pdist2.
 
figure(i_fig)
i_fig = i_fig + 1;
hold all
Xtest = [30, 312; 34, 650; 60, 650; 100, 700; ...
    120, 700; 95, 850; 40, 500; 20, 550; 100, 450];
gscatter(X(:,1),X(:,2),idx3,colors)
plot(centers(:,1),centers(:,2),'rx',...
    'MarkerSize',15,'LineWidth',3)
[~,idx_test] = pdist2(centers,Xtest,'cityblock','Smallest',1);
h = gscatter(Xtest(:,1),Xtest(:,2),idx_test,colors,'xx')
h1 = h(1); h1.MarkerSize = 12; h1.LineWidth = 1;
h2 = h(2); h2.MarkerSize = 12; h2.LineWidth = 1;
h3 = h(3); h3.MarkerSize = 12; h3.LineWidth = 1;
 
fig_dec(X); legend off
%% Decision boundary
 
x1range = min(X(:,1)):1:max(X(:,1));
x2range = min(X(:,2)):5:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
 
% idx2Region = kmeans(XGrid,2,'MaxIter',1,'Start',C);
idx2Region = kmeans(XGrid,3,'MaxIter',1,'Start',centers);
 
figure(i_fig)
i_fig = i_fig + 1;
hold all
 
% plot(X(idx3==1,1),X(idx3==1,2),'LineStyle','none','color',colors(1,:),'Marker','.','MarkerSize',12)
% hold on
% plot(X(idx3==2,1),X(idx3==2,2),'LineStyle','none','color',colors(2,:),'Marker','.','MarkerSize',12)
 
contour(x1Grid,x2Grid,reshape(idx2Region,size(x1Grid)),[1.5 1.5],'r','LineWidth',1.25);
contour(x1Grid,x2Grid,reshape(idx2Region,size(x1Grid)),[2.5, 2.5],'r','LineWidth',1.25);
gscatter(X(:,1),X(:,2),idx3,colors)
plot(centers(:,1),centers(:,2),'rx',...
    'MarkerSize',15,'LineWidth',3)
scatter(X(:,1),X(:,2),'.k')
fig_dec(X); legend off
 
 
%% Visualize decision areas
 
figure(i_fig)
i_fig = i_fig + 1;
hold all
 
gscatter(XGrid(:,1),XGrid(:,2),idx2Region,colors,'..');
plot(centers(:,1),centers(:,2),'rx',...
    'MarkerSize',15,'LineWidth',3)
 
scatter(X(:,1),X(:,2),'.k')
 
fig_dec(X);legend off

function fig_dec(X)
xlim([min(X(:,1)),max(X(:,1))])
ylim([min(X(:,2)),max(X(:,2))])
hold off; axis square;
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
end
