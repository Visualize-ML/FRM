function Y = PredictY(Wbs1, Wbs2, X)

m = size(X, 1);

Y = zeros(size(X, 1), 1);

a1 = sigmoid([ones(m, 1) X] * Wbs1');

a2 = sigmoid([ones(m, 1) a1] * Wbs2');

[a2max, Y] = max(a2, [], 2);

end
