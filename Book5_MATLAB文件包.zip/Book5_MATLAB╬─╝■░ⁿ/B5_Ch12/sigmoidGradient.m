function f = sigmoidGradient(x)
% sifmoidGradient() computes the gradient of Logisitic function
% f'(x)=f(x)(1-f(x))
f = zeros(size(x));
f = (1.0 ./ (1.0 + exp(-x))).*(1-(1.0 ./ (1.0 + exp(-x))));
end
