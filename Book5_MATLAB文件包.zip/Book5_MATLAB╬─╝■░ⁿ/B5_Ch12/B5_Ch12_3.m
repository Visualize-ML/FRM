% B5_Ch12_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
rng('default')
 
num = 300;
[X_original,Y_original] = generate_rnd(num);
X = X_original(all(~isnan(X_original),2),:);
Y = Y_original(all(~isnan(X_original),2),:);
X(:,1) = X(:,1)/1000;
 
i_fig = 1;
figure(i_fig)
i_fig = i_fig + 1;
hold on
colors = [0,153,219; 146,208,80;]/255;
 
scatter(X(:,1),X(:,2),'.k')
fig_dec(X)
 
m = [1.1, 1.5, 2, 4];
% fuzzy partition matrix exponent
 
x1range = min(X(:,1)):(max(X(:,1)) - min(X(:,1)))/50:max(X(:,1));
x2range = min(X(:,2)):(max(X(:,2)) - min(X(:,2)))/50:max(X(:,2));
[x1Grid, x2Grid] = meshgrid(x1range,x2range);
XGrid = [x1Grid(:) x2Grid(:)];
 
 
for i = 1:4
    % Cluster the data.
    options = [m(i) NaN NaN 0];
    [centers,w_X,objFcn] = fcm(X,2,options);
    
    figure(i_fig)
    i_fig = i_fig + 1;
    plot(objFcn)
    
    xlabel('Iteration count')
    ylabel('Objective function value')
    axis tight; box off
    
    % Classify the data points.
    maxU = max(w_X);
    index1 = find(w_X(1,:) == maxU);
    index2 = find(w_X(2,:) == maxU);
    
    f1 = scatteredInterpolant(X(:,1),X(:,2),w_X(1,:)','natural');
    W_grid_1 = f1(x1Grid, x2Grid);
    f2 = scatteredInterpolant(X(:,1),X(:,2),w_X(2,:)','natural');
    W_grid_2 = f2(x1Grid, x2Grid);
    
    % Find data points with lower maximum membership values.
    idx3 = find(maxU < 0.6);
    
    % A higher average maximum membership value
    % indicates that there is less fuzzy overlap
    averageMax = mean(maxU);
    
    figure(i_fig)
    i_fig = i_fig + 1;
    plot(X(index1,1),X(index1,2),'LineStyle','none','color',...
        colors(1,:),'Marker','.','MarkerSize',12)
    hold on
    plot(X(index2,1),X(index2,2),'LineStyle','none','color',...
        colors(2,:),'Marker','.','MarkerSize',12)
    plot(X(idx3,1),X(idx3,2),'ok','LineWidth',1)
    plot(centers(1,1),centers(1,2),'rx',...
        'MarkerSize',15,'LineWidth',3)
    plot(centers(2,1),centers(2,2),'rx',...
        'MarkerSize',15,'LineWidth',3)
    
    hold off; fig_dec(X); legend off
    title(['m = ' num2str(m(i)) ', Ave. max. = ' num2str(averageMax,3)])
    axis square;
    fig_name = ['Fig_Decision_',num2str(i_fig),'.fig'];
    savefig(fig_name)
    
    figure(i_fig)
    i_fig = i_fig + 1;
    plot(X(index1,1),X(index1,2),'LineStyle','none','color',...
        colors(1,:),'Marker','.','MarkerSize',12)
    hold on
    plot(X(index2,1),X(index2,2),'LineStyle','none','color',...
        colors(2,:),'Marker','.','MarkerSize',12)
    plot(X(idx3,1),X(idx3,2),'ok','LineWidth',1)
    plot(centers(1,1),centers(1,2),'rx',...
        'MarkerSize',15,'LineWidth',3)
    plot(centers(2,1),centers(2,2),'rx',...
        'MarkerSize',15,'LineWidth',3)
    contour3(x1Grid, x2Grid,W_grid_1,[0.5,0.5],'r','LineWidth',1)
    contour3(x1Grid, x2Grid,W_grid_1,[0.6,0.6],'k','LineWidth',1)
    contour3(x1Grid, x2Grid,W_grid_2,[0.6,0.6],'k','LineWidth',1)
    hold off; fig_dec(X); legend off
    title(['m = ' num2str(m(i)) ', Ave. max. = ' num2str(averageMax,3)])
    axis square;
    fig_name = ['Fig_Membership_',num2str(i_fig),'.fig'];
    savefig(fig_name)
    
    figure(i_fig)
    i_fig = i_fig + 1;
    mesh( x1Grid, x2Grid,W_grid_1)
    hold on
    mesh( x1Grid, x2Grid,W_grid_2)
    contour3(x1Grid, x2Grid,W_grid_1,[0.6,0.6],'k','LineWidth',1)
    contour3(x1Grid, x2Grid,W_grid_2,[0.6,0.6],'k','LineWidth',1)
    contour3(x1Grid, x2Grid,W_grid_2,[0.5,0.5],'r','LineWidth',1)
    scatter3(X(:,1),X(:,2),w_X(1,:)','.k');
    scatter3(X(:,1),X(:,2),w_X(2,:)','.k');
    hold off; fig_dec(X); legend off; zlabel('Membership value')
    title(['m = ' num2str(m(i)) ', Ave. max. = ' num2str(averageMax,3)])
    view(-30,45)
    fig_name = ['Fig_Surface_',num2str(i_fig),'.fig'];
    savefig(fig_name)
    
    
end

 
function fig_dec(X)
xlim([min(X(:,1)),max(X(:,1))])
ylim([min(X(:,2)),max(X(:,2))])
hold off; box off; grid off
xlabel('Income, x_1 (k$)'); ylabel('Credit score, x_2')
end
