% B5_Ch5_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
%% Deal Inputs
Notional = 10^8;    % IR Swap notional
SwapRate = 0.05;    % Swap Rate
RecFixed = 1;       % if Receive floating Pay fixed, this is -1
 
tau = 0.25;         % Payment Frequency
Maturity = 10;           % Swap Maturity
 
%% Parameter Inputs for Interest Rate Model
r = 0.05;   % current spot rate
a = 0.1;    % mean reversion rate or speed or reversion
b = 0.05;   % long-term mean level
vol = 0.01; % instantaneous volatility
 
%% Simulation 
NumOfSim = 5000;
Simulated_InterestRate = zeros(NumOfSim,Maturity/tau+1);
IRSwap_MtM = zeros(NumOfSim,Maturity/tau+1);
 
for n = 1:NumOfSim
    Diffusion_ir = randn(Maturity/tau,1);
    [IRSwap_MtM(n,:),Simulated_InterestRate(n,:)] ...
        = SimpleVascicek_Calc_IRSwap_MtM...
    (Notional,SwapRate,RecFixed,tau,Maturity,r,a,b,vol,Diffusion_ir);
end
 
%% Plot the simulated Interest Rate
n = 1:50;
figure;
plot(0:tau:Maturity, Simulated_InterestRate(n,:));
xlabel('Time');
ylabel('Simulated Interest Rate');
 
%% Plot IR Swap MtM
n = 1:100;
figure;
plot(0:tau:Maturity, IRSwap_MtM(n,:));
xlabel('Time');
ylabel('IRSwap MtM');
 
%% Plot IR Swap Credit Exposure
n = 1:100;
figure;
plot(0:tau:Maturity, max(0,IRSwap_MtM(n,:)));
xlabel('Time');
ylabel('IRSwap Credit Exposure');
 
%% Credit Exposure Metrics
 
% Credit Exposure
Exposure_IRSwap = max(0,IRSwap_MtM);
 
qntile = 0.95; % look at 95th percentile PFE
[EE_IRSwap,PFE_IRSwap,EffEE_IRSwap,EPE_IRSwap,EffEPE_IRSwap,...
    MaxPFE_IRSwap] = ExposureMetrics(Exposure_IRSwap,qntile);
 
%%
figure;
plot(0:tau:Maturity, [EE_IRSwap;PFE_IRSwap;EffEE_IRSwap;EPE_IRSwap;EffEPE_IRSwap;MaxPFE_IRSwap]);
xlabel('Time');
ylabel('Credit Exposure Metrics');


%% Deal Inputs
N = 40000;      % Number of shares
Maturity = 4;   % Swap Maturity
K = 3000;       % strike price
tau = 0.25;     % set up time buckets for every quarter
 
%% Parameter Inputs for EQ Model
S0 = 2458.245; 
drift = 0.02;   % equity drift
eq_vol = 0.17;  % equity vol
 
%% Parameter Inputs for Interest Rate Model
r = 0.05;       % current spot rate
a = 0.1;        % mean reversion rate or speed or reversion
b = 0.05;       % long-term mean level
IR_vol = 0.01;  % instantaneous volatility
 
%% Simulation 
NumOfSim = 5000;
Simulated_InterestRate = zeros(NumOfSim,Maturity/tau+1);
Simulated_EQ = zeros(NumOfSim,Maturity/tau+1);
EQfwd_MtM = zeros(NumOfSim,Maturity/tau+1);
 
for n = 1:NumOfSim
    Diffusion_eq = randn(Maturity/tau,1);
    Diffusion_ir = randn(Maturity/tau,1);
    [EQfwd_MtM(n,:),Simulated_InterestRate(n,:),Simulated_EQ(n,:)] ...
    = Simple_EQfwd_MtM...
    (N,Maturity,K,tau,S0,drift,eq_vol,r,a,b,IR_vol,Diffusion_eq,Diffusion_ir);
end
 
%% Plot the simulated Equity Rate
n = 1:50;
figure;
plot(0:tau:Maturity, Simulated_EQ(n,:));
xlabel('Time');
ylabel('Simulated Equity Price');
 
%% Plot Equity Forward MtM
n = 1:100;
figure;
plot(0:tau:Maturity, EQfwd_MtM(n,:));
xlabel('Time');
ylabel('EQ Forward');
 
%% Plot Equity Forward Credit Exposure
n = 1:100;
figure;
plot(0:tau:Maturity, max(0,EQfwd_MtM(n,:)));
xlabel('Time');
ylabel('EQ Forward Credit Exposure');
 
%% Credit Exposure Metrics
 
% Credit Exposure
Exposure_EQfwd = max(0,EQfwd_MtM);
 
qntile = 0.95; % look at 95th percentile PFE
[EE_EQfwd,PFE_EQfwd,EffEE_EQfwd,EPE_EQfwd,EffEPE_EQfwd,...
    MaxPFE_EQfwd] = ExposureMetrics(Exposure_EQfwd,qntile);
 
 
%%
figure;
plot(0:tau:Maturity, [EE_EQfwd;PFE_EQfwd;EffEE_EQfwd;EPE_EQfwd;EffEPE_EQfwd;MaxPFE_EQfwd]);
xlabel('Time');
ylabel('Credit Exposure Metrics');

function [IRSwap_MtM,Simulated_InterestRate] ...
    = SimpleVascicek_Calc_IRSwap_MtM...
    (Notional,SwapRate,RecFixed,tau,End,r,a,b,vol,Diffusion_ir)
    %% Simulate Future Interest Rate
    TimeLine = 0:tau:End; 
    Simulated_InterestRate = zeros(length(TimeLine),1);
 
    Simulated_InterestRate(1) = r;
    for i = 2:length(TimeLine)
        Simulated_InterestRate(i)=Simulated_InterestRate(i-1) ...
            + a*(b-Simulated_InterestRate(i-1))*tau ...
            + vol*sqrt(tau)*Diffusion_ir(i-1);
    end
 
    B = (1 - exp(-a*TimeLine(2:end)))/a; 
    A = exp((B - TimeLine(2:end))*(a^2*b-vol^2/2)/a^2-(vol^2/(4*a))*(B.*B));
 
    %% Calculate discount factor between t and t + delta t
    DF = zeros(length(TimeLine)-1,length(TimeLine)-1);
    for i = 1:length(TimeLine)-1
        for j = i:length(TimeLine)-1
            DF(i,j) = A(j-i+1)*exp(-B(j-i+1)*Simulated_InterestRate(i));
        end
    end
 
    %% Calculate IR Swap MtM at each time step
    PV_flt = 1 - DF(:,end);
    PV_fix = SwapRate*tau*sum(DF,2);
    IRSwap_MtM = (PV_fix - PV_flt)*RecFixed*Notional; 
    IRSwap_MtM = [IRSwap_MtM;0];
 
end

function [EQfwd_MtM,Simulated_InterestRate,Simulated_EQ] ...
    = Simple_EQfwd_MtM...
    (N,Maturity,K,tau,S0,drift,eq_vol,r,a,b,IR_vol,Diffusion_eq,Diffusion_ir)
 
%% Simulate Future Equity Price
TimeLine = 0:tau:Maturity; 
Simulated_EQ = zeros(length(TimeLine),1);
 
Simulated_EQ(1) = S0;
% Diffusion_eq = randn(length(TimeLine)-1,1);
 
for i = 2:length(TimeLine)
    Simulated_EQ(i)=Simulated_EQ(i-1) ...
        *(1 + drift*tau + eq_vol*sqrt(tau)*Diffusion_eq(i-1));
end
 
%% Simulate Future Interest Rate
% TimeLine = 0:tau:End; 
Simulated_InterestRate = zeros(length(TimeLine),1);
 
Simulated_InterestRate(1) = r;
% Diffusion_ir = randn(length(TimeLine)-1,1);
 
for i = 2:length(TimeLine)
    Simulated_InterestRate(i)=Simulated_InterestRate(i-1) ...
        + a*(b-Simulated_InterestRate(i-1))*tau ...
        + IR_vol*sqrt(tau)*Diffusion_ir(i-1);
end
 
B = (1 - exp(-a*TimeLine(2:end)))/a; 
A = exp((B - TimeLine(2:end))*(a^2*b-IR_vol^2/2)/a^2-(IR_vol^2/(4*a))*(B.*B));
 
%% Calculate discount factor between t and t + delta t
DF = zeros(length(TimeLine)-1,length(TimeLine)-1);
for i = 1:length(TimeLine)-1
    for j = i:length(TimeLine)-1
        DF(i,j) = A(j-i+1)*exp(-B(j-i+1)*Simulated_InterestRate(i));
    end
end
 
%% Calculate EQ Forward MtM at each time step
EQfwd_MtM = zeros(length(TimeLine),1);
EQfwd_MtM(1:end-1) = (Simulated_EQ(1:end-1) - K*DF(:,end))*N;
EQfwd_MtM(end) = (Simulated_EQ(end) - K)*N;
 
end


function [EE,PFE,EffEE,EPE,EffEPE,MaxPFE] = ExposureMetrics(Exposure,qntile)
 
%% Credit Exposure Metrics
 
% Expected Exposure
EE = mean(Exposure);
 
% Potential Future Exposure
PFE = quantile(Exposure,qntile);
 
% Effective Expected Exposure
EffEE = EE;
for i = 1: length(EffEE)
    EffEE(i) = max(EE(1:i));
end
 
% Expected Positive Exposure
% it is supposed to be time weighted average
% as our example here has equal interval time buckets
% we just take equal weight average here
% same for EffEPE
EPE = mean(EE)*ones(1,length(EE));
 
% Effective Expected Positive Exposure
EffEPE = mean(EffEE)*ones(1,length(EffEE));
 
% Maximum PFE
MaxPFE=max(PFE)*ones(1,length(PFE));
 
end
