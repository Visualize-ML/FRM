% B5_Ch5_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
% Define PFE profile
ConfiLevel = 0.95;
 
%% Forward expdosure approxi
T = 5;
drift = 0.01;
vol = 0.18; 
% set up Time buckets
TimeBuckets = 0:1/12:T;
% analytical approxi solution
PFE = drift.*TimeBuckets + vol.*sqrt(TimeBuckets).*norminv(ConfiLevel);
% plot
figure;
plot(TimeBuckets, PFE);
xlabel('Time Buckets');
ylabel('PFE%');
 
%% flex the vol - a forward
T = 5;
drift = 0.01;
vol_range = 0.01:0.01:0.2;
% set up Time buckets
TimeBuckets = 0:1/12:T;
 
PFE = drift.*ones(numel(vol_range),1).*TimeBuckets + vol_range'.*sqrt(TimeBuckets).*norminv(ConfiLevel);
 
num_plots = numel(vol_range);
my_col = brewermap(num_plots,'RdYlBu');
 
figure
for i = 1: num_plots    
    plot(TimeBuckets, PFE(i,:),...
        'color',my_col(i,:));
 
    yt = get(gca, 'ytick');
    ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
    set(gca, 'yticklabel', ytl);
    hold on
end
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
%% flex the drift - a forward
T = 5;
drift_range = -0.05:0.01:0.05;
vol = 0.10; 
% set up Time buckets
TimeBuckets = 0:1/12:T;
 
PFE = drift_range'.*TimeBuckets + vol.*sqrt(TimeBuckets).*norminv(ConfiLevel);
 
num_plots = numel(drift_range);
my_col = brewermap(num_plots,'RdYlBu');
 
figure
for i = 1: num_plots    
    plot(TimeBuckets, PFE(i,:),...
        'color',my_col(i,:));
  
    yt = get(gca, 'ytick');
    ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
    set(gca, 'yticklabel', ytl);
    hold on
end
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
 
%% IR Swap exposure approxi
T = 10;
vol = 0.008; 
% set up Time buckets
TimeBuckets = 0:1/12:T;
 
% analytical approxi solution
PFE = vol.*sqrt(TimeBuckets).*(T-TimeBuckets).*norminv(ConfiLevel);
 
% plot
figure;
plot(TimeBuckets, PFE);
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
 
%% flex the maturity T - a swap
T = 5:1:20;
TimeBuckets = 0:1/12:T(end);
vol = 0.008; 
PFE = vol.*sqrt(TimeBuckets).*max(0,T'-TimeBuckets).*norminv(ConfiLevel);
 
num_plots = numel(T);
my_col = brewermap(num_plots,'RdYlBu');
 
figure
for i = 1: num_plots    
    plot(TimeBuckets, PFE(i,:),...
        'color',my_col(i,:));
  
    yt = get(gca, 'ytick');
    ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
    set(gca, 'yticklabel', ytl);
    hold on
end
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
%% flex the vol - a swap
T = 10;
TimeBuckets = 0:1/12:T;
vol_range = 0.005:0.001:0.02;
PFE = vol_range'.*sqrt(TimeBuckets).*(T-TimeBuckets).*norminv(ConfiLevel);
 
num_plots = numel(vol_range);
my_col = brewermap(num_plots,'RdYlBu');
 
figure
for i = 1: num_plots    
    plot(TimeBuckets, PFE(i,:),...
        'color',my_col(i,:));
   
    yt = get(gca, 'ytick');
    ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
    set(gca, 'yticklabel', ytl);
    hold on
end
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
 
%% Cross-Currency Swap exposure approxi
T = 5;
drift_fx = 0;
vol_ir = 0.005; 
vol_fx = 0.05;
rho = 0.2;
% set up Time buckets
TimeBuckets = 0:1/12:T;
 
% analytical approxi solution
PFE_fx = drift_fx.*TimeBuckets + vol_fx.*sqrt(TimeBuckets).*norminv(ConfiLevel);
PFE_irswap = vol_ir.*sqrt(TimeBuckets).*(T-TimeBuckets).*norminv(ConfiLevel);
 
PFE_ccsw = sqrt(...
    vol_fx^2.*TimeBuckets + vol_ir^2.*TimeBuckets.*(T-TimeBuckets).^2 +...
    2*rho*vol_fx*vol_ir.*TimeBuckets.*(T-TimeBuckets))...
    .*norminv(ConfiLevel);
 
PFE_Aggre = PFE_fx + PFE_irswap;
PFE_Diff = PFE_fx - PFE_irswap;
 
% plot
figure;
plot(TimeBuckets, PFE_fx);
yt = get(gca, 'ytick');
ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
set(gca, 'yticklabel', ytl);
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
figure;
plot(TimeBuckets, PFE_irswap);
yt = get(gca, 'ytick');
ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
set(gca, 'yticklabel', ytl);
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
figure;
plot(TimeBuckets, [PFE_fx; PFE_irswap; PFE_ccsw]);
yt = get(gca, 'ytick');
ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
set(gca, 'yticklabel', ytl);
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
 
figure;
plot(TimeBuckets, [PFE_fx; PFE_irswap; PFE_ccsw; PFE_Aggre; PFE_Diff]);
yt = get(gca, 'ytick');
ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
set(gca, 'yticklabel', ytl);
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
legend({'PFE: FX','PFE: IR','PFE: Cross-Currency Swap','PFE: FX + IR','PFE: FX - IR'},'Location','northwest')
 
%% flex the rho - a cross-currency swap
T = 10;
drift_fx = 0;
vol_ir = 0.005; 
vol_fx = 0.05;
rho_range = -1:0.1:1;
% set up Time buckets
TimeBuckets = 0:1/12:T;
 
PFE = sqrt(...
    (vol_fx^2.*TimeBuckets + vol_ir^2.*TimeBuckets.*(T-TimeBuckets).^2).*...
    ones(numel(rho_range),1) +...
    2.*rho_range'.*vol_fx*vol_ir.*TimeBuckets.*(T-TimeBuckets))...
    .*norminv(ConfiLevel);
 
num_plots = numel(rho_range);
my_col = brewermap(num_plots,'RdYlBu');
 
figure
for i = 1: num_plots    
    plot(TimeBuckets, PFE(i,:),...
        'color',my_col(i,:));
   
    yt = get(gca, 'ytick');
    ytl = strcat(strtrim(cellstr(num2str(yt'*100))), '%');
    set(gca, 'yticklabel', ytl);
    hold on
end
xlabel('Time Buckets');
ylabel('PFE% (as of Notional)');
