% B5_Ch5_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 % Data input 
Timebuckets = xlsread('CCR_Netting_CSA_example.xlsx','TimeBuckets');
Trade1 = xlsread('CCR_Netting_CSA_example.xlsx','Trade1');
Trade2 = xlsread('CCR_Netting_CSA_example.xlsx','Trade2');
Trade3 = xlsread('CCR_Netting_CSA_example.xlsx','Trade3');
Trade4 = xlsread('CCR_Netting_CSA_example.xlsx','Trade4');
 
%% Figure
% Plot Trade 1 MtM
figure(1)
plot(Timebuckets, Trade1(1:50,:));
xlabel('Time buckets');
ylabel('100m IRS Payer GBP 5Y');
 
% Plot Trade 2 MtM
figure(2)
plot(Timebuckets, Trade2(1:50,:));
xlabel('Time buckets');
ylabel('100m IRS Payer GBP 6Y');
 
% Plot Trade 3 MtM
figure(3)
plot(Timebuckets, Trade3(1:50,:));
xlabel('Time buckets');
ylabel('100m IRS Payer EUR 5Y');
 
% Plot Trade 4 MtM
figure(4)
plot(Timebuckets, Trade4(1:50,:));
xlabel('Time buckets');
ylabel('25m CCS GBPUSD 5Y');
 
%% Calculate each individual deal's exposure
Exposure1 = max(0,Trade1);
Exposure2 = max(0,Trade2);
Exposure3 = max(0,Trade3);
Exposure4 = max(0,Trade4);
 
%% Plot individual deals EE and PFE
figure(5) 
plot(Timebuckets, [mean(Exposure1); quantile(Exposure1,0.95)]);
xlabel('Time buckets');
ylabel('100m IRS Payer GBP 5Y');
 
figure(6) 
plot(Timebuckets, [mean(Exposure2); quantile(Exposure2,0.95)]);
xlabel('Time buckets');
ylabel('100m IRS Payer GBP 6Y');
 
figure(7) 
plot(Timebuckets, [mean(Exposure3); quantile(Exposure3,0.95)]);
xlabel('Time buckets');
ylabel('100m IRS Payer EUR 5Y');
 
figure(8) 
plot(Timebuckets, [mean(Exposure4); quantile(Exposure4,0.95)]);
xlabel('Time buckets');
ylabel('25m CCS GBPUSD 5Y');
 
%% Calculate NoNet exposure, and Netting exposure
NoNetExposure = max(0,Trade1) + max(0,Trade2) + max(0,Trade3) + max(0,Trade4);
NettingExposure = max(0,Trade1 + Trade2 + Trade3 + Trade4);
 
%% Calculate Collateralized exposure
TH = 10^6;
m = 14/365;
SecondaryTimebuckets = max(0,Timebuckets - m);
 
% use linear interpolation to quickly estimate the exposure at secondary timebuckets
NettingExposure2 = zeros(size(NettingExposure,1),size(NettingExposure,2));
for i = 2:length(Timebuckets)
    if Timebuckets(i)<m
        NettingExposure2(:,i)=zeros(size(NettingExposure,1),1);
    else
        NettingExposure2(:,i)= max(0,NettingExposure(:,i)-...
            m*(NettingExposure(:,i-1)-NettingExposure(:,i))/...
            (Timebuckets(i-1)-Timebuckets(i)));
    end
end
 
Collateral = max(NettingExposure2-TH,0);
CollateralizedExposure = max(NettingExposure-Collateral,0);
 
%%
EE_NoNet= mean(NoNetExposure);
EE_Netting = mean(NettingExposure);
EE_CollExp = mean(CollateralizedExposure);
 
PFE95_NoNet = quantile(NoNetExposure,0.95);
PFE95_Netting = quantile(NettingExposure,0.95);
PFE95_CollExp = quantile(CollateralizedExposure,0.95);
 
%%
figure;
plot(Timebuckets, [EE_NoNet; EE_Netting; EE_CollExp]);
xlabel('Time buckets');
ylabel('Exposure');
 
%%
figure;
plot(Timebuckets, [PFE95_NoNet; PFE95_Netting; PFE95_CollExp]);
xlabel('Time buckets');
ylabel('Exposure PFE');
