% B5_Ch5_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% CVA calculation
DP = xlsread('CCR_Netting_CSA_example.xlsx','DP');
Recovery = 0.4;
%%
CVA = (1-Recovery)*sum(EE_Netting(2:end).*(DP(2:end)-DP(1:end-1)));
 
%% figure 
figure
 
subplot (2,1,1)
plot(Timebuckets, DP);
xlabel('Time');
ylabel('DP');
 
subplot (2,1,2)
plot(Timebuckets, EE_Netting);
xlabel('Time');
ylabel('Discounted EE Netting');
