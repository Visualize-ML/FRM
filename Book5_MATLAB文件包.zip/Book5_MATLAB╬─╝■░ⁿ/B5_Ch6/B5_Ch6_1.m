% B5_Ch6_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch6_1_A.m

clc; close all; clear all
 
stock_data = hist_stock_data(now-365*2, now,'TSLA');
 
Open   = stock_data.Open;
High   = stock_data.High;
Low    = stock_data.Low;
Close  = stock_data.Close;
Price  = stock_data.Close;
Adj_Cl = stock_data.AdjClose;
Volume = stock_data.Volume;
Date   = string(stock_data.Date);
Date   = datetime(Date,'InputFormat','yyyy-MM-dd');
%Tranform the data to timetable
stock_TT = timetable(Date,Open,High,Low,Close,Price,Volume,Adj_Cl);
log_r_daily = price2ret(stock_TT.Adj_Cl);
log_r_daily = [NaN;log_r_daily];
 
stock_TT = addvars(stock_TT,log_r_daily);
 
%Fill the missing data with previous value
if any(any(ismissing(stock_TT)))==true
    stock_TT = fillmissing(stock_TT,'previous');
end
 
%%
summary(stock_TT)
head(stock_TT)
tail(stock_TT)
%% Adjusted close price
 
fig_index = 1;
figure(fig_index); fig_index = fig_index + 1;
plot(stock_TT.Date,stock_TT.Adj_Cl);
ylabel('Adjusted close price');
xlabel('Time');
box off; grid off; axis tight
 
%% Daily log return
 
figure(fig_index); fig_index = fig_index + 1;
plot(stock_TT.Date,stock_TT.log_r_daily,'Marker','.'); hold on
plot(stock_TT.Date,stock_TT.log_r_daily*0,'r');
ylabel('Daily log return');
xlabel('Time');
box off; grid off; axis tight
 
%% Histogram of daily return
 
figure(fig_index); fig_index = fig_index + 1;
nbins = 40; % number of buckets or bins
h = histogram(stock_TT.log_r_daily,nbins)
h.Normalization = 'probability';
ylabel('Probability'); xlabel('Daily log return');
box off; grid off; axis tight
 
%% Daily log return using rowfun
 
daily_log_r_fcn = @(Open, High, Low, Close, Price, Volume, Adj_Cl, log_r_daily) log(Close/Open);
 
daily_log_r2 = rowfun(daily_log_r_fcn,stock_TT,'OutputVariableNames',{'Daily_log_r2'});
 
daily_simple_r_fcn = @(Open, High, Low, Close, Price, Volume, Adj_Cl, log_r_daily) (Close - Open)/Open;
 
daily_simple_r = rowfun(daily_simple_r_fcn,stock_TT,'OutputVariableNames',{'Daily_log_r2'});
 
%% Weekly data
 
weeklyOpen = retime(stock_TT(:,'Open'),'weekly','firstvalue');
weeklyHigh = retime(stock_TT(:,'High'),'weekly','max');
weeklyLow = retime(stock_TT(:,'Low'),'weekly','min');
weeklyClose = retime(stock_TT(:,'Close'),'weekly','lastvalue');
weeklyStd = retime(daily_log_r2(:,'Daily_log_r2'),'weekly',@std);
weeklyTT = [weeklyOpen,weeklyHigh,weeklyLow,weeklyClose,weeklyStd];
wkly_open_close = [weeklyOpen,weeklyClose];
 
wkly_log_r_fcn = @(Open, Close) log(Close) - log(Open);
wkly_log_r = rowfun(wkly_log_r_fcn,wkly_open_close,'OutputVariableNames',{'wkly_log_r'});
 
weeklyTT = synchronize(weeklyTT,stock_TT(:,'Volume'),'weekly','sum');
weeklyTT.Properties.VariableNames{'Daily_log_r2'} = 'wkly_std';
head(weeklyTT)
tail(weeklyTT)
 
%% Weekly return
 
figure(fig_index); fig_index = fig_index + 1;
plot(wkly_log_r.Date,wkly_log_r.wkly_log_r,'Marker','.'); hold on
plot(wkly_log_r.Date,wkly_log_r.wkly_log_r*0,'r')
ylabel('Weekly log return');
xlabel('Time');
box off; grid off; axis tight

% B5_Ch6_1_B.m

%% Candle stick
 
figure(fig_index); fig_index = fig_index + 1;
candle(stock_TT(end-20:end,:),'b');
ylabel('Price (high, low, open, close)');
xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Line break, red-bearish, green-bullish 
 
linebreak_price(:,'Price') = stock_TT(:,'Close');
linebreak_price.Time = stock_TT.Date;
 
figure(fig_index); fig_index = fig_index + 1;
plot1 = linebreak(linebreak_price(end-40:end,:));
xlabel('Time'); ylabel('Line break')
box off; grid off; axis tight
legend('Green-bullish','Red-bearish');
 
%% Line break, red-bullish, green-bearish
 
linebreak_price(:,'Price') = stock_TT(:,'Close');
linebreak_price.Time = stock_TT.Date;
 
figure(fig_index); fig_index = fig_index + 1;
plot1 = linebreak(linebreak_price(end-40:end,:));
xlabel('Time'); ylabel('Line break')
box off; grid off; axis tight
set(plot1(1),'Color',[1 0 0]);
set(plot1(2),'Color',[0 1 0]);
legend('Red-bullish','Green-bearish');

% B5_Ch6_1_C.m

%% High-low
 
figure(fig_index); fig_index = fig_index + 1;
endTime = stock_TT.Date(end);
index = timerange(endTime - days(30),endTime);
highlow(stock_TT(index,:));
ylabel('Price (high, low, open, close)');
xlabel('Time');
box off; grid off; axis tight
 
%% High-low and volumn
 
figure(fig_index); fig_index = fig_index + 1;
priceandvol(stock_TT(end-20:end,:));
box off; grid off; axis tight
 
%% Price and volume chart
 
figure(fig_index); fig_index = fig_index + 1;
 
h = volarea(stock_TT(end-60:end,:))
ylabel('Volume');
xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
h(1).Color = 'r';
h(2).FaceColor = [189, 214, 238]/255;
h(2).EdgeColor = [1, 1, 1];
 
%% New plot function stackedplot R2018b
 
% figure(fig_index); fig_index = fig_index + 1;
% stackedplot(stock_TT,{'Adj_Cl','Volume','log_r_daily'});
 
 
%% Kagi
 
figure(fig_index); fig_index = fig_index + 1;
kagi(linebreak_price(end-40:end,:))
xlabel('Time'); ylabel('Kagi')
box off; grid off; axis tight
%% Renko
 
figure(fig_index); fig_index = fig_index + 1;
renko(linebreak_price(end-20:end,:),20)
xlabel('Time'); ylabel('Renko')
box off; grid off; axis tight
xtickangle(45)

% B5_Ch6_1_D.m

%%%%%%%%%%
%% Time Series Volumes
%%%%%%%%%%
%% Positive volume index
 
figure(fig_index); fig_index = fig_index + 1;
volume = posvolidx(stock_TT);
plot(volume.Time,volume.PositiveVolume)
 
ylabel('Positive Volume Index'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Negative volume index
 
figure(fig_index); fig_index = fig_index + 1;
volume = negvolidx(stock_TT);
plot(volume.Time,volume.NegativeVolume)
 
ylabel('Negative Volume Index'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Relative Strength Index (RSI)
 
figure(fig_index); fig_index = fig_index + 1;
index = rsindex(stock_TT);
plot(index.Time,index.RelativeStrengthIndex)
 
ylabel('Relative Strength Index'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)

% B5_Ch6_1_E.m

%%%%%%%%%%%%%%%
%% Time Series Rate of Change
%%%%%%%%%%%%%%%
%% Accumulation/Distribution line
 
figure(fig_index); fig_index = fig_index + 1;
line = adline(stock_TT);
plot(line.Time,line.ADLine)
 
ylabel('Accumulation/Distribution Line'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
 
%% Time series Bollinger band
 
figure(fig_index); fig_index = fig_index + 1;
[middle,upper,lower]= bollinger(stock_TT);
CloseBolling = [middle.Close, upper.Close,lower.Close];
plot(middle.Time,CloseBolling)
ylabel('Bollinger Bands for closing price'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Highest high
figure(fig_index); fig_index = fig_index + 1;
values = hhigh(stock_TT);
plot(values.Time,values.HighestHigh)
 
ylabel('Highest High'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Lowest low
 
figure(fig_index); fig_index = fig_index + 1;
values = llow(stock_TT);
plot(values.Time,values.LowestLow)
 
ylabel('Lowest Low'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Median price
 
MedianPrice = medprice(stock_TT);
 
figure(fig_index); fig_index = fig_index + 1;
plot(MedianPrice.Time,MedianPrice.MedianPrice)
xlabel('Time'); ylabel('Median Price')
box off; grid off; axis tight
 
%% High-low, Moving Average (MA)
 
figure(fig_index); fig_index = fig_index + 1;
 
index = timerange(endTime - days(180),endTime);
highlow(stock_TT(index,:));
hold on
 
type = 'linear';
windowSize = 5;
ma5 = movavg(stock_TT(:,'Close'),type,windowSize);
windowSize = 10;
ma10 = movavg(stock_TT(:,'Close'),type,windowSize);
 
ma5 = ma5(index,:);
ma10 = ma10(index,:);
plot(ma5.Time,ma5.Close,'r');
plot(ma10.Time,ma10.Close,'g');
 
legend('High-low','5-Day MA','20-Day MA','Location','best')
xlabel('Time'); ylabel('High-low and MA')
box off; grid off; axis tight
 
%% %% High-low, Exponential Moving Average (EMA)
 
figure(fig_index); fig_index = fig_index + 1;
 
index = timerange(endTime - days(180),endTime);
highlow(stock_TT(index,:));
hold on
 
ema5 = movavg(stock_TT(:,'Close'),'exponential',5);
ema10 = movavg(stock_TT(:,'Close'),'exponential',10);
 
ema5 = ema5(index,:);
ema10 = ema10(index,:);
plot(ema5.Time,ema5.Close,'r');
plot(ema10.Time,ema10.Close,'g');
hold off
 
legend('High-low','5-Day EMA','10-Day EMA','Location','best')
xlabel('Time'); ylabel('High-low and EMA')
box off; grid off; axis tight
 
%% On-Balance Volume (OBV)
 
figure(fig_index); fig_index = fig_index + 1;
volume = onbalvol(stock_TT);
plot(volume.Time,volume.OnBalanceVolume)
ylabel('On-Balance Volume'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Price rate of change
 
figure(fig_index); fig_index = fig_index + 1;
PriceChangeRate = prcroc(stock_TT);
plot(PriceChangeRate.Time,PriceChangeRate.PriceRoc)
 
ylabel('Price Rate of Change'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Price and Volume Trend (PVT)
 
figure(fig_index); fig_index = fig_index + 1;
trend = pvtrend(stock_TT);
plot(trend.Time,trend.PriceVolumeTrend)
ylabel('Price and Volume Trend'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Typical Price
% typical price is the average of the high, low, and closing prices for each period
 
TypicalPrice = typprice(stock_TT);
 
figure(fig_index); fig_index = fig_index + 1;
plot(TypicalPrice.Time,TypicalPrice.TypicalPrice)
xlabel('Time'); ylabel('Typical Price')
box off; grid off; axis tight
 
%% Volume rate of change
 
figure(fig_index); fig_index = fig_index + 1;
volumeChangeRate = volroc(stock_TT);
plot(volumeChangeRate.Time,volumeChangeRate.VolumeChangeRate)
ylabel('Volume Rate of Change'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Weighted Closing
% The weighted closing price is the average of
% twice the closing price plus the high and low prices.
 
 
WeightedClose = wclose(stock_TT);
 
figure(fig_index); fig_index = fig_index + 1;
plot(WeightedClose.Time,WeightedClose.WeightedClose)
 
xlabel('Time'); ylabel('Weighted closing price')
box off; grid off; axis tight
 
%% Williams Accumulation/Distribution line
 
figure(fig_index); fig_index = fig_index + 1;
WADLine = willad(stock_TT);
plot(WADLine.Time,WADLine.WillAD)
ylabel('Williams A/D Line'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)

% B5_Ch6_1_F.m

%%%%%%%%%%%%%%%%%%
%% Time Series Oscillations
%%%%%%%%%%%%%%%%%%
 
%% Accumulation/Distribution oscillator
 
figure(fig_index); fig_index = fig_index + 1;
ADOsc = adosc(stock_TT);
plot(ADOsc.dates, ADOsc.ADOscillator,'Marker','.')
 
box off; grid off; axis tight
xlabel('Time'); ylabel('A/D Oscillator')
 
%% Chaikin oscillator
 
figure(fig_index); fig_index = fig_index + 1;
oscillator = chaikosc(stock_TT);
plot(oscillator.Time, oscillator.ChaikinOscillator)
ylabel('Chaikin Oscillator'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% MACD and Signal Line
 
figure(fig_index); fig_index = fig_index + 1;
[macdLine, signalLine] = macd(stock_TT(:,'Close'));
 
plot(macdLine.Time,macdLine.Close);
hold on
plot(signalLine.Time,signalLine.Close);
hold off
legend('MACD Line', 'Signal Line')
box off; grid off; axis tight
xlabel('Time'); ylabel('MACD and Signal Line')
 
%% Stochastic oscillator
 
figure(fig_index); fig_index = fig_index + 1;
oscillator = stochosc(stock_TT,'NumPeriodsD',7,'NumPeriodsK',10,'Type','exponential');
plot(oscillator.Time,oscillator.FastPercentK,oscillator.Time,oscillator.FastPercentD)
box off; grid off; axis tight
xlabel('Time'); ylabel('Stochastic Oscillator')
 
%% Acceleration between times
 
acceleration = tsaccel(stock_TT);
% acceleration.Price  = [];
% acceleration.Volume = [];
% acceleration.Adj_Cl = [];
% acceleration.log_r_daily = [];
 
figure(fig_index); fig_index = fig_index + 1;
subplot(2,2,1)
 
plot(acceleration.Time,acceleration.Open); hold on
plot(acceleration.Time,acceleration.Low*0,'r')
ylabel('Acceleration.Open'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,2)
 
plot(acceleration.Time,acceleration.Close); hold on
plot(acceleration.Time,acceleration.Low*0,'r')
ylabel('Acceleration.Close'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,3)
 
plot(acceleration.Time,acceleration.High); hold on
plot(acceleration.Time,acceleration.Low*0,'r')
ylabel('Acceleration.High'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,4)
 
plot(acceleration.Time,acceleration.Low); hold on
plot(acceleration.Time,acceleration.Low*0,'r')
ylabel('Acceleration.Low'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Momentum between times
 
momentum = tsmom(stock_TT);
 
figure(fig_index); fig_index = fig_index + 1;
subplot(2,2,1)
 
plot(momentum.Time,momentum.Open); hold on
plot(momentum.Time,momentum.Low*0,'r')
ylabel('Momentum.Open'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,2)
 
plot(momentum.Time,momentum.Close); hold on
plot(momentum.Time,momentum.Low*0,'r')
ylabel('Momentum.Close'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,3)
 
plot(momentum.Time,momentum.High); hold on
plot(momentum.Time,momentum.Low*0,'r')
ylabel('Momentum.High'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
subplot(2,2,4)
 
plot(momentum.Time,momentum.Low); hold on
plot(momentum.Time,momentum.Low*0,'r')
ylabel('Momentum.Low'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%%%%%%%%%%%%
%% Time Series Volatilities
%%%%%%%%%%%%
 
%% Chaikin volatility
 
figure(fig_index); fig_index = fig_index + 1;
volatility = chaikvolat(stock_TT,'NumPeriods',14,'WindowSize',14);
plot(volatility.Time,volatility.ChaikinVolatility)
ylabel('Chaikin Volatility'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
 
%% Williams %R
 
figure(fig_index); fig_index = fig_index + 1;
PercentR = willpctr(stock_TT);
plot(PercentR.Time,PercentR.WillPercentR)
ylabel('Williams %R'); xlabel('Time');
box off; grid off; axis tight
xtickangle(45)
