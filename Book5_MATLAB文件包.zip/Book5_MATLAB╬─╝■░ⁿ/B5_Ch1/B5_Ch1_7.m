% B5_Ch1_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
% Inflation and interest rates data
load Data_Canada
[numObs,numY] = size(Data);
 
% Englie-Granger cointegration test
% Obtain long-term equilibrium
[~,~,~,~,reg] = egcitest(Data,'test','t2');

c0 = reg.coeff(1);

alpha = reg.coeff(2:5);

beta = [1;-alpha];
 
% Obtain short-term equilibrium
% Maximum number of lags
q = 3;
tBase = (q+2):numObs;                   
T = length(tBase);                       
 
% Create Y_t-i, i=1,2,...,q
YLags = lagmatrix(Data,0:(q+1));            

LY = YLags(tBase,(numY+1):2*numY); 
 
% Create system equation
DeltaYLags = zeros(T,(q+1)*numY);

for k = 1:(q+1)
    DeltaYLags(:,((k-1)*numY+1):k*numY) = ...
               YLags(tBase,((k-1)*numY+1):k*numY) ...
             - YLags(tBase,(k*numY+1):(k+1)*numY);
end

DY = DeltaYLags(:,1:numY);       
DLY = DeltaYLags(:,(numY+1):end); 
 
% Solve equation
X = [(LY*beta-c0), DLY, ones(T,1)]; 
Result = (X\DY)'; 
 
% Seperate results
lambda = Result(:,1);
B1 = Result(:,2:6);
B2 = Result(:,7:11);
B3 = Result(:,12:16);
c1 = Result(:,end);
 
 
lambda,alpha,c0,B1,B2,B3,c1
