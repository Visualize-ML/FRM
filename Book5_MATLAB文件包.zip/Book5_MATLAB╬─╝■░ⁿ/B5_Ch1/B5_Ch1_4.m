% B5_Ch1_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
xrange = 1;
pmin = 0;
pmax = 5;
alpha = 0.6;
 
f = @(x1,x2,p)(abs(x1).^p+abs(x2).^p).^(1./p)-xrange;
 
figure(1)
plot_contours(f,xrange)
view(60,30)
 
figure(2)
plot_contours(f,xrange)
view(0,90)
daspect([1,1,1])
 
figure(3)
plot_contours(f,xrange)
view(45,0)
 
function plot_contours(f,xrange)
 
prange = [0.25,0.5,0.75,1:20];
my_col = brewermap(length(prange),'RdYlBu');
 
for i = 1:length(prange)
    pv = prange(i);
    [x1, x2] = meshgrid(linspace(-xrange, xrange, 51),linspace(-xrange, xrange, 51)); hold on
    
    F = f(x1, x2, pv);
    C = contours(x1, x2, F, [0 0]);
    
    x1L = C(1, 1:end);
    x2L = C(2, 1:end);
    FL = interp2(x1, x2, F, x1L, x2L);
    
    line(x1L, x2L, FL+pv,'color',my_col(i,:), 'LineWidth', 1);
    hold on
end
 
hold off
xlabel('{\it x}_1'); ylabel('{\it x}_2'); zlabel('{\it p}')
end
