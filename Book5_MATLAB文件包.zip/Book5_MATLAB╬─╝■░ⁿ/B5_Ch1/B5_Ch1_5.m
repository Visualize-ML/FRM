% B5_Ch1_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
%% Import MATLAB data
load Data_CreditDefaults
 
% Matrix of regresor X
X = Data(:, 1:4);
% Number of observations
T_num = size(X,1);
% Regressand y
y = Data(:, 5);
VarNames = {'AGE','BBB','CPF','SPR'};
 
% Lasso regression
[Betas,Info] = lasso(X,y);
 
% Plot
[ax,figh] = lassoPlot(Betas, Info,'PlotType','Lambda');

ax.XGrid = 'on';
ax.YGrid = 'on';
ax.XLabel.String = 'Lasso Parameter';
ax.YLabel.String = 'Coefficients, Beta';
 
hlplot = ax.Children;
htraces = hlplot(4:-1:1);
set(hlplot,'LineWidth',2)
legend(htraces,VarNames,'Location','NW')
