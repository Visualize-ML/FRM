% B5_Ch1_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch1_6_A.m

clear all; close all; clc
 
load Data_Canada
 
figure
plot(dates,Data,'LineWidth',1)
xlabel('Years (1954-1994)');
ylabel('Inflaction and Interest Rates (%)');
 
VarNames = series(1:end);
legend(VarNames,'location','NW')
title '{\bf Historical Canadian Interest Rates}';
axis tight
grid off
 
% Englie-Granger cointegration test
[h_egc, pValue_egc, stat_egc, cValue_egc] = ...
egcitest(Data, 'test', {'t1'}, 'alpha', 0.05)

% B5_Ch1_6_B.m

[h_egc, pValue_egc, stat_egc, cValue_egc] = ...
egcitest(Data,'test',{'t2'},'alpha', 0.05)

% B5_Ch1_6_C.m

[h_egc, pValue_egc, stat_egc, cValue_egc] = ...
    egcitest(Data,'test',{'t1','t2'},'alpha', 0.05)
