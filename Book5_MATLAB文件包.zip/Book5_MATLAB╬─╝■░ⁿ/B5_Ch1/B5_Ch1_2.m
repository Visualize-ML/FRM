% B5_Ch1_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch1_2_A.m

clc; clear all; close all
 
%% Import MATLAB data
load Data_CreditDefaults
 
% Matrix of regresor X
X = Data(:, 1:4);
% Number of observations
T_num = size(X,1);
% X Matrix with constant
XI = [ones(T_num, 1), X];
VarNames = {'AGE','BBB','CPF','SPR'};
% Regressand y
y = Data(:, 5);

% B5_Ch1_1_B.m

% Define ridge parameter
MuI = mean(diag(XI'*XI));  
k = 0:MuI/10; 

% B5_Ch1_2_C.m

% Ridge regression
ridgeBetas = ridge(y,X,k,0);

[var_num,k_num] = size(ridgeBetas)

figure
plot(k,ridgeBetas(2:end,:))
xlim([0 max(k)])
legend(VarNames)
xlabel('Ridge Parameter \itk') 
ylabel('Coefficient Estimate') 

% B5_Ch1_2_D.m

% Calculate MSE
yhat = XI*ridgeBetas;

RidgeRes = repmat(y,1,k_num)-yhat;

RidgeSSE = RidgeRes'*RidgeRes;

RidgeDFE = T_num-var_num;

RidgeMSE = diag(RidgeSSE/RidgeDFE);
 
figure
plot(k,RidgeMSE)
xlim([0 max(k)])
xlabel('Ridge Parameter \itk') 
ylabel('MSE') 
