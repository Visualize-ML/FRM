% B5_Ch1_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B5_Ch1_1_A.m

clc; clear all; close all
 
%% Import MATLAB data
load Data_CreditDefaults
 
% Matrix of regresor X
X = Data(:, 1:4);
% Table of regressor X
XTbl = DataTable(:,1:4); 
% Regressor names
RegressorNames = series(1:4);
% Number of observations
T_num = size(X,1);
 
% Regressand y
y = Data(:, 5);
 
% Convert dates to serial date numbers:
dateNums = datenum([dates,ones(T_num,2)]);
 
%% Original regression model
% Use fitlm() function
Md0 = fitlm(DataTable)

% B5_Ch1_1_B.m

%% Visulize the correlation of X
corr_coe = corrcoef(X)
 
figure
corrplot(XTbl, 'testR', 'on')

% B5_Ch1_1_C.m

%% Calculate condition numbers
XI = [ones(T_num, 1), X];
 
kappa = cond(XI)
 
% Ones-matrix
kappa_one = cond(ones(size(XI)))
 
% Zeros-matrix
kappa_zero = cond(zeros(size(XI)))
 
% Identity-matrix
kappa_identity = cond(eye(size(XI, 2)))

% B5_Ch1_1_D.m

%% Calculate VIF
VIF = diag(inv(corr_coe))'
 
RSquared_i = 1-(1./VIF)

% B5_Ch1_1_E.m

%% Collinearity test
X0Tbl = ...
[table(ones(T_num,1),'VariableNames',{'Const'}),XTbl];
 
collintest(X0Tbl);
 
figure
collintest(X0Tbl,'tolIdx',10,'tolProp',0.5, ...
'display','off','plot','on');

% B5_Ch1_1_F.m

% Default settings of 'tolIdx'=30 and 'tolProp'=0.5
collintest(X0Tbl, 'plot', 'on') 

