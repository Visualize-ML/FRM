% B5_Ch1_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang, Sheng Tu, Feng Zhang, and Wei Lu, 2020
% Book 5  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% Set plot ranges
xrange = 1;
prange = [0.01, 0.5, 1, 3, 10, 10000];
 
% Define l_p norm equation
f = @(x1,x2,p)(abs(x1).^p+abs(x2).^p).^(1./p)-xrange;
 
% Plot
figure()
for i = 1:length(prange)
    subplot(2,3,i)    
    pv = prange(i);
    fs = fimplicit(@(x1,x2) f(x1,x2,pv), ...
        [-xrange, xrange, -xrange, xrange], ...
        'LineWidth', 1.5);
 
    xlabel('{\it x}_{1}')
    ylabel('{\it x}_{2}')
    title(['{\it l}_{p} Norm with p = ', num2str(pv)])
    daspect([1,1,1])
end
