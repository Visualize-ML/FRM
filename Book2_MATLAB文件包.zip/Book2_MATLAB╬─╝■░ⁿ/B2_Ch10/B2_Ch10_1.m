% B2_Ch10_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch10_1_A.m
clc; clear all; close all;
 
% Import data
load CreditCardData

data_summary = summary(data);
disp(data_summary)

% Create "creditscorecard" object
cscobj = creditscorecard(data, ...
    'IDVar', 'CustID', 'ResponseVar', 'status');


%% B2_Ch10_1_B.m
cscobj.IDVar
cscobj.ResponseVar
cscobj.PredictorVars
cscobj.CategoricalPredictors


%% B2_Ch10_1_C.m
% Observe categorical variable
bininfo(cscobj,'ResStatus')
plotbins(cscobj, 'ResStatus')


%% B2_Ch10_1_D.m 
% Observe continous variable
bininfo(cscobj, 'CustIncome')
 
bin_cp = 2e4:5e3:6e4;

cscobj = ...
    modifybins(cscobj, 'CustIncome', ...
    'CutPoints', bin_cp);
 
bininfo(cscobj, 'CustIncome')
 
plotbins(cscobj, 'CustIncome')
xtickangle(60)


%% B2_Ch10_1_E.m 
% Apply autobinning()
cscobj = autobinning(cscobj);
 
bininfo(cscobj, 'ResStatus')
bininfo(cscobj, 'CustIncome')
 
plotbins(cscobj, 'ResStatus')
plotbins(cscobj, 'CustIncome')
xtickangle(60)


%% B2_Ch10_1_F.m 
% Results here are not provided in the book;
plotbins(cscobj, cscobj.PredictorVars)


%% B2_Ch10_1_G.m
% Modify bins of CustIncome
[bin, bin_cp] = bininfo(cscobj,'CustIncome');

bin_cp([3 4]) = [];
 
cscobj = modifybins(cscobj,'CustIncome','CutPoints', bin_cp);
 
plotbins(cscobj,'CustIncome')


%% B2_Ch10_1_H.m
% Modify bins of CustAge, TmWBank, AMBalance
[bin, bin_cp] = bininfo(cscobj,'CustAge');
bin_cp([1 5]) = []; 
cscobj = modifybins(cscobj,'CustAge','CutPoints',bin_cp);
 
[bin, bin_cp] = bininfo(cscobj,'TmWBank');
bin_cp(2) = []; 
cscobj = modifybins(cscobj,'TmWBank','CutPoints',bin_cp);
 
[bin, bin_cp] = bininfo(cscobj,'AMBalance');
bin_cp(2) = []; 
cscobj = modifybins(cscobj,'AMBalance','CutPoints',bin_cp);

% Fit a logisitic regression model
[cscobj, cscobj_mdl] = fitmodel(cscobj);


%% B2_Ch10_1_I.m
 [cscobj, cscobj_mdl] = fitmodel(cscobj, ...
'VariableSelection', 'Stepwise');


%% B2_Ch10_1_J.m
% Skip this section to obtain the same results presented in
% in the book and produced by B2_Ch10_1_M.m 
% Use all predictor variables for model fitting
[cscobj, cscobj_mdl] = fitmodel(cscobj, ...
'VariableSelection', 'FullModel');


%% B2_Ch10_1_K.m
% Dispay existing predictor variables
cscobj.PredictorVars


%% B2_Ch10_1_L.m
% Re-define single predictor variable
% Skip this section to obtain the same results presented in
% in the book and produced by B2_Ch10_1_M.m 
cscobj.PredictorVars = {'CustID','CustIncome'};
 
% Re-define multiple predictor variables
cscobj.PredictorVars = {'CustID', ...
'CustIncome', 'CustAge', 'ResStatus'};


%% B2_Ch10_1_M.m
% Skip B2_Ch10_1_J.m and B2_Ch10_1_L.m to obtain the same 
% results presented in the book
% Review scorecard points
displaypoints(cscobj)


%% B2_Ch10_1_N.m
% Format socrecard "Bin"
cscobj = modifybins(cscobj,'CustAge','BinLabels',...
{'Up to 36' '37 to 39' '40 to 45' '46 to 57' '58 and up'});
 
cscobj = modifybins(cscobj,'CustIncome','BinLabels',...
{'Up to 28999' '29000 to 32999' '33000 to 41999' '42000 to 46999' '47000 and up'});
 
cscobj = modifybins(cscobj,'TmWBank','BinLabels',...
{'Up to 11' '12 to 44' '45 to 70' '71 and up'});
 
cscobj = modifybins(cscobj,'AMBalance','BinLabels',...
{'Up to 558.87' '558.88 to 1597.43' '1597.44 and up'});
 
displaypoints(cscobj)


%% B2_Ch10_1_O.m
% Format socrecard "Point"
% (worst and best scores)
worst_score = 300;
best_score = 900;
 
cscobj = formatpoints(cscobj,...
    'WorstAndBestScores',[worst_score best_score]);
 
displaypoints(cscobj)


%% B2_Ch10_1_P.m
% Input customer info
Predictors = {'CustAge', 'ResStatus', 'EmpStatus', ...
    'CustIncome', 'TmWBank', 'OtherCC', 'AMBalance'}';
 
Bin = {'37 to 39', 'Home Owner', 'Employed', ...
    '33000 to 41999', 'Up to 11', 'No', '558.88 to 1597.43'}';
 
customer_info = table(Predictors, Bin);
 
% Apply scorecard model
cscobj_points = displaypoints(cscobj);
 
customer_info = innerjoin(customer_info, cscobj_points); 
 
customer_score = sum(customer_info.Points);
 
text = sprintf('The customer obtains the score of %d.',...
    round(customer_score, 0));
 
disp(text)
