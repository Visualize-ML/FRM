% B2_Ch10_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch10_3.m
clc; clear all; close all;
 
xmin = 1;
xmax = 20;
x = xmin:xmax;
 
xlb = 2;
xub = 6;
 
y = [];
yb = [];
 
% Calculate combination number
for i = 1:length(x)
    
    yp = 0;
    ypb = 0;
    for xp = 1:x(i)
        
        numtmp = nchoosek(x(i), xp);        
        yp = numtmp + yp;        
        if xp >= xlb && xp <= xub
            ypb = numtmp + ypb;
        end
        
    end
    y = [y, yp];    
    yb = [yb, ypb];
    
end
 
% Plot
% plot(x, y, 'g', 'linewidth', 1.5)
plot(x, y, '-bo', 'markersize', 6, 'linewidth', 1)
hold on
plot(x, yb, '-ro', 'markersize', 6, 'linewidth', 1)
xlim([xmin, xmax]);
 
ylabel('Number of Combinations')
xlabel('Number of Variables')
 
legend('All combinations', 'Conditioned combinations', ...
    'Location', 'Northwest')
set(gcf, 'color', 'w')



