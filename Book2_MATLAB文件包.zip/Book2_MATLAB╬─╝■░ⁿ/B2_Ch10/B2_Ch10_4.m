% B2_Ch10_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch10_4_D.m
clc; clear all; close all;

% Case 1
TA = 2.1e6;
WC = 0.52e6;
RE = 1.011e6;
EBIT = 0.51e6;
MVE = 3.12e6;
TL = 0.905e6;
S = 1.04e6;


Z1 = ZScore_Public(WC,TA,RE,EBIT,MVE,TL,S)

Z2 = ZScore_Private(WC,TA,RE,EBIT,MVE,TL,S)

Z3 = ZScore_NM(WC,TA,RE,EBIT,TL,MVE)


%% B2_Ch10_4_A.m
function [Z] = ZScore_Public(WC,TA,RE,EBIT,MVE,TL,S)
%   Calculate Altman Z-Score fore public corporation
%   WC = Working Capital
%   TA = Total Assests
%   RE = Retained Earnings
%   EBIT = Earnings Before Interest and Tax
%   MVE = Market Value of Equity
%   TL = Total Liabilities

% Calculate input factors
X1 = WC/TA;
X2 = RE/TA;
X3 = EBIT/TA;
X4 = MVE/TL;
X5 = S/TA;

% Calculate z-score
Z = 1.2*X1 + 1.4*X2 + 3.3*X3 + .6*X4 + X5;

% Inference
if Z > 2.99
    disp('Business is Healthy')
else if 1.81 < Z < 2.99
        disp('Business is Intermediate')
    else
        disp('Business is Bankrupt')
    end
end
end

%% B2_Ch10_4_B.m
function [Z] = ZScore_Private(WC,TA,RE,EBIT,MVE,TL,S)
%   Calculate Altman Z-Score fore private corporation
%   WC = Working Capital
%   TA = Total Assests
%   RE = Retained Earnings
%   EBIT = Earnings Before Interest and Tax
%   MVE = Market Value of Equity
%   TL = Total Liabilities

% Calculate input factors
X1 = WC/TA;
X2 = RE/TA;
X3 = EBIT/TA;
X4 = MVE/TL;
X5 = S/TA;

% Calculate z-score
Z = .717*X1 + .847*X2 + 3.107*X3 + .42*X4 + .998*X5;

% Inference
if Z > 2.90
    disp('Business is Healthy')
else if 1.23 < Z < 2.90
        disp('Business is Intermediate')
    else
        disp('Business is Bankrupt')
    end
end
end

%% B2_Ch10_4_C.m
function [Z] = ZScore_NM(WC,TA,RE,EBIT,TL,MVE)
%   Calculate Altman Z-Score fore non-manufacture corporation
%   WC = Working Capital
%   TA = Total Assests
%   RE = Retained Earnings
%   EBIT = Earnings Before Interest and Tax
%   MVE = Market Value of Equity
%   TL = Total Liabilities


% Calculate input factors
X1 = WC/TA;
X2 = RE/TA;
X3 = EBIT/TA;
X4 = MVE/TL;

% Calculate z-score
Z = 6.56*X1 + 3.26*X2 + 6.72*X3 + 1.05*X4;

% Inference
if Z > 2.60
    disp('Business is Healthy')
else if 1.10 < Z < 2.60
        disp('Business is Intermediate')
    else
        disp('Business is Bankrupt')
    end
end
end

