% B2_Ch10_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch10_2_A.m
clc; clear all; close all;
 
% Import data and create "creditscorecard" object
load CreditCardData
 
cscobj = creditscorecard(data, ...
    'IDVar', 'CustID', 'ResponseVar', 'status');
 
% Apply autobinning()
cscobj = autobinning(cscobj);
 
% Modify bins of CustIncome, CustAge, TmWBank, AMBalance
[bin, bin_cp] = bininfo(cscobj,'CustIncome');
bin_cp([3 4]) = [];
cscobj = modifybins(cscobj,'CustIncome','CutPoints',bin_cp);
 
[bin, bin_cp] = bininfo(cscobj,'CustAge');
bin_cp([1 5]) = []; 
cscobj = modifybins(cscobj,'CustAge','CutPoints',bin_cp);
 
[bin, bin_cp] = bininfo(cscobj,'TmWBank');
bin_cp(2) = []; 
cscobj = modifybins(cscobj,'TmWBank','CutPoints',bin_cp);
 
[bin, bin_cp] = bininfo(cscobj,'AMBalance');
bin_cp(2) = []; 
cscobj = modifybins(cscobj,'AMBalance','CutPoints',bin_cp);
 
% Format socrecard "Bin"
cscobj = modifybins(cscobj,'CustAge','BinLabels',...
{'Up to 36' '37 to 39' '40 to 45' '46 to 57' '58 and up'});
 
cscobj = modifybins(cscobj,'CustIncome','BinLabels',...
{'Up to 28999' '29000 to 32999' '33000 to 41999' '42000 to 46999' '47000 and up'});
 
cscobj = modifybins(cscobj,'TmWBank','BinLabels',...
{'Up to 11' '12 to 44' '45 to 70' '71 and up'});
 
cscobj = modifybins(cscobj,'AMBalance','BinLabels',...
{'Up to 558.87' '558.88 to 1597.43' '1597.44 and up'});


%% B2_Ch10_2_B.m
%Extract existing predictor variables
Predictor = cscobj.PredictorVars;
 
%Extract InfoValue and Chi2PValue
InfoValue = [];
Chi2PValue = [];
 
for i = 1:numel(Predictor)
    
    % Get InfoValue
    bi = bininfo(cscobj, Predictor{i});    
    InfoValue(i) = bi.InfoValue(end);
    
    % Get Chi2PValue
    cscobj.PredictorVars = {'CustID', Predictor{i}};    
    [cscobj, cscobj_mdl] = fitmodel(cscobj, ...
        'VariableSelection', 'FullModel', 'Display', 'Off');
    
     tl = cscobj_mdl.devianceTest;     
     Chi2PValue(i) = tl{2, {'pValue'}};
    
end
 
Predictor = Predictor';
InfoValue = InfoValue';
Chi2PValue = Chi2PValue';
 
All_Predictors = table(Predictor, InfoValue, Chi2PValue);


%% B2_Ch10_2_C.m
% Sort by InfoValue
All_Predictors = sortrows(All_Predictors,...
    {'InfoValue'}, 'descend');
All_Predictors
 
% Sort by Chi2PValue
All_Predictors = sortrows(All_Predictors,...
    {'Chi2PValue'}, 'ascend');
All_Predictors


%% B2_Ch10_2_D.m
% Select predictors
Selected_Predictors = All_Predictors{1:4, {'Predictor'}};
 
Selected_Predictors = Selected_Predictors';
 
% Direct fitting with fitmodel()
cscobj.PredictorVars = [{'CustID'}, Selected_Predictors];
 
[cscobj, cscobj_mdl] = fitmodel(cscobj,...
'VariableSelection', 'Stepwise');


%% B2_Ch10_2_E.m
% Fitting with exhaustive search
Model_ID = [];
Model_Formula = [];
Predictor_Num = [];
Adj_R_Squared = [];
 
n = 1;
 
for j = 1:numel(Selected_Predictors)
    
    combinations = nchoosek(Selected_Predictors, j);    
    [rownum, varnum] = size(combinations);
            
    for i = 1:rownum
        
        disp(n)
        
        cscobj.PredictorVars = [{'CustID'}, combinations(i, :)];        
        
        [cscobj, cscobj_mdl] = fitmodel(cscobj,...
            'VariableSelection', 'FullModel', 'Display', 'Off');
        
        % Extract and sotre model info
        Model_ID = [Model_ID; n];
        
        Model_Formula = ...
            [Model_Formula; {char(cscobj_mdl.Formula)}];
        
        Predictor_Num = ...
            [Predictor_Num; varnum];
        
        Adj_R_Squared = ...
            [Adj_R_Squared; cscobj_mdl.Rsquared.Adjusted];
        
        n = n+1;
               
    end    
end
 
Candidate_Model = table(Model_ID, Model_Formula, ...
    Predictor_Num, Adj_R_Squared);


%% B2_Ch10_2_F.m
% Sort candidat models by adjusted R-squared
Candidate_Model = sortrows(Candidate_Model,...
{'Adj_R_Squared'}, 'descend');

disp(Candidate_Model)
