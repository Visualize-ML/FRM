% B2_Ch4_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
spot_price_range = 0.01:1:100;
IR_range = 0:0.02:0.2;
volatility = 0.35;
spot_price_length = length(spot_price_range);
k = 50;
IR_length = length(IR_range);
time_to_m = 2; % year, to be updated 2, 1, 1/12
 
IR_matrix = IR_range(ones(spot_price_length,1),:)';
IR_range_holder = ones(length(IR_range),1);
spot_price_matrix = spot_price_range(IR_range_holder,:);
all_one_matrix = ones(size(IR_matrix));
maturity_matrix = time_to_m*all_one_matrix;
% Plot Call option price versus maturity
my_col = brewermap(IR_length,'RdYlBu');
% This function, brewermap, can be easily downloaded
% from MATLAB support and used for free
 
figure (1)
 
[call_option_price_matrix,put_option_price_matrix]  ...
    = blsprice(spot_price_matrix, ...
    k*all_one_matrix, IR_matrix,...
    maturity_matrix, volatility*all_one_matrix);
 
mesh(spot_price_range, IR_range, call_option_price_matrix);
xlabel('Stock Price [USD]');
ylabel('Interest rate');
zlabel('Call option price [USD]');
title('Call option price versus interest rate');
colorbar;
xlim([0 max(spot_price_range)])
ylim([min(IR_range) max(IR_range)])
set(gcf,'color','white')
 
figure (2)
 
for i = 1:IR_length
    
    plot(spot_price_range, call_option_price_matrix(i,:),...
        'color',my_col(i,:));
    hold on
    legendCell{i} = num2str(IR_range(i),'IR = %0.2f');
end
 
legend(legendCell,'Location','Best')
xlim ([0,100]); daspect([1,1,1])
xlabel('Stock Price [USD]');
ylabel('Call option price [USD]');
title('Call option price versus interest rate');
set(gcf,'color','white')
box off; grid off 
% Plot Put option price versus maturity
 
figure (3)
mesh(spot_price_range, IR_range, put_option_price_matrix);
xlabel('Stock Price [USD]');
ylabel('Interest rate');
zlabel('Put option price [USD]');
title('Put option price versus interest rate');
colorbar;
xlim([0 max(spot_price_range)])
ylim([min(IR_range) max(IR_range)])
set(gcf,'color','white')
 
figure (4)
 
for i = 1:IR_length
    
    plot(spot_price_range, put_option_price_matrix(i,:),'color',my_col(i,:));
    hold on
    legendCell{i} = num2str(IR_range(i),'IR = %0.2f');
end
 
legend(legendCell,'Location','Best')
xlim ([0,100]); daspect([1,1,1])
xlabel('Stock Price [USD]');
ylabel('Put option price [USD]');
title('Put option price versus interest rate');
set(gcf,'color','white')
box off; grid off

