% B2_Ch4_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
K = 50;
S0 = K;
 
N_steps = 252;
mu = 0.05;
sigma = 0.5;
N_paths = 500;
T_sim = 1;
 
stock_path = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0);
S_T = stock_path(:,end);
 
possible_call = max(0,S_T-K); 
possible_put  = max(0,K-S_T);
 
Call = exp(-mu*T_sim)*mean(possible_call);
Put = exp(-mu*T_sim)*mean(possible_put);
 
[Call_BSM,Put_BSM] = blsprice(S0,K,mu,T_sim,sigma);
 
figure(1)
histfit(S_T,20,'lognormal'); box off
ylabel('Frequency'); xlabel('Possible stock price in a year');
 
figure(2)
subplot(1,2,1)
histogram(possible_call,20); box off
xlabel('Possible call price'); ylabel('Frequency')
 
subplot(1,2,2)
histogram(possible_put,20); box off
xlabel('Possible put price'); ylabel('Frequency')
 
figure(3)
S_range = [0:1:max(S_T)];
plot(S_range,max(S_range - K,0)); hold on
plot(S_T,possible_call,'+'); box off
daspect([1 1 1]); xlabel('Stock price')
ylabel('Call price at maturity')
 
figure(4)
S_range = [0:1:max(S_T)];
plot(S_range,max(K - S_range,0)); hold on
plot(S_T,possible_put,'+'); box off
daspect([1 1 1]); xlabel('Stock price')
ylabel('Put price at maturity')
 
function S = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0)
dt = T_sim/N_steps;
drift = (mu - 0.5*sigma^2)*dt;
S = S0*ones(N_paths, N_steps+1);
brownian = sigma*sqrt(dt)*normrnd(0,1,N_paths, N_steps);
S(:, 2:end) = S0*exp(cumsum(drift + brownian, 2));
end

