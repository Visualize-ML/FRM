% B2_Ch4_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
spot_price_range = 0.01:1:100;
interest_rate = 0.1;
volatility = 0.35;
spot_price_length = length(spot_price_range);
k_range = [30:5:60]; % USD
k_length = length(k_range);
time_to_m = 6/12; % year
 
k_matrix = k_range(ones(spot_price_length,1),:)';
k_range_holder = ones(length(k_range),1);
spot_price_matrix = spot_price_range(k_range_holder,:);
all_one_matrix = ones(size(k_matrix));
maturity_matrix = time_to_m*all_one_matrix;
% Plot Call option price versus maturity
my_col = brewermap(k_length,'RdYlBu');
 
% This function, brewermap, can be easily downloaded
% from MATLAB support and used for free
 
figure (1)
 
[call_option_price_matrix,put_option_price_matrix]  ...
    = blsprice(spot_price_matrix, ...
    k_matrix, interest_rate*all_one_matrix,...
    maturity_matrix, volatility*all_one_matrix);
 
mesh(spot_price_range(1:2:end), k_range,...
    call_option_price_matrix(:,1:2:end));
xlabel('Stock Price [USD]');
ylabel('Strike [USD]');
zlabel('Call option price [USD]');
title('Call option price versus maturity');
colorbar; grid off; box off
xlim([0 max(spot_price_range)])
ylim([min(k_range) max(k_range)])
set(gcf,'color','white'); view(-45,30)
 
figure (2)
 
for i = 1:k_length
    
    plot(spot_price_range, call_option_price_matrix(i,:),...
        'color',my_col(i,:));
    hold on
    legendCell{i} = num2str(k_range(i),'K = %-d USD');
end
 
legend(legendCell,'Location', 'Best'); legend boxoff 
xlim ([0,100]);  daspect([1,1,1])
xlabel('Stock Price [USD]');
ylabel('Call option price [USD]');
title('Call option price versus strike price');
set(gcf,'color','white'); box off; grid off
 
% Plot Put option price versus maturity
 
figure (3)
mesh(spot_price_range(1:2:end), k_range,...
    put_option_price_matrix(:,1:2:end));
xlabel('Stock Price [USD]');
ylabel('Strike [USD]');
zlabel('Put option price [USD]');
title('Put option price versus strike price');
colorbar; colorbar; grid off; box off
xlim([0 max(spot_price_range)])
ylim([min(k_range) max(k_range)])
set(gcf,'color','white'); view(45,30)
 
figure (4)
 
for i = 1:k_length
    
    plot(spot_price_range, put_option_price_matrix(i,:),'color',my_col(i,:));
    hold on
    legendCell{i} = num2str(k_range(i),'K = %-d USD');
end
 
legend(legendCell); legend boxoff 
xlim ([0,100]); daspect([1,1,1])
xlabel('Stock Price [USD]');
ylabel('Put option price [USD]');
title('Put option price versus maturity');
set(gcf,'color','white'); box off; grid off
