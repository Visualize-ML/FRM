% B2_Ch4_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
Price = 50;  % spot exchange rate 
Strike = 30:1:70;  % strike 
Time = 1; 
Rate = 0.1;
sigma = 0.2; 
 
[call,put] = blsprice(Price,Strike,Rate,Time,sigma);
[call_ATM,put_ATM] = blsprice(Price,Price,Rate,Time,sigma);
 
figure(1)
aboveLine = (Strike <= Price);
belowLine = (Strike >= Price);
atLine    = (call == call_ATM);
 
call_ITM = call;
call_OTM = call;
call_ATM = call;
 
call_ITM(aboveLine) = NaN;
call_OTM(belowLine) = NaN;
call_ATM(~atLine) = NaN;
 
stem(Strike,call_ITM,'r'); hold on
stem(Strike,call_OTM,'b'); hold on
stem(Strike,call_ATM,'k'); hold on
legend('K > S0','K < S0','K = S0','location','best')
box off; grid off
ylabel('Call option price'); xlabel('Strike')
 
 
figure(2)
aboveLine = (Strike <= Price);
belowLine = (Strike >= Price);
atLine    = (put == put_ATM);
 
put_ITM = put;
put_OTM = put;
put_ATM = put;
 
put_ITM(aboveLine) = NaN;
put_OTM(belowLine) = NaN;
put_ATM(~atLine) = NaN;
 
stem(Strike,put_ITM,'r'); hold on
stem(Strike,put_OTM,'b'); hold on
stem(Strike,put_ATM,'k'); hold on
legend('K > S0','K < S0','K = S0','location','best')
box off; grid off
ylabel('Put option price'); xlabel('Strike')
