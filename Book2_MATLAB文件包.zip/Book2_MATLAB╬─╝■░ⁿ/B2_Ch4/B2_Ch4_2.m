% % B2_Ch4_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
vol = 0.2; % Volatility
r = 0.05;  % Risk-free interest rate
tau_array = 0:0.1:2; % Time to maturity (year(s))
Price_array = [40,50,60];
Strike = 50;   % Strike price
[tau_matrix,Price_matrix] = meshgrid(tau_array,Price_array);
[Call_matrix,Put_matrix] = blsprice(Price_matrix,Strike,r,tau_matrix,vol);
 
figure(1)
subplot(1,2,1)
plot(tau_array,Call_matrix)
xlabel('Time to maturity');ylabel('Call price')
box off; xlim([min(tau_array) max(tau_array)]); 
ylim([0 max(Call_matrix(:))])
legend('OTM','ATM','ITM')
 
subplot(1,2,2)
plot(tau_array,Put_matrix)
box off; xlim([min(tau_array) max(tau_array)]); 
ylim([0 max(Call_matrix(:))])
xlabel('Time to maturity');ylabel('Put price')
legend('ITM','ATM','OTM')
