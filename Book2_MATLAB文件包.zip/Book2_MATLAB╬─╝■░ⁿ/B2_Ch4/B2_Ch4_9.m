% B2_Ch4_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

S0_series = [40, 50, 60];
K = 50;
r = 0.04;
T = 1;
sigma = 0.1;
Num_step = 10:1:100; % Number of interations
option_price = zeros(size(Num_step));
Flag = 0;
% Flag indicating whether option is a call or put,
% specified as a scalar Flag = 1 for a call option,
% or Flag = 0 for a put option.
for j = 1:length(S0_series)
    
    S0 = S0_series(j);
    
    for i = 1:length(Num_step)
        
        delta = T/Num_step(i);
        [StockPrice, OptionPrice] = binprice(S0, K, r, T, delta, sigma, Flag);
        % binprice: Binomial put and call American option pricing using Cox-Ross-Rubinstein model
        
        option_price(i) = OptionPrice(1,1);
        
    end
    
    figure(j)
    plot(Num_step, option_price);
    xlabel('Number of steps');
    ylabel('Option value [USD]');
    title({['Convergence of binomial-tree pricing of American option'];...
        ['S0 = ' num2str(S0) ' USD; K = ' num2str(K) ' USD']});
    set(gcf,'color','white')
    xlim([min(Num_step) max(Num_step)])
    
end
