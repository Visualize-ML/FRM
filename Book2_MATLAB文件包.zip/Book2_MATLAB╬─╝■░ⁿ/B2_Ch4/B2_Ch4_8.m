% B2_Ch4_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
S0_series = [40,50,60];
K = 50; % strike price
r = 0.04; % risk-free interest rate
T = 1;    % time to maturity, in year(s)
sigma = 0.1; % volatility of underlying asset log returns
Num_steps = 10:1:100; % Number of simulation steps
option_price = zeros(size(Num_steps));
earlyExercise = false;  
% false: European; true: American
Flag = 1; 
% Flag = 1: a call option,
% or Flag = 0: a put option.
for j = 1:length(S0_series)
    
    S0 = S0_series(j);
    
    [Call,Put] = blsprice(S0,K,r,T,sigma);
    % BSM prices of European options
    
    if Flag == 1
        bls_price = Call;
    else
        bls_price = Put;
    end
    
    for i = 1:length(Num_steps)
        
        steps = Num_steps(i);
        dt = T/steps;
        %         [StockPrice, OptionPrice] = binprice(S0, K, r, T, dt, sigma, Flag);
 
        option_V = binPriceCRR(K,S0,r,sigma,dt,steps,Flag,earlyExercise);
        % binprice: Binomial put and call American option
        % pricing using Cox-Ross-Rubinstein model
        
        option_price(i) = option_V;
        
    end
    figure(j)
    plot(Num_steps, option_price,'b'); hold on
    plot(Num_steps, repmat(bls_price, size(Num_steps)),'r');
    xlabel('Number of steps');
    ylabel('Option value [USD]');
    title({['Convergence of binomial-tree pricing of European option'];...
        ['S0 = ' num2str(S0) ' USD; K = ' num2str(K) ' USD']});
    set(gcf,'color','white')
    xlim([min(Num_steps) max(Num_steps)])
    
end
 
 
%%
 
function option_price = binPriceCRR(K,S0,r,sigma,dt,steps,Flag,earlyExercise)
 
a = exp(r*dt);
u = exp(sigma*sqrt(dt));
d = 1/u;
p = (a-d)/(u-d);
 
First_Tree = nan(steps+1,steps+1);
First_Tree(1,1) = S0;
 
for idx = 2:steps+1
    First_Tree(1:idx-1,idx) = First_Tree(1:idx-1,idx-1)*u;
    First_Tree(idx,idx) = First_Tree(idx-1,idx-1)*d;
end
 
Second_Tree = nan(size(First_Tree));
switch Flag
    case 0
        Second_Tree(:,end) = max(K-First_Tree(:,end),0);
    case 1
        Second_Tree(:,end) = max(First_Tree(:,end)-K,0);
end
 
steps = size(First_Tree,2)-1;
for idx = steps:-1:1
    Second_Tree(1:idx,idx) = ...
        exp(-r*dt)*(p*Second_Tree(1:idx,idx+1) ...
        + (1-p)*Second_Tree(2:idx+1,idx+1));
    if earlyExercise
        switch Flag
            case 0
                Second_Tree(1:idx,idx) = ...
                    max(K-First_Tree(1:idx,idx),Second_Tree(1:idx,idx));
            case 1
                Second_Tree(1:idx,idx) = ...
                    max(First_Tree(1:idx,idx)-K,Second_Tree(1:idx,idx));
        end
    end
end
 
option_price = Second_Tree(1);
end
