% B2_Ch4_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% stock and option paths
% Please copy and paste in the M-file window, then run the code
clc; clear all; close all
K = 50;
S0 = K;
stock_ticks = linspace(30,70,100);
N_steps = 252;
mu = 0.05;
sigma = 0.5;
T_t = [N_steps:-1:0]/N_steps; % unit year
stock_path = GBM_stock(1, N_steps,1, mu, sigma,S0);
T_t_grid = repmat(T_t,length(stock_ticks),1);
stock_grid = repmat(stock_ticks',1,length(T_t));
 
[Call_path,Put_path] = blsprice(stock_path,K,mu,T_t,sigma);
[Call_surf,Put_surf] = blsprice(stock_grid,K,mu,T_t_grid,sigma);
 
figure(1)
subplot(2,1,1)
plot(T_t, stock_path,'b'); hold on
plot([T_t(1),T_t(end)],[K,K],'r')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock')
box off; grid off;
 
subplot(2,1,2)
plot(T_t, Call_path,'k'); hold on
plot([T_t(1),T_t(end)],[Call_path(1),Call_path(1)],'r')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Call option')
box off; grid off;
 
figure(2)
subplot(2,1,1)
plot(T_t, stock_path,'b'); hold on
plot([T_t(1),T_t(end)],[K,K],'r')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock')
box off; grid off;
 
subplot(2,1,2)
plot(T_t, Put_path,'k'); hold on
plot([T_t(1),T_t(end)],[Put_path(1),Put_path(1)],'r')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Put option')
box off; grid off;
 
 
figure(3)
mesh(T_t_grid(1:2:end,end:-10:1), stock_grid(1:2:end,end:-10:1),...
    Call_surf(1:2:end,end:-10:1),'MeshStyle','column','FaceColor','none')
hold all
plot3([T_t(1),T_t(end)],[K,K],[0,0],'r')
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1.5)
stem3(T_t(end:-20:1), stock_path(end:-20:1), Call_path(end:-20:1),'xk')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock'); zlabel('Call option')
box off; grid off
% you can also use downsample if you have the license
 
figure(4)
mesh(T_t_grid(1:2:end,1:10:end), stock_grid(1:2:end,1:10:end),...
    Call_surf(1:2:end,1:10:end),'MeshStyle','column','FaceColor','none')
hold all
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1.5)
plot3(T_t, stock_path, Call_path,'k','LineWidth',1.5)
plot3([T_t(1),T_t(end)],[K,K],[0,0],'r')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); 
ylabel('Stock'); zlabel('Call option')
box off; grid off

function S = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0)
dt = T_sim/N_steps;
drift = (mu - 0.5*sigma^2)*dt;
S = S0*ones(N_paths, N_steps+1);
brownian = sigma*sqrt(dt)*normrnd(0,1,N_paths, N_steps);
S(:, 2:end) = S0*exp(cumsum(drift + brownian, 2));
end
