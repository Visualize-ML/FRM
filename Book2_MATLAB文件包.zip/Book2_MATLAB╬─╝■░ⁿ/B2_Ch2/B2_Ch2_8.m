% B2_Ch2_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
N = 400;
% number of particles
particle_disp = struct();
% x-y plane
particle_disp.x = randn(N, 1);
particle_disp.y = randn(N, 1);
 
% possible, (X,Y) one-step location, zero correlation
 
correl_series = [0.75, -0.75];
index = length(correl_series);
 
for i = 1:index
    
    correl = correl_series(i);
    
    figure(i)
    particle_disp.z = correl*particle_disp.x +...
        sqrt(1-correl^2)*particle_disp.y;
    
    scatterhist(particle_disp.x, particle_disp.z);
    xlabel('X'); ylabel('Z');
    set(gcf,'color','w');
    
end
