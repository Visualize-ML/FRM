% B2_Ch2_16.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
x0 = 1; 
% initial position
mu = 0.15;
sigma = 0.2;
t_series = [0.25:0.25:5];
x = [0.05:0.025:3];
 
length_t = length(t_series);
log_pdf_series = [];
 
my_col = brewermap(length_t,'RdYlBu');
figure(1)
 
for i = 1:length_t
    
    t = t_series(i);
    sigma_logn = sigma*sqrt(t);
    mu_logn = log(x0) + (mu - 0.5*sigma^2)*t;
    log_pdf = lognpdf(x,mu_logn,sigma_logn);
    
    plot(x,log_pdf,'color',my_col(i,:)); hold on
    legendCell{i} = num2str(t_series(i),'t = %.2f');
    log_pdf_series = [log_pdf_series; log_pdf];
    
end
 
legend(legendCell,'location','best')
xlabel ('Position of random walk')
ylabel ('Probability')
ylim ([0, 4]); xlim ([0, 3])
box off; grid off
set(gcf,'color','w');
 
figure(2)
 
mesh(x,t_series,log_pdf_series)
xlabel ('Position of random walk')
xlim ([0.05, 3]); ylim ([0.25, 5])
ylabel ('Time, t'); zlabel ('Probability')
zlim ([0, 4]); box off; grid off
set(gcf,'color','w');
