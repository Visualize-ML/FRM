% B2_Ch2_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
num_points = 500;
MUs = [0,0];
std1 = 1; std2 = 1;
rho12 = 0.75;
cov12 = std1*std2*rho12;
SIGMA = [std1^2, cov12
         cov12, std2^2];
 
L = chol(SIGMA);
Z = randn(num_points,2);
X = repmat(MUs,num_points,1) + Z*L;
 
figure(1)
subplot(1,2,1)
plot(Z(:,1),Z(:,2),'.')
xlabel('Z_1'); ylabel('Z_2');
daspect([1,1,1]); box off
xlim([-4, 4]); ylim([-4, 4]); 
 
subplot(1,2,2)
plot(X(:,1),X(:,2),'.')
xlabel('X_1'); ylabel('X_2');
daspect([1,1,1]); box off
xlim([-4, 4]); ylim([-4, 4]); 
