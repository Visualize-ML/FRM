% B2_Ch2_14.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
num_steps = 8;
 
NUM_paths = [2,5,10,200];
 
for i = 1:length(NUM_paths)
    
    num_paths = NUM_paths(i);
    
    t = 0:num_steps;
    delta_x = randi([0,1],num_paths,num_steps)*2 - 1;
    % randsrc
    realized_x_paths = [zeros(num_paths,1),cumsum(delta_x,2)];
    destinations = realized_x_paths(:,end)
    
    figure(i)
    subplot(1,2,1)
    plot(t,realized_x_paths,'-o','MarkerFaceColor','w','LineWidth',2)
    daspect([1, 1, 1]);box off; grid off
    xlabel('Step'); ylabel('Location')
    ylim([-num_steps-1,num_steps+1])
    xlim([0,num_steps]); y1=get(gca,'ylim');
    
    subplot(1,2,2)
    edges = -num_steps-1:2:num_steps+1;
    histogram(destinations,edges);
    xlim(y1); view(90,-90); box off;
    ylabel('Number of points')
    title(['Number of paths = ',num2str(num_paths)])
end
