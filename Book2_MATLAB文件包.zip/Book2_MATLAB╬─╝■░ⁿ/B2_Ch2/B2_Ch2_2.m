% B2_Ch2_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% marginal frequency/probability/distribution
 
XY = [0 1 0 0;
      1 3 5 0;
      1 4 1 1;
      3 0 0 0;];

xvalues = {'x1','x2','x3','x4'};
yvalues = {'y1','y2','y3','y4'};

total = sum(XY(:));
X = sum(XY,1); Y = sum(XY,2);
 
figure(1)
subplot(4,4,[2:4 6:8 10:12]); % Top right square
heatmap(xvalues, yvalues, XY)
y_lim=get(gca,'ylim'); X_lim=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
Y = flipud(Y);
bar(Y,0.5);
text([1:length(Y)], Y, num2str(Y,'%0.0f'),...
    'HorizontalAlignment','center','VerticalAlignment','middle')
box off; xlim([0.5,4.5]); xlabel('Y');
view(90,-90); box off; ylabel('Frequency')
ylim([0, 12]); set(gca,'XTickLabel',[]);
 
subplot(4,4,[14:16]); % Btm right
bar(X,0.5); xlabel('X'); ylabel('Frequency')
% xlim(X_lim); box off
text([1:length(X)], X', num2str(X','%0.0f'),...
    'HorizontalAlignment','center','VerticalAlignment','bottom')
box off; xlim([0.5,4.5]); xlabel('X');
ylim([0, 12]); set(gca,'XTickLabel',[]);
