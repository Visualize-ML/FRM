% B2_Ch2_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
x = [-10:.25:10];
% Distance of random walk at t
mu = 0;
% W(0) = 0, which is the starting point of random walk
t = 1:20;
sigma = 1; % standard normal distribution
sigma_series = sqrt(t)*sigma;
 
[X,SIGMA] = meshgrid(x,sigma_series);
 
figure(1)
plot(t,sigma_series)
xlabel('t'); ylabel('Sigma*sqrt(t)')
grid off; box off
xlim ([min(t),max(t)])
 
n_sigma = length (sigma_series);
my_col = brewermap(n_sigma,'RdYlBu');
pdf_matrix = [];
 
figure(2)
for i = 1:n_sigma
    sigma = sigma_series(i);
    pdf = normpdf(x,mu,sigma);
    pdf_matrix = [pdf_matrix;pdf];
    plot(x,pdf,'color',my_col(i,:))
    legendCell{i} = num2str(t(i),'t = %.0f');
    hold on
end
 
legend(legendCell,'location','best')
xlabel ('Position of random walk')
ylabel ('Probability'); grid off; box off
ylim ([0, 0.4]); set(gcf,'color','w');
 
figure(3)
 
mesh(x,t,pdf_matrix)
xlabel ('Position of random walk')
xlim ([-5, 5]); ylim ([min(t),max(t)])
ylabel ('Time, t'); zlabel ('Probability')
zlim ([0, 0.4]); set(gcf,'color','w');
grid off; box off
