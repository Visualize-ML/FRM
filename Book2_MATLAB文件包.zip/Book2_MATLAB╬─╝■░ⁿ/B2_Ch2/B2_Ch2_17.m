% B2_Ch2_17.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all;
n = 3000; % Number of darts
r = 1; % radius of the circle
% In general, you can generate N random numbers in the interval (a,b)
% with the formula r = a + (b-a).*rand(N,1).
[pi_est,n_area,x,y] = estimate_PI (n, r);
 
figure(1)
rectangle('Position',[-1,-1,2,2]);
hold on;
theta=linspace(0,2*pi,1000);
rho=ones(1,1000);
[xc,yc] = pol2cart(theta,rho);
plot(xc,yc,'k-','linewidth',2);
axis square;
inside=find(x.^2+y.^2<1);
outside=find(x.^2+y.^2>=1);
plot(x(inside),y(inside),'r.');
plot(x(outside),y(outside),'bx');
title(['m/n = ',num2str(n_area),'/',num2str(n),...
    ', \pi_e_s_t = ',num2str(pi_est,'%8.6f')]);
xlabel('x coordinate')
ylabel('y coordinate')
 
 
n_series = 1e3:1e3:1e5;
 
for i = 1:length(n_series)
    
    n = n_series(i);
    [pi_est,~,~,~] = estimate_PI (n, r);
    PI_EST (i) = pi_est;
    
end
 
figure(2)
hAx = subplot(2,1,1)
PI = pi*ones(1,length(n_series));
plot(n_series/1000, PI_EST,'.'); hold on
plot(n_series/1000, PI)
hAx.XAxis.TickLabelFormat='%.fk';
xlabel('Number of darts')
ylabel('Estimation of \pi')
box off; grid off;
 
hAx = subplot(2,1,2)
error = PI_EST - PI;
plot(n_series/1000, error,'.')
hAx.XAxis.TickLabelFormat='%.fk';
xlabel('Number of darts')
ylabel('Error (\pi_e_s_t - \pi)')
set(gca, 'XAxisLocation', 'origin')
box off; grid off;
%%
function [pi_est,n_area,x,y] = estimate_PI (n, r)
 
b = 1;
a = -1;
x = a + (b-a)*rand(n,1);    % x coordinates of the darts
y = a + (b-a)*rand(n,1);    % y coordinates of the darts
n_area =sum(x.^2+y.^2<r^2); % number of darts in the circle
pi_est=4*n_area/n;          % Estimate of pi
 
end
