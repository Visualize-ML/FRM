% B2_Ch2_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

N = 5000; 
% number of steps
displacement = randn(1,N); 
% randn returns a random scalar drawn from 
% the standard normal distribution.
% Brownian motion in one dimension is composed of 
% a sequence of normally distributed random displacements
% randn function returns a matrix of a normally distributed 
% random numbers with standard deviation 1
 
figure(1)
% to simulate the motion of a single particle in one dimension
plot(displacement,'o'); 
xlabel ('Cases')
ylabel ('Displacement of random walk')
set(gcf,'color','w');
 
figure(2)
histogram(displacement, 20); 
% histogram(X,nbins) uses a number of bins 
% specified by the scalar, nbins.
xlabel('Displacement of random walk')
ylabel('Number of occurrences')
set(gcf,'color','w');
 
figure(3)
histogram(displacement, 20, 'Normalization','probability');
ytix = get(gca, 'YTick')
set(gca, 'YTick',ytix, 'YTickLabel',ytix)
xlabel('Displacement of random walk')
ylabel('Probability, normalized')
set(gcf,'color','w');
 
figure (4)
cumu_disp = cumsum(displacement); 
plot(cumu_disp); 
ylabel('Position'); 
xlabel('Time step'); 
set(gcf,'color','w');
