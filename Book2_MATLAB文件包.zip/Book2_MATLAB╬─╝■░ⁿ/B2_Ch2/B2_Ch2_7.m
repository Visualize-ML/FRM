% B2_Ch2_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all;
close all;
clc
 
num_sim=10^4; mu=2; sigma=0.5;
val_cdf = rand(1,num_sim);
% X = rand returns a single uniformly distributed 
% random number in the interval (0,1).
X_norm_rand = norminv(val_cdf,mu,sigma);
% x = norminv(p,mu,sigma) returns the inverse of the normal cdf 
% with mean mu and standard deviation sigma, 
% evaluated at the probability values in p.
num_bins = 11;
% bins_cdf_edges = linspace(0,1,num_bins);
x=linspace((round(min(X_norm_rand)*100)-1)/100,...
    (round(max(X_norm_rand)*100)-1)/100,100);
 
subplot(4,4,[2:4 6:8 10:12]);
smoothed_cdf = ksdensity(X_norm_rand,x,'function','cdf');
% Kernel smoothing function estimate for univariate and bivariate data
plot(x,smoothed_cdf);
hold on
plot(X_norm_rand, val_cdf, 'x')

y1=get(gca,'ylim'); x1=get(gca,'xlim')
 
subplot(4,4,[1 5 9]);
% hist(val_cdf,bins_cdf_edges);
hist(val_cdf,num_bins);
view(90,-90); xlim(y1); xlabel('CDF')
 
subplot(4,4,[14:16]);
histfit(X_norm_rand,40)
xlim(x1); xlabel('x')
