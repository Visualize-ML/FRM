% B2_Ch2_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
NUM_steps = [2,4,6,8];
node_start = 0;
 
for m = 1:length(NUM_steps)
    
    num_steps = NUM_steps(m);
    T = 0:num_steps;
    
    nodes_current = node_start;
    
    figure(m)
    subplot(1,4,[1,2])
    hold all
    
    for i = 1:num_steps
        t = T(i);
        nodes_next = [];
        
        n = i;
        num_paths = [];
        
        for j = 1:length(nodes_current)
            
            node_up = nodes_current(j) + 1;
            plot([t,t+1],[nodes_current(j),node_up],'-o',...
                'MarkerFaceColor','w','LineWidth',1 ...
                ,'color',[0, 0.4470, 0.7410])
            
            node_down = nodes_current(j) - 1;
            plot([t,t+1],[nodes_current(j),node_down],'-o',...
                'MarkerFaceColor','w','LineWidth',1 ...
                ,'color',[0, 0.4470, 0.7410])
            
            nodes_next = [nodes_next; node_up; node_down;];
            
        end
        nodes_current = sort(unique(nodes_next));
    end
    
    num_paths = [];
    for k = 0:num_steps
        num_paths = [num_paths; nchoosek(num_steps,k)];
    end
    ylim([[-num_steps-0.5,num_steps+.5]])
    xlabel('Steps'); ylabel('Location')
    daspect([1, 1, 1]); title(['Total steps = ',num2str(num_steps)])
    
    subplot(1,4,3)
    locations = -num_steps:2:num_steps';
    bar(locations,num_paths,0.5/max(NUM_steps)*num_steps);
    text(locations, num_paths*1.2, num2str(num_paths,'%0.0f'),...
        'HorizontalAlignment','center','VerticalAlignment','middle')
    box off; xlim([-num_steps-0.5,num_steps+.5]); xlabel('Number of paths');
    view(90,-90); box off; ylabel('Frequency')
    ylim([0, max(num_paths)*1.4]); set(gca,'XTickLabel',[]);
    title(['Total paths = ',num2str(sum(num_paths))])
    
    
    subplot(1,4,4)
    probabilities = num_paths/sum(num_paths);
    bar(locations,probabilities,0.5/max(NUM_steps)*num_steps);
    text(locations, probabilities+0.1, num2str(probabilities,'%0.3f'),...
        'HorizontalAlignment','center','VerticalAlignment','middle')
    box off; xlim([-num_steps-0.5,num_steps+.5]); xlabel('Number of paths');
    view(90,-90); box off; ylabel('Probability')
    ylim([0, max(probabilities)+0.1]); set(gca,'XTickLabel',[]);
    
end
