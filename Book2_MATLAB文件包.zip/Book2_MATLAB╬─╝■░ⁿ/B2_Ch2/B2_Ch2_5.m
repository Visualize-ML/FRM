% B2_Ch2_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

num_points = 1000;
 
U = rand(num_points,2);
u1 = U(:,1); u2 = U(:,2); 
 
figure(1)
subplot(1,2,1)
plot(u1,u2,'.')
daspect([1,1,1]); box off
xticks([0,1]); yticks([0,1]);
 
subplot(1,2,2)
plot(u1,u1/2+u2/2,'.')
daspect([1,1,1]); box off
xticks([0,1]); yticks([0,1]);
