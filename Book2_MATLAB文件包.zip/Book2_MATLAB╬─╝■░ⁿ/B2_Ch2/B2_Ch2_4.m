% B2_Ch2_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
num_points = 100;
z = randn(num_points,1);
 
X1 = z; X2 = z;
X2 (abs(X2) <= 1) = -X2(abs(X2) <= 1);
 
figure(1)
num_bins = 10;
subplot(4,4,[2:4 6:8 10:12]); % Top right square
s_handle = scatter(X1,X2,40,'b','filled')
s_handle.MarkerFaceAlpha = 0.1;
s_handle.MarkerEdgeColor = 'none';
xlim([-4,4]); ylim([-4,4])
y_lim=get(gca,'ylim'); X_lim=get(gca,'xlim');
 
 
subplot(4,4,[1 5 9]); % Top left
histfit(X2,num_bins);
xlim(y_lim); xlabel('X_2'); 
view(90,-90); box off; ylabel('Frequency')
 
subplot(4,4,[14:16]); % Btm right
histfit(X1,num_bins)
xlabel('X_1'); ylabel('Frequency')
xlim(X_lim); box off
