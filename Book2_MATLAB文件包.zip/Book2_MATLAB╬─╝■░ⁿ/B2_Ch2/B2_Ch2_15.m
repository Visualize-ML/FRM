% B2_Ch2_15.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
N = 1000;
% number of steps
particle_disp = struct(); 
particle_path = struct(); 
% x-y plane
particle_disp.x = randn(N, 1);
particle_disp.y = randn(N, 1);
particle_path.x = cumsum(particle_disp.x); 
particle_path.y = cumsum(particle_disp.y); 
 
correl = -0.9
% to be updated, .0.5, 0.9, -0.5, -0.9, 0 (uncorrelated)
particle_disp.z = correl*particle_disp.x +...
    sqrt(1-correl^2)*particle_disp.y;
particle_path.z = cumsum(particle_disp.z); 
 
figure(1)
% co-movement of X and Y, zero correlation
plot(particle_path.x); hold on;
plot(particle_path.z); hold off
xlabel('Steps'); 
ylabel('Displacement'); 
set(gcf,'color','w');
