% B2_Ch2_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% bi-variate uniform distribution
% range [a, b]
clc; close all; clear all
a = -2; b = 2; num_bins = 10;
 
figure(1)
subplot(1,2,1)
num_points = 20; plot_unif_hist(a,b,num_points,num_bins)
 
subplot(1,2,2)
num_points = 1000; plot_unif_hist(a,b,num_points,num_bins)
 
function plot_unif_hist(a, b, num_points,num_bins)
 
unif_rand = a + (b - a)*rand(num_points,2);
scatterhist(unif_rand(:,1),unif_rand(:,2),'NBins',...
    [num_bins,num_bins],'Marker','.');
xlabel('X_1'); ylabel('X_2')
title(['Total observations = ',num2str(num_points)])
xlim([a,b]); ylim([a,b])
end
