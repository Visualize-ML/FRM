% B2_Ch2_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% univariate uniform distribution
% range [a, b]
clc; close all; clear all
a = -2; b = 2;
num_bins = 10;
 
figure(1)
subplot(2,2,1)
num_points = 20;
plot_unif_hist(a,b,num_points,num_bins)
 
subplot(2,2,2)
num_points = 100;
plot_unif_hist(a,b,num_points,num_bins)
 
subplot(2,2,3)
num_points = 500;
plot_unif_hist(a,b,num_points,num_bins)
 
subplot(2,2,4)
num_points = 10000;
plot_unif_hist(a,b,num_points,num_bins)
 
function plot_unif_hist(a, b, num_points,num_bins)

    bins_edges = linspace(a,b,num_bins);
    unif_rand = a + (b - a)*rand(num_points,1);
    histogram(unif_rand, bins_edges);
    xlabel('x'); ylabel('Number of observations')
    title(['Total observations = ',num2str(num_points)])
    xlim([a,b]); box off; grid off

end
