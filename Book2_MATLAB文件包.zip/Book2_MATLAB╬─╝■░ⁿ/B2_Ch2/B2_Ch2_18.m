% B2_Ch2_18.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
x = 2:0.05:10;
fcn = x.*sin(x)/2 + 8;
fun = @(x) x.*sin(x)/2 + 8;
area_true = integral(fun,min(x),max(x));
% Original function
 
figure(1)
plot(x,fcn); hold on
x2 = [x, fliplr(x)];
curve1 = zeros(1,length(x));
curve2 = fcn;
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g');
 
xlabel('x'); ylabel('y')
line3 = ['True area = ',num2str(area_true)];
title({line3})
%% Area approximation using Monte Carlo simulation
num_points = 500;
 
figure(2)
y_max = round(max(fcn));
p_x = min(x) + (max(x) - min(x))*rand(1,num_points);
p_y = 0 + (y_max - 0)*rand(1,num_points);
plot(x,fcn); hold on
x2 = [x, fliplr(x)];
curve1 = zeros(1,length(x));
curve2 = fcn;
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g'); hold on
p_accepted = 0; % Counter of accepted points

for i = 1:num_points
    xx = p_x(i);
    yy = p_y(i);
    if yy < xx.*sin(xx)/2 + 8
        p_accepted = p_accepted + 1;
        plot(xx,yy,'.r'); hold on
    else
        plot(xx,yy,'xb'); hold on
    end
end

area_total = (y_max-0)*(max(x) - min(x));
area_est = area_total*p_accepted/num_points;
line1 = [num2str(p_accepted),' points in ', num2str(num_points)];
line2 = ['Estimated area = ',num2str(area_est)];
line3 = ['Analytical solution = ',num2str(area_true)];
title({line1;line2;line3})
 
xlabel('x'); ylabel('y')
