% B2_Ch2_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

num_points = 2000;
radius = 4;
 
r1 = radius*rand(num_points,1);
theta1 = 2*pi*rand(num_points,1);
 
x1 = r1.*cos(theta1);
y1 = r1.*sin(theta1);
 
r2 = radius*sqrt(rand(num_points,1));
theta2 = 2*pi*rand(num_points,1);
 
x2 = r2.*cos(theta2);
y2 = r2.*sin(theta2);
 
figure(1)
subplot(1,2,1)
plot(x1,y1,'.')
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-5,5]); ylim([-5,5]);
 
subplot(1,2,2)
plot(x2,y2,'.')
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-5,5]); ylim([-5,5]);
