% B2_Ch7_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url); series = 'SP500';
startdate = '08/08/2017';
% beginning of date range for historical data
enddate = '08/08/2019'; % to be updated
% ending of date range for historical data
 
d = fetch(c,series,startdate,enddate);
% display description of data structure
 
index = 1;
 
SP500 = d.Data(:,2); date_series = d.Data(:,1);
 
SP500_non_NaN_index = ~isnan(SP500);
SP500_rm_NaN = SP500(SP500_non_NaN_index);
date_series_rm_NaN = date_series(SP500_non_NaN_index);
 
[daily_log_return,interval] = tick2ret (SP500_rm_NaN,...
    date_series_rm_NaN,'Continuous');
daily_log_return = [NaN; daily_log_return];
[ranked_log_return, ranked_log_return_index] = sort(daily_log_return);
 
figure (index); index = index + 1;
subplot(1,3,1)
plot (ranked_log_return, 'o')
ylabel ('Daily log return'); set(gcf,'color','white')
ranked_length = length (ranked_log_return);
axis tight; box off
xlabel(['# of returns: ',num2str(length(ranked_log_return))])
y_limit = ylim;
 
subplot(1,3,2)
 
window_10_percent = ranked_log_return(1:ranked_length*0.1);
plot (window_10_percent, 'o')
ylabel ('Daily log return')
set(gcf,'color','white'); ylim(y_limit); box off
title('Worst 10% of daily returns')
xlabel(['# of scenarios: ',num2str(length(window_10_percent))])
 
subplot(1,3,3)
window_5_percent = ranked_log_return(1:ranked_length*0.05);
plot (window_5_percent, 'o')
ylabel ('Daily log return')
set(gcf,'color','white'); ylim(y_limit); box off
title('Worst 5% of daily returns')
xlabel(['# of scenarios: ',num2str(length(window_5_percent))])
 
figure (index); index = index + 1;
 
probplot(daily_log_return); hold on
title('Probability Plot'); legend('Normal','Data')
 
%% Apply historical scenarios to baseline
P_baseline = SP500_rm_NaN(end);
 
daily_historical_scenarios = daily_log_return;
P_1_day_simulated = P_baseline.*exp(daily_historical_scenarios);
PnL_simulated = P_1_day_simulated - P_baseline;
 
ranked_PnL = sort(PnL_simulated);
 
figure (index); index = index + 1;
subplot(1,3,1)
plot (ranked_PnL, 'o')
ylabel ('Daily PnL')
set(gcf,'color','white')
ranked_length = length (ranked_PnL);
axis tight; box off
xlabel(['# of daily PnL scenarios: ',num2str(length(ranked_PnL))])
y_limit = ylim;
 
subplot(1,3,2)
 
window_10_percent = ranked_PnL(1:ranked_length*0.1);
plot (window_10_percent, 'o')
ylabel ('Daily PnL')
set(gcf,'color','white'); ylim(y_limit); box off
title('Worst 10% of daily PnL')
xlabel(['# of scenarios: ',num2str(length(window_10_percent))])
 
subplot(1,3,3)
window_5_percent = ranked_PnL(1:ranked_length*0.05);
plot (window_5_percent, 'o')
ylabel ('Daily PnL')
set(gcf,'color','white'); ylim(y_limit); box off
title('Worst 5% of daily PnL')
xlabel(['# of scenarios: ',num2str(length(window_5_percent))])
 
%% 95% Historical VaR versus 95% Parametric VaR
% Estimation window is fixed, not rolling
 
figure (index); index = index + 1;
confidence_level = 0.95;
 
computeHistoricalVaR(daily_log_return,confidence_level)
xlim([-0.04,0.04])
xlabel('Daily log return')
set(gcf,'color','white')
 
figure (index); index = index + 1;
 
computeParametricVaR(daily_log_return,confidence_level)
xlim([-0.04,0.04])
xlabel('Daily log return')
set(gcf,'color','white')
 
%% 99% Historical VaR versus 99% Parametric VaR
% Estimation window is fixed, not rolling
 
figure (index); index = index + 1;
confidence_level = 0.99;
 
computeHistoricalVaR(daily_log_return,confidence_level)
xlim([-0.04,0.04])
xlabel('Daily log return')
set(gcf,'color','white')
 
figure (index); index = index + 1;
 
computeParametricVaR(daily_log_return,confidence_level)
xlim([-0.04,0.04])
xlabel('Daily log return')
set(gcf,'color','white')
 
%% Sub-functions
 
function VaR = computeHistoricalVaR(returns,confidence_level)
returns = rmmissing(returns);
% B = A(~isnan(A)) can be used
 
sorted_returns = sort(returns);
num_returns = numel(returns);
VaR_index = ceil((1-confidence_level)*num_returns);
VaR = sorted_returns(VaR_index);
 
% Plot results if requested
[freq,bins] = hist(returns,50);
count_cutoff = freq.*(bins < VaR);
 
bar(bins,freq,'b');
hold on;
bar(bins,count_cutoff,'r');
hold on
plot([VaR,VaR],[0,max(freq)],'--')
 
line1 = [num2str(confidence_level*100),'% VaR: '];
line2 = [num2str(abs(VaR)),' \rightarrow'];
 
text (VaR*1.1, 0.5*max(freq),{line1,line2},'HorizontalAlignment','right')
hold off;
title(['Historical ',num2str(confidence_level*100),'% VaR'],'FontWeight','bold');
ylabel('Number of occurances'); box off
end
 
 
function [VaR, mu, sigma, pdf_full] = computeParametricVaR(returns,confidence_level)
returns = rmmissing(returns);
% B = A(~isnan(A)) can be used
 
[mu,sigma] = normfit(returns);
VaR = -sigma*norminv(confidence_level) + mu;
 
% Plot results if requested
x_min = min(returns);
x_max = max(returns);
x_full = linspace(x_min,x_max,1000);
x_partial = x_full(x_full < VaR);
pdf_full = normpdf(x_full,mu,sigma);
pdf_partial = normpdf(x_partial,mu,sigma);
area(x_full,pdf_full,'FaceColor','w'); hold all
area(x_partial,pdf_partial,'FaceColor','r');
 
[freq,bins] = hist(returns,50); a = bar(bins,freq,'w');
 
plot([VaR,VaR],[0,max(freq)],'--')
 
line1 = [num2str(confidence_level*100),'% VaR: '];
line2 = [num2str(abs(VaR)),' \rightarrow'];
 
text (VaR*1.1, 0.5*max(freq),{line1,line2},...
    'HorizontalAlignment','right')
hold off; set(get(a,'Children'),'FaceAlpha',0.8)
line3 = ['Parametric ',num2str(confidence_level*100),...
    '% VaR'];
line4 = ['Daily mu = ',num2str(mu),'; daily sigma = ',num2str(sigma)];
title({line3,line4},'FontWeight','bold');
ylabel('Number of occurances'); box off
end
