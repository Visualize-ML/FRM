% B2_Ch7_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
J_holding = 5;
% holding period
sigma = 0.0114; % daily
% volatility of daily log returns
% annualized standard deviation at 18.1%, 0.181
 
conf_levels = 0.9:0.005:0.99;
% array of confidence level
mu = 0;
% mean level of underlying log returns
P_baseline = 1e3;
% current value of the portfolio
 
VaR=P_baseline*(sigma*sqrt(J_holding')*...
    norminv(conf_levels,0,1)-...
    mu*J_holding'*ones(size(conf_levels)));
% Normal VaR
 
LogVaR=P_baseline*(1 - exp(mu*J_holding'*...
    ones(size(conf_levels)) - ...
    sigma*sqrt(J_holding')*norminv(conf_levels,0,1)));
% Lognormal VaR
 
figure(1)
plot(conf_levels,VaR); box off
 
xlabel('Confidence level'); ylabel('VaR','rotation',0);
title('VaR versus confidence level')
 
figure(2)
plot(conf_levels,VaR); hold on
plot(conf_levels,LogVaR); box off
 
xlabel('Confidence level'); ylabel('VaR','rotation',0);
legend('Normal VaR','Lognormal VaR')
title('Normal VaR versus lognormal VaR')
