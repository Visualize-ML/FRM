% B2_Ch7_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Duration Approximation
%  Duration-Convexity Approximation
 
clc; clear all; close all
 
coupon_rate = 0.2;
par = 100;
coupon = par*coupon_rate;
CFs = [coupon coupon coupon coupon + par];
 
YTM = [0:0.01:0.4];
current_ytm = coupon_rate;
[D, D_mod] = cfdur(CFs, current_ytm);
 
C = cfconv(CFs, current_ytm);
 
PV_0 = pvvar([0 CFs], current_ytm);
 
delta_YTM = YTM - current_ytm;
 
for i = 1:length(YTM)
    
    ytm = YTM(i);
    
    PV(i) = pvvar([0 CFs], ytm);
    
end
 
PV_1_D_approx = PV_0.*(1 - D_mod.*delta_YTM);
 
figure(1)
 
x = YTM;
curve1 = PV;
curve2 = PV_1_D_approx;
x2 = [x, fliplr(x)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g','LineStyle','none'); hold on
 
plot(YTM, PV,'LineWidth',2); hold on
xlabel('Yield to maturity')
ylabel('Bond price [USD]')
plot(coupon_rate, par, 'o')
 
plot(YTM, PV_1_D_approx,'--','LineWidth',2); hold on
legend('Error','Current','PV vs YTM','Duration approximation')
 
PV_1_D_C_approx = PV_0.*(1 - D_mod.*delta_YTM + 1/2*C.*delta_YTM.^2);
 
figure(2)
 
x = YTM;
curve1 = PV;
curve2 = PV_1_D_C_approx;
x2 = [x, fliplr(x)];
inBetween = [curve1, fliplr(curve2)];
fill(x2, inBetween, 'g','LineStyle','none'); hold on
 
plot(YTM, PV,'LineWidth',2); hold on
xlabel('Yield to maturity')
ylabel('Bond price [USD]')
plot(coupon_rate, par, 'o')
 
plot(YTM, PV_1_D_C_approx,'--','LineWidth',2); hold on
legend('Error','Current','PV vs YTM','Duration-Convexity approximation')
 
 
figure(3)
subplot(1,2,1)
error_D = PV_1_D_approx - PV;
 
delta_YTM = YTM - coupon_rate;
plot(delta_YTM, error_D,'LineWidth',2); hold on
ylim([-30,5])
plot(0, 0, 'o')
xlabel('\Delta y')
ylabel('Error [USD]')
title('Duration approx.')
set(gca, 'XAxisLocation', 'origin')
 
subplot(1,2,2)
error_D_C = PV_1_D_C_approx - PV;
plot(delta_YTM, error_D_C,'LineWidth',2); hold on
ylim([-30,5])
plot(0, 0, 'o')
xlabel('\Delta y')
ylabel('Error [USD]')
title('Duration-convexity approx.')
set(gca, 'XAxisLocation', 'origin')
