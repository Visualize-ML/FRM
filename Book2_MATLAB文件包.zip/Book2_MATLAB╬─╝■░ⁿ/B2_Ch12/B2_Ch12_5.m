% B2_Ch12_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch12_5_A.m
clc; clear all; close all;
 
% Load historical data
filename = 'hist_data.csv';
 
data = readtable(filename, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false);

summary(data)


%% B2_Ch12_5_B.m
% Calculate LGD and its transformations
% Recovery rates have be capped and floored in the range
% [0.00001, 0.99999]
data.Y1 = 1-data.RecoveryRate;
 
% Logistic transformation of LGD
data.Y2 = log(data.Y1./(1-data.Y1));
 
% Probit transformation of LGD
data.Y3 = norminv(data.Y1);
 
% Natural logarithm of recovery rate
data.Y4 = log(1-data.Y1);
 
% Plot
figure
xlabels = {'Y1','Y2','Y3','Y4'};
bins = 25;
titles = ...
    {'Original LGD', 'Logistic transformation of LGD',...
    'Probit transformation of LGD',...
    'Natural logarithm of 1-LGD'};
 
for i=1:4
    
    subplot(2,2,i)
    hist(table2array(data(:, xlabels(i))), bins)
    xlabel(xlabels(i))
    title(titles(i))
end


%% B2_Ch12_5_C.m
% Fit into regression model
mdl1 = fitlm(data, 'Y1 ~ LTV + Purpose')
 
mdl2 = fitlm(data, 'Y2 ~ LTV + Purpose')
 
mdl3 = fitlm(data, 'Y3 ~ LTV + Purpose')
 
mdl4 = fitlm(data, 'Y4 ~ LTV + Purpose')

