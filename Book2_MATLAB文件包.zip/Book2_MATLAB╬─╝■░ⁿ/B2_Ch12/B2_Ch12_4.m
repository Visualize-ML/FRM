% B2_Ch12_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch12_4_A.m
clc; clear all; close all;
 
% Load portfolio data
load CreditPortfolioData.mat
whos EAD PD LGD Weights2F FactorCorr2F


%% B2_Ch12_4_B.m
% Creat creditDefaultCopula object
rng('default');

cdcobj = creditDefaultCopula(EAD,PD,LGD,Weights2F, ...
    'FactorCorrelation',FactorCorr2F,...
    'VaRLevel', 0.95);
 
disp(Weights2F(1:5,:))
disp(FactorCorr2F)


%% B2_Ch12_4_C.m
% Change the VaR level to 99.5%.
cdcobj.VaRLevel = 0.995;


%% B2_Ch12_4_D.m
% View creditDefaultCopula object
disp(cdcobj)

cdcobj.Portfolio(1:5,:)


%% B2_Ch12_4_E.m
% Run simulation
numSteps = 1e5;
cdcobj = simulate(cdcobj, numSteps);
 
[pr,pr_ci] = portfolioRisk(cdcobj);
 
% Display risk measures
fprintf('Portfolio risk measures:\n');
disp(pr)
 
fprintf('\n\nConfidence intervals for the risk measures:\n');
disp(pr_ci) 


%% B2_Ch12_4_F.m
% Plot portfolio loss
figure
histogram(cdcobj.PortfolioLosses)
title('Portfolio Losses');
xlabel('Losses ($)')
ylabel('Frequency')
hold on
 
% Overlay the risk measures on the histogram.
xlim([0 1.1 * pr.CVaR])
plotline = @(x,color) plot([x x],ylim,'LineWidth',2,'Color',color);
plotline(pr.EL,'b');
plotline(pr.VaR,'r');
cvarline = plotline(pr.CVaR,'m');
 
% Shade the areas of expected loss and economic capital.
plotband = @(x,color) patch([x fliplr(x)],[0 0 repmat(max(ylim),1,2)],...
    color,'FaceAlpha',0.15);
elband = plotband([0 pr.EL],'blue');
ulband = plotband([pr.EL pr.VaR],'red');
legend([elband,ulband,cvarline],...
    {'Expected Loss','Economic Capital','CVaR (99.5%)'},...
    'Location','north');


%% B2_Ch12_4_J.m
% Compare Gaussian and t copulas
cdcobj_t = simulate(cdcobj,numSteps,'Copula','t');

pr_t = portfolioRisk(cdcobj_t);
 
fprintf('Portfolio risk with Gaussian copula:\n');
disp(pr)
 
fprintf('\n\nPortfolio risk with t copula (dof = 5):\n');
disp(pr_t)
 
% Plot the Gaussian copula tail.
figure;
subplot(2,1,1)
p1 = histogram(cdcobj.PortfolioLosses);
hold on
plotline(pr.VaR,[1 0.5 0.5])
plotline(pr.CVaR,[1 0 0])
xlim([0.8 * pr.VaR  1.2 * pr_t.CVaR]);
ylim([0 1000]);
grid on
legend('Loss Distribution','VaR','CVaR')
title('Portfolio Losses with Gaussian Copula');
xlabel('Losses ($)');
ylabel('Frequency');
 
% Plot the t copula tail.
subplot(2,1,2)
p2 = histogram(cdcobj_t.PortfolioLosses);
hold on
plotline(pr_t.VaR,[1 0.5 0.5])
plotline(pr_t.CVaR,[1 0 0])
xlim([0.8 * pr.VaR  1.2 * pr_t.CVaR]);
ylim([0 1000]);
grid on
legend('Loss Distribution','VaR','CVaR');
title('Portfolio Losses with t Copula (dof = 5)');
xlabel('Losses ($)');
ylabel('Frequency'); 


%% B2_Ch12_4_H.m
% Specifiy t-copula degree of freedom
cdcobj_t = simulate(cdcobj,numSteps,'Copula','t',...
'DegreesOfFreedom', 7);


