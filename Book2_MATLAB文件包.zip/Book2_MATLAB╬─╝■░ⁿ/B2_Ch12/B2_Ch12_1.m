% B2_Ch12_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch12_1.m
clc; clear all; close all;
 
% Time to maturity
T = 0.5:0.5:5;
% Risk-free spot rate
r = [3.57,3.7,3.81,3.95,4.06,4.16,4.24,4.33,4.42,4.45];
r = r*0.01;
 
% Bond yield
y = [3.67,3.82,3.94,4.10,4.22,4.32,4.44,4.53,4.64,4.67];
y = y*0.01;
 
% Credit spread
s = y-r;

% Recovery rate
R = 0.4;
 
% Cumulative risk-neutral default probability
cpd=(1-exp(-s.*T))./(1-R);
 
% Annualized cumulative risk-neutral default probability
cpd_annual = 1-(1-cpd).^(1./T);
 
% Summary table
results = table(T',r',y',s',cpd',cpd_annual');
results.Properties.VariableNames = ...
    {'Time_to_Maturity','RiskFree_Spot_Rate', ...
    'Bond_Yield','Credit_Spread',...
    'Cumulative_RiskNeutral_PD',...
    'Annual_RiskNeutral_PD'};
disp(results)


