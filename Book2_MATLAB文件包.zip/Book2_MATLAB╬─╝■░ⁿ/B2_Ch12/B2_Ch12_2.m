% B2_Ch12_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch12_2_A.m
clc; clear all; close all;
 
% Input market info
Settle = datenum('08-Jul-2018');
 
MarketDate = datenum({'06/15/2020', '01/08/2021', ...
    '02/01/2023', '03/18/2023', '08/04/2028'}','mm/dd/yyyy');
 
CouponRate = [2.240 2.943 5.750 3.336 4.134]'/100;
MarketPrice = [101.300 103.020 115.423 104.683 108.642]';
MarketData = [MarketDate,MarketPrice,CouponRate];
 

%% B2_Ch12_2_B.m
% Get zero rates using IRDataCurve object
CurveSettle = Settle;

CurveDates = datemnth(CurveSettle, ...
    [[1 3 6], 12 * [1 2 3 5 7 10 20 30]]');

Data = [0.25 0.28 0.37 0.48 0.62 0.71 ...
    0.93 1.18 1.35 1.68 2.12]'/100;
 
irdc = IRDataCurve('Zero',CurveSettle, CurveDates, Data);
 
ZeroRates = getZeroRates(irdc, CurveDates);


%% B2_Ch12_2_C.m
% Bootstrap
ZeroData = [CurveDates, ZeroRates];

format long

[ProbabilityData,HazardData] = ...
    bondDefaultBootstrap(ZeroData,MarketData,Settle);
 
Date = ...
    datetime(ProbabilityData(:,1), 'ConvertFrom', 'datenum');
 
PD = ProbabilityData(:,2);
 
Hazard = HazardData(:,2);
 
results = table(Date, PD, Hazard)


%% B2_Ch12_2_D.m
[ProbabilityData,HazardData] = ...
    bondDefaultBootstrap(ZeroData,MarketData,Settle, ...
    'RecoveryRate', 0.4, 'Face', 100, 'Period', 2);

