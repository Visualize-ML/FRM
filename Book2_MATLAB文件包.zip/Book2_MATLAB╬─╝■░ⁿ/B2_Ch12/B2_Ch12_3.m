% B2_Ch12_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch12_3.m
clc; clear all; close all;
 
% Input market info of CDS
Settle = datenum('17-Jul-2018');
 
Spread_Time = [1 2 3 5 7]';
Market_Dates = daysadd(datenum(Settle),360*Spread_Time,1);
Spread = [136 165 202 275 313]';
 
MarketData = [Market_Dates Spread];
 
% Interest rate info
Zero_Time = [.5 1 2 3 4 5]';
Zero_Dates = daysadd(datenum(Settle),360*Zero_Time,1);
Zero_Rate = [1.35 1.43 1.9 2.47 2.936 3.311]'/100;
 
ZeroData = [Zero_Dates Zero_Rate];
 
% Bootstrap
format long
[ProbabilityData, HazardData] = cdsbootstrap(ZeroData,MarketData,Settle);
 
Date = ...
    datetime(ProbabilityData(:,1), 'ConvertFrom', 'datenum');
 
PD = ProbabilityData(:,2);
 
Hazard = HazardData(:,2);
 
results = table(Date, PD, Hazard)

