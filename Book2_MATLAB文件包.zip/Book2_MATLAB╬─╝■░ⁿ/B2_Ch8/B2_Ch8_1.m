% B2_Ch8_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
series = 'SP500';
startdate = '01/01/2009';
% beginning of date range for historical data
enddate = now; % to be updated
% ending of date range for historical data
 
d = fetch(c,series,startdate,enddate)
% display description of data structure
 
index = 1;
 
SP500 = d.Data(:,2);
date_series = d.Data(:,1);
[daily_log_return,interval] = tick2ret (SP500, date_series,'Continuous');

%% Parametric daily VaR: 95% and 99%
% Percentage VaR and Dollar VaR
% Estimation window: 250 business days
% Rolling window
 
daily_log_return_no_NaN = daily_log_return;
daily_log_return_no_NaN(isnan(daily_log_return_no_NaN))=0;
 
DateReturns = date_series(2:end);
SampleSize = length(daily_log_return);
 
EstimationWindowSize = 250;
TestWindowStart      = find(year(DateReturns)==year(now) - 10,1)+EstimationWindowSize ;
TestWindow           = TestWindowStart : SampleSize;
 
conf_levels = [0.05 0.01];
 
Zscore   = norminv(conf_levels);
Normal95 = zeros(length(TestWindow),1);
Normal99 = zeros(length(TestWindow),1);
 
for t = TestWindow
    i = t - TestWindowStart + 1;
    EstimationWindow = t-EstimationWindowSize:t-1;
    Sigma = nanstd(daily_log_return(EstimationWindow));
    Normal95(i) = -Zscore(1)*Sigma;
    Normal99(i) = -Zscore(2)*Sigma;
end
 
%%
figure (index)
index = index + 1;
 
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
 
subplot(2,1,2)
plot(DateReturns(TestWindow),[Normal95*100 Normal99*100])
xlabel('Year')
ylabel('Daily VaR [%]')
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
title('Moving daily parametric VaR')
datetick('x','yyyy','keeplimits')
ylim([0,max(Normal99*100)*1.1])
xlim([date_series(250),date_series(end)])
set(gcf,'color','white')
 
%% Historical daily VaR: 95% and 99%
% Estimation window: 250 business days
% Rolling window
 
Historical95 = zeros(length(TestWindow),1);
Historical99 = zeros(length(TestWindow),1);
 
for t = TestWindow
    i = t - TestWindowStart + 1;
    EstimationWindow = t-EstimationWindowSize:t-1;
    X = daily_log_return(EstimationWindow);
    Historical95(i) = -quantile(X,conf_levels(1));
    Historical99(i) = -quantile(X,conf_levels(2));
end
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
 
subplot(2,1,2)
plot(DateReturns(TestWindow),[Historical95*100 Historical99*100])
ylabel('VaR [%]')
xlabel('Year')
ylabel('Daily VaR [%]')
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
ylim([0,max(Historical99*100)*1.1])
set(gcf,'color','white')
title('Moving daily historical VaR')
 
%%
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),[Normal95*100 Historical95*100])
xlabel('Year')
ylabel('Daily 95% VaR [%]')
legend({'Parametric','Historical'},'Location','Best')
datetick('x','yyyy','keeplimits')
ylim([0,max(Historical95*100)*1.1])
xlim([date_series(250),date_series(end)])
set(gcf,'color','white')
title('Rolling estimation window = 250 business days')
 
 
subplot(2,1,2)
plot(DateReturns(TestWindow),[Normal99*100 Historical99*100])
xlabel('Year')
ylabel('Daily 99% VaR [%]')
legend({'Parametric','Historical'},'Location','Best')
datetick('x','yyyy','keeplimits')
ylim([0,max(Historical99*100)*1.1])
xlim([date_series(250),date_series(end)])
set(gcf,'color','white')
 
%% Parametric weekly VaR: 95% and 99%
% Rolling estimation window = 250 days
% Rule of square root
 
figure (index)
index = index + 1;
 
holding_J = 5; % unit: days
plot(DateReturns(TestWindow),[Normal95*100*sqrt(holding_J) ...
    Normal99*100*sqrt(holding_J)])
xlabel('Year')
ylabel('Weekly VaR [%]')
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
title('Moving weekly parametric VaR using square root')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
ylim([0,max(Normal99*100)*1.1*sqrt(5)])
set(gcf,'color','white')
 
%% VaR calculation using EWMA
 
EWMA95 = [];
EWMA99 = [];
 
conf_levels = [0.05 0.01];
Zscore = norminv(conf_levels);
 
decay_depth = [EstimationWindowSize-1:-1:0]';
WEIGHTs = [];
LAMBDAs = [1,0.99,0.94,0.9];
WEIGHTs = ones(length(EstimationWindow),1);
 
figure (index)
index = index + 1;
title('EWMA daily parametric VaR')
for jj = 1:length(LAMBDAs)
    
    lambda = LAMBDAs(jj);
    
    if lambda == 1
        WEIGHTs = WEIGHTs./EstimationWindowSize;
        
    else
        WEIGHTs = (1 - lambda)/(1 - lambda^EstimationWindowSize).*lambda.^decay_depth;
        
    end
    
    for t = TestWindow
        i = t - TestWindowStart + 1;
        EstimationWindow = t-EstimationWindowSize:t-1;
        X = daily_log_return_no_NaN(EstimationWindow);
        XX = X.*X;
        Sigma2 = sum(WEIGHTs.*XX);
        Sigma = sqrt(Sigma2);
        EWMA95(i,jj) = -Zscore(1)*Sigma;
        EWMA99(i,jj) = -Zscore(2)*Sigma;
        
    end
    
    ax = subplot(4,1,jj);
    plot(DateReturns(TestWindow),[EWMA95(:,jj)*100 EWMA99(:,jj)*100])
    ylabel('VaR [%]')
    xlabel(['Year; EWMA \lambda = ',num2str(lambda)])
    datetick('x','yyyy','keeplimits')
    xlim(ax,[date_series(250),date_series(end)])
    ylim(ax,[0, 8])
    
    set(gcf,'color','white')
    
end
 
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
 
figure (index)
index = index + 1;
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
 
subplot(2,1,2)
plot(DateReturns(TestWindow),EWMA95(:,1:3)*100)
ylabel('Daily EWMA VaR [%]')
xlabel('Year')
legend({['\lambda = ',num2str(LAMBDAs(1))],...
    ['\lambda = ',num2str(LAMBDAs(2))],...
    ['\lambda = ',num2str(LAMBDAs(3))]},'Location','Best')
 
xlabel('Year')
datetick('x','yyyy','keeplimits')
set(gcf,'color','white')
xlim([date_series(250),date_series(end)])
title('EWMA moving 95% daily VaR')

% B2_Ch8_1_B.m

J_holding = 1:60; 
% holding period
sigma = 0.1;   
% volatility of underlying log returns
conf_levels = 0.95; 
% array of confidence level
mu = 0;
% mean level of underlying log returns
P = 1e6; % current value of the portfolio
 
VaR=P*(-sigma*sqrt(J_holding')*norminv(1-conf_levels,0,1)...
    -mu*J_holding'*ones(size(conf_levels)))/1e6; % Normal VaR 
 
ES=P*(sigma*sqrt(J_holding')*normpdf(norminv(conf_levels,0,1))./(1-conf_levels)...
    -mu*J_holding'*ones(size(conf_levels)))/1e6; % Normal ES
 
figure (index)
index = index + 1;
 
plot(J_holding,ES,'r'); hold on
plot(J_holding,VaR,'b'); box off
legend('ES','VaR')
 
xlabel('Holding period [days]');
xlim([min(J_holding) max(J_holding)])
ylabel('Risk measure [MM]','rotation',0);
title('Risk measure versus confidence level')


% B2_Ch8_1_C.m

%% Risk measures: VaR vs ES 95% and 99%
 
CONF_LEVELS = [0.95, 0.99];
 
for kk = 1:length(CONF_LEVELS)
    confidence_level = CONF_LEVELS(kk);
    NN = length(daily_log_return_no_NaN);
    
    for i = 1:NN-251
        
        % Get standard deviation of that change
        [Historical_VaR,Historical_ES] = hHistoricalVaRES(daily_log_return_no_NaN(i:i + 249),confidence_level);
        [Parametric_VaR,Parametric_ES,EWMA_VaR,EWMA_ES] = hNormalVaRES(daily_log_return_no_NaN(i:i + 249),confidence_level);
        
        % Now normalize to annual volatility
        Historical_ES_series(i) = Historical_ES;
        Parametric_ES_series(i) = Parametric_ES;
        EWMA_ES_series(i) = EWMA_ES;
        
        Historical_VaR_series(i) = Historical_VaR;
        Parametric_VaR_series(i) = Parametric_VaR;
        EWMA_VaR_series(i) = EWMA_VaR;
    end
    
    
    figure (index)
    index = index + 1;
    
    plot (date_series(253:end),Historical_ES_series*100); hold on
    plot (date_series(253:end),Parametric_ES_series*100); hold on
    plot (date_series(253:end),EWMA_ES_series*100); hold on
    
    datetick('x','yyyy','keeplimits')
    xlim([date_series(250),date_series(end)])
    ylim([0,max(max(EWMA_ES_series,EWMA_VaR_series))*110])
    xlabel('Year')
    ylabel('Risk measure [%]')
    title(['Confidence level: ',num2str(confidence_level*100),'%'])
    set(gcf,'color','white')
    legend('Historical ES','Parametric ES', 'EWMA ES')
    
    figure (index)
    index = index + 1;
    
    plot (date_series(253:end),Historical_VaR_series*100); hold on
    plot (date_series(253:end),Parametric_VaR_series*100); hold on
    plot (date_series(253:end),EWMA_VaR_series*100); hold on
    
    datetick('x','yyyy','keeplimits')
    xlim([date_series(250),date_series(end)])
    ylim([0,max(max(EWMA_ES_series,EWMA_VaR_series))*110])
    xlabel('Year')
    ylabel('Risk measure [%]')
    title(['Confidence level: ',num2str(confidence_level*100),'%'])
    set(gcf,'color','white')
    legend('Historical VaR','Parametric VaR','EWMA VaR')
end

% B2_Ch8_1_D.m

%% Analysis before aged-weighted historical VaR
 
figure (index)
index = index + 1;
 
subplot(1,2,1)
probplot(daily_log_return_no_NaN); hold on
title('Probability Plot')
legend('Normal','Data')
 
subplot(1,2,2)
lambda = 0.94;
total_length = length(daily_log_return_no_NaN);
decay_depth = [total_length-1:-1:0]';
Age_weighted_PROB = (1 - lambda)/(1 - lambda^total_length).*lambda.^decay_depth;
FREQ = round(Age_weighted_PROB*total_length);
xlim([date_series(250),date_series(end)])
probplot(daily_log_return_no_NaN, [], FREQ);
title('Age-weighted probability Plot')
legend('Normal','Data')
 
figure (index)
index = index + 1;
subplot(2,1,1)
plot(DateReturns,daily_log_return_no_NaN);
ylabel('Daily log return')
datetick('x','yyyy','keeplimits')
xlabel('Year')
xlim([date_series(250),date_series(end)])
 
subplot(2,1,2)
 
plot(DateReturns,Age_weighted_PROB);
ylabel('Probability')
datetick('x','yyyy','keeplimits')
xlabel('Year')
xlim([date_series(250),date_series(end)])
%% Age-weighted Historical VaR
% EWMA historical VaR
% Hybrid VaR
 
decay_depth = [EstimationWindowSize-1:-1:0]';
WEIGHTs = [];
LAMBDAs = [1,0.99,0.94,0.9];
WEIGHTs = ones(length(EstimationWindow),1);
conf_levels = [0.05 0.01];
 
figure (index)
index = index + 1;
title('EWMA daily parametric VaR')
for jj = 1:length(LAMBDAs)
    
    lambda = LAMBDAs(jj);
    
    if lambda == 1
        WEIGHTs = WEIGHTs./EstimationWindowSize;
        
    else
        WEIGHTs = (1 - lambda)/(1 - lambda^EstimationWindowSize).*lambda.^decay_depth;
        
    end
    
    FREQ = WEIGHTs;
    
    for t = TestWindow
        i = t - TestWindowStart + 1;
        EstimationWindow = t-EstimationWindowSize:t-1;
        X = daily_log_return_no_NaN(EstimationWindow);
        [cdf,data] = ecdf(X,'freq',FREQ);
        xq = conf_levels(1);
        Hybrid_VaR95(i,jj) = -interp1(cdf,data,xq);
        xq = conf_levels(2);
        Hybrid_VaR99(i,jj) = -interp1(cdf,data,xq);
        
    end
    
    subplot(4,1,jj)
    plot(DateReturns(TestWindow),[Hybrid_VaR95(:,jj)*100 Hybrid_VaR99(:,jj)*100])
    ylabel('VaR [%]')
    xlabel(['Year; EWMA \lambda = ',num2str(lambda)])
    datetick('x','yyyy','keeplimits')
    xlim([date_series(250),date_series(end)])
    set(gcf,'color','white')
    ylim([0 max(max(Hybrid_VaR99*100))])
    
end
 
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
subplot(2,1,2)
plot(DateReturns(TestWindow),Hybrid_VaR95(:,1:3)*100)
ylabel('VaR [%]')
xlabel('Year')
legend({['\lambda = ',num2str(LAMBDAs(1))],...
    ['\lambda = ',num2str(LAMBDAs(2))],...
    ['\lambda = ',num2str(LAMBDAs(3))]},'Location','Best')
 
xlabel('Year')
datetick('x','yyyy','keeplimits')
set(gcf,'color','white')
xlim([date_series(250),date_series(end)])
title('Aged-weighted historical 95% daily VaR')
 
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
subplot(2,1,2)
plot(DateReturns(TestWindow),Hybrid_VaR99(:,1:3)*100)
ylabel('VaR [%]')
xlabel('Year')
legend({['\lambda = ',num2str(LAMBDAs(1))],...
    ['\lambda = ',num2str(LAMBDAs(2))],...
    ['\lambda = ',num2str(LAMBDAs(3))]},'Location','Best')
 
xlabel('Year')
datetick('x','yyyy','keeplimits')
set(gcf,'color','white')
xlim([date_series(250),date_series(end)])
title('Aged-weighted historical 99% daily VaR')

% B2_Ch8_1_E.m

%% Benson-Zangari MC VaR
% Using Monte Carlo simulation method
% Proposed by MSCI RiskMetrics RiskManager
 
decay_depth = [EstimationWindowSize-1:-1:0]';
WEIGHTs = [];
LAMBDAs = [1,0.99,0.94,0.9];
WEIGHTs = ones(length(EstimationWindow),1);
pVaR = [0.05 0.01];
num_sim = 5000; % number of MC simulations
 
figure (index)
index = index + 1;
title('EWMA daily parametric VaR')
for jj = 1:length(LAMBDAs)
    
    lambda = LAMBDAs(jj);
    
    if lambda == 1
        WEIGHTs = sqrt(WEIGHTs./EstimationWindowSize);
        
    else
        WEIGHTs = sqrt((1 - lambda)/(1 - lambda^EstimationWindowSize).*lambda.^decay_depth);
        
    end
    
    
    for t = TestWindow
        i = t - TestWindowStart + 1;
        EstimationWindow = t-EstimationWindowSize:t-1;
        X = daily_log_return_no_NaN(EstimationWindow);
        
        RR = WEIGHTs.*X;
        ZZ = randn(EstimationWindowSize,num_sim);
        YY = RR'*ZZ; 
        % obtain num_sim simulated daily log return
        % sort using historical method
        
        MC_VaR95(i,jj) = -quantile(YY,pVaR(1));
        MC_VaR99(i,jj) = -quantile(YY,pVaR(2));
        
    end
    
    subplot(4,1,jj)
    plot(DateReturns(TestWindow),[MC_VaR95(:,jj)*100 MC_VaR99(:,jj)*100])
    ylabel('VaR [%]')
    xlabel(['Year; EWMA \lambda = ',num2str(lambda)])
    datetick('x','yyyy','keeplimits')
    xlim([date_series(250),date_series(end)])
    set(gcf,'color','white')
    ylim([0 max(max(MC_VaR99*100))])
    
end
 
legend({'95% Confidence Level','99% Confidence Level'},'Location','Best')
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
subplot(2,1,2)
plot(DateReturns(TestWindow),MC_VaR95(:,1:3)*100)
ylabel('VaR [%]')
xlabel('Year')
legend({['\lambda = ',num2str(LAMBDAs(1))],...
    ['\lambda = ',num2str(LAMBDAs(2))],...
    ['\lambda = ',num2str(LAMBDAs(3))]},'Location','Best')
 
xlabel('Year')
datetick('x','yyyy','keeplimits')
set(gcf,'color','white')
xlim([date_series(250),date_series(end)])
title('Benson-Zangari MC 95% daily VaR')
 
 
figure (index)
index = index + 1;
 
subplot(2,1,1)
plot(DateReturns(TestWindow),daily_log_return_no_NaN(TestWindow).^2)
ylabel('Daily log return squared')
xlabel('Year')
datetick('x','yyyy','keeplimits')
xlim([date_series(250),date_series(end)])
 
subplot(2,1,2)
plot(DateReturns(TestWindow),MC_VaR99(:,1:3)*100)
ylabel('VaR [%]')
xlabel('Year')
legend({['\lambda = ',num2str(LAMBDAs(1))],...
    ['\lambda = ',num2str(LAMBDAs(2))],...
    ['\lambda = ',num2str(LAMBDAs(3))]},'Location','Best')
 
xlabel('Year')
datetick('x','yyyy','keeplimits')
set(gcf,'color','white')
xlim([date_series(250),date_series(end)])
title('Benson-Zangari MC 99% daily VaR')

% B2_Ch8_1_F.m

%% Sub-functions

function [VaR,ES] = hHistoricalVaRES(Sample,VaRLevel)
 
% Convert to losses
Sample = -Sample;
 
N = length(Sample);
k = ceil(N*VaRLevel);
 
z = sort(Sample);
 
VaR = z(k);
 
if k < N
    ES = ((k - N*VaRLevel)*z(k) + sum(z(k+1:N)))/...
     (N*(1 - VaRLevel));
else
    ES = z(k);
end
end
 
function [VaR,ES,EWMA_VaR,EWMA_ES] = hNormalVaRES(Sample,VaRLevel)
 
Sample(isnan(Sample))=0;
 
Miu = nanmean(Sample);
Sigma = nanstd(Sample);
 
VaR = -1*(Miu-Sigma*norminv(VaRLevel));
ES = -1*(Miu-Sigma*normpdf(norminv(VaRLevel))./(1-VaRLevel));
 
Sample_Size = length(Sample);
 
lambda = 0.94; % default value, industry recommended
decay_depth = [Sample_Size-1:-1:0]';
WEIGHTs = (1 - lambda)/(1 - lambda^Sample_Size).*...
lambda.^decay_depth;
XX = Sample.^2;
Sigma2 = sum(WEIGHTs.*XX);
EWMA_Sigma = sqrt(Sigma2);
 
EWMA_Mu = nanmean(Sample); 
% uniformally weighted average;
% Exponentially weighted average (EWA) can be used as well
 
EWMA_VaR = -1*(EWMA_Mu-EWMA_Sigma*norminv(VaRLevel));
EWMA_ES = -1*(EWMA_Mu-EWMA_Sigma*normpdf(norminv(VaRLevel))./...
(1-VaRLevel));
 
end
