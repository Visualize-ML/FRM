% B2_Ch8_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Download S&P 500 data
clc; close all; clear all
 
% price = hist_stock_data('01012010','05302020','^gspc'); 
price = hist_stock_data('01012010','05302020','AAPL'); 
%returns the data sorted from the newest date to the oldest date
 
index = 1;
 
modified_date = datenum(price.Date,'yyyy-mm-dd'); 
% How to use https://www.mathworks.com/help/matlab/ref/datenum.html
 
[daily_log_return,~] = tick2ret (price.Close, modified_date,'Continuous');
 
[daily_simple_return,~] = tick2ret (price.Close, modified_date,'Simple');
 
DateReturns = modified_date(2:end);
SampleSize = length(daily_log_return);
 
TestWindowStart      = find(year(DateReturns)==2011,1);
TestWindow           = TestWindowStart : SampleSize;
EstimationWindowSize = 250;
 
conf_levels = [0.05 0.01];
 
Zscore   = norminv(conf_levels);
Normal95 = zeros(length(TestWindow),1);
Normal99 = zeros(length(TestWindow),1);
 
for t = TestWindow
    i = t - TestWindowStart + 1;
    EstimationWindow = t-EstimationWindowSize:t-1;
    Sigma = std(daily_log_return(EstimationWindow)); % window is one year long
    Normal95(i) = -Zscore(1)*Sigma;
    Normal99(i) = -Zscore(2)*Sigma;
end
 
%% Historical Conditional daily VaR: 95% and 99%
 
Historical95 = zeros(length(TestWindow),1);
Historical99 = zeros(length(TestWindow),1);
 
for t = TestWindow
    i = t - TestWindowStart + 1;
    EstimationWindow = t-EstimationWindowSize:t-1;
    X = daily_log_return(EstimationWindow);
    Historical95(i) = -quantile(X,conf_levels(1));
    Historical99(i) = -quantile(X,conf_levels(2));
end
 
 
%% VaR calculation using EWMA
 
lambda = 0.94;
Sigma2     = zeros(length(daily_log_return),1);
Sigma2(1)  = daily_log_return(1)^2;
 
for i = 2 : (TestWindowStart-1)
    Sigma2(i) = (1-lambda) * daily_log_return(i-1)^2 + lambda * Sigma2(i-1);
end
% Use the EWMA in the test window to estimate the VaR.
 
Zscore = norminv(conf_levels);
EWMA95 = zeros(length(TestWindow),1);
EWMA99 = zeros(length(TestWindow),1);
 
for t = TestWindow
    k     = t - TestWindowStart + 1;
    Sigma2(t) = (1-lambda) * daily_log_return(t-1)^2 + lambda * Sigma2(t-1);
    Sigma = sqrt(Sigma2(t));
    EWMA95(k) = -Zscore(1)*Sigma;
    EWMA99(k) = -Zscore(2)*Sigma;
end
 
 
%% VaR Backtesting
 
ReturnsTest = daily_log_return(TestWindow);
DatesTest   = DateReturns(TestWindow);
figure(1)
plot(DatesTest,ReturnsTest*100,'.'); hold on
plot(DatesTest,[-Normal95*100 -Historical95*100 -EWMA95*100]); hold on
plot(DatesTest,zeros(size(DatesTest)),'g')
 
legend({'Returns','Normal','Historical','EWMA'},'Location','Best')
ylabel('1-day 95% VaR (%)')
xlabel('Year'); box off; grid off
 
datetick('x','yyyy','keeplimits')
xlim([modified_date(250),modified_date(end)])
ylim([-10 10]); set(gcf,'color','white')
 
ReturnsTest = daily_log_return(TestWindow);
DatesTest   = DateReturns(TestWindow);
 
figure(2)
plot(DatesTest,ReturnsTest*100,'.'); hold on
plot(DatesTest,[-Normal99*100 -Historical99*100 -EWMA99*100]); hold on
plot(DatesTest,zeros(size(DatesTest)),'g')
 
legend({'Returns','Normal','Historical','EWMA'},'Location','Best')
ylabel('1-day 99% VaR (%)')
xlabel('Year'); box off; grid off
 
datetick('x','yyyy','keeplimits')
xlim([modified_date(250),modified_date(end)])
ylim([-10 10]); set(gcf,'color','white')
 
%% VaR Back Testing, 95%, Zoomed in
 
ZoomInd   = (DatesTest >= datenum('2018-01-01','yyyy-mm-dd')) ...
    & (DatesTest <= datenum('2018-12-31','yyyy-mm-dd'));
VaRData   = [-Normal95(ZoomInd) -Historical95(ZoomInd) -EWMA95(ZoomInd)];
Date_zoomIn = DatesTest(ZoomInd);
Return_zoomIn = ReturnsTest(ZoomInd);
N_zoomIn = Normal95(ZoomInd);
H_zoomIn = Historical95(ZoomInd);
EWMA_zoomIn = EWMA95(ZoomInd);
 
IndN95    = (Return_zoomIn < -N_zoomIn);
IndHS95   = (Return_zoomIn < -H_zoomIn);
IndEWMA95 = (Return_zoomIn < -EWMA_zoomIn);
 
figure (3)
 
bar(Date_zoomIn,Return_zoomIn*100,0.5,'FaceColor',[0.7 0.7 0.7]);
colors = {'r','b','g'}
hold on
for i = 1 : size(VaRData,2)
    stairs(Date_zoomIn-0.5,VaRData(:,i)*100,colors{i});
end
 
plot(Date_zoomIn(IndN95),-N_zoomIn(IndN95)*100,'rx',...
    Date_zoomIn(IndHS95),-H_zoomIn(IndHS95)*100,'bx',...
   Date_zoomIn(IndEWMA95),-EWMA_zoomIn(IndEWMA95)*100,...
   'gx','MarkerSize',8,'LineWidth',1.5)
 
legend({'Returns','Normal','Historical','EWMA',...
    [num2str(sum(IndN95)),' violations'],...
    [num2str(sum(IndHS95)),' violations'],...
    [num2str(sum(IndEWMA95)),' violations']},'Location','Best')
xlim([Date_zoomIn(1)-1, Date_zoomIn(end)+1])
hold off; xlabel('Year'); box off
datetick('x','mmm dd, yyyy'); set(gcf,'color','white')
ylabel('VaR (%)'); xlabel('Date')
title('95% VaR violations for different models')
ax = gca; ax.ColorOrderIndex = 1;
 
%% VaR Back Testing, 99%, Zoomed in
 
ZoomInd   = (DatesTest >= datenum('2018-01-01','yyyy-mm-dd')) ...
    & (DatesTest <= datenum('2018-12-31','yyyy-mm-dd'));
VaRData   = [-Normal99(ZoomInd) -Historical99(ZoomInd) -EWMA99(ZoomInd)];
Date_zoomIn = DatesTest(ZoomInd);
Return_zoomIn = ReturnsTest(ZoomInd);
N_zoomIn = Normal99(ZoomInd);
H_zoomIn = Historical99(ZoomInd);
EWMA_zoomIn = EWMA99(ZoomInd);
 
IndN99    = (Return_zoomIn < -N_zoomIn);
IndHS99   = (Return_zoomIn < -H_zoomIn);
IndEWMA99 = (Return_zoomIn < -EWMA_zoomIn);
 
figure (4)
 
bar(Date_zoomIn,Return_zoomIn*100,0.5,'FaceColor',[0.7 0.7 0.7]);
colors = {'r','b','g'}
hold on
for i = 1 : size(VaRData,2)
    stairs(Date_zoomIn-0.5,VaRData(:,i)*100,colors{i});
end
 
plot(Date_zoomIn(IndN99),-N_zoomIn(IndN99)*100,'rx',...
    Date_zoomIn(IndHS99),-H_zoomIn(IndHS99)*100,'bx',...
   Date_zoomIn(IndEWMA99),-EWMA_zoomIn(IndEWMA99)*100,...
   'gx','MarkerSize',8,'LineWidth',1.5)
 
legend({'Returns','Normal','Historical','EWMA',...
    [num2str(sum(IndN99)),' violations'],...
    [num2str(sum(IndHS99)),' violations'],...
    [num2str(sum(IndEWMA99)),' violations']},'Location','Best')
xlim([Date_zoomIn(1)-1, Date_zoomIn(end)+1])
hold off; xlabel('Year'); box off
datetick('x','mmm dd, yyyy'); set(gcf,'color','white')
ylabel('VaR (%)'); xlabel('Date')
title('99% VaR violations for different models')
ax = gca; ax.ColorOrderIndex = 1;
