% B2_Ch6_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
S0 = 50;
N_steps = 100;
mu = 0.05;
sigma = 0.5;
T = [0:N_steps]/250; % unit year
stock_path = GBM_stock(1, N_steps,1, mu, sigma,S0);
nums = 1:N_steps+1;
arithmetic_average = cumsum(stock_path)./nums;
geometric_average  = cumprod(stock_path).^(1./nums);
prodct = cumprod(stock_path);
sample_step = 10;
T_sampled = [0:sample_step:N_steps]/250; % unit year
index_sampled = 1:sample_step:N_steps+1;
nums_sampled = [1:length(T_sampled)];
 
arithmetic_average_sampled = cumsum(stock_path(index_sampled))./nums_sampled;

geometric_average_sampled  = cumprod(stock_path(index_sampled)).^(1./nums_sampled);
 
figure(1)
plot(T,stock_path); hold on
plot(T,geometric_average); hold on
plot(T,arithmetic_average); hold on
xlabel('Time [year]'); ylabel('Asset price and its average')
legend('Path','Geometric, continuous','Arithmetic, continuous','location','best')
box off; grid off
 
figure(2)
plot(T,stock_path); hold on
plot(T_sampled,stock_path(index_sampled),'xk'); hold on
stairs(T_sampled,geometric_average_sampled); hold on
stairs(T_sampled,arithmetic_average_sampled); hold on
xlabel('Time [year]'); ylabel('Asset price and its average')
legend('Path','Samples','Geometric, discrete','Arithmetic, discrete','location','best')
box off; grid off
 
function S = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0)
dt = T_sim/N_steps;
drift = (mu - 0.5*sigma^2)*dt;
S = S0*ones(N_paths, N_steps+1);
brownian = sigma*sqrt(dt)*normrnd(0,1,N_paths, N_steps);
S(:, 2:end) = S0*exp(cumsum(drift + brownian, 2));
end
