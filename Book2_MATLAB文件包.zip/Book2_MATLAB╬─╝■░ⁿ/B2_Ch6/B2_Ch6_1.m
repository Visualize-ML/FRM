% B2_Ch6_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Compute Cash-or-Nothing Option Prices and Sensitivities
clc; clear all; close all
 
Settle0 = 'Jan-01-2018';
Maturity = 'Jan-01-2019';
month_shift_array = 1:11;
T2t_array = 12 - month_shift_array;
CalWin = datenum(Settle0);
 
AssetPrice_array = 50:1:150;
num_dates = length(month_shift_array);
num_prices = length(AssetPrice_array);
Call_Delta_array = zeros(num_dates,num_prices);
Call_Gamma_array = zeros(num_dates,num_prices);
Call_price_array = zeros(num_dates,num_prices);
Put_Delta_array = zeros(num_dates,num_prices);
Put_Gamma_array = zeros(num_dates,num_prices);
Put_price_array = zeros(num_dates,num_prices);
Call_Theta_array = zeros(num_dates,num_prices);
Put_Theta_array = zeros(num_dates,num_prices);
 
% Initialization
Sigma = .25;
DivType = 'Continuous';
Rates = 0.045;
DivAmount = Rates;
Compounding = -1;
Basis = 1;
 
OptSpec = {'call'; 'put'};
Strike = 100;
Payoff = 10;
 
for j = 1:length(month_shift_array)
    
    New_settle = addtodate(CalWin, month_shift_array(j), 'month');
    New_Settle = datestr(New_settle);
    
    
    RateSpec = intenvset('ValuationDate', New_Settle,...
        'StartDates', New_Settle,...
        'EndDates', Maturity, 'Rates', Rates,...
        'Compounding', Compounding, 'Basis', Basis);
    
    for i = 1:length(AssetPrice_array)
        
        AssetPrice = AssetPrice_array(i);
        
        StockSpec = stockspec(Sigma, AssetPrice, DivType, DivAmount);
        
        % Compute the Delta, Gamma and Price
        
        OutSpec = { 'delta';'gamma';'theta';'price'};
        [Delta, Gamma, Theta, Price] = cashsensbybls(RateSpec, StockSpec,...
            New_Settle, Maturity, OptSpec, Strike, Payoff, 'OutSpec', OutSpec);
        
        Call_Delta_array (j,i) = Delta(1);
        Call_Gamma_array (j,i) = Gamma(1);
        Call_price_array (j,i) = Price(1);
        Call_Theta_array (j,i) = Theta(1);
        
        Put_Delta_array (j,i)  = Delta(2);
        Put_Gamma_array (j,i)  = Gamma(2);
        Put_price_array (j,i)  = Price(2);
        Put_Theta_array (j,i)  = Theta(2);
        
    end
end
 
%% Value versus asset price and time to maturity
 
my_col = brewermap(num_dates,'RdYlBu');
 
index = 1;
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Call_price_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Cash-or-nothing call')
box off; set(gcf,'color','white')
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Put_price_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Cash-or-nothing put')
box off; set(gcf,'color','white')
 
%% Delta versus asset price and time to maturity
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Call_Delta_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Delta, cash-or-nothing call')
box off; set(gcf,'color','white')
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Put_Delta_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Delta, cash-or-nothing put')
box off; set(gcf,'color','white')
 
%% Gamma versus asset price and time to maturity
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Call_Gamma_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Gamma, cash-or-nothing call')
box off; set(gcf,'color','white')
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Put_Gamma_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Gamma, cash-or-nothing put')
box off; set(gcf,'color','white')
 
%% Theta versus asset price and time to maturity
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Call_Theta_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Theta, cash-or-nothing call')
box off; set(gcf,'color','white')
 
figure(index)
index = index + 1;
 
for i = 1:num_dates
    plot(AssetPrice_array,Put_Theta_array(i,:),...
        'color',my_col(num_dates-i+1,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.f month(s)');
end
legend(legendCell,'location','best')
xlabel('Asset price'); ylabel('Theta, cash-or-nothing put')
box off; set(gcf,'color','white')
 
figure(index)
index = index + 1;
 
mesh(AssetPrice_array(1:2:end),T2t_array(3:end),...
    Call_Theta_array(3:end,1:2:end),'MeshStyle','column')
xlim([min(AssetPrice_array(1:2:end)) max(AssetPrice_array(1:2:end))])
xlabel('Asset price'); ylabel('Time to maturity [month(s)]')
zlabel('Theta, cash-or-nothing call'); box off; grid off
 
figure(index)
index = index + 1;
 
mesh(AssetPrice_array(1:2:end),T2t_array(3:end),...
    Put_Theta_array(3:end,1:2:end),'MeshStyle','column')
xlim([min(AssetPrice_array(1:2:end)) max(AssetPrice_array(1:2:end))])
xlabel('Asset price'); ylabel('Time to maturity [month(s)]')
zlabel('Theta, cash-or-nothing put'); box off; grid off

