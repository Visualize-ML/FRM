% B2_Ch6_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%
close all; clear all; clc

S_array = 60:2:140; % underlying price
K = 100; % strike price
H = 75; % barrier price 75, 90, 125
r = 0.2; % risk-free interest rate
q = 0.00;   % continuous dividend rate, b=r-q
rebate = 0;
T = 0.5;   % time to maturity
sigma = 0.1; % volatility
Barrier_type = 'DI';

T2t_array = [1:12]/12;
num_dates = length(T2t_array);
num_prices = length(S_array);

barrier_call_matrix = zeros(num_dates,num_prices);
barrier_put_matrix  = zeros(num_dates,num_prices);

% please convert the following two loops to vector computations

for j = 1:length(T2t_array)
    
    T = T2t_array(j);
    
    for i = 1:length(S_array)
        
        S = S_array(i);
        
            [barrier_call,barrier_put] = ...
        blsprice_barrier(S,K,H,r,q,T,sigma,rebate,Barrier_type);
    
        barrier_call_matrix (j,i) = barrier_call;
        
        barrier_put_matrix (j,i)  = barrier_put;      
        
    end
end

my_col = brewermap(num_dates,'RdYlBu');


figure(1)

for i = 1:num_dates
    plot(S_array,barrier_call_matrix(i,:),...
        'color',my_col(i,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.2f yr(s)');
end

legend(legendCell,'location','best')

plot([K, K], [0, max(barrier_call_matrix(:))],'k'); hold on
plot([H, H], [0, max(barrier_call_matrix(:))],'k'); hold on
text (K, max(barrier_call_matrix(:))*0.8, '\leftarrow K')
text (H, max(barrier_call_matrix(:))*0.8, '\leftarrow H')
box off; set(gcf,'color','white')
set(gca, 'XAxisLocation', 'origin')
xlabel('Underlying asset price, S'); ylabel('Value'); 
title(strcat('Barrier call option-',Barrier_type))
daspect([1 1 1])

figure(2)

for i = 1:num_dates
    plot(S_array,barrier_put_matrix(i,:),...
        'color',my_col(i,:)); hold on
    legendCell{i} = num2str(T2t_array(i),'T = %.2f yr(s)');
end

legend(legendCell,'location','best')
plot([K, K], [0, max(barrier_put_matrix(:))],'k'); hold on
plot([H, H], [0, max(barrier_put_matrix(:))],'k'); hold on
text (K, max(barrier_put_matrix(:))*0.8, '\leftarrow K')
text (H, max(barrier_put_matrix(:))*0.8, '\leftarrow H')
box off; set(gcf,'color','white')
set(gca, 'XAxisLocation', 'origin')
box off; set(gcf,'color','white')
xlabel('Underlying asset price, S'); ylabel('Value'); 
title(strcat('Barrier put option-',Barrier_type))
daspect([1 1 1])

%%
function [call,put] = blsprice_barrier(S,K,H,r,q,T,sigma,rebate,Barrier_type)

syms A(phi) B(phi) C(phi,eta) D(phi,eta) E(eta) F(eta)
% phi: call (phi = 1), put (phi = -1)
% eta: down (eta = 1), up (eta = -1)

mu     = (r - q - sigma^2/2)/sigma^2;
lambda = sqrt(mu^2 + 2*r/sigma^2);
z      = log(H/S)/sigma/sqrt(T) + lambda*sigma*sqrt(T);

x1 = log(S/K)/sigma/sqrt(T) + (1+mu)*sigma*sqrt(T);
x2 = log(S/H)/sigma/sqrt(T) + (1+mu)*sigma*sqrt(T);

y1 = log(H^2/S/K)/sigma/sqrt(T) + (1+mu)*sigma*sqrt(T);
y2 = log(H/S)/sigma/sqrt(T) + (1+mu)*sigma*sqrt(T);

A(phi) = phi*S*exp(-q*T)*normcdf(phi*x1) - ...
    phi*K*exp(-r*T)*normcdf(phi*x1 - phi*sigma*sqrt(T));

B(phi) = phi*S*exp(-q*T)*normcdf(phi*x2) - ...
    phi*K*exp(-r*T)*normcdf(phi*x2 - phi*sigma*sqrt(T));

C(phi,eta) = phi*S*exp(-q*T)*(H/S)^(2*mu + 2)*normcdf(eta*y1) - ...
    phi*K*exp(-r*T)*(H/S)^(2*mu)*normcdf(eta*y1 - eta*sigma*sqrt(T));

D(phi,eta) = phi*S*exp(-q*T)*(H/S)^(2*mu + 2)*normcdf(eta*y2) - ...
    phi*K*exp(-r*T)*(H/S)^(2*mu)*normcdf(eta*y2 - eta*sigma*sqrt(T));

E(eta) = rebate*exp(-r*T)*(normcdf(eta*x2 - eta*sigma*sqrt(T)) - ...
    (H/S)^(2*mu)*normcdf(eta*y2 - eta*sigma*sqrt(T)));

F(eta) = rebate*((H/S)^(mu + lambda)*normcdf(eta*z) + ...
    (H/S)^(mu - lambda)*normcdf(eta*z - 2*eta*lambda*sigma*sqrt(T)));

switch Barrier_type
    
    case 'UO' %====================================
        eta = -1; type = 1;
        if H < K
            
            phi = 1; % call
            call = F(eta);
            phi = -1; % put
            put  = B(phi) - D(phi,eta) + F(eta);
            
        else % H > K
            phi = 1; % call
            call = A(phi) - B(phi) + C(phi,eta) - D(phi,eta) + F(eta);
            phi = -1; % put
            put  = A(phi) - C(phi,eta) + F(eta);
            
        end
        
    case 'UI'  %====================================
        eta = -1; type = 2;
        if H < K
            phi = 1; % call
            call = A(phi) + E(eta);
            phi = -1; % put
            put  = A(phi) - B(phi) + D(phi,eta) + E(eta);
            
        else % H > K
            phi = 1; % call
            call = B(phi) - C(phi,eta) + D(phi,eta) + E(eta);
            
            phi = -1; % put
            put  = C(phi,eta) + E(eta);
            
        end
        
    case 'DO'  %====================================
        eta = 1; type = 3;
        if H < K
            phi = 1; % call
            call = A(phi) - C(phi,eta) + F(eta);
            
            phi = -1; % put
            put  = A(phi) - B(phi) + C(phi,eta) - D(phi,eta) + F(eta);
            
        else % H > K
            phi = 1; % call
            call = B(phi) - D(phi,eta) + F(eta);
            
            phi = -1; % put
            put  = F(eta);
            
        end
        
    case 'DI' %====================================
        % down knock-in
        eta = 1; type = 4;
        if H < K
            phi = 1; % call
            call = C(phi,eta) + E(eta);
            
            phi = -1; % put
            put  = B(phi) - C(phi, eta) + D(phi, eta) + E(eta);
            
        else % H > K
            phi = 1; % call
            call = A(phi) - B(phi) + D(phi,eta) + E(eta);
            phi = -1; % put
            put  = A(phi) + E(eta);
        end
        
        
    otherwise
        disp('Barrier type is not supported')
        
end

call = double(call);
put  = double(put);

% disp(double(A(phi)));
% disp(double(B(phi)));
% disp(double(C(phi,eta)));
% disp(double(D(phi,eta)));
% disp(double(E(eta)));
% disp(double(F(eta)));

if type == 1 && S >= H % UO
    
    call = 0; put = 0;
    
elseif type == 2 && S >= H % UI
    
    [call,put] = blsprice(S,K,r,T,sigma);
    
elseif type == 3 && S <= H % DO
    
    call = 0; put = 0;
    
elseif type == 4 && S <= H % DI
    
    [call,put] = blsprice(S,K,r,T,sigma);
    
else
    
end

end
