% B2_Ch3_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
analysis_date = datenum('21-Jul-2019');
nPeriods = 36;
DeltaTime = 1/4; % unit: year
nTrials = 10;  % possible paths or surfaces
 
SimDates = daysadd(analysis_date,360*DeltaTime*(0:nPeriods),1);
SimTimes = diff(yearfrac(SimDates(1),SimDates));
 
Tenor = (1:20)'; % unit: year
HW_alpha = 0.2;
HW_sigma = 0.01;
 
analysis_date = datenum('21-Jul-2019');
 
% Zero Curve
original_tenors = [1 3 5 7 10 20];
CurveDates = daysadd(analysis_date,360*(original_tenors),1);
origianl_ZeroRates = [1.9 2.6 3.1 3.5 4 4.3]'/100; % Observed data
 
index = 1;
figure(index)
index = index + 1;
plot(original_tenors,origianl_ZeroRates,'-o')
title(['Term structure on the analysis date of ' datestr(analysis_date)]);
xlabel('Tenor [years]'); ylabel('Interest rate')
set(gcf,'color','white'); box off
xlim ([min(original_tenors) max(original_tenors)])
ylim ([0 max(origianl_ZeroRates)])
 
%% Hull-White one factor simulation
 
RateSpec = intenvset('Rates',origianl_ZeroRates,'EndDates',CurveDates,'StartDate',analysis_date);
 
% Construct the HullWhite1F model using the HullWhite1F constructor.
HW1F = HullWhite1F(RateSpec,HW_alpha,HW_sigma);
 
% Use Monte Carlo simulation to generate the interest-rate paths with
% HullWhite1F.simTermStructs.
HW1FSimPaths = HW1F.simTermStructs(nPeriods,'NTRIALS',nTrials,...
    'DeltaTime',DeltaTime,'Tenor',Tenor,'antithetic',true);
 
%%
trialIdx = 1;
 
figure(index)
index = index + 1;
mesh(Tenor,SimDates,HW1FSimPaths(:,:,trialIdx)); hold on

plot3(original_tenors, SimDates(1)*ones(size(original_tenors))...
    , origianl_ZeroRates,'k','LineWidth',2)

datetick y keepticks keeplimits
title(['Evolution of the Zero Curve for Trial: ' num2str(trialIdx) ' of Hull White Model'])
xlabel('Tenors [years]')
ylabel('Projected time frame')
zlabel('Interest rate')
xlim ([min(Tenor) max(Tenor)])
ylim ([min(SimDates) max(SimDates)])
zlim ([0 max(max(HW1FSimPaths(:,:,trialIdx)))])
set(gcf,'color','white'); box off; grid off
 
%%
figure(index)
index = index + 1;
mesh(Tenor,SimDates,HW1FSimPaths(:,:,trialIdx),'MeshStyle','column'); hold on
plot3(original_tenors, SimDates(1)*ones(size(original_tenors))...
    , origianl_ZeroRates,'k','LineWidth',2)
datetick y keepticks keeplimits
title(['Evolution of the Zero Curve for Trial:' num2str(trialIdx) ' of Hull White Model'])
xlabel('Tenors [years]')
ylabel('Projected time frame')
zlabel('Interest rate')
xlim ([min(Tenor) max(Tenor)])
ylim ([min(SimDates) max(SimDates)])
zlim ([0 max(max(HW1FSimPaths(:,:,trialIdx)))])
set(gcf,'color','white'); box off; grid off

figure(index)
index = index + 1;
mesh(Tenor,SimDates,HW1FSimPaths(:,:,trialIdx),'MeshStyle','row'); hold on
plot3(original_tenors, SimDates(1)*ones(size(original_tenors))...
    , origianl_ZeroRates,'k','LineWidth',2)
datetick y keepticks keeplimits
title(['Evolution of the Zero Curve for Trial:' num2str(trialIdx) ' of Hull White Model'])
xlabel('Tenors [years]')
ylabel('Projected time frame')
zlabel('Interest rate')
xlim ([min(Tenor) max(Tenor)])
ylim ([min(SimDates) max(SimDates)])
zlim ([0 max(max(HW1FSimPaths(:,:,trialIdx)))])
set(gcf,'color','white'); box off; grid off