% B2_Ch3_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
r0 =.1;
% r0: current short rate at time t
a =.3;
% a: the speed of mean reversion
b =.08;
% b: long-term mean of the short rate
sigma =.01;
% sigma: the volatility of the short rate
 
tenor_step=1; % Yearly frequency
tenors=[0:tenor_step:30]'; % Maturity matrix
 
B=(1-exp(-a*tenors))/a;
A=(B-tenors)*(b-sigma^2/(2*a^2))-(sigma^2*B.^2)/(4*a);
P=exp(A-B*r0);
R=-log(P)./tenors;
 
delta_t=tenor_step/50;
num_sims=1000; 
num_paths=max(tenors)/delta_t;
rsim=zeros(num_sims,num_paths); 
drsim=zeros(num_sims,num_paths);
rsim(:,1)=r0;
 
for j=2:num_paths
    dW=randn(num_sims,1);
    drsim(:,j)=a*(b-rsim(:,j-1))*delta_t+sigma*sqrt(delta_t)*dW;
    rsim(:,j)=rsim(:,j-1)+drsim(:,j);
end
 
P_sim=ones(length(tenors),1);
for i=2:length(tenors)
    P_sim(i)=mean(exp(-delta_t*sum(rsim(:,1:tenors(i)/delta_t),2)));
end
 
R_sim=-log(P_sim)./tenors;
 
figure(1)
subplot(2,1,1)
plot(tenors,P,'b',tenors,P_sim,'ok')
legend('Analytical','Simulation','location','best')
xlabel('Tenors, T-t [years]'); ylabel('P(t,T)')
box off; set(gcf,'color','white')
 
subplot(2,1,2)
plot(tenors,R,'b',tenors,R_sim,'ok')
legend('Analytical','Simulation','location','best')
xlabel('Tenors, T-t [years]'); ylabel('R(t,T)')
box off; set(gcf,'color','white')
ylim([(round(min(R_sim)/0.01)-1)*0.01,...
    (round(max(R_sim)/0.01)+1)*0.01])
