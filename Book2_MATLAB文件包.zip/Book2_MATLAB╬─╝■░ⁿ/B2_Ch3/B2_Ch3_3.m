% B2_Ch3_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Simulate correlated stock paths
clc; close all; clear all
num_days_per_yr = 252;
S0 = [50,  100];
mu = [0.1, 0.12];
% mu: drift term, risk-free interest rate
sigma= [0.3, 0.35];
% sigma: std dev over total interval
 
corr = [1   0.5;
        0.5 1 ];
% correlation matrix
 
total_yr = 1;
% S0: initial position (USD)
N=num_days_per_yr*total_yr;
% N: number of time steps (trading days)
dt = 1/num_days_per_yr;
nsims = 20;
 
date_series = [0:N];
price_series = multi_correl_stocks_paths_sim...
    (S0,mu,sigma,corr,dt,N,nsims);
 
index = 1;
figure(index)
index = index + 1;
 
for i = 1:nsims
    
    plot(date_series, squeeze(price_series(:,i,:))); hold on
    
end
 
xlabel('Time [days]'); ylabel('Simulated asset value [USD]');
set(gcf,'color','w'); xlim([0,N]); box off
 
% plot two paths of each asset
 
figure(index)
index = index + 1;
selected_indices = [1, 5, 10, 15];
 
for i = 1:length(selected_indices)
    
    path_i = selected_indices(i);
    subplot(2,2,i)
    plot(date_series, squeeze(price_series(:,path_i,:))); hold on
    xlabel('Time [days]'); ylabel('Simulated asset value [USD]');
    set(gcf,'color','w'); xlim([0,N]); box off
    
end
 
 
function S = multi_correl_stocks_paths_sim(S0,mu,sig,corr,dt,steps,nsims)
 
nAssets = length(S0);
 
% calculate the drift
nu = mu - sig.*sig/2;
 
% do a Cholesky factorization on the correlation matrix
L = chol(corr);
% pre-allocate the output
S = nan(steps+1,nsims,nAssets);
 
% generate correlated random sequences and paths
for idx = 1:nsims
    % generate uncorrelated random sequence
    Z = randn(steps,size(corr,2));
    % correlate the sequences
    correlated_random = Z*L;
    
    % Generate potential paths
    S(:,idx,:) = [ones(1,nAssets); ...
        cumprod(exp(repmat(nu*dt,steps,1)+correlated_random*diag(sig)*sqrt(dt)))]*diag(S0);
end
 
% If only one simulation then remove the unitary dimension
if nsims==1
    S = squeeze(S);
end
 
end
