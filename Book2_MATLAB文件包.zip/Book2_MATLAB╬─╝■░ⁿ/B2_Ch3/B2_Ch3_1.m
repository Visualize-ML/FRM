% B2_Ch3_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; clc; close all
year_total = 1; 
% unit: year
mu=0.05;
% mu: drift term, risk-free interest rate
sigma=0.1;
num_sims=250;
% K: number of simulations
S0=100;
% S0: initial position ($)
num_steps=252*year_total;
% N: number of time steps (trading days)
dt=1/252;
% dt: step size, one business day, 1/252 year
 
St_all_path = [];
index = 1;
figure(index)
index = index + 1;
 
nu = mu - sigma*sigma/2;
 
St_all_path = S0*[ones(1,num_sims); ...
    cumprod(exp(nu*dt+sigma*sqrt(dt)*randn(num_steps,num_sims)),1)];
 
plot([0:num_steps],St_all_path,'b')
xlim([0 num_steps]); box off
xlabel('Time [days]'); ylabel('Simulated asset value [USD]');
set(gcf,'color','w');
 
%%
figure(index)
index = index + 1;
num_bins = 10;
subplot(1,5,[1:3])
plot([0:num_steps],St_all_path,'b'); hold on
xlim([0 num_steps]); box off
xlabel('Time [days]'); ylabel('Simulated asset value [USD]');
set(gcf,'color','w');
y1=get(gca,'ylim'); 
 
 
subplot(1,5,4)
 
s_handle = scatter(num_steps*ones(1,num_sims),St_all_path(end,:),40,'b','filled')
s_handle.MarkerFaceAlpha = 0.1;
s_handle.MarkerEdgeColor = 'none';
ylim(y1); box off; xlim([num_steps-0.5 num_steps+0.5]); 
xticks([num_steps])
x_tick = ['T = ',num2str(num_steps/252),' yr'];
xticklabels({x_tick})
 
subplot(1,5,5)
histfit(St_all_path(end,:),num_bins,'lognormal');
xlim(y1); view(90,-90); box off;
 
 
%%
figure(index)
index = index + 1;
 
step_num = 10;
 
histfit(St_all_path(step_num, :),num_bins,'lognormal');
% 20 bins
set(gcf,'color','w');
xlabel(['Simulated asset values at the ',...
    num2str(step_num),'th time step [USD]'])
ylabel('Probability')
title(['Snapshot: ',num2str(step_num),' days'])
xlim([(round(min(min(St_all_path))/10) - 1)*10,...
    round(max(max(St_all_path))/10 + 1)*10])
 
%%
figure(index)
index = index + 1;
step_num = num_steps;
% can be updated in between 1 ~ 252
 
histogram(St_all_path(step_num, :) - S0, 15,...
    'Normalization','probability');
% 20 bins
set(gcf,'color','w');
xlabel(['P/L at the ',...
    num2str(step_num),' day [USD]'])
ylabel('Probability')
xlim([(round(min(min(St_all_path))/10) - 1)*10 - S0, ...
    round(max(max(St_all_path))/10 + 1)*10 - S0])
title(['Snapshot: ',num2str(step_num),' days'])
