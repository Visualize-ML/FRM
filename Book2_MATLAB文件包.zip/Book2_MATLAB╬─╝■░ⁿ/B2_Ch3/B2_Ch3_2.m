% B2_Ch3_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% tickers list: https://en.wikipedia.org/wiki/List_of_S%26P_500_companies
% GM: General Motors
% F: Ford Motor
% MCD: McDonald's Corp.
% IBM:  International Business Machines
 
clc; close all; clear all
 
price = hist_stock_data('01012015','31052019','GM','F','MCD','IBM');
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
%%
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
GM_price = price(1).AdjClose;
Ford_price = price(2).AdjClose;
McDon_price = price(3).AdjClose;
IBM_price = price(4).AdjClose;
 
GM_daily_log_return=diff(log(GM_price))*100;
% also price2ret can be used
Ford_daily_log_return=diff(log(Ford_price))*100;
McDon_daily_log_return=diff(log(McDon_price))*100;
IBM_daily_log_return=diff(log(IBM_price))*100;


%% Correlations
 
figure(4)
 
subplot(2,2,1)
x = GM_daily_log_return;
y = Ford_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
b = X\y; yCalc2 = X*b;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('GM (%)'); ylabel('Ford (%)')
 
subplot(2,2,2)
x = GM_daily_log_return;
y = IBM_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
b = X\y; yCalc2 = X*b;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('GM (%)'); ylabel('IBM (%)')
 
subplot(2,2,3)
x = IBM_daily_log_return;
y = McDon_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
b = X\y; yCalc2 = X*b;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('IBM (%)'); ylabel('McDonald (%)')
set(gcf,'color','white')
 
subplot(2,2,4)
x = GM_daily_log_return;
y = McDon_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
b = X\y; yCalc2 = X*b;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('GM (%)'); ylabel('McDonald (%)')
set(gcf,'color','white')
%% Matrix of correlations
 
A = [GM_daily_log_return Ford_daily_log_return ...
     IBM_daily_log_return McDon_daily_log_return];
R = corrcoef(A)
 
figure(5)
 
xvalues = {'GM','Ford','IBM','McD'};
yvalues = {'GM','Ford','IBM','McD'};
h = heatmap(xvalues,yvalues,R);
 
h.Title = 'Correlations of log returns';
set(gcf,'color','white')
 
% plotmatrix(A)
