% B2_Ch3_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% download three-year interest rate data
clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
startdate = '01/01/2017';
% beginning of date range for historical data
enddate = '12/31/2018'; % to be updated
% ending of date range for historical data
 
series = 'DGS1MO';
treasury_1_month_data = fetch(c,series,startdate,enddate)
% display description of data structure
treasury_1_month = treasury_1_month_data.Data(:,2);
date_series = treasury_1_month_data.Data(:,1);
 
treasury_1_month_nan_removed = treasury_1_month/100;
treasury_1_month_nan_removed(any(isnan(treasury_1_month),2),:) = [];
 
date_series_nan_removed = date_series;
date_series_nan_removed(any(isnan(treasury_1_month),2)) = [];
 
daily_diff_1_month = diff (treasury_1_month_nan_removed(:,1));
daily_diff_1_month = [NaN; daily_diff_1_month];
 
%%
r_past_252 = treasury_1_month_nan_removed(end-251:end);
 
figure(1)
x2 = r_past_252(1:end-1);
y2 = r_past_252(2:end);
F2 = [ones(size(x2)),x2];
[b2,~,errors] = regress(y2,F2);
x_fine = linspace(min(x2),max(x2));
alpha2 = b2(1);
beta2  = b2(2);
y_regressed2 = alpha2 + beta2*x_fine;
plot(x2,y2,'o'); hold on
plot(x_fine,y_regressed2,'r')
% plot(r(i), r(i+1))
xlabel('r(i)'); ylabel('r(i+1)');
 
dt      = 1/252;
speed_2 = -log(beta2)/dt;
level_2 = alpha2/(1 - beta2);
sigma_2 =  std(errors)*sqrt(-2*log(beta2)/dt/(1-beta2^2));
title_text = ['theta = ',num2str(speed_2),...
    '; mu = ',num2str(level_2),...
    '; sigma = ',num2str(sigma_2)];
title(title_text); box off; grid off
 
%%
 
dt = 1/252;
total_data = treasury_1_month_nan_removed;
dates_array = date_series_nan_removed(252+1:end);
theta_array = nan(size(dates_array));
mu_array = nan(size(dates_array));
sigma_array = nan(size(dates_array));
 
for i = 1:(length(treasury_1_month_nan_removed) - 252)
    window_data = total_data(i:i+252 - 1);
    [theta, mu, sigma] = calib_vasicek(dt,window_data);
    theta_array(i) = theta;
    mu_array(i) = mu;
    sigma_array(i) = sigma;
end
 
 
%%
figure(2)
subplot(3,1,1)
ax = gca;
plot(dates_array,theta_array)
datetick('x','yyyy mmm')
ylabel('\theta');
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(theta_array)*1.1])
ax.YAxis.Exponent = 0;
 
subplot(3,1,2)
ax = gca;
plot(dates_array,mu_array)
datetick('x','yyyy mmm')
ylabel('\mu');
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(mu_array)*1.1])
ax.YAxis.Exponent = 0;
 
subplot(3,1,3)
ax = gca;
plot(dates_array,sigma_array)
datetick('x','yyyy mmm')
ylabel('\sigma');
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(sigma_array)*1.1])
ax.YAxis.Exponent = 0;
 

figure(3)
subplot(3,1,1)
ax = gca;
stairs(dates_array(1:5:end),theta_array(1:5:end))
datetick('x','yyyy mmm')
ylabel('\theta'); xlim([min(dates_array),max(dates_array)])
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(theta_array)*1.1])
ax.YAxis.Exponent = 0;
 
subplot(3,1,2)
ax = gca;
stairs(dates_array(1:5:end),mu_array(1:5:end))
datetick('x','yyyy mmm'); 
ylabel('\mu'); xlim([min(dates_array),max(dates_array)])
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(mu_array)*1.1])
ax.YAxis.Exponent = 0;
 
subplot(3,1,3)
ax = gca;
stairs(dates_array(1:5:end),sigma_array(1:5:end))
datetick('x','yyyy mmm')
ylabel('\sigma'); xlim([min(dates_array),max(dates_array)])
box off; set(gca, 'XAxisLocation', 'origin');
ylim([0, max(sigma_array)*1.1])
ax.YAxis.Exponent = 0;
%% utilities
 
 
function [theta, mu, sigma] = calib_vasicek(dt,data)
 
x2 = data(1:end-1);
y2 = data(2:end);
F2 = [ones(size(x2)),x2];
[b2,~,errors] = regress(y2,F2);
alpha2 = b2(1);
beta2  = b2(2);
 
theta = -log(beta2)/dt;
mu = alpha2/(1 - beta2);
sigma =  std(errors)*sqrt(-2*log(beta2)/dt/(1-beta2^2));
end
