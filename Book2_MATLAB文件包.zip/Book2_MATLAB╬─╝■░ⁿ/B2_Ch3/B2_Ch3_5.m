% B2_Ch3_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
theta = 0.5; x_end = 2; y_end = 2;
sigma = 0.2;
dt = 0.02; t = 0:dt:10;
x = []; y = []; X = [0, 0, 4, 4]; Y = [0, 4, 4, 0];
figure(1)
 
% please eliminate the for loops using cumsum()
for j = 1:length(X)
    x(1) = X(j);
    y(1) = Y(j);
    
    for i = 1:length(t)-1
        dx = theta*(x_end-x(i))*dt+sigma*sqrt(dt)*randn;
        x(i+1) = x(i) + dx;
        dy = theta*(y_end-y(i))*dt+sigma*sqrt(dt)*randn;
        y(i+1) = y(i) + dy;
    end
    
    plot(x,y); hold on
end
 
xlabel('x'); ylabel('y')
xlim([0, 4]); ylim([0, 4]); 
