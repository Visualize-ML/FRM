% B2_Ch3_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
num = 1:2000;
rng(1); % For reproducibility
Mdl = arima('MA',{-0.8 0.5},'Constant',0,'Variance',1);
return_r = simulate(Mdl,length(num));
 
price = cumsum(return_r);
 
figure(1)
subplot (2,1,1)
plot(num, price)
ylabel('Price, P')
xlabel('Time')
 
subplot (2,1,2)
stem(num,return_r,'.')
ylabel('Return, r')
xlabel('Time')
 
figure(2)
autocorr(return_r)
 
figure(3)
 
LAGs = [1,2,3,4];
 
for i = 1:length(LAGs)
    lag = LAGs(i);
    u_t_lag = return_r(1:end - lag);
    u_t = return_r(1+lag:end);
    
    subplot(2,2,i)
    plot(u_t_lag, u_t, '.'); hold on
%   plotregression(u_t_lag,u_t,'Regression')
    
    F1 = [ones(size(u_t_lag)),u_t_lag];
    b1 = regress(u_t,F1);
    x_fine = [min(u_t_lag):0.01:max(u_t_lag)];
    y_regressed1 = b1(1) + b1(2)*x_fine;
    plot(x_fine,y_regressed1,'LineWidth',2)
    
    xlabel(['u_t_-_',num2str(lag)])
    ylabel(['u_t'])
    line = ['Lag = ',num2str(lag)];
    title(line)
    daspect([1 1 1])
end

