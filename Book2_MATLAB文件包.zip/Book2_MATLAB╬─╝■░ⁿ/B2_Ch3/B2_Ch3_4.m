% B2_Ch3_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
theta = 4; mu = 2;
sigma = 0.2;
dt = 0.05; t = 0:dt:10;
x = []; X = [0, 2, 4];
figure(1)
 
% please eliminate the for loops using cumsum()
for j = 1:length(X)
    x(1) = X(j);
    
    for i = 1:length(t)-1
        dx = theta*(mu-x(i))*dt+sigma*sqrt(dt)*randn;
        x(i+1) = x(i) + dx;
    end
    
    plot(t,x); hold on
end
 
xlabel('t'); ylabel('Trajectory')
