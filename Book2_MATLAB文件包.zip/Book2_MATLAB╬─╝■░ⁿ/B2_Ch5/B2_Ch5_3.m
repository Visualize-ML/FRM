% B2_Ch5_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% stock and option paths
clc; clear all; close all
K = 50;
S0 = K;
stock_ticks = linspace(30,70,100);
N_steps = 252;
IR = 0.02;
sigma = 0.5;
T_t = [N_steps+1:-1:1]/N_steps; % unit year
stock_path = GBM_stock(1, N_steps,1, IR, sigma,S0);
T_t_grid = repmat(T_t,length(stock_ticks),1);
stock_grid = repmat(stock_ticks',1,length(T_t));
 
[Call_path,Put_path] = blsprice(stock_path,K,IR,T_t,sigma);
[Delta_Call_path,Delta_Put_path] = blsdelta(stock_path,K,IR,T_t,sigma);
 
[Call_surf,Put_surf] = blsprice(stock_grid,K,IR,T_t_grid,sigma);
[Delta_Call_surf,Delta_Put_surf] = blsdelta(stock_grid,K,IR,T_t_grid,sigma);
 
%%
figure(1)
subplot(3,1,1)
plot(T_t, stock_path,'b','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[K,K],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
ylabel('Stock'); box off; grid off;
 
subplot(3,1,2)
plot(T_t, Call_path,'r','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[Call_path(1),Call_path(1)],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
ylabel('Call option'); box off; grid off;
 
subplot(3,1,3)
plot(T_t, Delta_Call_path,'g','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[0.5,0.5],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
xlabel('Time to maturity [year]'); ylabel('Delta')
box off; grid off; set(gca, 'XAxisLocation', 'origin')
 
%%
 
figure(2)
mesh(T_t_grid(1:2:end,1:10:end), stock_grid(1:2:end,1:10:end),...
    Call_surf(1:2:end,1:10:end),'MeshStyle','column',...
    'FaceColor','none')
hold all
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1)
plot3(T_t, stock_path, Call_path,'r','LineWidth',1)
plot3([T_t(1),T_t(end)],[K,K],[0,0],'k--')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock'); zlabel('Call option')
box off; grid off; view([-45, 30]); xlim([0, max(T_t)])
 
 
%%
figure(3)
mesh(T_t_grid(1:2:end,1:10:end), stock_grid(1:2:end,1:10:end),...
    Delta_Call_surf(1:2:end,1:10:end),'MeshStyle','column','FaceColor','none')
hold all
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1)
plot3(T_t, stock_path, Delta_Call_path,'g','LineWidth',1)
plot3([T_t(1),T_t(end)],[K,K],[0,0],'k--')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock'); zlabel('Delta, long call')
box off; grid off; view ([45, 30])
 
%%
figure(4)
subplot(3,1,1)
plot(T_t, stock_path,'b','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[K,K],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
ylabel('Stock'); box off; grid off;
 
subplot(3,1,2)
plot(T_t, Put_path,'r','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[Put_path(1),Put_path(1)],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
ylabel('Put option')
box off; grid off;
 
subplot(3,1,3)
plot(T_t, Delta_Put_path,'g','LineWidth',1); hold on
plot([T_t(1),T_t(end)],[-0.5, -0.5],'k--')
set (gca, 'xdir', 'reverse'); xlim([0, max(T_t)])
xlabel('Time to maturity [year]'); ylabel('Delta')
box off; grid off; set(gca, 'XAxisLocation', 'origin')
%%
 
figure(5)
mesh(T_t_grid(1:2:end,1:10:end), stock_grid(1:2:end,1:10:end),...
    Put_surf(1:2:end,1:10:end),'MeshStyle','column','FaceColor','none')
hold all
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1)
plot3(T_t, stock_path, Put_path,'r','LineWidth',1)
plot3([T_t(1),T_t(end)],[K,K],[0,0],'k--')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock'); zlabel('Put option')
box off; grid off; view([-215, 30]); xlim([0, max(T_t)])
 
 
%%
figure(6)
mesh(T_t_grid(1:2:end,1:10:end), stock_grid(1:2:end,1:10:end),...
    Delta_Put_surf(1:2:end,1:10:end),'MeshStyle','column','FaceColor','none')
hold all
plot3(T_t, stock_path, zeros(size(T_t)),'b','LineWidth',1)
plot3(T_t, stock_path, Delta_Put_path,'g','LineWidth',1)
plot3([T_t(1),T_t(end)],[K,K],[0,0],'k--')
set (gca, 'xdir', 'reverse')
xlabel('Time to maturity [year]'); ylabel('Stock'); zlabel('Delta, long put')
box off; grid off; view ([45, 30])
hAxis = gca;
hAxis.XRuler.FirstCrossoverValue  = 0; 
hAxis.YRuler.FirstCrossoverValue  = 1; 
hAxis.ZRuler.FirstCrossoverValue  = 1; 
hAxis.ZRuler.SecondCrossoverValue = 1; 
hAxis.XRuler.SecondCrossoverValue = 0; 
hAxis.YRuler.SecondCrossoverValue = 1; 
 
%%
 
Gamma_Call_path = blsgamma(stock_path,K,IR,T_t,sigma);
 
Gamma_Call_surf = blsgamma(stock_grid,K,IR,T_t_grid,sigma);

%%
function S = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0)
dt = T_sim/N_steps;
drift = (mu - 0.5*sigma^2)*dt;
S = S0*ones(N_paths, N_steps+1);
brownian = sigma*sqrt(dt)*normrnd(0,1,N_paths, N_steps);
S(:, 2:end) = S0*exp(cumsum(drift + brownian, 2));
end
