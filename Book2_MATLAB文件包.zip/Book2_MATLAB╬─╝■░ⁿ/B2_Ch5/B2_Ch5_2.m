% B2_Ch5_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
S_array = 30:2:70; 
% array of stock price
K = 50;  
% strike price
tau = 1; 
% time to maturity
vol = 0.3; 
% volatility of log return of underlying asset
r = 0.05;  
% risk-free rate
 
[CallDelta_BSM,PutDelta_BSM] = blsdelta(S_array,K,r,tau,vol);
CallDelta_Numerical = nan(size(CallDelta_BSM));
PutDelta_Numerical  = nan(size(CallDelta_BSM));
 
delta_S = 2; 
for i = 1:length(S_array)
    S = S_array(i);
    % calculate Delta for call and put numerically 
    [Call_plus,Put_plus] = blsprice(S + delta_S,K,r,tau,vol);
    [Call_minus,Put_minus] = blsprice(S - delta_S,K,r,tau,vol);
    CallDelta_Numerical(i) = (Call_plus - Call_minus)/2/delta_S;
    PutDelta_Numerical(i) = (Put_plus - Put_minus)/2/delta_S;
end
 
figure(1)
subplot(2,1,1)
plot(S_array,CallDelta_BSM); hold on
plot(S_array,CallDelta_Numerical,'x')
xlabel('Underlying asset'); ylabel('Delta, call')
legend('BSM','Numerical'); box off
set(gca, 'XAxisLocation', 'origin')
 
subplot(2,1,2)
stem(S_array,CallDelta_BSM - CallDelta_Numerical); box off
xlabel('Underlying asset'); ylabel('Error (BSM - Numerical)')
 
figure(2)
subplot(2,1,1)
plot(S_array,PutDelta_BSM); hold on
plot(S_array,PutDelta_Numerical,'x')
xlabel('Underlying asset'); ylabel('Delta, put')
legend('BSM','Numerical')
set(gca, 'XAxisLocation', 'origin'); box off
 
subplot(2,1,2)
stem(S_array,PutDelta_BSM - PutDelta_Numerical)
xlabel('Underlying asset'); ylabel('Error (BSM - Numerical)')
set(gca, 'XAxisLocation', 'origin'); box off
