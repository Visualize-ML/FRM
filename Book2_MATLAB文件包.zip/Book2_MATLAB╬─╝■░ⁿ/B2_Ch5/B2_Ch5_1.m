% B2_Ch5_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
spot_price_range = 0.01:1:100; 
% variation of underlying price
strike_price = 50;
interest_rate = 0.1;
% risk-free interest rate
volatility = 0.35;
% volatility of log return for underlying price
spot_price_length = length(spot_price_range);
maturity_range = [1:4:48]; 
% time to maturity. Unit: month(s)
maturity_length = length(maturity_range);
maturity_matrix = maturity_range(ones(spot_price_length,1),:)'/12;
 
maturity_range_holder = ones(length(maturity_range),1);
spot_price_matrix = spot_price_range(maturity_range_holder,:);
all_one_matrix = ones(size(maturity_matrix));
% long call price
call_option_price_matrix  = blsprice(spot_price_matrix,...
    strike_price*all_one_matrix, interest_rate*all_one_matrix,...
    maturity_matrix, volatility*all_one_matrix);
% long call delta
call_option_delta_matrix  = blsdelta(spot_price_matrix,...
    strike_price*all_one_matrix, interest_rate*all_one_matrix,...
    maturity_matrix, volatility*all_one_matrix);
 
my_col = brewermap(maturity_length,'RdYlBu');
%%
figure (1)
subplot(2,1,1)
for i = 1:maturity_length
    
    plot(spot_price_range, call_option_price_matrix(i,:),...
        'color',my_col(i,:));
    hold on
    legendCell{i} = num2str(maturity_range(i)/12,'T = %.2f yr(s)');
end
legend(legendCell,'location','best') 
xlabel('S [USD]'); ylabel('V, long call [USD]');
title('Long call'); set(gcf,'color','white'); box off
 
subplot(2,1,2)
 
for i = 1:maturity_length
    
    plot(spot_price_range, call_option_delta_matrix(i,:),'color',my_col(i,:));
    hold on
    
end
 
xlabel('S [USD]'); ylabel('\Delta, long call');
set(gcf,'color','white'); box off
 
%% Plot Delta, long European call versus maturity
 
figure (2)
 
mesh(spot_price_range, maturity_range, call_option_delta_matrix);
xlabel('S [USD]'); ylabel('T-t [month(s)]');
zlabel('\Delta, long call'); colorbar; box off
xlim([0 max(spot_price_range)])
ylim([min(maturity_range) max(maturity_range)])
set(gcf,'color','white')
 
%% Plot contours of delta 
 
figure (3)
 
levels = [0.05,0.1:0.1:0.9,0.95,0.975];
contour(spot_price_range, maturity_range, call_option_delta_matrix,levels,'ShowText','on');
xlabel('S [USD]'); ylabel('T-t [month(s)]');
colorbar; box off; xlim([0 max(spot_price_range)])
ylim([min(maturity_range) max(maturity_range)])
set(gcf,'color','white')
 
%% Plot the contour of delta 0.5
 
figure (4)
levels = [0.5,0.5];
[C,h] = contour(spot_price_range, maturity_range,...
    call_option_delta_matrix,levels,'ShowText','on');
% plot(C(2,2:end),C(1,2:end))
xlabel('S [USD]'); ylabel('T-t [month(s)]');
set(gcf,'color','white'); box off
 
%% Delta versus time to maturity, stock prices fixed
 
figure (5)
 
interested_stock_price = 30:10:90;
 
stock_p_length=length(interested_stock_price);
 
for i = 1:stock_p_length
    
    stock_p = interested_stock_price (i);
    plot(maturity_range,call_option_delta_matrix(:,stock_p)); hold on
    legendCell{i} = num2str(stock_p,'S = %-d USD');
end
 
legend(legendCell)
 
xlabel('T-t [month(s)]'); ylabel('\Delta, long call');
set(gcf,'color','white'); box off
