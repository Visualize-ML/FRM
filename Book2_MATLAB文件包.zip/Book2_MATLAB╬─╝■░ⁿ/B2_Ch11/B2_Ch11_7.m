% B2_Ch11_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_7_D.m
clc; clear all; close all;
 
% Generate sythetic equity price of one year (252-day)
% One single-path
rng(1);
 
% mu: drift term, risk-free interest rate
% control factor
mu = [0.08, 0.09];
 
St_all_path = [];
 
for i=1:length(mu)
    sigma=0.2;
    % K: number of simulations/paths
    num_sims=1;
    % S0: initial position ($)
    S0=0.5;
    
    % N: number of time steps (trading days)
    num_steps=252;
    % dt: step size, one business day, 1/252 year
    dt=1/num_steps;
    
nu = mu(i) - sigma*sigma/2;

    St_all_path(:,i) = S0*[ones(1,num_sims); ...
        cumprod(exp(nu*dt+sigma*sqrt(dt)*...
        randn(num_steps,num_sims)),1)];
end
 
% Plot sythetic equity price
figure(1)
plot(0:num_steps, St_all_path)
xlim([0 num_steps]);
box off
legend('Equity Price Path I', 'Equity Price Path II')


%% B2_Ch11_7_E.m
% Initialize parameters
EquityNum = 1;
Rate = 0.03;
T = 1:5;
 
% Short-term debt
STD = 0.7;
% Long-term debt
LTD = 0.4;
% Total dbt
Liability = STD + 0.5*LTD;
 

%% B2_Ch11_7_F.m
for j=1:length(mu)
    Equity = St_all_path(:,j);
    
    for i=1:length(T)
        % With specifying "Drift" & "Maturity"
        [PD1(:,i,j),DD1(:,i,j),A1(:,i,j),Sa1(i,j)] =...
            mertonByTimeSeries(Equity*EquityNum,...
            Liability*ones(1,length(St_all_path)),...
            Rate*ones(1,length(St_all_path)),...
            'Maturity',T(i));
        
        % Risk-neutral
        [PD2(i,j),DD2(i,j),A2(:,i,j),Sa2(i,j),Mu2(i,j)] = ...
            KMVcal(Equity,EquityNum,Liability,Rate,T(i),...
            0);
        
        % Real-world
        [PD3(i,j),DD3(i,j),A3(:,i,j),Sa3(i,j),Mu3(i,j)] = ...
            KMVcal(Equity,EquityNum,Liability,Rate,T(i),...
            1);
    end
end
 
%% B2_Ch11_7_G.m
% Plot results
Index = {'I','II'};
 
for j=1:length(mu)
    figure(2);
    subplot(length(mu),1,j)
    plot(PD1(end,:,j));
    hold on
    plot(PD2(:,j), '-.o');
    hold on
    plot(PD3(:,j), '-.*');
    hold off
    legend('Risk Neutral-MATLAB',...
        'Risk Neutral-User',...
        'Real World-User')
    title(strcat('Equity Price Path', {' '}, Index(j),' - PD'))
    
    figure(3);
    subplot(length(mu),1,j)
    plot(Sa1(:,j));
    hold on
    plot(Sa2(:,j), '-.o');
    hold on
    plot(Sa3(:,j), '-.*');
    hold off
    legend('Risk Neutral-MATLAB',...
        'Risk Neutral-User',...
        'Real World-User')
    title(strcat('Equity Price Path ', {' '}, Index(j),...
        ' - Asset Volatility'))
    
end
 
figure(4);
plot([min(T), max(T)],[Rate, Rate]);
hold on
plot(Mu2(:,1), '-.o');
hold on
plot(Mu3(:,2), '-.*');
hold off
legend('Risk Free Rate',...
    'Asset Return Mean-Equity Price Path I',...
    'Asset Return Mean-Equity Price Path II')
title('Risk Free Rate vs. Asset Return Mean')
 





%% B2_Ch11_7_A.m
function f = KMVequ(Liability,Equity,Rate,Maturity,Sa,A)

%% Inputs
% Equity    : Equity value
% Liability : Liability value
% Rate      : Risk-free interest rate
% Maturity  : Time to maturity (time horizon) in years
% Sa        : Asset value volatility
% A         : Asset value

T=Maturity;
r=Rate;
d1=(log(A/Liability)+(r+0.5*Sa^2)*T)/(Sa*sqrt(T));
d2=d1-Sa*sqrt(T);

f=(A/Equity)*normcdf(d1)-...
    (Liability/Equity)*exp(-r*T)*normcdf(d2)-1;

end


%% B2_Ch11_7_B.m
function [A] = SolveA(Liability,Equity,Rate,Maturity,Sa)

%% Inputs
% Equity    : Equity value
% Liability : Liability value
% Rate      : Risk-free interest rate
% Maturity  : Time to maturity (time horizon) in years
% Sa        : Asset value volatility
% A         : Asset value

A0=Liability;
A =fsolve(@(A)KMVequ(Liability,Equity,Rate,Maturity,Sa,A), A0);

end


%% B2_Ch11_7_C.m
function [PD,DD,A,Sa,Mu] = ...
    KMVcal(Equity, EquityNum, Liability, ...
    Rate, Maturity, Flag)

%% Inputs
% Equity    : Vector of Share prices
% EquityNum : Volume/Number of outstanding shares
% Liability : Total Liabilities
% Rate      : Risk-free interest rate
% Maturity  : Time to maturity (time horizon) in years
% Flag      : Switch of risk-neutral PD and real-world PD

%% Threshold
% Sig_Threshold : The accuracy of Sigma

%% OutPuts
% PD : Probability of defatul
% DD : Distance to default
% A  : Asset value
% Sa : Asset value volatility
% Mu : Asset value expectation

Sig_Threshold = 10^-7;
lm = length(Equity);
Etot=Equity*EquityNum;

LS=log(Equity(2:end)./Equity(1:end-1));
h=length(Etot);
Se=std(LS);

% Sa : Asset Volatility to be computed
% Initial value
Sa=Se*(Etot(1)/(Etot(1)+Liability));

% Sa_tmp is the Asset Volatility at the previous iteration
% Sa_tmp is initialized at the first step
Sa_tmp=Sa;
j = 1;

while abs(Sa-Sa_tmp)>Sig_Threshold || j==1
    for i=1:lm
        % A(i) is the asset value at time step i
        A(i)=SolveA(Liability,Etot(i),Rate,Maturity,Sa);
    end
    % LR is the implied asset returns ( Log returns )
    LR=log(A(2:end)./A(1:end-1));
    R=mean(LR);
    Sa_tmp=Sa;
    Sa=std(LR)*sqrt(h);
    
    % Mu is the expected return of the asset value
    Mu =h*R-0.5*Sa^2;
    
    j=j+1;
    
end

% disp(j)
% Sa % asset volatility
if Flag == 1
    DD = (log(A(lm)/Liability)+...
        (Mu -(0.5*Sa^2))*Maturity)/(Sa*sqrt(Maturity));
else
    DD = (log(A(lm)/Liability)+...
        (Rate -(0.5*Sa^2))*Maturity)/(Sa*sqrt(Maturity));
end

% Calculate PD
PD = 1-normcdf(DD);
end

