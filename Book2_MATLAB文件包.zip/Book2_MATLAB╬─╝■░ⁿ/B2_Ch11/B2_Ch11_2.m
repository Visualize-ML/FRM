% B2_Ch11_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_2.m
% Calculate the PD of "Creditscorecard Object"
% Run the codes of Chapter 11 to create a 
% "creditscorecard object" first
[Scores,Points] = score(cscobj);
 
pd = probdefault(cscobj);

figure
scatter(Scores, pd, 12);
xlabel('Score')
ylabel('Probability of Default')
 
xLimits = [300, 900];
yLimits = [0, 1];

