% B2_Ch11_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_4.m
clc; clear all; close all;
 
% Initialize
A = 100e6;
Dt = 100e6;
r = 0.1;
sigma_A = 0.2;
T = 5;
 
% Calculation
% Distance to default
sigma_T = (log(A/Dt)+(r-0.5*sigma_A^2)*T)/sigma_A/sqrt(T)
d1 = sigma_T + sigma_A*sqrt(T)
d2 = sigma_T
PD = 1-normcdf(d2)


