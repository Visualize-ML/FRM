% B2_Ch11_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_1_A.m
clc; clear all; close all;
 
% Initialize
p = 0.02;
tn = 51;
index = 1:tn;
index = (index-1)';
 
% Calculate survival rate and conditional PD
survival = ones(tn, 1);
PD_con = 1-survival;
 
% after starting pint, index > 0
PD_con(2:tn) = p*(1-p).^(index(2:tn)-1);
survival(2:tn) = (1-p).^index(2:tn);
 
% Calculate unconditional PD
PD_uncon = cumsum(PD_con);
 
% Plot
figure
bar(index, PD_con);
hold on;
scatter(index, PD_uncon, 12, 'r');
hold on;
scatter(index, survival, 12, 'b');
legend('Discrete Conditional PD',...
    'Discrete Unconditional PD',...
    'Discrete Survival Rate');


%% B2_Ch11_1_B.m
% Fit to single-term exponential model
f1 = fit(index, survival,'exp1');

f2 = fit(index, survival,'exp1', 'StartPoint',[0,1]);
 
% Plot
figure
scatter(index, PD_uncon, 12, 'r');
hold on;
scatter(index, survival, 12, 'b');
hold on;
plot(index, 1-f2.a*exp(f2.b*index), '-r');
hold on;
plot(index, f2.a*exp(f2.b*index), '-b');
 
legend('Discrete Uncontidional PD',...
    'Discrete Survival Rate',...
    'Continuous Uncontidional PD, p(t)',...
'Continuous Survival Rate, s(t)');

