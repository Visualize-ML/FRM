% B2_Ch11_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_5.m
clc; clear all; close all;
 
% Import data
load MertonData.mat
 
% Display data
MertonData
 
% Initializing
Equity    = MertonData.Equity;
EquityVol = MertonData.EquityVol;
Liability = MertonData.Liability;
Drift     = MertonData.Drift;
Rate      = MertonData.Rate;
 
% Without specifying "Drift" & "Maturity"
[PD1,DD1,A1,Sa1] = ...
    mertonmodel(Equity,EquityVol,Liability,Rate)
 
% Specifying "Drift"
[PD2,DD2,A2,Sa2] = ...
    mertonmodel(Equity,EquityVol,Liability,Rate,...
    'Drift',Drift)
 
% Specifying "Drift" & "Maturity"
[PD3,DD3,A3,Sa3] = ...
    mertonmodel(Equity,EquityVol,Liability,Rate,...
    'Drift',Drift,'Maturity',3)



