% B2_Ch11_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_6.m
clc; clear all; close all;
 
% Import data
load MertonData.mat
 
% Initializing
Dates     = MertonDataTS.Dates;
Equity    = MertonDataTS.Equity;
Liability = MertonDataTS.Liability;
Rate      = MertonDataTS.Rate;
 
% Without specifying "Drift" & "Maturity" & "NumPeriods"
[PD4,DD4,A4,Sa4] =...
    mertonByTimeSeries(Equity,Liability,Rate);
 
% With specifying "Drift" & "Maturity"
[PD5,DD5,A5,Sa5] =...
    mertonByTimeSeries(Equity,Liability,Rate,...
    'Drift',0.10,'Maturity',3);
 
% With specifying "Drift" & "Maturity" & "NumPeriods"
[PD6,DD6,A6,Sa6] =...
    mertonByTimeSeries(Equity,Liability,Rate,...
    'Drift',0.10,'Maturity',3,'NumPeriods',252);


