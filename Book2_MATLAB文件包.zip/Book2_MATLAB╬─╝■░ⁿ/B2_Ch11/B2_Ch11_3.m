% B2_Ch11_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B2_Ch11_3_A.m
clc; clear all; close all;
 
load Data_TransProb
 
[obs_num, var_num]=size(data); 
var_name = data.Properties.VariableNames;
 
ID_level = unique(data.ID); 
Rating_level = unique(data.Rating)
 
data.Date = datetime(data.Date, 'InputFormat', 'dd-MMM-yyyy');
 
date_min = min(data.Date) 
date_max = max(data.Date)


%% B2_Ch11_3_B.m
% Plot
summary = groupsummary(data, {'Rating', 'Date'});
summary = sortrows(summary, {'Rating', 'Date'});
 
summary.Year = year(summary.Date);
summary = groupsummary(summary, {'Rating', 'Year'});
summary.Rating = categorical(summary.Rating);
 
var_rating = unique(summary.Rating);
 
for i = 1:length(var_rating)
    
    data_tmp = summary(summary.Rating == var_rating(i), :);
    
    plot3(data_tmp.Year, data_tmp.Rating, data_tmp.GroupCount, '-o', 'Linewidth', 2);
    hold on
   
end
hold off;
grid off;
ylabel('Rating');
xlabel('Year');
zlabel('Number of Observations');
view(60, 45);


%% B2_Ch11_3_C.m
% Estimate transition probabilities using default settings
% i.e., 'algorithm', 'duration'
transMat1 = transprob(data);

transMat1


%% B2_Ch11_3_D.m
% Estimate transition probabilities using 'cohort' algorithm
% Specifiy start and end dates
startdate = datetime('31-Dec-1985', 'InputFormat', 'dd-MMM-yyyy');
enddate = datetime('31-Dec-2002', 'InputFormat', 'dd-MMM-yyyy');
 
transMat2 = transprob(data,'algorithm','cohort', ...
    'startDate', startdate, 'endDate', enddate, ...
'snapsPerYear', 4);

transMat2


%% B2_Ch11_3_E.m
% Multiple-year TM or PD
TMall = [];
 
TMall(:,:,1) = transMat2;
TMall(:,:,2) = (transMat2*1e-2)^2*1e2;
TMall(:,:,3) = (transMat2*1e-2)^3*1e2;
TMall(:,:,4) = (transMat2*1e-2)^4*1e2;
TMall(:,:,5) = (transMat2*1e-2)^5*1e2;
TMall(:,:,6) = (transMat2*1e-2)^6*1e2;
 
DPMat = [TMall(:, end, 1), TMall(:, end, 2), ...
    TMall(:, end, 3), TMall(:, end, 4),...
    TMall(:, end, 5), TMall(:, end, 6)];

% Plot of multiple-year TMs
var_rating_reorder = ["AAA","AA","A","BBB","BB","B","CCC","D"];
 
figure
for i=1:6
    subplot(3,2,i)
    
    heatmap(round(TMall(:, :, i), 2), ...
        'ColorbarVisible', 'off', ...
        'XData', var_rating_reorder, ...
        'YData', var_rating_reorder, ...
        'Colormap', autumn, 'ColorScaling', 'log');    
    
    title(strcat('Transition Matrix of ', {' '}, ...
        num2str(i), '-Year'))
end
 
% Plot of multiple-year PD
TMall_swap = permute(TMall, [1, 3, 2]);
 
figure
for i=1:7    
    semilogy(TMall_swap(i, :, end));
    hold on
end
 
set(gca,'xtick', 1:6)
xlabel('Year')
ylabel('Probability of Default')
legend(var_rating_reorder(1:7))
 

%% B2_Ch11_3_F.m
% TM aggregate
[transMat2, sampleTotals] = transprob(data,...
    'algorithm','cohort', ...
    'startDate', startdate, 'endDate', enddate, ...
    'snapsPerYear', 4);
 
edges = [4 7 8];

sampleTotalsGrp = transprobgrouptotals(sampleTotals,edges);
 
% Transition matrix at investment grade / speculative grade level
transMatIGSG = transprobbytotals(sampleTotalsGrp)


