% B2_Ch9_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
E_R_array = [0.2 0.1];
vol_array = [0.3 0.15];
num_assets = length(vol_array);
corre_range = -1:0.1:1;
 
figure (1)
 
my_col = brewermap(length(corre_range),'RdYlBu');
 
for i=1:length(corre_range)
    
    corre = corre_range(i); % range: [-1, 1]
    
    corre_matrix = [ 1  corre
                    corre  1];
    
    cov_matrix = corr2cov(vol_array, corre_matrix);
    % Convert standard deviation and correlation to covariance
    
    [sigma_p, ER_p, PortWts] = portopt(E_R_array, cov_matrix, 20);
    plot(sigma_p, ER_p,'color',my_col(i,:)); 
    hold on; box off
    % portopt has been partially removed and 
    % will no longer accept ConSet or varargin arguments. 
    % Use Portfolio instead to solve portfolio problems 
    hold on
    
end
 
xlabel('Portfolio volatility')
ylabel('Portfolio expected return')
set(gcf,'color','white')
grid off
