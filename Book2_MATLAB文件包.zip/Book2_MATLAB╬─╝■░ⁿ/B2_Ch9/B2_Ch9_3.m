% B2_Ch9_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% First, specify the expected returns, standard deviations, and
% correlation matrix for a hypothetical portfolio of three assets
 
E_R_array = [0.1 0.15 0.12];
vol_array = [0.2 0.25 0.18];
 
corre_matrix = [1    0.3   0.4
                0.3  1     0.3
                0.4  0.3   1 ];
 
figure(1)
cov_matrix = corr2cov(vol_array, corre_matrix);
 
portopt(E_R_array, cov_matrix, 20)
 
rng('default')
Weights = rand(1000, 3);
 
Total = sum(Weights, 2);     % Add the weights
Total = Total(:,ones(3,1));  % Make size-compatible matrix
Weights = Weights./Total;    % Normalize so sum = 1
 
[sigma_p, ER_p] = portstats(E_R_array, cov_matrix, Weights);
 
hold on
plot (sigma_p, ER_p, '.r')
title('Mean-Variance Efficient Frontier and Random Portfolios')
hold off
xlabel('Portfolio volatility')
ylabel('Portfolio expected return')
set(gcf,'color','white')
grid off; box off
