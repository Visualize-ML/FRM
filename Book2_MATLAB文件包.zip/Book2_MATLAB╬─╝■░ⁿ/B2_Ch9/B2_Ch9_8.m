% B2_Ch9_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
% Step 1: Define three bonds available for hedging the original portfolio
 
Settle     = '19-Aug-1999';
% analysis date
Maturity   = ['17-Jun-2010'; '09-Jun-2015'; '14-May-2025'];
Face       = [100; 100; 1000];
CouponRate = [0.07; 0.06; 0.045];
 
Yields = [0.05; 0.06; 0.065];
 
% Step 2: calculate the price, modified duration in years, 
% and convexity in years of each bond
 
[CleanPrice, AccruedInterest] = bndprice(Yields,CouponRate,... 
Settle, Maturity, 2, 0, [], [], [], [], [], Face);
 
Durations = bnddury(Yields, CouponRate, Settle, Maturity,...
2, 0, [], [], [], [], [], Face);
 
Convexities = bndconvy(Yields, CouponRate, Settle,... 
Maturity, 2, 0, [], [], [], [], [], Face);
 
Prices  =  CleanPrice + AccruedInterest;
 
% Step 3: Set up and solve the system of linear equations 
% whose solution is the weights of the new bonds in a new portfolio 
% with the same duration and convexity as the original portfolio
 
A = [Durations'
     Convexities'
     ones(size(Durations'))];
 
b = [ 10.3181
     157.6346
       1];
 
% A*Weights = b;
 
Weights = A\b
% Step 4: Compute the duration and convexity of the hedge portfolio, 
% which should now match the original portfolio.
 
PortfolioDuration  = Weights' * Durations;
PortfolioConvexity = Weights' * Convexities;
 
% Step 5: Finally, scale the unit portfolio to 
% match the value of the original portfolio 
 
PortfolioValue = 100000;
HedgeAmounts   = Weights ./ Prices * PortfolioValue
