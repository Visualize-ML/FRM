% B2_Ch9_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
E_R_1 = 0.2;
E_R_2 = 0.1;
sigma_1 = 0.3;
sigma_2 = 0.15;
% short selling allowed
w1 = -1:0.01:2;
w2 = 1 - w1;
 
% short selling unallowed
% w1 = [0:0.01:1];
% w2 = 1 - w1;
 
figure (1)
corre_range = [-1:0.1:1];
my_col = brewermap(length(corre_range),'RdYlBu');
 
for i=1:length(corre_range)
    
    corre = corre_range(i); % range: [-1, 1]
    
    ER_p = w1*E_R_1 + w2*E_R_2;
    % maximize expected portfolio return
    sigma_p = sqrt(w1.^2*sigma_1^2 + w2.^2*sigma_2^2 ...
        + 2*w1.*w2*corre*sigma_1*sigma_2);
    % minimize portfolio volatility
    
    plot(sigma_p, ER_p,'color',my_col(i,:))
    xlim([0 0.6]); ylim([0 0.3]); box off
    
    hold on
    
end
 
xlabel('Portfolio volatility')
ylabel('Portfolio expected return')
set(gcf,'color','white')
