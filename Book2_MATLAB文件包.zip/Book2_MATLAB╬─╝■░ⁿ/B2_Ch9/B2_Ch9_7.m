% B2_Ch9_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
T_sim = 1;
% Length of simulations; unit: year
S0 = 50;
% Original stock price, USD
K = 50;
% Call option strike price
mu = 0.1;
% Drift in GBM
r = 0.1;
% Risk-free rate in BSM
sigma = 0.2;
% Volatility in GBM and BSM
[chargeToCustomer,~] = blsprice(S0,K,r,T_sim,sigma);
N_paths = 1000; 
% Number of simulation paths
% To be updated: 1, 20, 1000
N_steps = 100;
% Number of simulation steps
dt = T_sim/N_steps;
time_array = dt:dt:T_sim;
S_paths = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0);
 
[delta0,~] = blsdelta(S0,K,r,T_sim,sigma);
 
stockQuantity = delta0;
 
cost = stockQuantity .* S0;
bankBalance = chargeToCustomer-cost;
bankBalance_dynamic_hedge = zeros(size(S_paths));
bankBalance_no_hedge = zeros(size(S_paths));
delta_array = zeros(size(S_paths));
 
bankBalance_dynamic_hedge (:,1) = bankBalance;
bankBalance_no_hedge (:,1)  = chargeToCustomer;
delta_array (:,1) = delta0;
 
% array size: N_paths * (N_steps + 1)
 
for t=1:(N_steps-1)
    S = S_paths(:,t);
    timeToMaturity = T_sim-time_array(t);
    [delta,~] = blsdelta(S,K,r,timeToMaturity,sigma);
    newStockQuantity = delta;
    amountToBuy = newStockQuantity - stockQuantity;
    cost = amountToBuy .* S;
    bankBalance = exp(r*dt)*bankBalance - cost;
    stockQuantity = newStockQuantity;
    bankBalance_dynamic_hedge (:,1+t) = bankBalance;
    delta_array (:,1+t) = delta;
    bankBalance_no_hedge (:,1+t)  = chargeToCustomer;
end
 
S = S_paths(:,N_steps);
stockValue = stockQuantity .* S;
liability = max(S-K, 0);
bankBalance = exp(r*dt)*bankBalance + stockValue - liability;
bankBalance_dynamic_hedge (:,end) = bankBalance;
delta_array (:,end) = nan;
bankBalance_no_hedge(:,end) = chargeToCustomer - liability;
finalBankBalance = bankBalance;
 
whole_time_array = [0,time_array];
figure(1)
subplot(3,1,1)
plot(whole_time_array,S_paths)
ylabel('Stock'); box off
 
subplot(3,1,2)
plot(whole_time_array,delta_array)
ylabel('Delta'); box off
 
subplot(3,1,3)
plot(whole_time_array,bankBalance_dynamic_hedge); hold on
plot(whole_time_array,bankBalance_no_hedge)
ylabel('Bank balance'); xlabel('Time [year]')
box off; set(gcf,'color','white')
legend('Dynamic hedge','No hedge')
 
figure(2)
 
plot(whole_time_array,S_paths)
ylabel('Stock'); xlabel('Time [year]')
box off; set(gcf,'color','white')
 
figure(3)
subplot(2,1,1)
plot(whole_time_array(end-10:end),bankBalance_no_hedge(:,end-10:end),'r')
ylabel('Bank balance'); xlabel('Time [year]')
box off; set(gcf,'color','white')
 
subplot(2,1,2)
plot(whole_time_array(end-10:end),bankBalance_dynamic_hedge(:,end-10:end),'b'); hold on
ylabel('Bank balance'); xlabel('Time [year]')
box off; set(gcf,'color','white')
 
 
figure(4)
histfit(S_paths(:,end),15,'lognormal')
xlabel('Stock price, when option matures'); ylabel('Frequency')
box off; set(gcf,'color','white')
 
figure(5)
PnLs = bankBalance_dynamic_hedge(:,end);
histogram(PnLs,20,'Normalization','probability')
confidence_level = 0.95;
sorted_returns = sort(PnLs);
num_returns = numel(PnLs);
VaR_index = ceil((1-confidence_level)*num_returns);
VaR = sorted_returns(VaR_index);
xlabel('Bank balance, dynamic hedge'); ylabel('Probability')
box off; set(gcf,'color','white')
title(['Mean = ',num2str(mean(PnLs)),'; 95% VaR = ',num2str(VaR)])
 
figure(6)
PnLs = bankBalance_no_hedge(:,end);
histogram(PnLs,20,'Normalization','probability')
confidence_level = 0.95;
sorted_returns = sort(PnLs);
num_returns = numel(PnLs);
VaR_index = ceil((1-confidence_level)*num_returns);
VaR = sorted_returns(VaR_index);
xlabel('Bank balance, no hedge'); ylabel('Probability')
box off; set(gcf,'color','white')
title(['Mean = ',num2str(mean(PnLs)),'; 95% VaR = ',num2str(VaR)])
 
function S = GBM_stock(N_paths, N_steps, T_sim, mu, sigma, S0)
dt = T_sim/N_steps;
drift = (mu - 0.5*sigma^2)*dt;
S = S0*ones(N_paths, N_steps+1);
brownian = sigma*sqrt(dt)*normrnd(0,1,N_paths, N_steps);
S(:, 2:end) = S0*exp(cumsum(drift + brownian, 2));
end
