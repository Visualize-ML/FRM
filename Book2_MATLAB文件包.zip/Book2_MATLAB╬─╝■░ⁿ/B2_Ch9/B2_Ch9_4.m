% B2_Ch9_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
price = hist_stock_data('01012015','31052019',...
    'GM','F','MCD','IBM','^GSPC');
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');

GM_price = price(1).AdjClose;
Ford_price = price(2).AdjClose;
McDon_price = price(3).AdjClose;
IBM_price = price(4).AdjClose;
SP500_price = price(5).AdjClose;
 
GM_daily_log_return=diff(log(GM_price))*100;
% also price2ret can be used
Ford_daily_log_return=diff(log(Ford_price))*100;
McDon_daily_log_return=diff(log(McDon_price))*100;
IBM_daily_log_return=diff(log(IBM_price))*100;
SP500_daily_log_return=diff(log(SP500_price))*100;
%%
 
Ford_std=std(Ford_daily_log_return);
IBM_std=std(IBM_daily_log_return);
McDon_std=std(McDon_daily_log_return);
GM_std=std(GM_daily_log_return);
SP500_std=std(SP500_daily_log_return);
 
figure(1)
c = categorical({'Ford','IBM','MCD','GM','S&P500'});
c = reordercats(c,{'Ford','IBM','MCD','GM','S&P500'});
std_array = [Ford_std,IBM_std,McDon_std,GM_std,SP500_std];
bar(c, std_array, 'BarWidth', 0.4)
ylabel('Volatility')
text(1:length(std_array),std_array,num2str(std_array', '%0.3f')...
    ,'vert','bottom','horiz','center'); 
box off
 
figure(2)
A = SP500_daily_log_return;
rho_Ford = corrcoef(A,Ford_daily_log_return);
rho_IBM = corrcoef(A,IBM_daily_log_return);
rho_McDon = corrcoef(A,McDon_daily_log_return);
rho_GM = corrcoef(A,GM_daily_log_return);
c_rho = categorical({'Ford','IBM','MCD','GM'});
c_rho = reordercats(c_rho,{'Ford','IBM','MCD','GM'});
rho_array = [rho_Ford(2,1),rho_IBM(2,1),rho_McDon(2,1),rho_GM(2,1)];
bar(c_rho, rho_array, 'BarWidth', 0.4)
ylabel('Correlation with S&P 500')
text(1:length(rho_array),rho_array,num2str(rho_array', '%0.3f')...
    ,'vert','bottom','horiz','center'); 
box off
 
 
figure(3)
beta_array = rho_array.*std_array(1:4)/std_array(5);
bar(c_rho, beta_array, 'BarWidth', 0.4)
ylabel('Beta with S&P 500')
text(1:length(beta_array),beta_array,num2str(beta_array', '%0.3f')...
    ,'vert','bottom','horiz','center'); 
box off
 
Ford_std=std(Ford_daily_log_return);
IBM_std=std(IBM_daily_log_return);
McDon_std=std(McDon_daily_log_return);
GM_std=std(GM_daily_log_return);
SP500_std=std(SP500_daily_log_return);
 
A = [Ford_daily_log_return IBM_daily_log_return ...
     McDon_daily_log_return GM_daily_log_return ...
     SP500_daily_log_return];
R = corrcoef(A)
 
figure(4)
 
xvalues = {'Ford','IBM','MCD','GM','S&P500'};
yvalues = {'Ford','IBM','MCD','GM','S&P500'};
h = heatmap(xvalues,yvalues,R);
 
h.Title = 'Correlations of log returns';
set(gcf,'color','white')
 
%% Correlations
 
figure(5)
 
subplot(2,2,1)
x = SP500_daily_log_return;
y = Ford_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
beta = X\y; yCalc2 = X*beta;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('S%P 500 (%)'); ylabel('Ford (%)')
title(['\beta = ',num2str(beta(2))])
 
subplot(2,2,2)
x = SP500_daily_log_return;
y = IBM_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
beta = X\y; yCalc2 = X*beta;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('S&P 500 (%)'); ylabel('IBM (%)')
title(['\beta = ',num2str(beta(2))])
 
subplot(2,2,3)
x = SP500_daily_log_return;
y = McDon_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
beta = X\y; yCalc2 = X*beta;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('S&P 500 (%)'); ylabel('McDonald (%)')
set(gcf,'color','white')
title(['\beta = ',num2str(beta(2))])
 
subplot(2,2,4)
x = SP500_daily_log_return;
y = GM_daily_log_return;
scatter(x,y,'.'); hold on
format long; X = [ones(length(x),1) x];
beta = X\y; yCalc2 = X*beta;
plot(x,yCalc2,'r')
xlim([-10,10]); ylim([-10,10])
xlabel('S&P 500 (%)'); ylabel('GM (%)')
set(gcf,'color','white')
title(['\beta = ',num2str(beta(2))])
