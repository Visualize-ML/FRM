% B2_Ch9_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
% Step 1: define three bonds
 
Settle     = '19-Aug-1999'; % analysis date
Maturity   = ['17-Jun-2010'; '09-Jun-2015'; '14-May-2025'];
Face       = [100; 100; 1000];
CouponRate = [0.07; 0.06; 0.045];
 Yields = [0.05; 0.06; 0.065];
 
% Step 2: calculate price, duration, and convexity
 
[CleanPrice, AccruedInterest] = bndprice(Yields, CouponRate,...
    Settle, Maturity, 2, 0, [], [], [], [], [], Face);
 
Durations = bnddury(Yields, CouponRate, Settle, Maturity, 2, 0,...
    [], [], [], [], [], Face);
 
Convexities = bndconvy(Yields, CouponRate, Settle, Maturity, 2, 0,...
    [], [], [], [], [], Face);
 
Prices  =  CleanPrice + AccruedInterest;
 
 
% Step 3: duration and convexity of the portfolio
 
Portfolio_original_price   = 1000;
% Total portfolio value
PortfolioWeights = ones(3,1)/3;
% Equal weights
PortfolioAmounts   = Portfolio_original_price * PortfolioWeights ./ Prices;
PortfolioDuration  = PortfolioWeights' * Durations;
PortfolioConvexity = PortfolioWeights' * Convexities;
 
% Step 4: yield curve shift
 
dY_array = -0.02:0.001:0.02;
PriceApprox1 = ones(size(dY_array));
PriceApprox2 = ones(size(dY_array));
NewPrice = ones(size(dY_array));
 
for i = 1:length(dY_array)
    
    dY = dY_array(i);
    
    PercentApprox1 = -PortfolioDuration * dY * 100;
    
    PercentApprox2 =  PercentApprox1 + ...
        PortfolioConvexity*dY^2*100/2.0;
    
    % Step 5: approximate portfolio value
    
    PriceApprox1(i)  =  Portfolio_original_price + ...
        PercentApprox1 * Portfolio_original_price/100;
    
    PriceApprox2(i)  =  Portfolio_original_price + ...
        PercentApprox2 * Portfolio_original_price/100;
    
    % Step 6: Calculate the true new portfolio price by shifting the yield curve.
    
    [CleanPrice, AccruedInterest] = bndprice(Yields + dY,...
        CouponRate, Settle, Maturity, 2, 0, [], [], [], [], [],Face);
    
    NewPrice(i) = PortfolioAmounts' * (CleanPrice + AccruedInterest);
    
end
 
figure(1)
plot(dY_array,NewPrice); hold on
plot(dY_array,PriceApprox1); hold on
plot(dY_array,PriceApprox2); hold on
plot(0,Portfolio_original_price,'ok')
legend('Analytical','Duration','Duration-convexity')
ax = gca; ax.XAxis.Exponent = 0; box off
xlabel('Yield curve shift'); ylabel('Value [USD]')
 
figure(2)
subplot(1,2,1)
error_D = PriceApprox1 - NewPrice;
 
plot(dY_array, error_D,'LineWidth',2); hold on
plot(0, 0, 'ok'); ylim([-40,5])
xlabel('Yield curve shift'); ylabel('Error [USD]'); 
box off; grid off; title('Duration approx.')
set(gca, 'XAxisLocation', 'origin')
 
subplot(1,2,2)
error_D_C = PriceApprox2 - NewPrice;
plot(dY_array, error_D_C,'LineWidth',2); hold on
plot(0, 0, 'ok'); ylim([-40,5]); xlabel('Yield curve shift')
ylabel('Error [USD]'); box off; grid off
title('Duration-convexity approx.')
set(gca, 'XAxisLocation', 'origin')
