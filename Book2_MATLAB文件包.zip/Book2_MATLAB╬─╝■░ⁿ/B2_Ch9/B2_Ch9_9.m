% B2_Ch9_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

n = 1:100;
rho = [0,0.1,0.2]';
nn = repmat(n,size(rho));
rhorho = repmat(rho,size(n));
 
vol_p = sqrt((1 + (nn-1).*rhorho)./nn);
figure(1)
plot(n,vol_p)
xlabel('Number of assets');  box off
ylabel('Volatility of portfolio')
ylim([0,1])
