% B2_Ch9_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
% source: openExample('finance/PlottingSensitivitiesofaPortfolioofOptionsExample')
 
stock_array = 20:90;
% Stock price; unit: USD
stock_length = length(stock_array);
strike_array = [75 70 50 55 75 50 40 75 60 35];
% Strike prices for different call options
% Number of types of call options: strike_array(strike_array)
 
time_to_maturity = [36  30  27  24  21  18  15  12  9  6];
% Time to maturities for each call option
num_options = [4  8  3  5  6  12  8  3  11  7];
% Number of call options in the portfolio
sigmas = 0.35*ones(10,1);
risk_free_rates = 0.1*ones(10,1);
 
all_Gammas = zeros(36, stock_length);
all_Deltas = zeros(36, stock_length);
all_Prices = zeros(36, stock_length);
 
for i = 1:length(strike_array)
    all_ones = ones(time_to_maturity(i),stock_length);
    NewR = stock_array(ones(time_to_maturity(i),1),:);
    
    T_2_t = (1:time_to_maturity(i))';
    T_2_t_matrix = T_2_t(:,ones(stock_length,1));
    
    [additional_prices,~] = blsprice(NewR, strike_array(i)*all_ones, ...
        risk_free_rates(i)*all_ones, T_2_t_matrix/36, sigmas(i)*all_ones);
    
    all_Prices(36-time_to_maturity(i)+1:36,:) = all_Prices(36-time_to_maturity(i)+1:36,:) ...
        + num_options(i) * additional_prices;
    
    additional_deltas = blsdelta(NewR, strike_array(i)*all_ones, ...
        risk_free_rates(i)*all_ones, T_2_t_matrix/36, sigmas(i)*all_ones);
    
    all_Deltas(36-time_to_maturity(i)+1:36,:) = all_Deltas(36-time_to_maturity(i)+1:36,:) ...
        + num_options(i) * additional_deltas;
    
    additional_gammas = blsgamma(NewR, strike_array(i)*all_ones, ...
        risk_free_rates(i)*all_ones, T_2_t_matrix/36, sigmas(i)*all_ones);
    
    all_Gammas(36-time_to_maturity(i)+1:36,:) = all_Gammas(36-time_to_maturity(i)+1:36,:) ...
        + num_options(i) * additional_gammas;
    
end
 
figure(1)
mesh(stock_array, 1:36, all_Prices);
view(60,60); set(gca, 'xdir','reverse');
axis([20 90  0 36  -inf inf]);
 
title('Value of option portfolio');
xlabel('Stock Price ($)'); ylabel('Time (months)');
zlabel('Value'); box off; grid off; colorbar('horiz');
 

figure(2)
mesh(stock_array, 1:36, all_Deltas);
view(60,60); set(gca, 'xdir','reverse');
axis([20 90  0 36  -inf inf]);
 
title('Delta of option portfolio');
xlabel('Stock Price ($)'); ylabel('Time (months)');
zlabel('Delta'); box off; grid off; colorbar('horiz');
 
 
figure(3)
mesh(stock_array, 1:36, all_Gammas);
view(60,60); set(gca, 'xdir','reverse');
axis([20 90  0 36  -inf inf]);
 
title('Gamma of option portfolio');
xlabel('Stock Price ($)'); ylabel('Time (months)');
zlabel('Gamma'); box off; grid off; colorbar('horiz');
