% B2_Ch1_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B2_Ch1_2_A.m
clc; clear all; close all

url = 'https://fred.stlouisfed.org/';
c = fred(url);
series = 'SP500';
startdate = '01/01/2009';
% beginning of date range for historical data
enddate = now; % to be updated
% ending of date range for historical data

d = fetch(c,series,startdate,enddate)
% display description of data structure

%% Prepare data for daily SP500

SP500 = d.Data(:,2);
date_series = d.Data(:,1);

SP500_nan_removed = SP500; % delete NaN

SP500_nan_removed(any(isnan(SP500),2),:) = [];

date_series_nan_removed  = date_series; % delete NaN

date_series_nan_removed(any(isnan(SP500),2),:) = [];

%% Index, vs, log return, vs log return squared

[daily_log_return,interval] = tick2ret (SP500_nan_removed,...
    date_series_nan_removed,'Continuous');
daily_log_return = [NaN; daily_log_return];

index = 1;
figure(index)
index = index + 1;

% plot index
subplot(3,1,1)
plot(date_series_nan_removed, SP500_nan_removed)
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(1)-1,date_series_nan_removed(end)+1])
ylim([0,max(SP500)*1.1])
xlabel('Year')
ylabel('S&P 500 index')
set(gcf,'color','white')

% plot daily log return
subplot(3,1,2)
plot(date_series_nan_removed, daily_log_return); hold on
x = date_series_nan_removed;
y = 0;
plot(x,y*ones(size(x)),'r','LineWidth',2)
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(1)-1,date_series_nan_removed(end)+1])
ylim([min(daily_log_return)*1.1,max(daily_log_return)*1.1])
xlabel('Year')
ylabel('Daily log return')
set(gcf,'color','white')

% plot daily log return squared
subplot(3,1,3)
daily_log_return_squared = daily_log_return.^2;
plot(date_series_nan_removed, daily_log_return_squared);
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(1)-1,date_series_nan_removed(end)+1])
ylim([0,max(daily_log_return_squared)*1.1])
xlabel('Year')
ylabel('Daily log return squared')
set(gcf,'color','white')

% B2_Ch1_2_B.m
%%  Moving average volatility, no demean
% Sometimes called realized volatility or
% simple moving average (SMA)

annual_moving_vol_no_demean = [];
annual_moving_vol_with_demean = [];

NN = length(daily_log_return);

for i = 1:NN-251
    
    % Get standard deviation of that change
    daily_moving_vol_no_demean(i) = ...
        nanstd(daily_log_return(i:i + 249));
    
    mean_temp = nanmean(daily_log_return(i:i + 249));
    
    daily_moving_vol_with_demean(i) = ...
        nanstd(daily_log_return(i:i + 249) - mean_temp);
    
    % Now normalize to annual volatility, square root rule
    annual_moving_vol_no_demean(i) = ...
        daily_moving_vol_no_demean(i)*sqrt(250);
    
    annual_moving_vol_with_demean(i) = ...
        daily_moving_vol_with_demean(i)*sqrt(250);
    
end

figure (index)
index = index + 1;

subplot(2,1,1)

plot(date_series_nan_removed(252:end),...
    daily_log_return_squared(252:end)); hold on
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(250),date_series_nan_removed(end)])
ylim([0,max(daily_log_return_squared)*1.1])
xlabel('Year')
ylabel('Daily log return squared')
set(gcf,'color','white')

subplot(2,1,2)
plot (date_series_nan_removed(252:end),daily_moving_vol_no_demean*100)
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(250),date_series_nan_removed(end)])
ylim([0,max(daily_moving_vol_no_demean)*110])
xlabel('Year')
ylabel('MA daily volatility [%]')
set(gcf,'color','white')


figure (index)
index = index + 1;

subplot(2,1,1)

plot(date_series_nan_removed(252:end), daily_log_return_squared(252:end))
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(250),date_series_nan_removed(end)])
ylim([0,max(daily_log_return_squared)*1.1])
xlabel('Year')
ylabel('Daily log return squared')
set(gcf,'color','white')

subplot(2,1,2)
plot (date_series_nan_removed(252:end),annual_moving_vol_no_demean*100)
datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(250),date_series_nan_removed(end)])
ylim([0,max(annual_moving_vol_no_demean)*110])
xlabel('Year')
ylabel('MA annual volatility [%]')
set(gcf,'color','white')


% B2_Ch1_2_C.m

figure (index)
index = index + 1;
past_2_yr = date_series_nan_removed(end-252*2:end);
log_r_past_2_yr = daily_log_return(end-252*2:end);
sigma_past_2_yr = annual_moving_vol_no_demean(end-252*2:end)'./sqrt(252);
mask = (-2*sigma_past_2_yr <= log_r_past_2_yr) & (log_r_past_2_yr <= 2*sigma_past_2_yr);
mask_within_95 = double(mask);
mask_outside_95 = 1 - double(mask);
mask_within_95(mask_within_95 == 0) = NaN;
mask_outside_95(mask_outside_95 == 0) = NaN;

plot(past_2_yr, log_r_past_2_yr.*mask_within_95,'.b'); hold on
plot(past_2_yr, log_r_past_2_yr.*mask_outside_95,'xr'); hold on
plot(past_2_yr, 2*sigma_past_2_yr); hold on
plot(past_2_yr, -2*sigma_past_2_yr); hold on

datetick('x','yyyy','keeplimits')
xlim([past_2_yr(1),past_2_yr(end)])
ylim([min(log_r_past_2_yr)*1.1,max(log_r_past_2_yr)*1.1])
xlabel('Year')
ylabel('Daily log return')
legend('Within 95%','Outside 95%','+ 2\sigma','- 2\sigma')
set(gcf,'color','white')
box off;

% B2_Ch1_2_D.m
%% Study of decay factor

LAMBDAs = [1, 0.99, 0.94, 0.9];

EstimationWindowSize = 250;

decay_depth = [EstimationWindowSize-1:-1:0]';
WEIGHTs = [];
WEIGHTs = ones(EstimationWindowSize,1);

for jj = 1:length(LAMBDAs)
    
    lambda = LAMBDAs(jj);
    
    if lambda == 1
        WEIGHTs_series(jj,:) = WEIGHTs./EstimationWindowSize;
        
    else
        WEIGHTs_series(jj,:)  = (1 - lambda)/(1 - ...
            lambda^EstimationWindowSize).*lambda.^decay_depth;
        
    end
    
end

figure (index)
index = index + 1;

plot(WEIGHTs_series(1,:)); hold on
plot(WEIGHTs_series(2,:)); hold on
plot(WEIGHTs_series(3,:)); hold on
plot(WEIGHTs_series(4,:)); hold on


legend('\lambda = 1 (no decay)','\lambda = 0.99',...
    '\lambda = 0.94','\lambda = 0.9')

title('Study of decay factors')
xlabel('Data point (day)')
ylabel('Weight')
xlim([1,250])
ylim([0,0.1])

figure (index)
index = index + 1;

equal_weighted_r2 = daily_log_return_squared(end - ...
    EstimationWindowSize + 1:end).*WEIGHTs_series(1,:)';

EWMA_weighted_r2 = daily_log_return_squared(end - ...
    EstimationWindowSize + 1:end).*WEIGHTs_series(3,:)';

subplot(2,1,1)
plot(date_series_nan_removed(end - EstimationWindowSize ...
    + 1:end),equal_weighted_r2,'.')
datetick('x','yyyy/mmm','keeplimits')
xlim([date_series_nan_removed(end - EstimationWindowSize + 1)...
    ,date_series_nan_removed(end)])
ylim([0,max(EWMA_weighted_r2)*1.1])
xlabel('Year')
ylabel('Log r squared*equal weight')
set(gcf,'color','white')


subplot(2,1,2)
plot(date_series_nan_removed(end - EstimationWindowSize ...
    + 1:end),EWMA_weighted_r2,'.')
datetick('x','yyyy/mmm','keeplimits')
xlim([date_series_nan_removed(end - EstimationWindowSize + 1)...
    ,date_series_nan_removed(end)])
ylim([0,max(EWMA_weighted_r2)*1.1])
xlabel('Year')
ylabel('Log r squared*EWMA weight')
set(gcf,'color','white')

% B2_Ch1_2_E.m

lambda = [0.9:0.01:0.99];
n_half_life = ceil(log(1/2)./log(lambda));
figure(1)
plot(lambda,n_half_life,'o'); hold on
str = string(n_half_life);
textscatter(lambda,5 + n_half_life,str);
xlabel('\lambda'); ylabel('Days [lags] for half-life')
box off

tol = 0.01;
n_1_percent_tol = ceil(log(tol)./log(lambda));
figure(2)
plot(lambda,n_1_percent_tol,'o'); hold on
str = string(n_1_percent_tol);
textscatter(lambda,20 + n_1_percent_tol,str);
xlabel('\lambda'); ylabel('Days [lags] for 1% tolerance')
box off

% B2_Ch1_2_F.m
%% EWMA volatility, decay factor lambda
% weight of current data = 1 - lambda

LAMBDA = [1, 0.99, 0.94, 0.9];
annual_moving_EWMA_volatility = [];

for k = 1:length(LAMBDA)
    
    lambda = LAMBDA(k);
    
    NN = length(daily_log_return);
    
    for i = 1:NN - 249
        
        Y=EWMASTD(daily_log_return(i:i + 249),lambda);
        % EWMASTD, is a self-defined function
        
        % Now normalize to annual volatility
        daily_moving_EWMA_volatility(i,k) = Y;
        annual_moving_EWMA_volatility(i,k) = Y*sqrt(250);
        
    end
    
    figure (index)
    index = index + 1;
    
    yyaxis left
    
    plot(date_series_nan_removed(250:end), ...
        daily_log_return_squared(250:end))
    datetick('x','yyyy','keeplimits')
    xlim([date_series_nan_removed(250),...
        date_series_nan_removed(end)])
    ylim([0,max(daily_log_return_squared)*1.1])
    ylabel('Daily log return squared')
    set(gcf,'color','white')
    
    yyaxis right
    plot (date_series_nan_removed(250:end),...
        annual_moving_EWMA_volatility(:,k)*100)
    datetick('x','yyyy','keeplimits')
    xlim([date_series_nan_removed(250),...
        date_series_nan_removed(end)])
    ylim([0,0.55*110])
    xlabel('Year')
    ylabel('Yearly EWMA volatility [%]')
    set(gcf,'color','white')
    line1 = ['EWMA conditional volatility: lambda = '...
        ,num2str(lambda)];
    if lambda == 1
        line2 = ['No decay']
    else
        line2 = ['Weight on current data: 1 - lambda = ' ...
            ,num2str(1 - lambda)];
    end
    title({line1,line2})
    
end

%% compare volatilities

figure (index)
index = index + 1;

plot (date_series_nan_removed(250:end),...
    daily_moving_EWMA_volatility(:,1)*100); hold on
plot (date_series_nan_removed(250:end),...
    daily_moving_EWMA_volatility(:,2)*100); hold on
plot (date_series_nan_removed(250:end),...
    daily_moving_EWMA_volatility(:,3)*100); hold on

legend('\lambda = 1 (no decay)','\lambda = 0.99',...
    '\lambda = 0.94')

datetick('x','yyyy','keeplimits')
xlim([date_series_nan_removed(250),date_series_nan_removed(end)])
ylim([0,0.035*110]); xlabel('Year')
ylabel('Daily EWMA volatility [%]'); set(gcf,'color','white')


% B2_Ch1_2_G.m
%%
index = index + 1;
figure(index)
past_2_yr = date_series_nan_removed(end-252*2:end);
log_r_past_2_yr = daily_log_return(end-252*2:end);
sigma_past_2_yr = daily_moving_EWMA_volatility(end-252*2:end,3);
mask = (-2*sigma_past_2_yr <= log_r_past_2_yr) & (log_r_past_2_yr <= 2*sigma_past_2_yr);
mask_within_95 = double(mask);
mask_outside_95 = 1 - double(mask);
mask_within_95(mask_within_95 == 0) = NaN;
mask_outside_95(mask_outside_95 == 0) = NaN;

plot(past_2_yr, log_r_past_2_yr.*mask_within_95,'.b'); hold on
plot(past_2_yr, log_r_past_2_yr.*mask_outside_95,'xr'); hold on
plot(past_2_yr, 2*sigma_past_2_yr); hold on
plot(past_2_yr, -2*sigma_past_2_yr); hold on

datetick('x','yyyy','keeplimits')
xlim([past_2_yr(1),past_2_yr(end)])
ylim([min(log_r_past_2_yr)*1.2,max(log_r_past_2_yr)*1.2])
xlabel('Year'); ylabel('Daily log return')
legend('Within 95%','Outside 95%','+ 2\sigma','- 2\sigma')
set(gcf,'color','white')
box off;

%% sub-function

function Sigma=EWMASTD(returns,lambda)

EstimationWindowSize = 250;
decay_depth = [EstimationWindowSize-1:-1:0]';
WEIGHTs = [];
WEIGHTs = ones(EstimationWindowSize,1);

if lambda == 1
    WEIGHTs = WEIGHTs./EstimationWindowSize;
    
else
    WEIGHTs = (1 - lambda)/(1 - lambda^EstimationWindowSize).*...
        lambda.^decay_depth;
    
end

XX = returns.*returns;
Sigma2 = sum(WEIGHTs.*XX);
Sigma = sqrt(Sigma2);

end

