% B2_Ch1_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 2  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
series = 'SP500';
startdate = '01/01/2008'; 
% beginning of date range for historical data
enddate = now; % to be updated
% ending of date range for historical data
 
d = fetch(c,series,startdate,enddate)
% display description of data structure
 
%% Plot daily SP500
SP500 = d.Data(:,2);
date_series = d.Data(:,1);
 
index = 1;
figure(index)
index = index + 1;
plot(date_series, SP500)
datetick('x','yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([0,max(SP500)*1.1])
xlabel('Year')
ylabel('S&P 500 index')
set(gcf,'color','white')


% B2_Ch1_1_B.m
%% Profit and Loss
 
PnL = diff(SP500);
PnL = [NaN; PnL];
% If X is a vector of length m, then Y = diff(X) returns 
% a vector of length m-1. The elements of Y are the 
% differences between adjacent elements of X.
% Y = [X(2)-X(1) X(3)-X(2) ... X(m)-X(m-1)]
 
figure(index)
index = index + 1;
plot(date_series, PnL,'.'); hold on
plot(date_series,0*PnL,'LineWidth',2)
datetick('x','yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(PnL)*1.1,max(PnL)*1.1])
xlabel('Year')
ylabel('S&P 500 daily P&L')
set(gcf,'color','white')
 
figure (index)
index = index + 1;
 
subplot (1,2,1)
histogram(PnL,50);
xlabel('Daily P&L')
ylabel('Number of occurrences')
 
subplot(1,2,2)
% Plot histogram with 100 bins together with normal fit
histfit(PnL,50);
xlabel('Daily P&L')
ylabel('Number of occurrences')
set(gcf,'color','white')

% B2_Ch1_1_C.m
%% Four moments of PnL
PnL(isnan(PnL)) = [];
disp(['Mean value of PnL: ', num2str(mean(PnL))])
 
disp(['Variance of PnL: ', num2str(var(PnL))])
 
disp(['Standard deviation of PnL: ', num2str(std(PnL))])
 
disp(['Skewness of PnL: ', num2str(skewness(PnL))])

disp(['Kurtosis of PnL: ', num2str(kurtosis(PnL))])
 
% Please also try m = moment(X,order), which returns the central 
% sample moment of X specified by the positive integer order

%% Daily log and simple returns
 
[daily_log_return,interval] = tick2ret (SP500, date_series,...
'Continuous');
 
[daily_simple_return,interval] = tick2ret (SP500, ...
date_series,'Simple');
 
% If Method is unspecified or 'Simple', the returns are:
% RetSeries(i) = TickSeries(i+1)/TickSeries(i) - 1
% If Method is 'Continuous', the returns are:
% RetSeries(i) = log[TickSeries(i+1)/TickSeries(i)]
% ranked_log_return = sort(daily_log_return); % sort returns
 
figure (index)
index = index + 1;
 
subplot(1,2,1)
plot(date_series(2:end), daily_log_return*100,'.'); hold on
% yline(0) % 2018b, new function to draw a reference line
x = date_series(2:end);
y = 0;
plot(x,y*ones(size(x)),'LineWidth',2)
datetick('x','yyyy','keeplimits')
xlim([date_series(2),date_series(end)])
ylim([min(daily_log_return)*110,max(daily_log_return)*110])
xlabel('Year')
ylabel('Daily log return [%]')
set(gcf,'color','white')
 
subplot(1,2,2)
plot(date_series(2:end), daily_simple_return*100,'.'); hold on
plot(x,y*ones(size(x)),'LineWidth',2)
datetick('x','yyyy','keeplimits')
xlim([date_series(2),date_series(end)])
ylim([min(daily_log_return)*110,max(daily_log_return)*110])
xlabel('Year')
ylabel('Daily simple return [%]')
set(gcf,'color','white')

% B2_Ch1_1_D.m
%% Four moments of daily log returns
daily_log_return(isnan(daily_log_return)) = [];
disp(['Mean value of log_r: ', num2str(mean(daily_log_return))])
% Please also try nanmean()
% y = nanmean(X) returns the mean of the elements of X, 
% computed after removing all NaN values.
 
disp(['Variance of log_r: ', num2str(var(daily_log_return))])
% please also try nanvar
% y = nanvar(X) is the variance var of X, 
% computed after removing NaN values.
 
disp(['Standard deviation of PnL: ', num2str(std(daily_log_return))])
% y = nanstd(X) is the standard deviation std of X, 
% computed after removing all NaN values.
 
disp(['Skew of log_r: ', num2str(skewness(daily_log_return))])
 
disp(['Kurt of log_r: ', num2str(kurtosis(daily_log_return))])

% B2_Ch1_1_E.m
%% Histogram, daily log return
 
figure (index)
index = index + 1;
 
subplot (1,2,1)
histogram(daily_log_return*100,50);
xlim([-8,8])
xlabel('Daily log return [%]')
ylabel('Frequency')
 
subplot(1,2,2)
% Plot histogram with 100 bins together with normal fit
histfit(daily_log_return*100,50);
xlim([-8,8])
xlabel('Daily log return [%]')
ylabel('Frequency')
set(gcf,'color','white')
 
 
figure (index)
index = index + 1;
 
% Plot histogram with 100 bins together with normal fit
histfit(daily_log_return*100,100);
xlim([-8,-2])
xlabel('Daily log return [%]')
ylabel('Frequency')
set(gcf,'color','white')
title('Fat tail of S&P 500 daily return')

% B2_Ch1_1_F.m
%% Fat tail CDF, daily log return
 
figure (index)
index = index + 1;
 
subplot (1,2,1)
 
[F,yi] = ecdf(daily_log_return*100); 
% empirical CDF
% [f,x] = ecdf(y) returns the empirical cumulative distribution function
% (cdf), f, evaluated at the points in x, using the data in the vector y.
stairs(yi,F,'r'); hold on;
axis([-8 8 0 1]);
xlabel('Daily log return [%]')
ylabel('CDF')
fitted_cdf = normcdf(yi,nanmean(daily_log_return*100),...
nanstd(daily_log_return*100));

plot(yi,fitted_cdf,'-'); % fitted normal
hold off; % cumulative distribution function (cdf)
legend('Empirical','Gaussian','location','northwest');
set(gcf,'color','white')
subplot (1,2,2)
 
stairs(yi,F,'r'); hold on;
axis([-7 -2 0 0.04]);
 
plot(yi,normcdf(yi,nanmean(daily_log_return*100),...
nanstd(daily_log_return*100)),'-'); 
% fitted normal
hold off; % cumulative distribution function (cdf)
xlabel('Daily log return [%]')
ylabel('CDF')
legend('Empirical','Gaussian','location','northwest');
set(gcf,'color','white')

% B2_Ch1_1_G.m
%% QQ Plot, daily log returns
 
figure (index)
index = index + 1;
 
subplot(1,2,1)
qqplot(daily_log_return*100)
xlabel('Normal distribution')
ylabel('Distribution of log return')
 
% QQ plot versus t distribution with
nu = 3.2; % to be updated
subplot(1,2,2)
qqplot(daily_log_return*100,...
trnd(nu,length(daily_log_return*100),1))

set(gcf,'color','white')
xlabel(['Student t distribution, \nu = ',num2str(nu)])
ylabel('Distribution of log return')

% B2_Ch1_1_H.m
%% Autocorrelation of log returns

figure (index)
index = index + 1;

autocorr(daily_log_return)

%% Autocorrelation of log returns squared

figure (index)
index = index + 1;

autocorr(daily_log_return.^2)

% B2_Ch1_1_I.m
%% Weekly log return
 
% daily_log_return=diff(log(SP500))*100;
day_lag = 5;
log_SP500 = log(SP500);
wkly_log_return = log_SP500(1+day_lag:end) - ...
 log_SP500(1:end-day_lag);
 
figure (index)
index = index + 1;
 
plot(date_series(1+day_lag:end), wkly_log_return*100,'.'); 
hold on
plot(x,y*ones(size(x)),'LineWidth',2)
datetick('x','yyyy','keeplimits')
xlim([date_series(2),date_series(end-day_lag)])
ylim([min(wkly_log_return)*110,max(wkly_log_return)*110])
xlabel('Year')
ylabel('Weekly log return [%]')
set(gcf,'color','white')


% B2_Ch1_1_J.m
%% Overlapping weekly return vs non-overlapping
 
WK_days = [1:5];
 
STDs = [nanstd(wkly_log_return)];
acf = autocorr(wkly_log_return);
AutoCORRs_lag1 = [acf(2)]; AutoCORRs_lag2 = [acf(3)];
 
for i = 1:length(WK_days)
    
    wk_d = WK_days(i);
    non_overlap_wkly = wkly_log_return(wk_d:5:end);
    wk_d_std = nanstd(non_overlap_wkly);
    acf = autocorr(non_overlap_wkly);
    
    STDs = [STDs,wk_d_std];
    AutoCORRs_lag1 = [AutoCORRs_lag1,acf(2)];
    AutoCORRs_lag2 = [AutoCORRs_lag2,acf(3)];
    
end
 
figure (index)
index = index + 1;
stem(STDs); xlabel('Case');ylabel('Standard deviation')
xlim([0.5,6.5])
x_labels = {'Overlapped','Mon-Mon','Tue-Tue',...
    'Wed-Wed','Thu-Thu','Fri-Fri'}
set(gca,'XTickLabel',x_labels) 
title('Comparing standard deviation')
 
figure (index)
index = index + 1;
autocorr(wkly_log_return)
 
figure (index)
index = index + 1;
autocorr(non_overlap_wkly) % Fri-Fri
 
figure (index)
index = index + 1;
subplot(2,1,1)
stem(AutoCORRs_lag1); 
xlabel('Case');ylabel('1-lag autocorrelation')
xlim([0.5,6.5])
x_labels = {'Overlapped','Mon-Mon','Tue-Tue',...
    'Wed-Wed','Thu-Thu','Fri-Fri'}
set(gca,'XTickLabel',x_labels) 
title('Comparing 1-lag autocorrelation')
 
subplot(2,1,2)
stem(AutoCORRs_lag2); 
xlabel('Case');ylabel('2-lag autocorrelation')
xlim([0.5,6.5])
x_labels = {'Overlapped','Mon-Mon','Tue-Tue',...
    'Wed-Wed','Thu-Thu','Fri-Fri'}
set(gca,'XTickLabel',x_labels) 
title('Comparing 2-lag autocorrelation')


