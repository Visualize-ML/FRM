# B2_Ch1_1.py

###############
# Prepared by Ran An, Wei Lu, and Feng Zhang
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 2  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

B2_Ch1_1_A.py
import numpy as np
import pandas_datareader 

ticker = 'AMZN'
stock = pandas_datareader.data.DataReader(ticker, data_source='yahoo', start='12-21-2020', end='12-28-2020')['Adj Close']
print(stock)

B2_Ch1_1_B.py
# via formula
returns_daily = (stock / stock.shift(1)) - 1
print(returns_daily)

B2_Ch1_1_C.py
# alternative via pct_change() function
returns_daily = stock.pct_change()
print(returns_daily)

B2_Ch1_1_D.py
# log return
log_return_daily = np.log(stock / stock.shift(1))
print(log_return_daily)