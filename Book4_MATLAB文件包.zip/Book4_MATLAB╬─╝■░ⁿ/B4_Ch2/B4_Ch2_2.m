% B4_Ch1_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
 
loc = [0,0,0];
 
figure(1)
x_i = [1,0,0]; y_j = [0,1,0]; z_k = [0,0,1];
plot_vector(loc,x_i); hold on
plot_vector(loc,y_j);
plot_vector(loc,z_k);
fig_dec
 
figure(2)
plot_vector(loc,x_i); hold on
plot_vector(loc,y_j);
plot_vector(loc,z_k);
plot_vector(loc,x_i+y_j); hold on
plot_vector(loc,x_i+z_k);
plot_vector(loc,y_j+z_k);
 
fig_dec
 
figure(3)
r     = 0.75;
[x,y,z] = Spherical_grid(r);
 
subplot(1,2,1)
x = x(:); y = y(:); z = z(:);
hold on
for i = 1:length(x)
    plot_vector(loc,[x(i),y(i),z(i)])
end
fig_dec
 
r     = 1;
[x,y,z] = Spherical_grid(r);
 
subplot(1,2,2)
x = x(:);
y = y(:);
z = z(:);
hold on
for i = 1:length(x)
    plot_vector(loc,[x(i),y(i),z(i)])
end
fig_dec
 
steps = [0:0.1:1];
[X,Y,Z] = meshgrid(steps,steps,steps);
figure(4)
scatter3(X(:),Y(:),Z(:),8,[X(:),Y(:),Z(:)],'filled'); hold on
fig_dec
view(115,20);
 
 
function [x_grid,y_grid,z_grid] = Spherical_grid(r)
 
theta = 0:pi/25:pi/2;
phi   = 0:pi/25:pi/2;
[theta,phi] = meshgrid(theta,phi);
x_grid = r.*sin(theta).*cos(phi);
y_grid = r.*sin(theta).*sin(phi);
z_grid = r.*cos(theta);
 
end
function plot_vector(loc,vec)
h = quiver3(loc(1),loc(2),loc(3),...
    vec(1),vec(2),vec(3),'color',vec);
h.AutoScale = 'off';
h.ShowArrowHead = 'off';
end
 
function fig_dec
 
daspect([1,1,1])
box off; view(135,20); axis tight; grid on
xticks([0:0.5:1]); yticks([0:0.5:1]); zticks([0:0.5:1])
xlabel('x, red'); ylabel('y, green'); zlabel('z, blue')
xlim([0,1]);ylim([0,1]);zlim([0,1]);
grid off
hAxis = gca;
hAxis.XRuler.FirstCrossoverValue  = 0; % X crossover with Y axis
hAxis.YRuler.FirstCrossoverValue  = 0; % Y crossover with X axis
hAxis.ZRuler.FirstCrossoverValue  = 0; % Z crossover with X axis
hAxis.ZRuler.SecondCrossoverValue = 0; % Z crossover with Y axis
hAxis.XRuler.SecondCrossoverValue = 0; % X crossover with Z axis
hAxis.YRuler.SecondCrossoverValue = 0; % Y crossover with Z axis
 
end
