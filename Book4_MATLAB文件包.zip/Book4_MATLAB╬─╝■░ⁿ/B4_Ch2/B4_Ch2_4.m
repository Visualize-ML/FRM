% B4_Ch1_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


clc; close all; clear all
 
v = [1;1/2];
 
center = [0,1];
 
t = -2:0.25:10;
x = v(1)*t + center(1);
y = v(2)*t + center(2);
 
X = [0,  0;
     1,  5;
     2, -2;
     4,  6;
     6,  0;
     8, -1;];
 
X_c = X - center;
b   = X_c*v/(v'*v);
X_h = b*v';
X_h = X_h + center;
 
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
plot(x,y); hold on
plot(X(4,1),X(4,2),'xb')
vectors = [x',y'] - [X(4,1),X(4,2)];
h = quiver(X(4,1)+0*vectors(:,1),X(4,2)+0*vectors(:,1)...
    ,vectors(:,1),vectors(:,2),'k');
h.ShowArrowHead = 'off';
h.AutoScale = 'off';
 
daspect([1,1,1])
box off; grid off
 
figure(fig_i)
fig_i = fig_i + 1;
subplot(2,1,1)
vector_length = vecnorm(vectors,2,2);
plot(x,vector_length)
ylim([0,9]); box off
 
subplot(2,1,2)
vector_length = vecnorm(vectors,2,2);
plot(x,vector_length.^2)
box off
 
figure(fig_i)
fig_i = fig_i + 1;
plot(x,y); hold on
plot(X(:,1),X(:,2),'xb')
plot(X_h(:,1),X_h(:,2),'xr')
plot([X(:,1),X_h(:,1)]',[X(:,2),X_h(:,2)]','k')
 
daspect([1,1,1])
box off; grid off
 
%% 3D, project points to a line in space
 
v = [1;1/2;2];
 
center = [0,1,2];
 
t = -2:1:4;
x = v(1)*t + center(1);
y = v(2)*t + center(2);
z = v(3)*t + center(3);
 
X = [0,  0,  0;
     1,  5,  2;
     2, -2,  5;
     4,  6, -1;
     6,  0,  3;
     8, -1,  1;];
 
X_c = X - center;
b   = X_c*v/(v'*v);
X_h = b*v';
X_h = X_h + center;
 
figure(fig_i)
fig_i = fig_i + 1;
plot3(x,y,z); hold on
plot3(X(:,1),X(:,2),X(:,3),'xb')
plot3(X_h(:,1),X_h(:,2),X_h(:,3),'xr')
plot3([X(:,1),X_h(:,1)]',[X(:,2),X_h(:,2)]',[X(:,3),X_h(:,3)]','k')
 
daspect([1,1,1])
box off; grid off
