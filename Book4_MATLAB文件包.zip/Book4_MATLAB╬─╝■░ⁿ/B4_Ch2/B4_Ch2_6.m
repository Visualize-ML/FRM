% B4_Ch1_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


clc; clear all; close all
syms x y
 
x0 = 0; y0 = 0;
r = 2; num = 30;
[xx_fine,yy_fine] = mesh_circ(x0,y0,r,num);
 
A = [1, 0; 0, 1;];
% A = [1, 0; 0, 2;];
% % A = [-1, 0; 0, -2;];
% % A = [1, 0; 0, -1;];
% % A = [0, 1/2; 1/2, 0;];
% A = [1, 0; 0, -1;];
% % A = [0, 1/2; 1/2, 0;];
% % A = [1, 0; 0, 0;];
% % A = [0, 0; 0, -1;];
theta_deg = 0; % please update the theta
theta = deg2rad(theta_deg);
R = [cos(theta), -sin(theta);
     sin(theta),  cos(theta)]
inv_R = inv(R)
A_new = inv_R*A*R
 
f = [x, y]*A_new*[x; y];
simplify(f)
vpa(simplify(f),5)
issymmetric(A_new)
lambdas = eig(A_new)
isposdef = all(lambdas > 0)
 
[~,positive_def_flag] = chol(A_new)
% positive_def_flag
% flag = 0, then the input matrix is symmetric positive definite
 
 
ff_fine = double(subs(f, [x y], {xx_fine,yy_fine}));
 
figure(1)
c_levels =  min(ff_fine(:)):(max(ff_fine(:))-min(ff_fine(:)))/9:max(ff_fine(:));
 
h = mesh(xx_fine,yy_fine,ff_fine); hold on
h.EdgeColor = [1,1,1]/2;
[~,h2] = contour3(xx_fine,yy_fine,ff_fine)
h2.LevelList = c_levels;
h2.LineWidth = 1.25;
grid off; box off
hAxis = gca;
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'ztick',[])
 
xlabel('x');ylabel('y');zlabel('z');
hAxis.XRuler.FirstCrossoverValue  = 0; % X crossover with Y axis
hAxis.YRuler.FirstCrossoverValue  = 0; % Y crossover with X axis
hAxis.ZRuler.FirstCrossoverValue  = 0; % Z crossover with X axis
hAxis.ZRuler.SecondCrossoverValue = 0; % Z crossover with Y axis
hAxis.XRuler.SecondCrossoverValue = 0; % X crossover with Z axis
hAxis.YRuler.SecondCrossoverValue = 0; % Y crossover with Z axis
view(-45,60)
view(-30,90)
xlim([min(xx_fine(:))*1.2,max(xx_fine(:))*1.2])
ylim([min(yy_fine(:))*1.2,max(yy_fine(:))*1.2])
zlim([min(ff_fine(:))-1,max(ff_fine(:))+1])

function [xx,yy] = mesh_circ(x0,y0,r,num)
 
theta = [0:pi/num:2*pi];
r = [0:r/num:r];
 
[theta,r] = meshgrid(theta,r);
 
xx = cos(theta).*r + x0;
yy = sin(theta).*r + y0;
 
end
