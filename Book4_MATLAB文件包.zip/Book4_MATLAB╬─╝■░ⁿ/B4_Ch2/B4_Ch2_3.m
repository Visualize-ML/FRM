% B4_Ch1_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
SIGMA = [5,0;0,1]; 
% SIGMA = [1,0;0,5];
% SIGMA = [3,2;2,3];
% SIGMA = [3,-2;-2,3];
 
num   = 1000;
X = mvnrnd([0,0],SIGMA,num);
sigma = cov(X)
[V_eig_original,LAMBDA_eig_original] = eig(SIGMA)
[V_eig,LAMBDA_eig] = eig(sigma);
[V_pca,Z,LAMBDA_pca] = pca(X);
V_PC1 = V_pca(:,1)*sqrt(LAMBDA_pca(1));
V_PC2 = V_pca(:,2)*sqrt(LAMBDA_pca(2));
centers = mean(X);
center_x = centers(1); center_y = centers(2);
 
figure(1)
plot(X(:,1),X(:,2),'.'); hold on
plot(center_x,center_y,'ok')
h = quiver(center_x,center_y,V_PC1(1),V_PC1(2));
h.AutoScaleFactor = 3;
h = quiver(center_x,center_y,V_PC2(1),V_PC2(2));
h.AutoScaleFactor = 3;
daspect([1,1,1]); xlim([-8,8]); ylim([-8,8]);
xlabel('x_1'); ylabel('x_2')

