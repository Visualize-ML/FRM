% B4_Ch1_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


clc; clear all; close all
 
corr_rho = cos(pi/6);
SIGMA = 3*[1,0;0,1]*[1,corr_rho;corr_rho,1]*[1,0;0,1];
num   = 1000;
 
 
rng('default')
X = mvnrnd([0,0],SIGMA,num);
% R = chol(SIGMA)
% X = mvnrnd([0,0],[1,0;0,1],num);
% X = X*R;
 
X = X - mean(X);
theta = pi*1/12*3;
v1 = [cos(theta);
      sin(theta)];
 
v2 = [-sin(theta);
       cos(theta)];
 
V = [v1,v2];
 
figure(1)
plot(X(:,1),X(:,2),'.'); hold on
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('x_1'); ylabel('x_2')
h = quiver(0,0,v1(1),v1(2));
h.AutoScaleFactor = 3;
h = quiver(0,0,v2(1),v2(2));
h.AutoScaleFactor = 3;
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
 
 
axes_x = [-8, 0;
           8, 0;]*V;
axes_y = [0,  8;
          0, -8;]*V;
 
Z = X*V;
 
figure(2)
plot(Z(:,1),Z(:,2),'.'); hold on
plot(axes_x(:,1)',axes_x(:,2)','k')
plot(axes_y(:,1)',axes_y(:,2)','k')
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('y_1'); ylabel('y_2')
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
h = quiver(0,0,1,0);
h.AutoScaleFactor = 3;
h = quiver(0,0,0,1);
h.AutoScaleFactor = 3;
 
edges = [-8:0.4:8];
 
figure(3)
 
subplot(2,1,1)
histogram(Z(:,1),edges,'Normalization','probability')
xlim([-8,8]); ylim([0,0.35])
ylabel('Probability'); xlabel('y2')
box off; grid off
 
subplot(2,1,2)
histogram(Z(:,2),edges,'Normalization','probability')
xlim([-8,8]); ylim([0,0.35])
ylabel('Probability'); xlabel('y2')
box off; grid off
 
SIGMA_Z = cov(Z);
figure(4)
heatmapHandle = heatmap(SIGMA_Z);
caxis(heatmapHandle,[0 6]);
%% Conversions
 
[n,~] = size(X); % n, number of observations
 
SIGMA = (X.'*X)/(n-1)
 
cov(X)
 
[V_eig,LAMBDA] = eig(SIGMA)
 
[U,S,V_svd] = svd(X);
 
S([1,2],:)
 
S([1,2],:).^2/(n-1)
 
[coeff,score,latent] = pca(X);
% coeff, V
% score, Z
% latent, lambda
 
figure(5)
subplot(1,2,1)
plot(X(:,1),X(:,2),'.'); hold on
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('x_1'); ylabel('x_2')
h = quiver(0,0,coeff(1,1),coeff(2,1));
h.AutoScaleFactor = 3;
h = quiver(0,0,coeff(1,2),coeff(2,2));
h.AutoScaleFactor = 3;
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
 
subplot(1,2,2)
plot(score(:,1),score(:,2),'.'); hold on
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('z_1'); ylabel('z_2')
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
 
 
R = chol(SIGMA)
% X = mvnrnd([0,0],[1,0;0,1],num);
% X = X*R;
Z = X*R^(-1);
cov(Z)
 
figure(5)
subplot(1,2,1)
plot(X(:,1),X(:,2),'.'); hold on
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('x_1'); ylabel('x_2')
h = quiver(0,0,v1(1),v1(2));
h.AutoScaleFactor = 3;
h = quiver(0,0,v2(1),v2(2));
h.AutoScaleFactor = 3;
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
 
subplot(1,2,2)
plot(Z(:,1),Z(:,2),'.'); hold on
daspect([1,1,1])
xlim([-8,8]); ylim([-8,8]);
xlabel('z_1'); ylabel('z_2')
hAxis = gca;
hAxis.XAxisLocation = 'origin';
hAxis.YAxisLocation = 'origin';
box off
