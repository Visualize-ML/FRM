% B4_Ch1_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clear all; close all; clc
 
O = [0, 0, 0];
A = [-2,1,1];
B = [1,-2,-1];
AO = A-O;
BO = B-O;
cross_prod1 = cross(AO,BO)
cross_prod2 = cross(BO,AO)
 
figure(1)
 
points=[A' B' O']; 
h5 = fill3(points(1,:),points(2,:),points(3,:),'b');
h5.EdgeColor = [1 1 1];
h5.FaceAlpha = 0.4;  hold on
 
h1 = quiver3(O(1),O(2),O(3),AO(1),AO(2),AO(3));
h2 = quiver3(O(1),O(2),O(3),BO(1),BO(2),BO(3));
h1.AutoScale = 'off'; h2.AutoScale = 'off';
h1.LineWidth = 1; h2.LineWidth = 1;
h3 = quiver3(O(1),O(2),O(3),cross_prod1(1),cross_prod1(2),cross_prod1(3)); hold on
h4 = quiver3(O(1),O(2),O(3),cross_prod2(1),cross_prod2(2),cross_prod2(3));
h3.AutoScale = 'off'; h4.AutoScale = 'off';
h3.LineWidth = 1; h4.LineWidth = 1;
 
daspect([1,1,1]); box on; grid off; view(-45,45)
xlabel('x'); ylabel('y'); zlabel('z')
hAxis = gca;
hAxis.XRuler.FirstCrossoverValue  = 0; % X crossover with Y axis
hAxis.YRuler.FirstCrossoverValue  = 0; % Y crossover with X axis
hAxis.ZRuler.FirstCrossoverValue  = 0; % Z crossover with X axis
hAxis.ZRuler.SecondCrossoverValue = 0; % Z crossover with Y axis
hAxis.XRuler.SecondCrossoverValue = 0; % X crossover with Z axis
hAxis.YRuler.SecondCrossoverValue = 0; % Y crossover with Z axis
