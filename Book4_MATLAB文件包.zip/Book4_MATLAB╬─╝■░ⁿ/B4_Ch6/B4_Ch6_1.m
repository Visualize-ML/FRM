% B4_Ch6_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms f(x1,x2)
x0 = [-10 -10]'; % initial point
 
tol = 1e-6;  % tolerance
 
max_iter = 200;
% max number of iterations
 
dx_min = 1e-6;
% minimum allowed perturbation
 
step_size = 0.15; % 0.1, 0.2, 0.25
% step size
 
gnorm = inf; x = x0; niter = 0; dx = inf;
gnorms = [];
% initialize parameters
 
f = x1.^2 + x1.*x2 + 3*x2.^2;
% objective function
 
X = []; X(:,1) = x0;
 
while and(gnorm>=tol, and(niter <= max_iter, dx >= dx_min))
    
    % calculate gradient
    g = gradient(x);
    gnorm = norm(g); 
    gnorms = [gnorms, gnorm];
    % Euclidean norm of vector
    
    xnew = x - step_size*g;
 
    X(:,niter+2) = xnew;
    niter = niter + 1;
    dx = norm(xnew-x);
    x = xnew;
    
end
 
% visualization
figure(1); 
fc = fcontour(f,[-12 12 -12 12]); hold on
fc.LevelList = [20:20:500];
plot(X(1,:),X(2,:),'ok-')
grid off; box off
colorbar
xlabel('x1'); ylabel('x2')
 
figure(2); 
% fmesh(f,[-12 12 -12 12]); hold on
 
[X_fine, Y_fine] = meshgrid(-12:.2:12,-12:.2:12);
contour_f = subs(f, [x1, x2], {X_fine,Y_fine}); 
descend_path = subs(f, [x1, x2], {X(1,:),X(2,:)});
contour3(X_fine,Y_fine,double(contour_f),[0:20:700]); hold on
plot3(X(1,:),X(2,:),descend_path,'ok-')
plot3(0,0,0,'rx','MarkerSize',12);
grid off; box off; colorbar;
xlabel('x1'); ylabel('x2'); zlabel('f(x1,x2)')
 
figure(3)
plot(1:niter,gnorms)
box off; grid off; 
xlabel('Iterations'); ylabel('Norm of error')
axis tight
 
% gradient of the objective function
function g = gradient(x)
g = [2*x(1) + x(2)
    x(1) + 6*x(2)];
end
