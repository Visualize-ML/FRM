% B4_Ch6_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
x1 = -4:0.2:4;
x2 = -4:0.2:4;
[xx1, xx2] = meshgrid(x1,x2);
 
ff1 = -xx1 + 0.5*xx2 - 1;
ff2 = -xx1 - 2*xx2 + 1;
ff3 = xx1  + xx2 - 2;
 
figure(1)
subplot(1,3,1)
plot_contours(xx1,xx2,ff1)
 
subplot(1,3,2)
plot_contours(xx1,xx2,ff2)
 
subplot(1,3,3)
plot_contours(xx1,xx2,ff3)
 
ff4 = xx1.^2/9 + xx2.^2/4 - 1;
ff5 = xx1.^2 - xx2 - 1;
 
figure(2)
subplot(1,2,1)
plot_contours(xx1,xx2,ff4)
 
subplot(1,2,2)
plot_contours(xx1,xx2,ff5)
 
function plot_contours(xx1,xx2,ff)
levels = [-10:1:10];
contour(xx1,xx2,ff,levels); hold on
caxis([-10 10])
[~,h] = contour(xx1,xx2,ff,[0, 0]);
h.LineWidth = 2;
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
box off; grid off
xticks([-2 0 2]); yticks([-2 0 2])
xlabel('x_1'); ylabel('x_2');
colorbar; axis square
end
