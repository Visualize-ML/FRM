% B4_Ch6_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
sigma_1 = 0.3;  % vol: asset 1
sigma_2 = 0.15; % vol: asset 2
 
rhos = [-1,-0.5,0,0.5,1];
% possible correlations between asset 1 and 2
 
x1 = -1.5:0.05:1.5;
x2 = -1.5:0.05:1.5;
x1_x = -0.5:0.1:1.5;
x2_y = 1 - x1_x;
[xx1,xx2] = meshgrid(x1,x2);
 
% Linear inequality constraints
A = []; b = [];
 
% Linear equality constraints
Aeq = [1, 1];
beq = [1];
 
% lower and upper bounds
lb = [-1.5;-1.5]; ub = [1.5;1.5];
 
% use default options
options = [];
 
% no initial feasible points
x0 = [];
 
for i = 1:length(rhos)
    figure(i)
    
    
    rho = rhos(i);
    % Objective function
    
    R = [0;0];
    Q = 2*[sigma_1^2, rho*sigma_1*sigma_2;
        rho*sigma_1*sigma_2, sigma_2^2];
    
    [x_optimal,fval] = quadprog(Q,R,A,b,Aeq,beq,lb,ub,x0,options);
    
    sigma_p_sq = xx1.^2*sigma_1^2 + xx2.^2*sigma_2^2 + ...
        2*xx1.*xx2*rho*sigma_1*sigma_2;
    levels = [0.001,0.004,0.01,0.02:0.01:0.2];
    
    subplot(1,2,1)
    
    contour3(xx1,xx2,sigma_p_sq,levels); hold on
    plot3(x_optimal(1),x_optimal(2),fval,'xr','MarkerSize',12)
    xlabel('x_1'); ylabel('x_2'); zlabel('f(x)')
    grid off; box off; zlim([0,0.2])
    title(['\rho = ',num2str(rho),...
        '; min f(x) = ',num2str(fval)])
    
    subplot(1,2,2)
    
    contour(xx1,xx2,sigma_p_sq,levels); hold on
    
    plot([-1.5,1.5],[0,0],'k');plot([0,0],[-1.5,1.5],'k');
    
    plot(x1_x,x2_y,'k','LineWidth',2);
    
    plot(x_optimal(1),x_optimal(2),'xr','MarkerSize',12)
    
    title(['Optimum: x_1 = ',num2str(x_optimal(1)),...
        ', x_2 = ',num2str(x_optimal(2))])
    
    xlabel('x_1'); ylabel('x_2');
    grid off; box off; colorbar
end
