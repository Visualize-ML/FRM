% B4_Ch9_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% Use S&P 500 as the market
% download 50 components of S&P 500 as the universe
clc; close all; clear all
 
AssetList = {'AAPL','ADBE','AIG','AMZN','ANSS','AXP',...
    'BA','BLK','C','CAT','CBOE','CME','COST','DD',...
    'DIS','ETN','F','FB','FDX','GE','GM','GOOG',...
    'HD','HON','HPQ','IBM','INTC','JNJ','JPM','KO'...
    ,'MCD','MMM','MS','MSCI','MSFT','NDAQ','NFLX',...
    'NKE','NVDA','PFE','PG','QCOM','RL','SBUX','TIF'...
    ,'TWTR','V','WMT','XOM','YUM'};
 
price_assets = hist_stock_data('01012016','01012017',AssetList);
price_SP500 = hist_stock_data('01012016','01012017','^IXIC'); %^IXIC, ^GSPC
%% Plot the relative levels of the stocks and S&P 500
num_Bdays_year = 252;
Price_levels = extractfield(price_assets,'AdjClose');
asset_labels = extractfield(price_assets,'Ticker');

dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');

no_data = AssetList;
no_data(ismember(AssetList, asset_labels)) = [];

num_assets = length(asset_labels);
Price_levels = reshape(Price_levels,length(dates),length(asset_labels));
price_SP500 = price_SP500.AdjClose;

relative_levels = ret2price(price2ret(Price_levels));
relative_up = relative_levels(:,relative_levels(end,:)>1);
relative_down = relative_levels(:,relative_levels(end,:)<1);
 
%% Relative daily stock adjusted closing prices
fig_index = 1;
figure(1)
fig_index = fig_index + 1;
plot(dates, relative_up,'r'); hold on
plot(dates, relative_down,'color',[2,148,255]./255); hold on
plot(dates, ret2price(price2ret(price_SP500)),'k','LineWidth',2); hold on
 
box off; grid off
datetick('x','mm/dd/yyyy')
% xlim([dates(1),dates(end)]);
xlabel('Date');
ylabel('Stock relative prices')
title ('Relative daily stock closings')
 
dailyReturn = price2ret(Price_levels);
mean_return = mean(dailyReturn)';
 
% risk-free rate, monthly
cash_rsk = 0;
 
%% Construction 1
Covariance = cov(dailyReturn);
nAssets = numel(mean_return); target_return = 0.001;      
% number of assets and desired return
Aeq = ones(1,nAssets); beq = 1;              
% equality Aeq*x = beq
Aineq = mean_return'; bineq = target_return;           
% inequality Aineq*x <= bineq
lb = zeros(nAssets,1); ub = ones(nAssets,1); 
% bounds lb <= x <= ub
c = zeros(nAssets,1);                        
% objective has no linear term; set it to zero
options = optimoptions('quadprog','Algorithm','interior-point-convex');
options = optimoptions(options,'Display','iter','TolFun',1e-10);
 
% Call solver and measure wall-clock time.
tic
[weights_no_shortsell,fval1] = quadprog(Covariance,c,Aineq,bineq,Aeq,beq,lb,ub,[],options); 
toc
 
figure(2)
stem([1:nAssets],weights_no_shortsell,'b')
xlim([1,nAssets]); box off
xlabel('Asset number'); ylabel('Asset weight')
 
%% Construction 2
group_set = round(nAssets/5);
% Add group constraints to existing equalities. 
Groups = blkdiag(ones(1,group_set),ones(1,group_set),ones(1,group_set),...
    ones(1,group_set),ones(1,nAssets - group_set*4));
Aineq = [Aineq; -Groups];         % convert to <= constraint 
bineq = [bineq; -0.2*ones(5,1)];  % by changing signs
 
tic
[weights_group_constraint,fval2] = quadprog(Covariance,...
    c,Aineq,bineq,Aeq,beq,lb,ub,[],options);
toc
 
figure(3)
stem([1:nAssets],weights_no_shortsell,'b'); hold on
stem([1:nAssets],weights_group_constraint,'r')
xlim([1,nAssets]); box off
xlabel('Asset number'); ylabel('Asset weight')
 
figure(4)
labels = {'Group 1','Group 2','Group 3','Group 4','Group 5'};
Group_weights = [sum(weights_group_constraint(1:group_set));...
    sum(weights_group_constraint(group_set+1:group_set*2));...
    sum(weights_group_constraint(group_set*2+1:group_set*3));...
    sum(weights_group_constraint(group_set*3+1:group_set*4));...
    sum(weights_group_constraint(group_set*4+1:end));];
pie(Group_weights); legend(labels)
