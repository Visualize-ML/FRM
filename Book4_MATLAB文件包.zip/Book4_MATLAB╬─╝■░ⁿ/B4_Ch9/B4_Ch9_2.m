% B4_Ch9_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms www1 www2 vol volvol rrr xxx xxx_sq yyy
 
sigma_1 = 0.3;  % vol: asset 1
sigma_2 = 0.15; % vol: asset 2
E_R_1 = 0.2;    % average return: asset 1
E_R_2 = 0.1;    % average return: asset 2
rho = 0.4;      % correlation between two assets
 
w1_fine = -2:0.05:2;
w2_fine = -2:0.05:2;
[ww1,ww2] = meshgrid(w1_fine,w2_fine);
 
% linear constraint
w1_lc = -2:0.025:2;
w2_lc = 1 - w1_lc;
 
sigma_p_sq_surface = ww1.^2*sigma_1^2 + ww2.^2*sigma_2^2 + ...
    2*ww1.*ww2*rho*sigma_1*sigma_2;
sigma_p_sq_curve = w1_lc.^2*sigma_1^2 + w2_lc.^2*sigma_2^2 + ...
    2*w1_lc.*w2_lc*rho*sigma_1*sigma_2;
 
sigma_p_surface = sqrt(sigma_p_sq_surface);
sigma_p_curve = sqrt(sigma_p_sq_curve);
return_surface = E_R_1*ww1 + E_R_2*ww2;
return_curve = E_R_1*w1_lc + E_R_2*w2_lc;
 
r_f = 0.03; % 0, 0.03, 0.06
Sharpe_r_curve = (return_curve - r_f)./sigma_p_curve;
 
Sharpe_r_surface = (return_surface - r_f)./sigma_p_surface;
 
fig_i = 1;
figure(fig_i)
 
levels = -3:0.05:1;
mesh(ww1,ww2,Sharpe_r_surface); hold on
 
loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
plot3(w1_lc,w2_lc,Sharpe_r_curve,'k','LineWidth',2);
plot3(w1_lc(loc_max_sharpe),w2_lc(loc_max_sharpe),...
    Sharpe_r_curve(loc_max_sharpe),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('Sharpe ratio')
grid off; box off; colorbar
xlim([-1,1]);ylim([-1,1]); 
zlim([min(levels),0.8])
% view([1,0,0])
% view([0,-1,0])
% % view([0,0,1])
 
fig_i = fig_i + 1;
figure(fig_i)
 
contour3(ww1,ww2,Sharpe_r_surface,levels); hold on
 
loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
plot3(w1_lc,w2_lc,Sharpe_r_curve,'k','LineWidth',2);
plot3(w1_lc(loc_max_sharpe),w2_lc(loc_max_sharpe),...
    Sharpe_r_curve(loc_max_sharpe),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('Sharpe ratio')
grid off; box off; colorbar
xlim([-1,1]);ylim([-1,1]); 
zlim([min(levels),0.8])
% view([1,0,0])
% view([0,-1,0])
% % view([0,0,1])
 
fig_i = fig_i + 1;
figure(fig_i)
 
contourf(ww1,ww2,Sharpe_r_surface,levels); hold on
 
loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
plot3(w1_lc,w2_lc,Sharpe_r_curve,'k','LineWidth',2);
plot3(w1_lc(loc_max_sharpe),w2_lc(loc_max_sharpe),...
    Sharpe_r_curve(loc_max_sharpe),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('Sharpe ratio')
grid off; box off; colorbar
xlim([-1,1]);ylim([-1,1]); 
zlim([min(levels),0.8])
% view([1,0,0])
% view([0,-1,0])
% % view([0,0,1])
