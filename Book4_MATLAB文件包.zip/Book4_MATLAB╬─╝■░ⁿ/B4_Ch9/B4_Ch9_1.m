% B4_Ch9_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
Er     = [0.2 0.1 0.3 0.25]';
Sigmas = [0.3 0.15 0.2 0.1]';
RHOs   = [1 0.4 -0.2 0.25;
          0.4 1 0.2 0.5;
          -0.2 0.2 1 0.1;
          0.25 0.5 0.1 1;];
SIGMA  = corr2cov(Sigmas, RHOs);
one_l  = ones(size(Er));
 
a = Er'*inv(SIGMA)*one_l;
b = Er'*inv(SIGMA)*Er;
c = one_l'*inv(SIGMA)*one_l;
d = b*c - a^2; 
 
x = [sqrt(1/c):0.001:0.3];
y = a/c + sqrt((x.^2 - 1/c)*d/c);
MVP_sigma_p = sqrt(1/c);
MVP_E_p     = a/c;
MVP_w = inv(SIGMA)*one_l/c;
 
Er_target_y = 0.6;
Er_target_x_frontier = sqrt(c/d*(Er_target_y - a/c)^2 + 1/c);
m = (b - Er_target_y*a)/d;
n = (Er_target_y*c - a)/d;
Er_target_frontier_w =(m*inv(SIGMA)*one_l + n*inv(SIGMA)*Er);
Er_target_frontier_w2 = ...
    inv([SIGMA,one_l,Er;
    one_l',0,0;
    Er',0,0])*[one_l*0;1;Er_target_y];
 
figure(1)
plot(x,y); hold on
plot(Sigmas,Er,'ok')
plot(MVP_sigma_p,MVP_E_p,'x')
plot(Er_target_x_frontier,Er_target_y,'x')
box off; grid off
xlim([0,0.3]); ylim([0,0.7])
xlabel('Porfolio vol'); ylabel('Porfolio expected return')
 
rf = 0.05;
j = b - 2*a*rf + rf^2*c;
 
x_tangent = 0:0.01:0.3;
 
y_tangent = sqrt(j)*x_tangent + rf;
 
Er_target_x_tangent = (Er_target_y - rf)/sqrt(j);
 
x_tangent_point = sqrt(j)/(a - c*rf);
y_tangent_point = j/(a - c*rf) + rf;
 
Er_target_tangent_w = (Er_target_y - rf)/j*...
    inv(SIGMA)*[Er - rf*one_l];
 
Er_target_tangent_wf = 1 - sum(Er_target_tangent_w);
 
Er_target_tangent_w/sum(Er_target_tangent_w);
 
w_tangent_point = inv(SIGMA)*(Er - rf*one_l)/(a - c*rf);
 
figure(2)
plot(x,y); hold on
plot(x_tangent,y_tangent,'k')
plot(x_tangent_point,y_tangent_point,'xk')
plot(Er_target_x_tangent,Er_target_y,'x')
 
plot(0,rf,'xk')
plot(Sigmas,Er,'ok')
plot(MVP_sigma_p,MVP_E_p,'x')
plot(Er_target_x_frontier,Er_target_y,'x')
box off; grid off
xlim([0,0.3]); ylim([0,0.7])
xlabel('Porfolio vol'); ylabel('Porfolio expected return')
