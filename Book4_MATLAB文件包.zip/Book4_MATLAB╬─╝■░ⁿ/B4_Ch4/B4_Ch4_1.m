% B4_Ch4_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; close all
syms x y
 
ee = [0,0.4:0.1:1,1.2:0.2:3];
my_col = brewermap(length(ee),'RdYlBu');
figure(1)
hold on
for i = 1:length(ee)
    e = ee(i);
    f = y^2 - 2*x - (e^2 - 1)*x^2;
    fimplicit(f, [-3 3 -3 3],'color',my_col(i,:))
end
 
axis equal; grid off; box off
xlabel('x'); ylabel('y')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-3,3]); ylim([-3,3])
