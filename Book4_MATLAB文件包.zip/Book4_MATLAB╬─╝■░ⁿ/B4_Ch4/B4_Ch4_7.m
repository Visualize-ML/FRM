% B4_Ch4_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


clc; close all; clear all
syms x y z
 
A = -4; B = 0; C = -4; D = 0; E = 0; F = 0;
A = 4; B = 0; C = 4; D = 0; E = 0; F = 0;
A = 4; B = 0; C = -4; D = 0; E = 0; F = 0; 
f = A*x^2 + B*x*y + C*y^2 + D*x + E*y + F;
x0 = 0; y0 = 0;
r = 1.5; num = 10;
[xx_circ,yy_circ] = mesh_circ(x0,y0,r,num);
 
xx = [-3:0.2:3]; yy = xx; 
[xx,yy] = meshgrid(xx,yy);
zz = double(subs(f,[x,y],{xx,yy}));
 
z0 = double(subs(f,[x,y],{x0,y0}));
 
g = gradient(f, [x, y])
 
[XX1_fine, XX2_fine] = meshgrid(-3:.4:3,-3:.4:3);
n_x0 = double(subs(g(1), [x,y], {x0,y0}));
n_y0 = double(subs(g(2), [x,y], {x0,y0}));
n_z0 = -1;
n = [n_x0, n_y0, n_z0];
P_vector = [x-x0, y-y0, z-z0];
eqn = dot(n, P_vector) == 0;
plane_f = solve(eqn,z);
 
zz_circ = double(subs(plane_f,[x,y],{xx_circ,yy_circ}));
 
figure(1)
 
h = meshc(xx,yy,zz); hold on
c_start = floor(min(double(zz(:))));
c_end   = ceil(max(double(zz(:))));
 
c_levels = c_start:(c_end-c_start)/20:c_end;
 
hContour=h(2);
hContour.LevelList = c_levels;
 
mesh(xx_circ,yy_circ,zz_circ,'edgecolor','k')
plot3(x0,y0,z0,'or','MarkerSize',10)
z_lim = zlim;
plot3(x0,y0,z_lim(1),'or','MarkerSize',10)
plot3([x0,x0],[y0,y0],[z0,z_lim(1)],'k')
% quiver3(x0,y0,z0,-n(1),-n(2),-n(3),2)
 
axis tight; box on; grid off
xlabel('x'); ylabel('y'); zlabel('z')
 
function [xx,yy] = mesh_circ(x0,y0,r,num)
 
theta = [0:pi/num:2*pi];
r = [0:r/num*2:r];
 
[theta,r] = meshgrid(theta,r);
 
xx = cos(theta).*r + x0;
yy = sin(theta).*r + y0;
 
end
