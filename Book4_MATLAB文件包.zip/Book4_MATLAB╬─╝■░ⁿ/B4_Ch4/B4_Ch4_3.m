% B4_Ch4_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% hyperboloid of one sheet
clc; clear all; close all

a=1; b=1; c=1;
u=linspace(-2,2,40);
v=linspace(0,2*pi,40);
[u,v]=meshgrid(u,v);
 
x=a*cosh(u).*cos(v);
y=b*cosh(u).*sin(v);
z=c*sinh(u);
 
figure(1)
mesh(x,y,z)
axis tight; daspect([1, 1, 1])
grid off; xlabel('x'); ylabel('y'); zlabel('z')
 
%% conical surface
 
x=a*u.*cos(v);
y=b*u.*sin(v);
z=u;
 
figure(2)
mesh(x,y,z); hold on
 
axis tight; daspect([1, 1, 1])
grid off; xlabel('x'); ylabel('y'); zlabel('z')
 
%% hyperboloid of two sheets
c=1;
x=a*sinh(u).*cos(v);
y=b*sinh(u).*sin(v);
z1=c*cosh(u);
 
figure(3)
mesh(x,y,z1); hold on
 
c=-1;
x=a*sinh(u).*cos(v);
y=b*sinh(u).*sin(v);
z2=c*cosh(u);
 
mesh(x,y,z2)
axis tight; daspect([1, 1, 1])
grid off; xlabel('x'); ylabel('y'); zlabel('z')
