% B4_Ch4_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x y
a = 2; b = 1;
 
f1 = x^2/a^2 + y^2/b^2 - 1;
 
figure(1)
 
fimplicit(f1, [-3 3 -3 3],'color',[0, 0, 1],'LineWidth',1.5); hold on
 
for theta = pi/45:2*pi/45:2*pi
    
    x0 = cos(theta)*a;
    y0 = sin(theta)*b;
    plot_tangent(x0,y0,a,b)
    
end
 
figure(2)
 
fimplicit(f1, [-3 3 -3 3],'color',[0, 0, 1],'LineWidth',1.5);
hold on
 
for theta = pi/45:2*pi/45:2*pi
    
    x0 = cos(theta)*a;
    y0 = sin(theta)*b;
    plot_norm(x0,y0,a,b)
    
end
 
axis equal; % grid on
xlabel('x'); ylabel('y'); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
function plot_tangent(x0,y0,a,b)
 
syms x y
f_tan = x*x0/a^2 + y*y0/b^2 - (x0^2/a^2 + y0^2/b^2);
 
fimplicit(f_tan, [-3 3 -3 3],'color',[0,96,166]/255,'LineWidth',0.25)
 
end
 
function plot_norm(x0,y0,a,b)
 
syms x y
f_norm = x*y0/b^2 - y*x0/a^2 - (x0*y0/b^2 - x0*y0/a^2);
 
fimplicit(f_norm, [-3 3 -3 3],'color',[0,96,166]/255,'LineWidth',0.25)
 
end
