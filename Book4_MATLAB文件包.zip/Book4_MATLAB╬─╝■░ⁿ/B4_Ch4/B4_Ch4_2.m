% B4_Ch4_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

syms x y
Q = [1 0; 0 1/4];
f1 = [x, y]*Q*[x; y] - 1;
 
figure(1)
subplot(2,2,1)
 
fimplicit(f1, [-3 3 -3 3])
axis equal; grid on
xlabel('x'); ylabel('y'); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
title('Original')
 
subplot(2,2,2)
theta_deg = 45;
fimplicit(f1, [-3 3 -3 3],'color',[183, 222, 232]/255)
hold on; plot_f2(Q,theta_deg)
 
subplot(2,2,3)
theta_deg = 90;
fimplicit(f1, [-3 3 -3 3],'color',[183, 222, 232]/255)
hold on; plot_f2(Q,theta_deg)
 
subplot(2,2,4)
theta_deg = 120;
fimplicit(f1, [-3 3 -3 3],'color',[183, 222, 232]/255)
hold on; plot_f2(Q,theta_deg)
 
function plot_f2(Q,theta_deg)
syms x y
theta = deg2rad(theta_deg);
R = [cos(theta), -sin(theta);
     sin(theta),  cos(theta)];
f2 = [x, y]*inv(R)*Q*R*[x; y] - 1;
simplify(f2)
fimplicit(f2, [-3 3 -3 3],'color',[0, 153, 255]/255)
axis equal; grid on; xlabel('x'); ylabel('y'); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
title(['Clockwise rotated by ',num2str(theta_deg),' degrees'])
 
end

