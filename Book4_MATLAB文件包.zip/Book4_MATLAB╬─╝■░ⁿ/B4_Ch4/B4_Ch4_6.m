% B4_Ch4_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x y
% A = 1; B = -1; C = 1; D = 0; E = 0; F = -1;
% A = 1; B = 0; C = 0; D = 0; E = -4; F = 0;
% A = 1; B = 2; C = 1; D = -4; E = 4; F = 0;
A = 0; B = 1; C = 0; D = 0; E = 0; F = -1;
f1 = A*x^2 + B*x*y + C*y^2 + D*x + E*y + F;
 
figure(1)
 
fimplicit(f1, [-3 3 -3 3],'color',[0, 0, 1],'LineWidth',1.5); hold on
 
xx = [-3:0.1:3]; yy = xx; 
[xx,yy] = meshgrid(xx,yy);
ff = subs(f1,[x,y],{xx,yy});
 
M = contour(xx,yy,ff,[0,0],'color',[0 0 0]);
xx0 = M(1,2:end); yy0 = M(2,2:end);
 
 
for ii = 1:length(xx0)
    
    x0 = xx0(ii);
    y0 = yy0(ii);
    plot_tangent(x0, y0, A, B, C, D, E, F)
    
end
 
axis equal; % grid on
xlabel('x'); ylabel('y'); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
 
figure(2)
 
fimplicit(f1, [-3 3 -3 3],'color',[0, 0, 1],'LineWidth',1.5); hold on
 
for ii = 1:length(xx0)
    
    x0 = xx0(ii);
    y0 = yy0(ii);
    plot_norm(x0, y0, A, B, C, D, E, F)
    
end
 
axis equal; % grid on
xlabel('x'); ylabel('y'); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
function plot_tangent(x0, y0, A, B, C, D, E, F)
syms x y
f_tan = (2*A*x0 + B*y0 + D)*(x - x0) + ...
    (B*x0 + 2*C*y0 + E)*(y - y0);
 
fimplicit(f_tan, [-3 3 -3 3],'color',[0,96,166]/255,'LineWidth',0.25)
 
end
 
function plot_norm(x0, y0, A, B, C, D, E, F)
 
syms x y
f_norm = (B*x0 + 2*C*y0 + E)*(x - x0) - ...
    (2*A*x0 + B*y0 + D)*(y - y0);
 
fimplicit(f_norm, [-3 3 -3 3],'color',[0,96,166]/255,'LineWidth',0.25)
 
end
