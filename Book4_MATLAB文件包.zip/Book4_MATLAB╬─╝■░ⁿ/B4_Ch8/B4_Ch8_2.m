% B4_Ch8_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
sigma_1 = 0.3;  % vol: asset 1
sigma_2 = 0.15; % vol: asset 2
E_R_1 = 0.2;    % average return: asset 1
E_R_2 = 0.1;    % average return: asset 2
 
rho = 0.4;
 
% Portfolio optimization
 
% Linear inequality constraints
A = []; b = [];
 
% Linear equality constraints
Aeq = [1, 1];
beq = [1];
 
% lower and upper bounds
lb = [-1.5;-1.5]; ub = [1.5;1.5];
 
r_fs = 0:0.01:0.1;
 
nvars = 2;
 
options=gaoptimset('populationsize',...
    100,'generations',38,'stallGenLimit',...
    200,'TolFun',1e-10,'PlotFcns',{@gaplotbestf,@gaplotdistance});
 
result_table = [];
 
for i = 1:length(r_fs)
    r_f = r_fs(i);
    % use default options
    FitnessFunction = @(x)max_Sharpe...
        (x,rho,sigma_1,sigma_2,E_R_1,E_R_2,r_f);
    % An Objective Function with Additional Arguments
    
    [x, fval] = ga(FitnessFunction,nvars,A,b,...
        Aeq,beq,lb,ub,[],options)
    
    temp = [r_f,x,-fval];
    result_table = [result_table;temp]
end
 
 
%% objective functions
 
function y = max_Sharpe(x,rho,sigma_1,sigma_2,E_R_1,E_R_2,r_f)
 
% portfolio vol:
vol_sq = x(1)^2*sigma_1^2 + x(2)^2*sigma_2^2 + ...
    2*x(1)*x(2)*rho*sigma_1*sigma_2;
 
% max return:
excess_r = E_R_1*x(1) + E_R_2*x(2) - r_f;
 
y = -excess_r/sqrt(vol_sq);
 
end
