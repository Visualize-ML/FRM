% B4_Ch8_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
sigma_1 = 0.3;  % vol: asset 1
sigma_2 = 0.15; % vol: asset 2
E_R_1 = 0.2;    % average return: asset 1
E_R_2 = 0.1;    % average return: asset 2
 
x1 = -1.5:0.05:1.5;
x2 = -1.5:0.05:1.5;
x1_x = -0.5:0.1:1.5;
x2_y = 1 - x1_x;
[xx1,xx2] = meshgrid(x1,x2);
 
rho = 0.4;
 
figure(1)
 
subplot(1,2,1)
sigma_p_sq = xx1.^2*sigma_1^2 + xx2.^2*sigma_2^2 + ...
    2*xx1.*xx2*rho*sigma_1*sigma_2;
levels = [0.001,0.004,0.01,0.02:0.01:0.2];
contour(xx1,xx2,sigma_p_sq,levels); hold on
 
plot([-1.5,1.5],[0,0],'k');plot([0,0],[-1.5,1.5],'k');
 
plot(x1_x,x2_y,'k','LineWidth',2);
xlabel('x_1'); ylabel('x_2');
grid off; box off; colorbar
daspect([1 1 1]); title('Portfolio vol squared')
 
subplot(1,2,2)
 
returns_sq = E_R_1*xx1 + E_R_2*xx2;
contour(xx1,xx2,returns_sq,[-0.4:0.05:0.4]); hold on
plot([-1.5,1.5],[0,0],'k');plot([0,0],[-1.5,1.5],'k');
colorbar
plot(x1_x,x2_y,'k','LineWidth',2);
xlabel('x_1'); ylabel('x_2');
grid off; box off;
daspect([1 1 1]); title('Portfolio return')
 
%% Portfolio optimization
 
% Linear inequality constraints
A = []; b = [];
 
% Linear equality constraints
Aeq = [1, 1];
beq = [1];
 
% lower and upper bounds
lb = [-1.5;-1.5]; ub = [1.5;1.5];
 
% use default options
FitnessFunction = @(x)simple_multiobjective...
    (x,rho,sigma_1,sigma_2,E_R_1,E_R_2);
% An Objective Function with Additional Arguments
 
numberOfVariables = 2;
 
options = optimoptions(@gamultiobj,'PlotFcn',...
    {@gaplotpareto,@gaplotscorediversity},...
    'PopulationSize',100);
[x_optimal, val] = gamultiobj(FitnessFunction,...
    numberOfVariables,A,b,Aeq,beq,lb,ub,options);
 
%% Visualize optimal solutions
 
figure(3)
 
contour(xx1,xx2,sigma_p_sq,levels); hold on
contour(xx1,xx2,returns_sq)
plot(x_optimal(:,1),x_optimal(:,2),'ok')
plot([-1.5,1.5],[0,0],'k');plot([0,0],[-1.5,1.5],'k');
plot(x1_x,x2_y,'k','LineWidth',2);
xlabel('x_1'); ylabel('x_2');
grid off; box off; daspect([1 1 1])
 
%%
figure(4)
subplot(1,2,1)
plot(val(:,1),-val(:,2),'o')
xlabel('Portfolio vol. squared')
ylabel('Portfolio return')
box off; grid off;
 
subplot(1,2,2)
plot(sqrt(val(:,1)),-val(:,2),'o')
xlabel('Portfolio volatility')
ylabel('Portfolio return')
box off; grid off;
 
%% objective functions
 
function y = simple_multiobjective(x,rho,sigma_1,sigma_2,E_R_1,E_R_2)
 
% min portfolio vol:
y(1) = x(1)^2*sigma_1^2 + x(2)^2*sigma_2^2 + ...
    2*x(1)*x(2)*rho*sigma_1*sigma_2;
 
% max return:
y(2) = -E_R_1*x(1) - E_R_2*x(2);
 
end

