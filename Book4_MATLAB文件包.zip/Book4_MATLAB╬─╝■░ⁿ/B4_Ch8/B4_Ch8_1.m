% B4_Ch8_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B4_Ch8_1_A.m

clc; close all; clear all
syms www1 www2 vol volvol rrr xxx xxx_sq yyy

sigma_1 = 0.3;  % vol: asset 1
sigma_2 = 0.15; % vol: asset 2
E_R_1 = 0.2;    % average return: asset 1
E_R_2 = 0.1;    % average return: asset 2
rho = 0.4;      % correlation between two assets

w1_fine = -2:0.01:2;
w2_fine = -2:0.01:2;
[ww1,ww2] = meshgrid(w1_fine,w2_fine);

% linear constraint
w1_lc = -2:0.025:2;
w2_lc = 1 - w1_lc;

sigma_p_sq_surface = ww1.^2*sigma_1^2 + ww2.^2*sigma_2^2 + ...
    2*ww1.*ww2*rho*sigma_1*sigma_2;
sigma_p_sq_curve = w1_lc.^2*sigma_1^2 + w2_lc.^2*sigma_2^2 + ...
    2*w1_lc.*w2_lc*rho*sigma_1*sigma_2;

% Analytical expressions

volvol = www1.^2*sigma_1^2 + www2.^2*sigma_2^2 + ...
    2*www1.*www2*rho*sigma_1*sigma_2;
vpa(expand(volvol))

vol = sqrt(volvol);
vpa(expand(vol))

volvol = www1.^2*sigma_1^2 + (1-www1).^2*sigma_2^2 + ...
    2*www1.*(1-www1)*rho*sigma_1*sigma_2;
vpa(expand(volvol))

vol = sqrt(volvol);
vpa(expand(vol))

volvol = (1-www2).^2*sigma_1^2 + www2.^2*sigma_2^2 + ...
    2*(1-www2).*www2*rho*sigma_1*sigma_2;
vpa(expand(volvol))

vol = sqrt(volvol);
vpa(expand(vol))

rrr = E_R_1*www1 + E_R_2*www2;
vpa(expand(rrr))

www1 = (yyy - E_R_2)/(E_R_1 - E_R_2);
www2 = (E_R_1 - yyy)/(E_R_1 - E_R_2);

xxx_sq = www1.^2*sigma_1^2 + www2.^2*sigma_2^2 + ...
    2*www1.*www2*rho*sigma_1*sigma_2;

vpa(expand(xxx_sq))

sigma_p_surface = sqrt(sigma_p_sq_surface);
sigma_p_curve = sqrt(sigma_p_sq_curve);

return_surface = E_R_1*ww1 + E_R_2*ww2;
return_curve = E_R_1*w1_lc + E_R_2*w2_lc;

%% plot return surface
fig_i = 1;
figure(fig_i)

contour3(ww1,ww2,return_surface,[-0.8:0.02:0.8]); hold on
colorbar
plot3(w1_lc,w2_lc,return_curve,'k','LineWidth',2);
xlabel('w_1'); ylabel('w_2'); zlabel('Portfolio return')
grid off; box off;
title('Portfolio return')
xlim([-2,2]);ylim([-2,2]);
% view([1,0,0])
% view([0,-1,0])
% view([0,0,1])

% B4_Ch8_1_B.m

%% plot elliptic paraboloid of the portfolio variance

fig_i = fig_i + 1;
figure(fig_i)

levels = [0.02:0.02:0.4];
contour3(ww1,ww2,sigma_p_sq_surface,levels); hold on

loc_min_sigma_p = find(sigma_p_sq_curve == min(sigma_p_sq_curve));
plot3(w1_lc,w2_lc,sigma_p_sq_curve,'k','LineWidth',2);
plot3(w1_lc(loc_min_sigma_p),w2_lc(loc_min_sigma_p),...
    sigma_p_sq_curve(loc_min_sigma_p),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('\sigma_p^2')
grid off; box off; colorbar
xlim([-2,2]);ylim([-2,2]);zlim([0,0.4])
view(30,20)
% view([1,0,0])
% view([0,-1,0])
% view([0,0,1])

fig_i = fig_i + 1;
figure(fig_i)

levels = [0.02:0.02:0.4];
contour(ww1,ww2,sigma_p_sq_surface,levels); hold on

plot([-2,2],[0,0],'k');plot([0,0],[-2,2],'k');

plot(w1_lc,w2_lc,'k','LineWidth',2);
plot(w1_lc(loc_min_sigma_p),w2_lc(loc_min_sigma_p),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('\sigma_p^2')
grid off; box off; colorbar
daspect([1 1 1]); title('Portfolio vol squared')
xlim([-2,2]);ylim([-2,2]);

% B4_Ch8_1_C.m

%% plot elliptic cone surface of the portfolio volatility
% volatility = square root of variance

fig_i = fig_i + 1;
figure(fig_i)

levels = [0.04:0.04:1];
contour3(ww1,ww2,sigma_p_surface,levels); hold on

plot3(w1_lc,w2_lc,sigma_p_curve,'k','LineWidth',2);
plot3(w1_lc(loc_min_sigma_p),w2_lc(loc_min_sigma_p),...
    sigma_p_curve(loc_min_sigma_p),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('\sigma_p')
grid off; box off; colorbar
xlim([-2,2]);ylim([-2,2]);
view(30,20)
% view([1,0,0])
% view([0,-1,0])
% view([0,0,1])
fig_i = fig_i + 1;
figure(fig_i)

levels = [0.04:0.04:1];
contour(ww1,ww2,sigma_p_surface,levels); hold on

plot([-2,2],[0,0],'k');plot([0,0],[-2,2],'k');

plot(w1_lc,w2_lc,'k','LineWidth',2);
plot(w1_lc(loc_min_sigma_p),w2_lc(loc_min_sigma_p),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('\sigma_p')
grid off; box off; colorbar
daspect([1 1 1]); title('Portfolio vol')
xlim([-2,2]);ylim([-2,2]);

fig_i = fig_i + 1;
figure(fig_i)

levels = [0.04:0.04:1];
contour(ww1,ww2,sigma_p_surface,levels); hold on

plot([-2,2],[0,0],'k');plot([0,0],[-2,2],'k');

plot(w1_lc,w2_lc,'k','LineWidth',2);
plot(w1_lc(loc_min_sigma_p),w2_lc(loc_min_sigma_p),'xr','MarkerSize',10);
xlabel('w_1'); ylabel('w_2'); zlabel('\sigma_p')
grid off; box off; colorbar
daspect([1 1 1]); title('Portfolio vol')
xlim([-2,2]);ylim([-2,2]);

% B4_Ch8_1_D.m

%% plot portfolio return vs portfolio vol

fig_i = fig_i + 1;
figure(fig_i)
loc_1 = find(w1_lc == 0);
loc_2 = find(w1_lc == 1);
loc_min = find(sigma_p_curve == min(sigma_p_curve));

plot(sigma_p_curve,return_curve,'-o','MarkerIndices',[loc_1,loc_2],...
    'MarkerFaceColor','w',...
    'MarkerEdgeColor','r',...
    'MarkerSize',6); hold on
plot(sigma_p_curve(loc_min),return_curve(loc_min),'xr','MarkerSize',6)
xlabel('Portfolio vol'); ylabel('Portfolio return')
xlim([0,0.4]); box off; ylim([0, 0.25])

% plot portfolio return vs portfolio variance

fig_i = fig_i + 1;
figure(fig_i)

loc_min = find(sigma_p_curve == min(sigma_p_curve));

plot(sigma_p_sq_curve,return_curve,'-o','MarkerIndices',[loc_1,loc_2],...
    'MarkerFaceColor','w',...
    'MarkerEdgeColor','r',...
    'MarkerSize',6); hold on
plot(sigma_p_sq_curve(loc_min),return_curve(loc_min),'xr','MarkerSize',6)
xlabel('Portfolio vol squared'); ylabel('Portfolio return')
xlim([0,0.2]); box off; ylim([0, 0.25])


% B4_Ch8_1_E.m

%% Plot tangent portfolios and max Sharpe Ratio

r_f = 0.03; % 0.05, 0.08

fig_i = fig_i + 1;
figure(fig_i)
Sharpe_r_curve = (return_curve - r_f)./sigma_p_curve;
loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
subplot(2,1,1)

plot(sigma_p_curve(loc_min:end),return_curve(loc_min:end)); hold on
plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'x')
xlim([0,0.4])
box off; xlabel('Portfolio vol'); ylabel('Portfolio return')

subplot(2,1,2)
plot(sigma_p_curve(loc_min:end),Sharpe_r_curve(loc_min:end)); hold on
plot(sigma_p_curve(loc_max_sharpe),Sharpe_r_curve(loc_max_sharpe),'x')
xlim([0,0.4])
box off; xlabel('Portfolio vol'); ylabel('Sharpe ratio')

fig_i = fig_i + 1;
figure(fig_i)

plot(sigma_p_curve,return_curve); hold on
plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'xr','MarkerSize',6)
xlabel('Portfolio vol'); ylabel('Portfolio return')
xlim([0,0.4])
plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'xr')

vol = 0:0.1:0.4;
Sharpe_max = Sharpe_r_curve(loc_max_sharpe);
r_tangent = Sharpe_max*vol + r_f;
plot(vol,r_tangent,'k')
plot(0,r_f,'xr')
box off
ylim([0,0.3])


r_fs = 0:0.01:0.1;

fig_i = fig_i + 1;
figure(fig_i)

for i = 1:length(r_fs)
    r_f = r_fs(i);
    Sharpe_r_curve = (return_curve - r_f)./sigma_p_curve;
    loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
    
    subplot(2,1,1)
    
    plot(sigma_p_curve(loc_min:end),return_curve(loc_min:end),'b'); hold on
    plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'xr')
    xlim([0,0.4])
    box off; xlabel('Portfolio vol'); ylabel('Portfolio return')
    
    subplot(2,1,2)
    plot(sigma_p_curve(loc_min:end),Sharpe_r_curve(loc_min:end),'b'); hold on
    plot(sigma_p_curve(loc_max_sharpe),Sharpe_r_curve(loc_max_sharpe),'xr')
    xlim([0,0.4])
    box off; xlabel('Portfolio vol'); ylabel('Sharpe ratio')
end

r_fs = 0:0.01:0.1;

fig_i = fig_i + 1;
figure(fig_i)

for i = 1:length(r_fs)
    r_f = r_fs(i);
    Sharpe_r_curve = (return_curve - r_f)./sigma_p_curve;
    loc_max_sharpe = find(Sharpe_r_curve == max(Sharpe_r_curve));
    plot(sigma_p_curve,return_curve); hold on
    plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'xr','MarkerSize',6)
    xlabel('Portfolio vol'); ylabel('Portfolio return')
    xlim([0,0.4])
    plot(sigma_p_curve(loc_max_sharpe),return_curve(loc_max_sharpe),'xr')
    
    vol = 0:0.1:0.4;
    Sharpe_max = Sharpe_r_curve(loc_max_sharpe);
    r_tangent = Sharpe_max*vol + r_f;
    plot(vol,r_tangent,'k')
    plot(0,r_f,'xr')
    box off
    ylim([0,0.3])
    
end

