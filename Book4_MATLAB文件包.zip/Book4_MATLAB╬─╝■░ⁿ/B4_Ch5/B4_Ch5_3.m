% B4_Ch5_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

syms f(x1, x2) a b c d
Q = [a, b; c, d];
X = [x1; x2];
 
FF = 1/2*transpose(X)*Q*X;
simplify(FF)
expand(FF)
 
hessian(FF, [x1;x2])
 
f(x1,x2) = FF
f_x = matlabFunction(f);
 
x1 = -10:1:10;
x2 = -10:1:10;
[xx1,xx2] = meshgrid(x1,x2);
 
Q_val = [3, 2;
    2, 3];
 
ff = feval(f_x,xx1,xx2,...
    Q_val(1,1),Q_val(1,2),...
    Q_val(2,1),Q_val(2,2));
 
% Q = [a, b;
%      c, d;] *Note: b = c
[V,LAMBDA] = eig(Q_val)
 
figure(1)
subplot(2,2,1)
meshc(xx1,xx2,ff)
decor
 
subplot(2,2,2)
contour(xx1,xx2,ff,20)
decor
 
subplot(2,2,3)
mesh(xx1,xx2,ff,'MeshStyle','column')
decor
 
subplot(2,2,4)
mesh(xx1,xx2,ff,'MeshStyle','row')
decor
 
function [] = decor()
xlabel('x_1'); ylabel('x_2'); zlabel('f(x_1,x_2)')
grid off; box off
end
