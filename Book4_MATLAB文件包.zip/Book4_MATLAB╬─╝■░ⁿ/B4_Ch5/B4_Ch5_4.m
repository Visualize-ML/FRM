% B4_Ch5_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

syms x1 x2 x3
x = [x1; x2; x3;];
Q = [2, -1, 0; 
    -1,  2, -1;
     0, -1, 2]
 
R = [-8;-4;8];
 
f = 1/2*x.'*Q*x + R.'*x;
simplify (f)
 
g_linear_eq = gradient(f,x)
sol = solve(g_linear_eq, x);
 
x1_Sol = sol.x1
x2_Sol = sol.x2
x3_Sol = sol.x3
 
x_extreme = -inv(Q)*R
 
Q = hessian(f,x)
Q = double(Q);
 
issymmetric(Q)
lambdas = eig(Q)
isposdef = all(lambdas > 0)
 
[~,positive_def_flag] = chol(Q)
% positive_def_flag
% flag = 0, then the input matrix is symmetric positive definite
