% B4_Ch5_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
syms x1 x2
f = -x1^2 - 2*x2^2 - x1*x2;
fx = matlabFunction(f)
xx1 = -4:0.4:4; xx2 = xx1;
[XX1,XX2] = meshgrid(xx1,xx2);
FF = feval(fx,XX1,XX2);
 
%% Surface and contour of the original function
 
figure(1)
set(gcf,'Position',[680 558 1178 420])
 
subplot(1,2,1)
h = meshc(XX1,XX2,FF); hold on
zlim_p = zlim;
plot3(0,0,0,'ok'); plot3(0,0,zlim_p(1),'ok')
levels = [-50:5:0];
hContour=h(2); hContour.LevelList = levels;
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
zlabel('${f(x_1,x_2)}$','Interpreter','latex')
grid off; box off; axis tight; view(-65,35)
set(gca, 'FontName', 'Times New Roman','fontsize',8)
 
subplot(1,2,2)
contour(XX1,XX2,FF,levels); hold on
plot(0,0,'ok')
axis equal; colorbar
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
set(gca, 'FontName', 'Times New Roman','fontsize',8)
 
%% First-order partial derivative with x1
 
df = gradient(f, [x1 x2]);
df_dx1 = matlabFunction(df(1))
df_dx2 = matlabFunction(df(2))

dFF_dx1 = feval(df_dx1,XX1,XX2);
dFF_dx2 = feval(df_dx2,XX1,XX2);
 
figure(2)
set(gcf,'Position',[680 558 1178 420])
 
subplot(1,2,1)
h = meshc(XX1,XX2,dFF_dx1); hold on
plot3(0,0,0,'ok'); levels = [-15:1:8];
hContour=h(2); hContour.LevelList = levels;
contour3(XX1,XX2,dFF_dx1,[0,0],...
    'color',[2,148,255]/255,'LineWidth',1)
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
zlabel('$\frac{\partial f}{\partial x_1}$','Interpreter','latex')
grid off; box off; axis tight; view(45,30)
set(gca, 'FontName', 'Times New Roman','fontsize',8)
grid off; box off; axis tight
 
subplot(1,2,2)
contour(XX1,XX2,dFF_dx1,levels); hold on
[df_dx1_0,~] = contour(XX1,XX2,dFF_dx1,[0,0],...
    'color',[2,148,255]/255,'LineWidth',1);
plot(0,0,'ok')
df_dx1_0_x1 = df_dx1_0(1,2:end); df_dx1_0_x2 = df_dx1_0(2,2:end);
axis equal; colorbar
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
set(gca, 'FontName', 'Times New Roman','fontsize',8)
 
%% First-order partial derivative with x2
 
figure(3)
set(gcf,'Position',[680 558 1178 420])
 
subplot(1,2,1)
h = meshc(XX1,XX2,dFF_dx2); hold on
plot3(0,0,0,'ok')
levels = [-20:2:20];
hContour=h(2); hContour.LevelList = levels;
contour3(XX1,XX2,dFF_dx2,[0,0],...
    'color',[255,153,255]/255,'LineWidth',1)
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
zlabel('$\frac{\partial f}{\partial x_2}$','Interpreter','latex')
grid off; box off; axis tight; view(145,30)
set(gca, 'FontName', 'Times New Roman','fontsize',8)
grid off; box off; axis tight
 
subplot(1,2,2)
contour(XX1,XX2,dFF_dx2,levels); hold on
[df_dx2_0,~] = contour(XX1,XX2,dFF_dx2,[0,0],...
    'color',[255,153,255]/255,'LineWidth',1);
plot(0,0,'ok')
df_dx2_0_x1 = df_dx2_0(1,2:end); df_dx2_0_x2 = df_dx2_0(2,2:end);
axis equal; colorbar
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
set(gca, 'FontName', 'Times New Roman','fontsize',8)
%%
figure(4)
set(gcf,'Position',[680 558 1178 420])
 
subplot(1,2,1)
h = meshc(XX1,XX2,FF); hold on
plot3(0,0,0,'ok')
zlim_p = zlim; plot3(0,0,zlim_p(1),'ok')
levels = [-50:5:0];
hContour=h(2); hContour.LevelList = levels;

plot3(df_dx1_0_x1,df_dx1_0_x2,...
    0*df_dx1_0_x2 + zlim_p(1),...
    'color',[2,148,255]/255,'LineWidth',1);
plot3(df_dx2_0_x1,df_dx2_0_x2,...
    0*df_dx2_0_x2 + zlim_p(1),...
    'color',[255,153,255]/255,'LineWidth',1);
 
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
zlabel('${f(x_1,x_2)}$','Interpreter','latex')
grid off; box off; axis tight; view(45,30)
set(gca, 'FontName', 'Times New Roman','fontsize',8)
grid off; box off; axis tight
 
subplot(1,2,2)
contour(XX1,XX2,FF,levels); hold on
plot(df_dx1_0_x1,df_dx1_0_x2,...
    'color',[2,148,255]/255,'LineWidth',1);
plot(df_dx2_0_x1,df_dx2_0_x2,...
    'color',[255,153,255]/255,'LineWidth',1);
plot(0,0,'ok')
xlabel('${x_1}$','Interpreter','latex'); 
ylabel('${x_2}$','Interpreter','latex'); 
axis equal; colorbar
set(gca, 'FontName', 'Times New Roman','fontsize',8)
