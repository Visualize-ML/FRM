% B4_Ch5_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms f(x)
f(x) = x.^2 + 5*sin(4*x);
 
f_x = matlabFunction(f)
xx = -4:0.01:4;
ff = feval(f_x,xx);
 
figure(1)
subplot(3,1,1)
plot(xx,ff); hold on
box off; grid off; xlabel('x'); ylabel('f(x)')
local_min = islocalmin(ff);
plot(xx(local_min),ff(local_min),'rx')
set(gca, 'XAxisLocation', 'origin')
 
df_x = matlabFunction(diff(f,x))
ff_df_x = feval(df_x,xx);
subplot(3,1,2)
plot(xx,ff_df_x); hold on
plot(xx(local_min),ff_df_x(local_min),'rx')
box off; grid off; xlabel('x'); ylabel('df/dx')
set(gca, 'XAxisLocation', 'origin')
 
df_x2 = matlabFunction(diff(f,x,2))
ff_df_x2 = feval(df_x2,xx);
subplot(3,1,3)
plot(xx,ff_df_x2); hold on
plot(xx(local_min),ff_df_x2(local_min),'rx')
box off; grid off; xlabel('x'); ylabel('d^2f/dx^2')
set(gca, 'XAxisLocation', 'origin')
 
figure(2)
subplot(3,1,1)
plot(xx,ff); hold on
box off; grid off; xlabel('x'); ylabel('f(x)')
local_max = islocalmax(ff);
plot(xx(local_max),ff(local_max),'rx')
set(gca, 'XAxisLocation', 'origin')
 
df_x = matlabFunction(diff(f,x))
ff_df_x = feval(df_x,xx);
subplot(3,1,2)
plot(xx,ff_df_x); hold on
plot(xx(local_max),ff_df_x(local_max),'rx')
box off; grid off; xlabel('x'); ylabel('df(x)/dx')
set(gca, 'XAxisLocation', 'origin')
 
df_x2 = matlabFunction(diff(f,x,2))
ff_df_x2 = feval(df_x2,xx);
subplot(3,1,3)
plot(xx,ff_df_x2); hold on
plot(xx(local_max),ff_df_x2(local_max),'rx')
box off; grid off; xlabel('x'); ylabel('d^2f/dx^2')
set(gca, 'XAxisLocation', 'origin')
