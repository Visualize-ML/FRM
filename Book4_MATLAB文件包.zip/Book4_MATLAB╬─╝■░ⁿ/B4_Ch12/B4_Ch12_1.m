% B4_Ch12_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B4_Ch12_1_A.m

clc; close all; clear all
 
stocks = {'COST','MCD','GM','GOOG','TSLA','PFE'};
 
price = hist_stock_data('01012018','01012020',stocks);
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
y_price = price(1).AdjClose;
x1_price = price(2).AdjClose;
x2_price = price(3).AdjClose;
x3_price = price(4).AdjClose;
x4_price = price(5).AdjClose;
x5_price = price(6).AdjClose;
 
y = diff(log(y_price));
x1  = diff(log(x1_price));
x2    = diff(log(x2_price));
x3  = diff(log(x3_price));
x4 = diff(log(x4_price));
x5   = diff(log(x5_price));
 
%% Principal components regressions
 
X = [x1,x2,x3,x4,x5];
[V,Z,eigen_values,~,explained,mu] = pca(X,'Economy',false);
% V*V' = I; norm(V(:,i)) = 1
% Z is the coordinates in V
 
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
 
subplot(1,2,1)
stem(eigen_values)
xlabel('Principal component')
ylabel('Eigenvalue'); box off; grid off
 
subplot(1,2,2)
plot(cumsum(eigen_values)/sum(eigen_values)*100); hold on
stem(eigen_values/sum(eigen_values)*100)
xlabel('Principal component')
ylabel('Variance explained (%)'); box off; grid off
 
figure(fig_i)
fig_i = fig_i + 1;
pareto(explained)
xlabel('Principal component')
ylabel('Variance explained (%)')
box off; grid off
 
figure(fig_i)
fig_i = fig_i + 1;
biplot(V(:,1:2),'scores',Z(:,1:2),'varlabels',{'x_1','x_2','x_3','x_4','x_5'});
daspect([1,1,1])
grid off; box off
 
figure(fig_i)
fig_i = fig_i + 1;
biplot(V(:,1:3),'Scores',Z(:,1:3),'varlabels',{'x_1','x_2','x_3','x_4','x_5'});
daspect([1,1,1])
grid off; box off
 
%% Plot the PCA loadings for the 1st, 2nd and 3rd PC
 
figure(fig_i)
fig_i = fig_i + 1;
% oldorder = get(gcf,'DefaultAxesColorOrder');
% set(gcf,'DefaultAxesColorOrder',jet(5));
 
plot(1:5,V(:,1:3),'-o');
% set(gcf,'DefaultAxesColorOrder',oldorder);
xlabel('Variable');
ylabel('PCA Loading');
xticks([1:5]); box off; grid off
xticklabels({'x_1','x_2','x_3','x_4','x_5'})
legend({'1st PC' '2nd PC' '3rd PC'},'location','best');
%% Principal Components Regression
 
% z, scores
% V is the matrix of loadings
 
k = 2; % First 2 principal components
[n,~] = size(X);
b_z_k2 = regress(y-mean(y), Z(:,1:k));
 
b_x_k2 = V(:,1:k)*b_z_k2;
b_x_k2 = [mean(y) - mean(X)*b_x_k2; b_x_k2];
% add b0
yfit_PCR_k2 = [ones(n,1) X]*b_x_k2;
 
figure(fig_i)
fig_i = fig_i + 1;
plot(y,yfit_PCR_k2,'r.'); hold on
plot(y,y,'-b')
plot([y,y]',[yfit_PCR_k2,y]','k-'); hold on
xlabel('Observed y');
ylabel('Fitted y');
title('Principal components, k = 2')
daspect([1,1,1])
 
k = 4; % First 4 principal components
[n,~] = size(X);
b_z_k4 = regress(y-mean(y), Z(:,1:k));
 
b_x_k4 = V(:,1:k)*b_z_k4;
b_x_k4 = [mean(y) - mean(X)*b_x_k4; b_x_k4];
% add b0
yfitPCR_4 = [ones(n,1) X]*b_x_k4;
 
figure(fig_i)
fig_i = fig_i + 1;
 
plot(y,yfitPCR_4,'b.'); hold on
plot(y,yfit_PCR_k2,'r.'); hold on
plot([y,y]',[yfit_PCR_k2,yfitPCR_4]','k-'); hold on
% plot(y,y,'-b')
xlabel('Observed y');
ylabel('Fitted y');
title(['Principal components, k = ',num2str(k)])
daspect([1,1,1])

% B4_Ch12_1_B.m

%% Partial least squares regression
 
[X_loadings,Y_loadings,X_scores,Y_scores,b_PLS_5,PLS_Var_5,MSE] = plsregress(X,y,5);
% X_loadings: predictor X loadings
% Y_loadings: response Y (y) loadings
% X_scores: predictor (X) scores
% Y_scores: response Y (y) scores
% Y = [ones(n,1),X]*b_PLS_5 + Yresiduals,
% Y0 = X0*b_PLS_5(2:end,:) + Yresiduals
% centered variables X0 and Y0
% PCTVAR containing the percentage of variance explained by the model.
% The first row of PCTVAR contains the percentage of variance 
% explained in X by each PLS component, and the second row 
% contains the percentage of variance explained in Y.
% MSE containing estimated mean-squared errors for 
% PLS models with 0:ncomp components
 
yfit_PLS_5 = [ones(size(X,1),1) X]*b_PLS_5;
 
figure(fig_i)
fig_i = fig_i + 1;
 
plot(1:5,cumsum(100*PLS_Var_5(2,:)),'-bo');
xlabel('Number of PLS components');
ylabel('Percent variance explained in y');
xticks(1:5); box off; grid off
 
figure(fig_i)
fig_i = fig_i + 1;
 
plot(1:5,cumsum(100*PLS_Var_5(1,:)),'-bo');
xlabel('Number of PLS components');
ylabel('Percent variance explained in X');
xticks(1:5); box off; grid off
 
TSS = sum((y-mean(y)).^2);
RSS_PLS = sum((y-yfit_PLS_5).^2);
rsquaredPLS = 1 - RSS_PLS/TSS
 
figure(fig_i)
fig_i = fig_i + 1;
[axes,h1,h2] = plotyy(0:5,MSE(1,:),0:5,MSE(2,:));
xticks(0:5)
set(h1,'Marker','o')
set(h2,'Marker','o')
legend('MSE predictors, X','MSE response, y')
xlabel('Number of PLS components')
%% Use 3 PLS components 
 
[XL,YL,XS,YS,beta,PCTVAR,MSE,stats] = plsregress(X,y,3);
W = stats.W;
% XL: X loadings, V
% YL: Y loadings, U (b)
% XS*XL' and XS*YL' are the PLS approximations to X0 and Y0.
% structure stats with the following fields:
% W � A p-by-ncomp matrix of PLS weights so that XS = Z = X0*W.
% T2 � The T2 statistic for each point in XS.
% Xresiduals � The predictor residuals, that is, X0-Z*XL' = X0-X0*W*XL';
% Yresiduals � The response residuals, that is,  Y0-Z*YL' = Y0-X0*W*YL'
 
yfit_PLS = [ones(size(X,1),1) X]*beta;
% beta(2:end,:) = W*YL'
 
 
TSS = sum((y-mean(y)).^2);
RSS_PLS = sum((y-yfit_PLS).^2);
Rsquared_PLS = 1 - RSS_PLS/TSS
 
figure(fig_i)
fig_i = fig_i + 1;
plot(y,yfit_PLS,'.')
daspect([1,1,1])
 
xlabel('Observed response'); ylabel('Fitted response')
 
figure(fig_i)
fig_i = fig_i + 1;
plot(1:5,stats.W,'o-');
legend({'1st PC','2nd PC','3rd PC'},'Location','best')
xlabel('Predictor');
xticks(1:5)
xticklabels({'x1','x2','x3','x4','x4'})
ylabel('Weight');
box off; grid off
 
figure(fig_i)
fig_i = fig_i + 1;
 
subplot(1,3,[1,2])
residuals = y - yfit_PLS;
stem(residuals,'.')
ylabel('Residual'); xlabel('Observation points')
box off; grid off; axis tight
y1 = ylim;
 
subplot(1,3,3)
histogram(residuals,'Normalization','probability');
xlim(y1); view(90,-90); box off;
ylabel('Probability')

