% B4_Ch10_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B4_Ch10_1_A.m

% Use S&P 500 as the market
% download 50 components of S&P 500 as the universe
clc; close all; clear all

AssetList = {'AAPL','ADBE','AIG','AMZN','ANSS','AXP',...
    'BA','BLK','C','CAT','CBOE','CME','COST','DD',...
    'DIS','ETN','F','FB','FDX','GE','GM','GOOG',...
    'HD','HON','HPQ','IBM','INTC','JNJ','JPM','KO'...
    ,'MCD','MMM','MS','MSCI','MSFT','NDAQ','NFLX',...
    'NKE','NVDA','PFE','PG','QCOM','RL','SBUX','TIF'...
    ,'TWTR','V','WMT','XOM','YUM'};

price_assets = hist_stock_data('01012016','01012017',AssetList);
price_market = hist_stock_data('01012016','01012017','^IXIC'); %^IXIC, ^GSPC
%% Plot the relative levels of the stocks and S&P 500
num_Bdays_year = 252;
Price_levels = extractfield(price_assets,'AdjClose');
asset_labels = extractfield(price_assets,'Ticker');

dates_cells = price_assets(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');

no_data = AssetList;
no_data(ismember(AssetList, asset_labels)) = [];

num_assets = length(asset_labels);
Price_levels = reshape(Price_levels,length(dates),length(asset_labels));
price_market = price_market.AdjClose;

relative_levels = ret2price(price2ret(Price_levels));
relative_up = relative_levels(:,relative_levels(end,:)>1);
relative_down = relative_levels(:,relative_levels(end,:)<1);

%% Relative daily stock adjusted closing prices

fig_index = 1;

figure(fig_index)
fig_index = fig_index + 1;
plot(dates, relative_up,'r'); hold on
plot(dates, relative_down,'color',[2,148,255]./255); hold on
plot(dates, ret2price(price2ret(price_market)),'k','LineWidth',2); hold on; box off; grid off
datetick('x','mm/dd/yyyy')
% xlim([dates(1),dates(end)]);
xlabel('Date');
ylabel('Stock relative prices')
title ('Relative daily stock closings')

%% Create a portfolio object
market_ret = mean(price2ret(price_market));
market_rsk = std(price2ret(price_market));
risk_free = 0.03;
% risk-free rate, monthly
cash_rsk = 0;

dailyReturn = price2ret(Price_levels);
% AssetMean = mean(price2ret(Price_levels));
% AssetCovar = cov(price2ret(Price_levels));

p = Portfolio('AssetList',asset_labels,'RiskFreeRate',risk_free/num_Bdays_year);
% p = setAssetMoments(p,AssetMean,AssetCovar);
% p = estimateAssetMoments(p, dailyReturn);

p = estimateAssetMoments(p, Price_levels,'dataformat', 'prices');

p = setInitPort(p,1/p.NumAssets);
[ersk,eret] = estimatePortMoments(p,p.InitPort);

i_std = sqrt(diag(p.AssetCovar));
i_mean = p.AssetMean;
i_label = p.AssetList;

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Asset Risks and Returns', ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_B.m

%% % Plot efficient frontier

p = setDefaultConstraints(p);

pwgt = estimateFrontier(p,20);
[prsk,pret] = estimatePortMoments(p,pwgt);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier', ...
    {'line', prsk, pret}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_C.m

%% Plot efficient frontier with tangent line (0 to 1 cash)

q = setBudget(p, 0, 1);

qwgt = estimateFrontier(q,20);
[qrsk,qret] = estimatePortMoments(q,qwgt);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with Tangent Line', ...
    {'line', prsk, pret}, ...
    {'line', qrsk, qret, [], [], 1}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});
hold on
w_tangent = estimateMaxSharpeRatio(p);
[risk_T, ret_T] = estimatePortMoments(p, w_tangent);
plot(risk_T*sqrt(num_Bdays_year),ret_T*num_Bdays_year,'p','markers',...
    15,'MarkerEdgeColor','k','MarkerFaceColor','y');

% B4_Ch10_1_D.m

%% Find a Portfolio with Targeted Returns

TargetReturns = 0.2:0.4:1;
% target annualized return and risk

% Obtain portfolios with targeted return and risk

awgt = estimateFrontierByReturn(p,TargetReturns/num_Bdays_year);
% TargetReturns/12 >>> monthly targeted returns

[arsk,aret] = estimatePortMoments(p,awgt);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with Targeted Portfolios', ...
    {'line', prsk, pret}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', arsk(1), aret(1),...
    {sprintf('%g%% return',100*TargetReturns(1))}}, ...
    {'scatter', arsk(2), aret(2),...
    {sprintf('%g%% return',100*TargetReturns(2))}}, ...
    {'scatter', arsk(3), aret(3),...
    {sprintf('%g%% return',100*TargetReturns(3))}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

%%

TargetReturns = 1; % 0.6, 0.2

awgt = estimateFrontierByReturn(p,TargetReturns/num_Bdays_year);

aBlotter = dataset({100*awgt(awgt > 0),'Weight'}, 'obsnames',...
    p.AssetList(awgt > 0));

displayPortfolio(sprintf('Portfolio with %g%% target return',...
    100*TargetReturns), aBlotter, false);

% B4_Ch10_1_E.m

%% Find a Portfolio with Targeted Risk

TargetRisk = 0.2:0.1:0.4;
bwgt = estimateFrontierByRisk(p,TargetRisk/sqrt(num_Bdays_year));
% TargetRisk/sqrt(num_Bdays_year) = daily standard deviation
[brsk,bret] = estimatePortMoments(p,bwgt);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with Targeted Portfolios', ...
    {'line', prsk, pret}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', brsk(1), bret(1),...
    {sprintf('%g%% risk',100*TargetRisk(1))}}, ...
    {'scatter', brsk(2), bret(2),...
    {sprintf('%g%% risk',100*TargetRisk(2))}}, ...
    {'scatter', brsk(3), bret(3),...
    {sprintf('%g%% risk',100*TargetRisk(3))}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

%%
TargetRisk = 0.4;
bwgt = estimateFrontierByRisk(p,TargetRisk/sqrt(num_Bdays_year));

bBlotter = dataset({100*bwgt(bwgt > 0),'Weight'}, 'obsnames', p.AssetList(bwgt > 0));

displayPortfolio(sprintf('Portfolio with %g%% Target Risk',...
    100*TargetRisk), bBlotter, false);

% B4_Ch10_1_F.m

%% Set lower-bound and upper-bound constraints

p = setDefaultConstraints(p);

pwgt = estimateFrontier(p,20);
[prsk,pret] = estimatePortMoments(p,pwgt);

p_bounds = setBounds(p,0.005,0.2);

pwgt_bounds = estimateFrontier(p_bounds,20);
[prsk_bounds,pret_bounds] = estimatePortMoments(p_bounds,pwgt_bounds);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Bound constraints', ...
    {'line', prsk, pret,{'Unconstrained'}}, ...
    {'line', prsk_bounds, pret_bounds,{sprintf('With bounds')} 'b'}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_G.m

%% Set linear inequality constraints

A = zeros(2,length(asset_labels));
A(1,1:30)   = -1;
A(2,21:end) = 1;
b = [-0.5; 0.5];

p = setDefaultConstraints(p);

pwgt = estimateFrontier(p,20);
[prsk,pret] = estimatePortMoments(p,pwgt);
p_ineq = p;
p_ineq = setInequality(p_ineq, A, b);

disp('Number of assets')
disp(p_ineq.NumAssets)
disp('A in inequality')
disp(p_ineq.AInequality)
disp('b in inequality')
disp(p_ineq.bInequality)

pwgt_ineq = estimateFrontier(p_ineq,20);
[prsk_ineq, pret_ineq] = estimatePortMoments(p_ineq,pwgt_ineq);


figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Inequality constraints', ...
    {'line', prsk, pret,{'Unconstrained'}}, ...
    {'line', prsk_ineq, pret_ineq,{sprintf('With inequality constraint')} 'b'}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_H.m

%% Set budget constraints

p = setDefaultConstraints(p);
lower_budget = 0.5;
upper_budget = 1.2;
% [0, 1] [0.5, 1] [0.8, 1] [1, 1.2]

pwgt = estimateFrontier(p,20);
[prsk,pret] = estimatePortMoments(p,pwgt);
p_budget = p;
p_budget = setBudget(p_budget, lower_budget, upper_budget);

disp('Number of assets')
disp(p_budget.NumAssets)
disp('Lower budget')
disp(p_budget.LowerBudget)
disp('Upper budget')
disp(p_budget.UpperBudget)

pwgt_budget = estimateFrontier(p_budget,20);
[prsk_budget, pret_budget] = estimatePortMoments(p_budget,pwgt_budget);


figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Equality constraints', ...
    {'line', prsk, pret,{'Unconstrained'}}, ...
    {'line', prsk_budget, pret_budget,{sprintf('Budget constraint')} 'b'}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_I.m

%% Turnover Constraint

BuyCost = 0; % daily
SellCost = 0;
Turnover = 0.2;

q = setCosts(p, BuyCost,SellCost);
q = setTurnover(q,Turnover);

[qwgt,qbuy,qsell] = estimateFrontier(q,20);
[qrsk,qret] = estimatePortMoments(q,qwgt);

% Plot efficient frontier with turnover constraint

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with Turnover Constraint', ...
    {'line', prsk, pret, {'Unconstrained'}}, ...
    {'line', qrsk, qret, {sprintf('%g%% Turnover', 100*Turnover)}, 'b'}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

%% multiple turnover rates

turnovers = 0.1:0.1:0.5;

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with Turnover Constraint', ...
    {'line', prsk, pret, {'Unconstrained'}}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});
TurnoverConstraintPlot(p,turnovers)

% B4_Ch10_1_J.m

%% Plot efficient frontiers with gross and net returns

BuyCost  = 0.0002; % daily
SellCost = 0.0002;

q = setCosts(p,BuyCost,SellCost);

qwgt = estimateFrontier(q,20);
[qrsk,qret] = estimatePortMoments(q,qwgt);

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with and without Transaction Costs', ...
    {'line', prsk, pret, {'Gross'}}, ...
    {'line', qrsk, qret, {'Net'}, 'b'}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});

% B4_Ch10_1_K.m

%% Tracking error constraint

ii = [29, 32, 33, 37];
% indexes of assets to include in tracking portfolio

TrackingError = 0.05/sqrt(252);
TrackingPort = zeros(length(asset_labels), 1);
TrackingPort(ii) = 1;
TrackingPort = (1/sum(TrackingPort))*TrackingPort;

q = setTrackingError(p,TrackingError,TrackingPort);

qwgt = estimateFrontier(q,20);
[qrsk,qret] = estimatePortMoments(q,qwgt);

[trsk,tret] = estimatePortMoments(q,TrackingPort);

% Plot efficient frontier with tracking-error constraint

figure(fig_index)
fig_index = fig_index + 1;
plot_edited('Efficient Frontier with 5% Tracking-Error Constraint', ...
    {'line', qrsk, qret, {'Tracking'}, 'b'}, ...
    {'scatter', trsk, tret, {'Tracking'}, 'r'},...
    {'line', prsk, pret, {'Unconstrained'}}, ...
    {'scatter', market_rsk, market_ret, {'Market'}}, ...
    {'scatter', cash_rsk, risk_free/num_Bdays_year, {'Cash'}}, ...
    {'scatter', ersk, eret, {'Original'}}, ...
    {'scatter', i_std, i_mean, i_label, '.b'});


% B4_Ch10_1_L.m

function TurnoverConstraintPlot(p, turnovers)

numPorts = 20;
p = p.setSolver('quadprog');

% Generate turnover-constrained portfolios
for currentTurnover = turnovers
    p = p.setTurnover(currentTurnover);
    Wts = p.estimateFrontier(numPorts);
    [Risks, Returns]   = p.estimatePortMoments(Wts);
    name = [num2str(100*currentTurnover) '% Turnover'];
    plot(Risks*sqrt(252), Returns*252, 'DisplayName', name, 'LineWidth', 2)
end

legend('Location', 'best')

end

function plot_edited(varargin)
num_Bdays_year = 252;
plottitle = varargin{1};
plotlegend = [];

for i = 2:nargin
    plotinfo = varargin{i};
    
    plottype = plotinfo{1};
    plotrsk = plotinfo{2};
    plotret = plotinfo{3};
    if numel(plotinfo) > 3
        plotlabel = plotinfo{4};
    else
        plotlabel = [];
    end
    if numel(plotinfo) > 4
        plotstyle = plotinfo{5};
        if isempty(plotstyle)
            plotstyle = 'b';
        end
    else
        if strcmpi(plottype,'line')
            plotstyle = 'k';
        else
            plotstyle = 'xr';
        end
    end
    if numel(plotinfo) > 5
        plotline = plotinfo{6};
        if isempty(plotline)
            plotline = 2;
        end
    else
        if strcmpi(plottype,'line')
            plotline = 2;
        else
            plotline = [];
        end
    end
    
    % line plot
    if strcmpi(plottype,'line')
        for k = 1:size(plotrsk,2)
            plot(sqrt(num_Bdays_year)*plotrsk(:,k), num_Bdays_year*plotret(:,k),...
                plotstyle, 'LineWidth', plotline);
            if i == 2 && k == 1
                hold on
            end
            if ~isempty(plotlabel) && ~isempty(plotlabel{k})
                plotlegend = [ plotlegend, {plotlabel{k}} ];
            end
        end
        
        % scatter plot
    else
        if any(plotstyle == '.b')
            scatter(sqrt(num_Bdays_year)*plotrsk, num_Bdays_year*plotret, plotstyle);
        else
            scatter(sqrt(num_Bdays_year)*plotrsk, num_Bdays_year*plotret, 50, 'rx');
        end
        if i == 2
            hold on
        end
        if ~isempty(plotlabel)
            for k = 1:numel(plotrsk)
                if ~isempty(plotlabel{k})
                    if numel(plotrsk) == 1
                        font_size = 12;
                        text(sqrt(num_Bdays_year)*plotrsk(k) + 0.01, ...
                            num_Bdays_year*plotret(k), plotlabel{k},'BackgroundColor',[.7 .9 .7],...
                            'FontSize', font_size,'Color','r'); % 'EdgeColor','red'
                    else
                        font_size = 6;
                        text(sqrt(num_Bdays_year)*plotrsk(k) + 0.005, ...
                            num_Bdays_year*plotret(k), plotlabel{k},...
                            'FontSize', font_size);
                        
                    end
                    
                    
                end
            end
        end
    end
end

if ~isempty(plotlegend)
    legend(plotlegend,'Location','SouthEast');
end

title(['\bf' plottitle ]);
xlabel('Standard deviation of returns (annualized)');
ylabel('Mean of returns (annualized)');
x_lim = xlim;

grid off; box off
end

function displayPortfolio(Description, Blotter, LongShortFlag, portfolioType)
fprintf('%s\n', Description);
disp(Blotter);
if (LongShortFlag)
    fprintf('Confirm %s Portfolio\n', portfolioType);
    fprintf('  (Net, Long, Short)\n');
    fprintf('%.4f ' , [ sum(Blotter.Weight), sum(Blotter.Long), sum(Blotter.Short) ]);
end
end
