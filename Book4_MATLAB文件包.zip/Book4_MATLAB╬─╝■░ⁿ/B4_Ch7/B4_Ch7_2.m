% B4_Ch7_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
x1 = -3:0.2:3;
x2 = -3:0.2:3;
[xx1,xx2] = meshgrid(x1,x2);
ff =  3*(1-xx1).^2.*exp(-(xx1.^2) - (xx2+1).^2) ... 
   - 10*(xx1/5 - xx1.^3 - xx2.^5).*exp(-xx1.^2-xx2.^2) ... 
   - 1/3*exp(-(xx1+1).^2 - xx2.^2);
 
FitnessFunction = @obj_fcn;
nvars = 2;
 
A = []; b = [];
Aeq = []; beq = [];
lb = [];
ub = [];
nonlcon= [];
% options = optimoptions('ga','ConstraintTolerance',1e-10,...
%     'PlotFcn', @gaplotbestf,'MaxStallGenerations',200);
 
options=gaoptimset('populationsize',...
    100,'generations',200,'stallGenLimit',...
    200,'TolFun',1e-10,'PlotFcns',{@gaplotbestf,@gaplotdistance}); 
 
%,'PlotFcns',@gaplotbestf,
%,'PlotFcns',@gaplotdistance,
 
[x, fval] = ga(FitnessFunction,nvars,A,b,...
    Aeq,beq,lb,ub,nonlcon,options);
 
figure(2)
subplot(1,2,1)
mesh(xx1,xx2,ff); hold on
plot3(x(1),x(2),fval,'rx')
box off; grid off
xlabel('x_1');ylabel('x_2'); zlabel('f(x)')
axis tight
 
subplot(1,2,2)
contour(xx1,xx2,ff,20); hold on
plot(x(1),x(2),'rx')
box off; grid off
xlabel('x_1');ylabel('x_2');
 
 
function y = obj_fcn(x)
 
y =  3*(1-x(1)).^2.*exp(-(x(1).^2) - (x(2)+1).^2) ... 
  - 10*(x(1)/5 - x(1).^3 - x(2).^5).*exp(-x(1).^2-x(2).^2) ... 
  - 1/3*exp(-(x(1)+1).^2 - x(2).^2);
 
end

