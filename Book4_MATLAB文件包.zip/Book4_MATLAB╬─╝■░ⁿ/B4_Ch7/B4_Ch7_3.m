% B4_Ch7_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
x = -5:0.1:5;
f1 = (x+2).^2 - 10;
f2 = (x-2).^2 ;
 
figure(1)
plot(x,f1);
hold on;
xticks([-5:5])
plot(x,f2,'r');
box off; grid off
xlabel('x'); ylabel('f(x)')
set(gca, 'XAxisLocation', 'origin')
legend('f_1(x)','f_2(x)')
%%
FitnessFunction = @simple_multiobjective;
numberOfVariables = 1;
 
A = []; b = [];
Aeq = []; beq = [];
lb = [];
ub = [];
options = optimoptions(@gamultiobj,'PlotFcn',...
    {@gaplotpareto,@gaplotscorediversity},'PopulationSize',200);

[x_sol, val] = gamultiobj(FitnessFunction,...
    numberOfVariables,A,b,Aeq,beq,lb,ub,options);
 
 
figure(3)
plot(x,f1,'b');
plot(x_sol,val(:,1),'xb')
hold on;
plot(x,f2,'r');
plot(x_sol,val(:,2),'xr')
plot(x_sol,zeros(size(x_sol)),'kx')
xticks([-5:5])
set(gca, 'XAxisLocation', 'origin')
box off; grid off
xlabel('x'); ylabel('f(x)')
 
figure(4)
subplot(4,4,[2:4 6:8 10:12]); % Top right square
plot(val(:,1),val(:,2),'kp')
y1=get(gca,'ylim'); x1=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
plot(val(:,2),x_sol,'rx')
xlim(y1); view(90,-90); box off;
xlabel('f_2(x)')
 
subplot(4,4,[14:16]); % Btm right
plot(val(:,1),x_sol,'bx')
xlim(x1); box off
xlabel('f_1(x)');
%% objective functions
function y = simple_multiobjective(x)
y(1) = (x+2)^2 - 10;
y(2) = (x-2)^2;
end
