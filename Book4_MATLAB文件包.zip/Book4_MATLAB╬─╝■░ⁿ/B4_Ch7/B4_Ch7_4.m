% B4_Ch7_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
xx1 = -6:0.1:6; xx2 = xx1;
[xx1,xx2] = meshgrid(xx1,xx2);
f1 = (xx1+2).^2 + (xx2+2).^2 - 10;
f2 = (xx1-2).^2 + (xx2-2).^2;
figure(1)
contour(xx1,xx2,f1,20); hold on;
contour(xx1,xx2,f2,20); grid off
xlabel('x_1'); ylabel('x_2');
axis square
%%
FitnessFunction = @simple_multiobjective;
numberOfVariables = 2;
 
A = []; b = [];
% A = [-1 0.5;
%      -1 -2;
%      1  1;];
% b = [1;-1;2];
 
Aeq = []; beq = [];
% Aeq = [1, -1]; beq = [1];
% lb = [-1; -Inf];
% ub = [Inf; 1];
lb = []; ub = [];
 
% options = optimoptions(@gamultiobj,'PlotFcn',...
%     {@gaplotpareto,@gaplotscorediversity});
options = optimoptions(@gamultiobj,'PlotFcn',...
    {@gaplotpareto,@gaplotscorediversity},'PopulationSize',400);
% [x_sol,fval] = gamultiobj(FitnessFunction,...
%     numberOfVariables,A,b,Aeq,beq,lb,ub,options);
[x_sol,fval] = gamultiobj(FitnessFunction,...
    numberOfVariables,A,b,Aeq,beq,lb,ub,...
    @nonlinear_constraints2,options);
 
%%
 
figure(3)
contour(xx1,xx2,f1,20); hold on;
contour(xx1,xx2,f2,20); grid off
plot(x_sol(:,1),x_sol(:,2),'x')
xlabel('x_1'); ylabel('x_2');
axis square
 
function y = simple_multiobjective(x)
y(1) = (x(1)+2)^2 + (x(2)+2)^2 - 10;
y(2) = (x(1)-2)^2 + (x(2)-2)^2 ;
end
 
function [c,ceq]=nonlinear_constraints(x)
 
% nonlinear inequalities
c(1) = (x(1)^2)/9 + (x(2)^2)/4 - 1;
c(2) = x(1)^2 - x(2) - 1;
 
% nonlinear equalities
ceq = [];
 
end
 
function [c,ceq]=nonlinear_constraints2(x)
 
% nonlinear inequalities
c = [];
 
% nonlinear equalities
ceq = (x(1)^2) + (x(2)^2) - 4;
 
end
