% B4_Ch7_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
xx = -4:0.01:4;
ff = obj_fcn(xx);
 
FitnessFunction = @obj_fcn;
nvars = 1;
 
A = []; b = [];
Aeq = []; beq = [];
lb = [];
ub = [];
nonlcon= [];
% options = optimoptions('ga','ConstraintTolerance',1e-10,...
%     'PlotFcn', @gaplotbestf,'MaxStallGenerations',200);
 
options=gaoptimset('populationsize',...
    100,'generations',200,'stallGenLimit',...
    200,'TolFun',1e-10,'PlotFcns',{@gaplotbestf,@gaplotdistance}); 
 
%,'PlotFcns',@gaplotbestf,
%,'PlotFcns',@gaplotdistance,
 
[x, fval] = ga(FitnessFunction,nvars,A,b,...
    Aeq,beq,lb,ub,nonlcon,options);
 
figure(2)
plot(xx,ff); hold on
plot(x,fval,'rx')
box off; grid off
xlabel('x'); ylabel('f(x)')
set(gca, 'XAxisLocation', 'origin')
 
function y = obj_fcn(x)
 
y = x.^2 + 5*sin(4*x);
 
end
