% B4_Ch11_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B4_Ch11_1_A.m

clc; close all; clear all
 
stocks = {'COST','MCD','GM','GOOG','TSLA','PFE'};
 
price = hist_stock_data('01012018','01012020',stocks);
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
y_price = price(1).AdjClose;
x1_price = price(2).AdjClose;
x2_price = price(3).AdjClose;
x3_price = price(4).AdjClose;
x4_price = price(5).AdjClose;
x5_price = price(6).AdjClose;
 
y = diff(log(y_price));
x1  = diff(log(x1_price));
x2    = diff(log(x2_price));
x3  = diff(log(x3_price));
x4 = diff(log(x4_price));
x5   = diff(log(x5_price));
x6 = [y,x1,x2,x3,x4,x5];
 
 
%% Linear regression, one-variable
 
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1; 
cov_x1_y = cov(x1,y);
cov_x1_y = cov_x1_y(1,2);
b1 = cov_x1_y/var(x1);
b0 = mean(y) - b1*mean(x1);
% use regress()
X = [ones(size(x1)) x1];
b = regress(y,X)
x1_x = min(x1):(max(x1) - min(x1))/10:max(x1);
y_hat_line = b1*x1_x + b0;
y_hat = interp1(x1_x,y_hat_line,x1);
mask = y_hat > y;
SST1 = var(y - mean(y));
SSR1 = var(y_hat - mean(y));
R_squared1 = SSR1/SST1
plot(x1(mask),y(mask),'.','color',[255,192,0]/255); hold on
plot(x1(~mask),y(~mask),'.','color',[0,153,255]/255); 
plot(mean(x1),mean(y),'ok','MarkerFaceColor','w')
plot(x1_x,y_hat_line,'color',[147, 205, 221]/255,'LineWidth',1.25)
xlim([-0.075,0.075]); ylim([-0.075,0.075]);
box off; daspect([1,1,1])
xlabel('x'); ylabel('y')
title(['OLS regression: y = ',num2str(b1),'*x + ',num2str(b0)])
format long
 
%% plot y-y_hat and residuals
 
figure(fig_i)
fig_i = fig_i + 1; 
 
plot(y,y_hat,'r.'); hold on
plot(y,y,'-b')
plot([y,y]',[y_hat,y]','k-'); hold on
xlabel('Observed y');
ylabel('Fitted y');
daspect([1,1,1])
 
figure(fig_i)
fig_i = fig_i + 1; 
 
subplot(1,3,[1,2])
stem(y-y_hat,'.'); hold on
ylabel('Residual'); xlabel('Observation points')
box off; grid off; axis tight
y1 = ylim;
 
subplot(1,3,3)
histogram(y-y_hat,'Normalization','probability');
xlim(y1); view(90,-90); box off;
ylabel('Probability')

% B4_Ch11_1_B.m

%% Least squared regression, two-variables
 
figure(fig_i)
fig_i = fig_i + 1; 
 
X = [ones(size(x1)),x1,x2];
b = inv(X.'*X)*X.'*y;
 
x1_x = min(x1):(max(x1) - min(x1))/10:max(x1);
x2_x = min(x2):(max(x2) - min(x2))/10:max(x2);
[x1_xx,x2_xx] = meshgrid(x1_x,x2_x)
y_hat_surf = b(1) + b(2)*x1_xx + b(3)*x2_xx;
 
y_hat = interp2(x1_xx,x2_xx,y_hat_surf, x1,x2);
mask = y_hat > y;
plot3(x1(mask),x2(mask),y(mask),'.','color',[255,192,0]/255); hold on
plot3(x1(~mask),x2(~mask),y(~mask),'.','color',[0,153,255]/255); 
% use regress()
X = [ones(size(x1)) x1 x2];
b = regress(y,X)
plot3(mean(x1),mean(x2),mean(y),'ok','MarkerFaceColor','w')
h = mesh(x1_xx,x2_xx,y_hat_surf)
h.FaceAlpha = 0.3
title(['OLS regression: y = ',num2str(b(2)),...
'*x1 + ',num2str(b(3)),'*x2 + ',num2str(b(1))])
axis tight; box off; daspect([1,1,1])
xlabel('x_1'); ylabel('x_2'); zlabel('y')
view(-30,30); zlim([-0.1,0.1])

% B4_Ch11_1_C.m

%% Least squared regression, multi-variables
X = [ones(size(x1)),x1,x2,x3,x4,x5];
b = inv(X.'*X)*X.'*y
 
b = regress(y,X)

% B4_Ch11_1_D.m

figure(fig_i)
fig_i = fig_i + 1; 
 
cov_x1_y = cov(x1,y);
cov_x1_y = cov_x1_y(1,2);
b1 = cov_x1_y/var(x1);
b0 = mean(y) - b1*mean(x1);
% use regress()
X = [ones(size(x1)) x1 x1.^2];
b = regress(y,X)
x1_x = min(x1):(max(x1) - min(x1))/10:max(x1);
y_hat_line = b(1) + x1_x*b(2) + x1_x.^2*b(3);
y_hat = interp1(x1_x,y_hat_line,x1);
mask = y_hat > y;
plot(x1(mask),y(mask),'.','color',[255,192,0]/255); hold on
plot(x1(~mask),y(~mask),'.','color',[0,153,255]/255); 
plot(mean(x1),mean(y),'ok','MarkerFaceColor','w')
plot(x1_x,y_hat_line,'color',[147, 205, 221]/255,'LineWidth',1.25)
axis tight; box off
xlabel('x'); ylabel('y')
daspect([1,1,1])
xlim([-0.075,0.075]); ylim([-0.075,0.075]);

% B4_Ch11_1_E.m

%% Total linear regression, one-variable
 
figure(fig_i)
fig_i = fig_i + 1; 

x1_centered = x1 - mean(x1);
y_centered = y - mean(y);
V = pca([x1,y])
b1 = -V(1,2)/V(2,2);
 
y_hat_line = b1*x1_x + b0;
y_hat = interp1(x1_x,y_hat_line,x1);
 
SST2 = var(y - mean(y));
SSR2 = var(y_hat - mean(y));
R_squared2 = SSR2/SST2
% R_squared cannot be applied in this use case
% This is only an example
 
mask = y_hat > y;
plot(x1(mask),y(mask),'.','color',[255,192,0]/255); hold on
plot(x1(~mask),y(~mask),'.','color',[0,153,255]/255); 
 
plot(mean(x1),mean(y),'ok','MarkerFaceColor','w')
plot(x1_x,y_hat_line,'color',[147, 205, 221]/255,'LineWidth',1.25)
 
h1 = quiver(mean(x1),mean(y),V(1,1),V(2,1),'b');
h1.AutoScaleFactor = 0.05;
h2 = quiver(mean(x1),mean(y),V(1,2),V(2,2),'r');
h2.AutoScaleFactor = 0.05;
xlim([-0.075,0.075]); ylim([-0.075,0.075]);  box off
xlabel('x'); ylabel('y')
title(['TLS regression: y = ',num2str(b1),'*x + ',num2str(b0)])
daspect([1,1,1])

% B4_Ch11_1_F.m

%% Total linear regression, two-variables
 
figure(fig_i)
fig_i = fig_i + 1; 
 
[V,~,LAMBDA] = pca([x1,x2,y])
b = -V(1:end-1,end)/V(end,end);
 
b0 = mean(y) - b(1)*mean(x1) - b(2)*mean(x2);
 
x1_x = min(x1):(max(x1) - min(x1))/10:max(x1);
x2_x = min(x2):(max(x2) - min(x2))/10:max(x2);
[x1_xx,x2_xx] = meshgrid(x1_x,x2_x);
y_hat_surf = b0 + b(1)*x1_xx + b(2)*x2_xx;
 
y_hat = interp2(x1_xx,x2_xx,y_hat_surf, x1,x2);
mask = y_hat > y;
plot3(x1(mask),x2(mask),y(mask),'.','color',[255,192,0]/255); hold on
plot3(x1(~mask),x2(~mask),y(~mask),'.','color',[0,153,255]/255); 
% use regress()
 
plot3(mean(x1),mean(x2),mean(y),'or')
 
h1 = quiver3(mean(x1),mean(x2),mean(y),V(1,1),V(2,1),V(3,1),'b');
h1.AutoScaleFactor = 0.05;
h2 = quiver3(mean(x1),mean(x2),mean(y),V(1,2),V(2,2),V(3,2),'r');
h2.AutoScaleFactor = 0.05;
h3 = quiver3(mean(x1),mean(x2),mean(y),V(1,3),V(2,3),V(3,3),'g');
h3.AutoScaleFactor = 0.05;
 
h = mesh(x1_xx,x2_xx,y_hat_surf);
h.FaceAlpha = 0.3;
title(['TLS regression: y = ',num2str(b(1)),...
'*x1 + ',num2str(b(2)),'*x2 + ',num2str(b0)])
axis tight; box off; daspect([1,1,1])
xlabel('x_1'); ylabel('x_2'); zlabel('y')
view(-30,30);
view(2,0)
zlim([-0.1,0.1])

% B4_Ch11_1_G.m

X = [x1,x2,x3,x4,x5];
[V,~,LAMBDA] = pca([X,y]);
b = -V(1:end-1,end)/V(end,end)
b0 = mean(y) - mean(X)*b
b = [b0;b];
 
figure(fig_i)
fig_i = fig_i + 1; 
stem(b)
xticks([0:5])
xticklabels({'b_0','b_1','b_2','b_3','b_4','b_5'})
ylabel('Coefficient')
box off; grid off
