% B4_Ch3_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms f(x)
f(x) = cos(2*x)*x;
df = diff(f,x)
 
x_fine = -5:0.1:5; x_coarse = -3.5:0.5:3.5;
 
f_x_fine = double(subs(f,[x],{x_fine}));
f_x_coarse = double(subs(f,[x],{x_coarse}));
df_x_coarse = double(subs(df,[x],{x_coarse}));
 
figure(1)
subplot(1,2,1)
plot(x_fine,f_x_fine,'color',[0,96,166]/255); hold on
plot(x_coarse,f_x_coarse,'xk')
quiver(x_coarse,f_x_coarse,...
    df_x_coarse,-1 + 0*df_x_coarse,...
    'color',[255,153,255]/255)
decor
 
subplot(1,2,2)
plot(x_fine,f_x_fine,'color',[0,96,166]/255); hold on
plot(x_coarse,f_x_coarse,'xk')
quiver(x_coarse,f_x_coarse,...
    1 + 0*df_x_coarse, df_x_coarse,...
    'color',[0,153,255]/255)
decor
 
function decor()
 
daspect([1,1,1]); xlim([-5,5]); ylim([-5,5]);
ax = gca; box off; grid off
ax.XAxisLocation = 'origin'; ax.YAxisLocation = 'origin';
yticks([-4:2:4]); xticks([-4:2:4]); xlabel('x'); ylabel('y')
 
end
