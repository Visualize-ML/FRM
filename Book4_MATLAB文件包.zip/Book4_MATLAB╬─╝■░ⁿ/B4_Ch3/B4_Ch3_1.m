% B4_Ch3_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x1 x2
 
f = -x1^2 - 2*x2^2 - x1*x2;
g = gradient(f, [x1, x2])
 
[XX1, XX2] = meshgrid(-3:0.4:3,-3:0.4:3);
[XX1_fine, XX2_fine] = meshgrid(-3:.2:3,-3:.2:3);
 
contour_f = subs(f, [x1 x2], {XX1_fine,XX2_fine});
 
figure(1)
% c_start = floor(min(double(contour_f(:))));
% c_end   = floor(max(double(contour_f(:))));
% c_levels = c_start:(c_end-c_start)/20:c_end;
 
c_start = -24; c_end   = 0;
c_levels = c_start:2:c_end;
 
ii = 1:4;
 
for i = ii
    
    subplot(2,2,i)
    plot_fig(g,XX1_fine,XX2_fine,contour_f,c_levels,i)
    
end
 
function plot_fig(g,XX1_fine,XX2_fine,contour_f,c_levels,i)
syms x1 x2
contour(XX1_fine,XX2_fine,double(contour_f),c_levels); hold on
 
c_level = c_levels(end-i); %  -1, -2, -3, - 4
[contour_loc,~] = contour(XX1_fine,XX2_fine,double(contour_f),[c_level,c_level],'LineWidth',3);
 
x1_contour_c = contour_loc(1,2:end);
x2_contour_c = contour_loc(2,2:end);
 
dFF_dx1 = subs(g(1), [x1 x2], {x1_contour_c x2_contour_c});
dFF_dx2 = subs(g(2), [x1 x2], {x1_contour_c x2_contour_c});
 
scale_factor = 0.15;
h = quiver(x1_contour_c, x2_contour_c, double(dFF_dx1)*scale_factor, double(dFF_dx2)*scale_factor);
h.AutoScale = 'off';
 
h.Color = [0,96,166]/255;
h.Marker = '.';
h.MarkerSize = 3;
h.MaxHeadSize = Inf;
 
xlabel('${x_1}$','Interpreter','latex');
ylabel('${x_2}$','Interpreter','latex');
zlabel('${f(x_1,x_2)}$','Interpreter','latex')
title(['Contour level = ',num2str(c_level)])
set(gca, 'FontName', 'Times New Roman','fontsize',10)
grid off; axis equal
xlim([-3,3]); ylim([-3,3]);
caxis([-18 0])
end
