% B4_Ch3_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x y z
[xx, yy, zz] = ellipsoid(0,0,0,1,1,1,30);
F = x^2 + y^2 + z^2 - 1;
x0 = 1/2; y0 = 1/2; z0 = sqrt(2)/2;
g = gradient(F, [x, y, z])
 
dF_dx = subs(g(1), [x y z], {x0,y0,z0});
dF_dy = subs(g(2), [x y z], {x0,y0,z0});
dF_dz = subs(g(3), [x y z], {x0,y0,z0});
 
n = [dF_dx, dF_dy, dF_dz];
P_vector = [x-x0, y-y0, z-z0];
eqn = dot(n, P_vector) == 0;
plane_f = solve(eqn,z);
 
[xx0,yy0] = meshgrid(x0-0.5:0.25:x0+0.5, y0-0.5:0.25:y0+0.5);
zz0 = double(subs(plane_f,[x,y],{xx0,yy0}));
 
figure(1)
plot3(x0,y0,z0,'ro'); hold on
mesh(xx, yy, zz)
h_vector = quiver3(x0,y0,z0,dF_dx,dF_dy,dF_dz)
h_vector.AutoScaleFactor = 0.5;
 
mesh(xx0,yy0,zz0,'edgecolor','k','FaceAlpha',0)
 
axis equal; box on; grid off
xlabel('x'); ylabel('y'); zlabel('z'); view(60,30)

