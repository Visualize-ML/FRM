% B4_Ch3_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

syms x y z
f1 = x + y - z;
f2 = y - z + 5;
f3 = x - z + 5;
f4 = z - 5;
 
figure(1)
subplot(2,2,1)
plot_fig(f1)
 
subplot(2,2,2)
plot_fig(f2)
 
subplot(2,2,3)
plot_fig(f3)
 
subplot(2,2,4)
plot_fig(f4)
 
function plot_fig(f)
 
syms x y z
 
[xx,yy] = meshgrid([0:0.5:5,0:0.5:5]);
 
f_z = solve(f,z);
ff_z = double(subs(f_z, [x y], {xx,yy}));
g = gradient(f, [x, y z]);
mesh(xx,yy,ff_z); hold on
 
x0 = xx(1:2:end,1:2:end);
y0 = yy(1:2:end,1:2:end);
z0 = ff_z(1:2:end,1:2:end);
 
dFF_dx = subs(g(1), [x y z], {x0,y0,z0});
dFF_dy = subs(g(2), [x y z], {x0,y0,z0});
dFF_dz = subs(g(3), [x y z], {x0,y0,z0});
 
h1 = quiver3(x0,y0,z0,dFF_dx,dFF_dy,dFF_dz,...
    'color',[255,153,255]/255);
h1.AutoScaleFactor = 1;
view(135,15); grid off; box on
xlabel('x'); ylabel('y'); zlabel('z');
xticks([0:2:4]); yticks([0:2:4]); zticks([0:2:10])
end
