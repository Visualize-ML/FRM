% B4_Ch3_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


figure(1)
 
subplot(3,2,1)
a = 1; b = 80; c = 1; d = 80; j = 3; k = 3;
plot_curve (a, b, c, d, j, k)
 
subplot(3,2,2)
a = 80; b = 1; c = 1; d = 80; j = 3; k = 3;
plot_curve (a, b, c, d, j, k)
 
subplot(3,2,3)
a = 1; b = 80; c = 1; d = 80; j = 3; k = 4;
plot_curve (a, b, c, d, j, k)
 
subplot(3,2,4)
a = 80; b = 1; c = 1; d = 80; j = 3; k = 4;
plot_curve (a, b, c, d, j, k)
 
subplot(3,2,5)
a = 1; b = 80; c = 80; d = 80; j = 3; k = 4;
plot_curve (a, b, c, d, j, k)
 
subplot(3,2,6)
a = 1; b = 80; c = 80; d = 1; j = 3; k = 4;
plot_curve (a, b, c, d, j, k)
 
 
function plot_curve (a, b, c, d, j, k)
 
t = 0:0.001:2*pi;
x = cos(a*t) - cos(b*t).^j;
y = sin(c*t) - sin(d*t).^k;
plot(x,y)
daspect([1,1,1])
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'ztick',[])
axis off
xlabel('x');ylabel('y');zlabel('z');
title({['a = ',num2str(a),'; b = ',num2str(b),...
    '; c = ',num2str(c),'; d = ',num2str(d),';'],...
    ['j = ',num2str(j),'; k = ',num2str(k)]})
end
