% B4_Ch3_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


clc; clear all; close all
syms x y
f = -(x^2 + y^2);
 
g = gradient(f, [x, y])
 
[XX, YY] = meshgrid(-2:.1:2,-2:.1:2);
 
 
ZZ = double(subs(f,[x,y],{XX,YY}));
x0 = -1; y0= -1;
dF_dx = subs(g(1), [x y], {x0,y0});
dF_dy = subs(g(2), [x y], {x0,y0});
z0 = double(subs(f,[x,y],{x0,y0}));
 
figure(1)
 
contour(XX,YY,ZZ,[-4:0.2:0]); hold on
contour(XX,YY,ZZ,[z0,z0],'LineWidth',1.5,'color',[0,96,166]/255); hold on
 
quiver(x0,y0,dF_dx,dF_dy,'color',[255,102,255]/255,'LineWidth',1.5)
 
daspect([1 1 1]); grid off; box on
xlabel('x'); ylabel('y'); zlabel('z'); zlim([-4,0])
 
figure(2)
contour3(XX,YY,ZZ,[-4:0.2:0]); hold on
% mesh(XX,YY,ZZ); hold on
[C,h] = contour3(XX,YY,ZZ,[z0,z0],'LineWidth',1.5,'color',[0,96,166]/255); hold on
plot3(C(1,2:end),C(2,2:end),-4+C(1,2:end)*0,'LineWidth',1.5,'color',[0,96,166]/255)
 
quiver3(x0,y0,z0,dF_dx,dF_dy,-1,'color',[255,102,255]/255,'LineWidth',1.5)
quiver3(x0,y0,-4,dF_dx,dF_dy,0,'color',[255,102,255]/255,'LineWidth',1.5)
 
daspect([1 1 1]); grid off; box on
xlabel('x'); ylabel('y'); zlabel('z')
zlim([-4,0]); view(-25,25)

