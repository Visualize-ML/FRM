% B4_Ch3_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 4  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
syms x y
f = x^2 + y^2 - 1;
g = gradient(f, [x, y])
 
[XX1, XX2] = meshgrid(-3:0.2:3,-3:0.2:3); % 0.4
 
[XX1_fine, XX2_fine] = meshgrid(-3:.2:3,-3:.2:3);
 
figure(1)
hold on
 
thetas = pi/12:pi/6:2*pi;
 
for ii = 1:length(thetas)
    theta = thetas(ii);
    x0 = cos(theta);
    y0 = sin(theta);
    plot(x0,y0,'xk')
    dFF_dx = subs(g(1), [x y], {x0,y0});
    dFF_dy = subs(g(2), [x y], {x0,y0});
    
    h1 = quiver(x0,y0,dFF_dx,dFF_dy,...
        'color',[255,153,255]/255)
    h1.AutoScaleFactor = 0.4;
    h2 = quiver(x0,y0,-dFF_dy,dFF_dx,...
        'color',[0,153,255]/255)
    h2.AutoScaleFactor = 0.4;
end
 
fimplicit(f, [-2 2 -2 2],'color',[0,96,166]/255,'LineWidth',1); hold on
daspect([1,1,1])
xlim([-2.1,2.1]); ylim([-2.1,2.1]);
ax = gca; box off; grid off
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
yticks([-2:1:2]); xticks([-2:1:2])
xlabel('x'); ylabel('y')

