# B1_Ch3_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
identity_matrix = np.identity(3,dtype = 'i')
eye_matrix1 = np.eye(3,dtype ='i')
eye_matrix2 = np.eye(3,2,dtype ='f')
eye_matrix3 = np.eye(3,3,1,dtype = 'i')
eye_matrix4 = np.eye(3,3,-1)
print(f'The identity matrix is \n {identity_matrix}')
print(f'The identity matrix created by eye function: \n {eye_matrix1}')
print(f'The 3×2 matrix is \n {eye_matrix2}')
print(f'The index of the diagonal is 1: \n {eye_matrix3}')
print(f'The index of the diagonal is -1: \n {eye_matrix4}')
