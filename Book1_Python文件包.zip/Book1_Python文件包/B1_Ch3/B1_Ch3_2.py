# B1_Ch3_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
a_list =[1,2,3,4]
a_tuple = tuple(a_list)
a_set = set(a_list)
print(f"The original list is {a_list}")
print("The array created from a list is {}".format(np.array(a_list)))
print(f"The array created from a tuple is {np.array(a_tuple)}")
print(f"The array created from a set is {np.array(a_set)}")
print(f"The type of the array created from a tuple is {type(np.array(a_tuple))}")
print(f"The type of the array created from a set is {type(np.array(a_set))}")