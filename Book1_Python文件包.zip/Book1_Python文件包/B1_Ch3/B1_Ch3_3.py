# B1_Ch3_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import math
degree_list = [10,20,30]
sin_list = [math.sin(i) for i in degree_list]
sin_list_int = np.array(sin_list,dtype='i')
sin_list_float = np.array(sin_list,dtype='f')
date_example = np.array(['2005-02-25','2011-12-25','2020-09-20'],dtype = 'M')
date_increment = np.array([100,200,300],dtype = 'm')
date_example_updated = date_example+date_increment
print(f'Saving the data in the format of integer:{sin_list_int}')
print(f'Saving the data in the format of floating point:{sin_list_float}')
print(f'Datetime example: {date_example}')
print(f'Updated datetime is: {date_example_updated}')
