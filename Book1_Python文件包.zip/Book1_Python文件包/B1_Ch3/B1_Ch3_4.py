# B1_Ch3_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
list_obj = [[1,1],[1,1]]
# create a ndarray and a list, respectively
ndarray_obj = np.ones((2,2),dtype = 'i')
list_np = np.array(list_obj)

#Case 1: create a ndarray from a list
nd_1 = np.array(list_obj,copy = False)
#Case 2: use the default value for the copy parameter
nd_2 = np.array(ndarray_obj)
#Case 3: copy = false
nd_3 = np.array(ndarray_obj,copy = False)
# Case 4: change dtype
nd_4 = np.array(ndarray_obj,copy = False,dtype = 'f')

ndarray_obj[1][1]=2
list_obj[1][1] =2

print(f"The ndarray in case 1 is \n {nd_1}\n")
print(f"The ndarray in case 2 is \n {nd_2}\n")
print(f"The ndarray in case 3 is \n {nd_3}\n")
print(f"The ndarray in case 4 is \n {nd_4}\n")
