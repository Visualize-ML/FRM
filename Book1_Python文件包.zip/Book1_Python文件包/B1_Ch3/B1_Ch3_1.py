# B1_Ch3_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import time
# Create a ndarray of integers in the range
# 0 up to (but not including) 10,000,000
array = np.arange(1e4)
# Convert it to a list
list_array = array.tolist()
start_time = time.time()
y = [val * 5 for val in list_array]
print("List calculation time is %s seconds." % (time.time() - start_time)) 
# List calculation time is 5.672233819961548 seconds.
start_time = time.time()
x = array * 5
print("NumPy Array calculation time is %s seconds." % (time.time() - start_time))
# ndarray calculation time is 0.12609171867370605 seconds.
