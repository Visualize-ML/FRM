# B1_Ch8_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import geom
import matplotlib.pyplot as plt
import numpy as np

p = 0.5

mean,var,skew,kurt = geom.stats(p,moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', mean, var, skew, kurt)

x = np.arange(geom.ppf(0.01, p), geom.ppf(0.99, p))

plt.plot(x, geom.pmf(x, p),'o')
plt.title('Geometric Distribution (p=0.5)')
plt.xlabel('x')
plt.ylabel('Probability')
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')