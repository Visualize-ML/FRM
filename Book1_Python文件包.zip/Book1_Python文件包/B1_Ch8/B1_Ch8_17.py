# B1_Ch8_17.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import lognorm
import numpy as np
import seaborn as sns

# shape parameter
s = 0.9

mean,var,skew,kurt = lognorm.stats(s, moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', mean, var, skew, kurt)

x = np.linspace(0,4,1000)
ax = sns.lineplot(x=x, y=lognorm.pdf(x, s), color='dodgerblue', label='PDF')
ax.fill_between(x, lognorm.pdf(x, s), color='lightblue', alpha=0.5)
ax = sns.lineplot(x=x, y=lognorm.cdf(x, s), color='red', label='CDF')

ax.set_title('Lognormal Distribution')
ax.set_xlabel('x')
ax.set_ylabel('Probability')
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')
