# B1_Ch8_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

# calculate the probability of Monty Hall problem

# function of Bayes theorem
def bayes_theorem(p_x, p_y_given_x, p_y):
    p_x_given_y = p_x * (p_y_given_x / p_y)
    return p_x_given_y
 
# P(CarA) P(CarB) P(CarC)
p_a = 1/3
p_b = 1/3
p_c = 1/3

# P(B|CarA) P(B|CarB) P(B|CarC)
p_b_given_a = 1/2
p_b_given_b = 0
p_b_given_c = 1

# calculate P(B)
p_b = p_b_given_a*p_a + p_b_given_b*p_b + p_b_given_c*p_c

# calculate P(A|B)
p_a_given_b = bayes_theorem(p_a, p_b_given_a, p_b)

# calculate P(C|B)
p_c_given_b = bayes_theorem(p_c, p_b_given_c, p_b)

# summary
print('Probability of Stay to Win : P(A|B) = %.3f%%' % (p_a_given_b * 100))
print('Probability of Switch to Win : P(C|B) = %.3f%%' % (p_c_given_b * 100))