# B1_Ch8_16.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.integrate import quad
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
import seaborn as sns

# integrate pdf to 68%, 95%, and 99.7%
percent68, _ = quad(norm.pdf, -1, 1, limit = 1000)
percent95, _ = quad(norm.pdf, -2, 2, limit = 1000)
percent99, _ = quad(norm.pdf, -3, 3, limit = 1000)

# plot normal profile
x = np.linspace(-3.5, 3.5)
y = norm.pdf(x)

fig, ax = plt.subplots(figsize=(14, 8))
ax.plot(x, y, 'k', linewidth=.5)
ax.set_ylim(ymin=0, ymax=0.53)
ax = sns.lineplot(x=x, y=y, color='#3C9DFF')
ax.vlines(0, 0, norm.pdf(0), color='coral')

# 68% region
a, b = -1, 1 

# make shaded region
ix = np.linspace(-1, 1)
iy = norm.pdf(ix)
ax = sns.lineplot(x=ix, y=iy, color='#3C9DFF')
ax.fill_between(ix,norm.pdf(ix), color='#DBEEF4', alpha=0.5)

textheight = 0.41
ax.text(0.0, textheight+0.01, r'{0:.2f}%'.format((percent68)*100),
         horizontalalignment='center', fontsize=18);

ax.annotate(r'',
            xy=(-1, textheight), xycoords='data',
            xytext=(1, textheight), textcoords='data',
            arrowprops=dict(arrowstyle="<|-|>",
                            connectionstyle="arc3",
                            mutation_scale=20,
                            fc="w")
            );
ax.vlines(a, 0, textheight+0.025, color='coral')
ax.vlines(b, 0, textheight+0.025, color='coral')

# 95% region
a, b = 1, 2 
# make shaded region
ix = np.linspace(1, 2)
iy = norm.pdf(ix)
ax.fill_between(ix,norm.pdf(ix), color='#DBEEF4', alpha=0.5)

a, b = -2, -1
# make shaded region
ix = np.linspace(-2, -1)
iy = norm.pdf(ix)
ax.fill_between(ix,norm.pdf(ix), color='#DBEEF4', alpha=0.5)

textheight = 0.45
ax.text(0.0, textheight+0.01, r'{0:.2f}%'.format((percent95)*100),
         horizontalalignment='center', fontsize=18);

ax.annotate(r'',
            xy=(-2, textheight), xycoords='data',
            xytext=(2, textheight), textcoords='data',
            arrowprops=dict(arrowstyle="<|-|>",
                            connectionstyle="arc3",
                            mutation_scale=20,
                            fc="w")
            );
ax.vlines(-2, 0, textheight+0.025, color='coral')
ax.vlines(2, 0, textheight+0.025, color='coral')

# 95% region
a, b = 2, 3
# make shaded region
ix = np.linspace(2, 3)
iy = norm.pdf(ix)
ax.fill_between(ix,norm.pdf(ix), color='#DBEEF4', alpha=0.5)

a, b = -3, -2 
# make shaded region
ix = np.linspace(-3, -2)
iy = norm.pdf(ix)
ax.fill_between(ix,norm.pdf(ix), color='#DBEEF4', alpha=0.5)

textheight = 0.49
ax.text(0.0, textheight+0.01, r'{0:.2f}%'.format((percent99)*100),
         horizontalalignment='center', fontsize=18);

ax.annotate(r'',
            xy=(-3, textheight), xycoords='data',
            xytext=(3, textheight), textcoords='data',
            arrowprops=dict(arrowstyle="<|-|>",
                            connectionstyle="arc3",
                            mutation_scale=20,
                            fc="w")
            );

ax.vlines(-3, 0, textheight+0.025, color='coral')
ax.vlines(3, 0, textheight+0.025, color='coral')

# title, labels and ticks
ax.set_title(r'68-95-99.7 Rule', fontsize = 24)
ax.set_ylabel(r'Probability Density', fontsize = 18)

xTickLabels = ['',
               r'$\mu - 3\sigma$',
               r'$\mu - 2\sigma$',
               r'$\mu - \sigma$',
               r'$\mu$',
               r'$\mu + \sigma$',
               r'$\mu + 2\sigma$',
               r'$\mu + 3\sigma$']

ax.set_xticklabels(xTickLabels, fontsize = 16)

ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')
