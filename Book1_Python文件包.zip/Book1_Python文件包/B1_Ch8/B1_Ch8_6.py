# B1_Ch8_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import randint 
import numpy as np
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, figsize=(14, 5))

low, high = 1, 7
mean, var, skew, kurt = randint.stats(low, high, moments='mvsk')

x = np.arange(low, high)

# plot from a "frozen" object (holding the given parameters fixed) of discrete uniform random variable
rv = randint(low, high)
ax1.plot(x, rv.pmf(x), 'ro', label='frozen PMF')
ax1.set_xlabel('x')
ax1.set_ylabel('p(x)')
ax1.set_title('PMF--frozen object')
ax1.spines['right'].set_visible(False)
ax1.spines['top'].set_visible(False)
ax1.yaxis.set_ticks_position('left')
ax1.xaxis.set_ticks_position('bottom')

# plot from random variates
ax2.plot(x, randint.pmf(x, low, high), 'bo', label='randint PMF')
ax2.set_xlabel('x')
ax2.set_ylabel('p(x)')
ax2.set_title('PMF--randint')
ax2.spines['right'].set_visible(False)
ax2.spines['top'].set_visible(False)
ax2.yaxis.set_ticks_position('left')
ax2.xaxis.set_ticks_position('bottom')