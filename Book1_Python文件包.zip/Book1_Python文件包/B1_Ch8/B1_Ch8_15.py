# B1_Ch8_15.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import norm
import seaborn as sns
import numpy as np

mean,var,skew,kurt = norm.stats(moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', mean, var, skew, kurt)

x = np.linspace(-4,4,1000)
ax = sns.lineplot(x=x, y=norm.pdf(x), color='dodgerblue')
ax.fill_between(x,norm.pdf(x), color='lightblue', alpha=0.2)

ax.set_title('Normal Distribution')
ax.set_xlabel('x')
ax.set_ylabel('PDF')
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')