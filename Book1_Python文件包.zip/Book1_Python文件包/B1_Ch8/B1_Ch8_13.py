# B1_Ch8_13.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import beta 
import numpy as np 
import seaborn as sns

x = np.linspace(0, 1.0, 100)   
# varying alpha and beta 
beta1 = beta.pdf(x, 0.5, 0.5) 
beta2 = beta.pdf(x, 2.0, 2.0) 
beta3 = beta.pdf(x, 1.0, 5.0)
beta4 = beta.pdf(x, 5.0, 1.0) 
beta5 = beta.pdf(x, 5.0, 5.0)
ax = sns.lineplot(x=x, y=beta1, label=r'$\alpha=0.5, \beta=0.5$')
ax = sns.lineplot(x=x, y=beta2, label=r'$\alpha=2.0, \beta=2.0$')
ax = sns.lineplot(x=x, y=beta3, label=r'$\alpha=1.0, \beta=5.0$')
ax = sns.lineplot(x=x, y=beta4, label=r'$\alpha=5.0, \beta=1.0$')
ax = sns.lineplot(x=x, y=beta5, label=r'$\alpha=5.0, \beta=5.0$')

ax.set_title('Beta Distribution')
ax.set_xlabel('x')
ax.set_ylabel('PDF')
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')