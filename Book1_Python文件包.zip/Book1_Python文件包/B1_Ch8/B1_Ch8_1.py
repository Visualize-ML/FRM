# B1_Ch8_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import random
import pandas as pd

# total trial number
trials_total = 1000
# number of outcome 3
outcome_freq = 0 
# define seed random number generator
random.seed(1)
# generate random integer in [1,6]
outcomes=pd.Series([], dtype=int)
for _ in range (trials_total):
    outcome = random.randint(1,6)
    if outcome == 3:
        outcome_freq = outcome_freq + 1
print('Probability of outcome 3: ', outcome_freq/trials_total)
