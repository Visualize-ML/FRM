# B1_Ch8_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import bernoulli  
import numpy as np  
import matplotlib.pyplot as plt  

p = 0.5
mean, var, skew, kurt = bernoulli.stats(p, moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', mean, var, skew, kurt)

x = np.linspace(0, 1, 6)     
plt.plot(x, bernoulli.pmf(x, p), '*') 
plt.title('PMF--Bernoulli Distribution (p=0.5)')
plt.xlabel('x')
plt.ylabel('P(x)')
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')