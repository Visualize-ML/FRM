# B1_Ch8_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

B1_CH8_4_A.py

import random
import pandas as pd

# define seed random number generator
random.seed(1)
# generate random integer in [1,6]
outcomes=pd.Series([], dtype=int)
for _ in range (10):
    outcome = random.randint(1,6)
    print(outcome)
    outcomes[len(outcomes)] = outcome



B1_CH8_4_B.py
import matplotlib.pyplot as plt
import numpy as np

plt.figure(figsize=(14, 3))
toss = ('1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th')
# bar graph
plt.subplot(131)
plt.xticks(np.arange(10), toss)
plt.bar(np.arange(10), outcomes) 
# scatter graph
plt.subplot(132)
plt.scatter(np.arange(10), outcomes)
plt.xticks(np.arange(10), toss)
# line graph
plt.subplot(133)
plt.plot(outcomes)
plt.xticks(np.arange(10), toss)
# graph title
plt.suptitle('Outcome of 10 Tosses')
plt.show()
