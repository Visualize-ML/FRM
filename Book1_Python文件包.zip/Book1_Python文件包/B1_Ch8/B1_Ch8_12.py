# B1_Ch8_12.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import expon
import numpy as np
import seaborn as sns

lam = 6
loc = 0
scale = 1.0/lam

mean,var,skew,kurt = expon.stats(loc, scale, moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', np.around(mean,2), np.around(var,2), skew, kurt)

x = np.linspace(0,2,1000)
ax = sns.lineplot(x=x, y=expon.pdf(x, loc, scale), color='dodgerblue', label='PDF')
ax.fill_between(x,expon.pdf(x, loc, scale), color='lightblue', alpha=0.5)

ax = sns.lineplot(x=x, y=expon.cdf(x, loc, scale), color='red', label='CDF')

ax.set_title('Exponential Distribution -- $\lambda=$' + str(lam))
ax.set_xlabel('x')
ax.set_ylabel('Probability')

ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')