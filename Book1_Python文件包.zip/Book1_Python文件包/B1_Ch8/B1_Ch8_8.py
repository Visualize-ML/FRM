# B1_Ch8_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import binom
import matplotlib.pyplot as plt
import numpy as np

n = 250
p = 0.6

mean,var,skew,kurt = binom.stats(n,p,moments='mvsk')
print('Expectation, Variance, Skewness, Kurtosis: ', mean, var, np.around(skew,4), np.around(kurt,4))

x = np.arange(0, 251)
# scatter graph
plt.plot(x, binom.pmf(x, n, p),'o')

plt.title('Binomial Distribution (n=250, p=0.6)')
plt.xlabel('Number of Stock Price Increase')
plt.ylabel('Probability of Stock Price Increase')
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')