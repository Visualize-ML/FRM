# B1_Ch8_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import random
   
trials = 1000 # total number of simulations/trials
 
wins_stick = 0  # number of wins if stick to the door picked initially
wins_switch = 0 # number of wins if switch the door 

random.seed(1) 

for _ in range(trials):
    # 0: door with goat behind
    # 1: door with car behind
    doors = [1,0,0]           # one car and two goats
    random.shuffle(doors)     # shuffling doors randomly
 
    initial_pick = random.randrange(3) # picking a random door
 
    door_initial_pick = doors[initial_pick] # storing initially picked door 
 
    del(doors[initial_pick]) # remaining doors (excluding initial pick)
 
    counter = 0
    for door in doors: 
        if door == 0:
            del(doors[counter]) # deleting a door if a goat behind: door == 0
            break
        counter+=1
 
    if door_initial_pick == 1: # wins_stick adds 1 if initial pick is 1 (goat)
        wins_stick+=1
 
    if doors[0] == 1: # wins_switch adds 1 if it is goat after switch
        wins_switch+=1
 
print("Probablity of Stay to Win =", wins_stick/trials)
print("Probablity of Switch to Win = ", wins_switch/trials)