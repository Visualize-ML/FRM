# B1_Ch8_14.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import gamma 
import numpy as np 
import seaborn as sns

x = np.linspace(0, 10.0, 100)   
# varying alpha and beta 
gamma1 = gamma.pdf(x, 1.0, 0.0, 1.0) 
gamma2 = gamma.pdf(x, 2.0, 0.0, 1/0.5) 

ax = sns.lineplot(x=x, y=gamma1, label=r'$\alpha=1.0, \beta=1.0$')
ax = sns.lineplot(x=x, y=gamma2, label=r'$\alpha=2.0, \beta=0.5$')

ax.set_title('Gamma Distribution')
ax.set_xlabel('x')
ax.set_ylabel('PDF')
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')