# B1_Ch8_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import pandas as pd
import matplotlib.ticker as mticker
import matplotlib.pyplot as plt

f = pd.Series()
F = pd.Series()
F.at[0] = 0.0
for x in range(1, 7):
    f.at[x]= 1/6
    F.at[x] = F.at[x-1] + f[x]  

fig, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, figsize=(14, 5))
# set up positions and labels for y ticks
positions = [1/6, 2/6, 3/6, 4/6, 5/6, 1] 
labels = ['1/6', '2/6', '3/6', '4/6', '5/6', '1']    

# PDF figure
ax1_xticks = range(1,7)

ax1.plot(ax1_xticks, f, 'bo')   
ax1.vlines(ax1_xticks, 0, f, color='blue')

ax1.set_xlabel('x')
ax1.set_ylabel('f(x)')
ax1.set_ylim(0.0, 1.0)

ax1.yaxis.set_major_locator(mticker.FixedLocator(positions))
ax1.yaxis.set_major_formatter(plt.FixedFormatter(labels))
ax1.set_title('PMF')

# CDF figure
ax2_xticks = range(0,8)

ax2.hlines(y=F, xmin=ax2_xticks[:-1], xmax=ax2_xticks[1:], color='red', zorder=1)
ax2.vlines(x=ax2_xticks[1:-1], ymin=F[:-1], ymax=F[1:], color='red', linestyle='dashed', zorder=1)

ax2.scatter(ax2_xticks[1:-1], F[1:], color='red', s=20, zorder=2)
ax2.scatter(ax2_xticks[1:-1], F[:-1], color='white', s=20, zorder=2, edgecolor='red')

ax2.set_xlabel('x')
ax2.set_ylabel('F(x)')

ax2.yaxis.set_major_locator(mticker.FixedLocator(positions))
ax2.yaxis.set_major_formatter(plt.FixedFormatter(labels))
ax2.set_title('CDF')