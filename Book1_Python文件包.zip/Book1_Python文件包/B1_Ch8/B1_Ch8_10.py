# B1_Ch8_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import poisson
import matplotlib.pyplot as plt
import numpy as np

lamb = 2
mean,var,skew,kurt = poisson.stats(lamb, moments='mvsk')

x = np.arange(0, 15)

plt.plot(x, poisson.pmf(x, lamb), 'ro', label=r'$\mathit{\lambda}=%i$' % lamb)
plt.title('Poisson Distribution'+r' ($\mathit{\lambda}=%i$)' % lamb)
plt.xlabel('x')
plt.ylabel('Probability')
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')