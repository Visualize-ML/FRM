# B1_Ch11_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def blsprice(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    
    Call = norm.cdf(d1, loc=0, scale=1)*St - \
        norm.cdf(d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    Put  = -norm.cdf(-d1, loc=0, scale=1)*St + \
        norm.cdf(-d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    return Call, Put


def blsdelta(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    Delta_call  = norm.cdf(d1, loc=0, scale=1)
    Delta_put   = -norm.cdf(-d1, loc=0, scale=1)
    return Delta_call, Delta_put

def blsgamma(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
        
    Gamma = norm.pdf(d1)/St/vol/math.sqrt(tau);

    return Gamma

def plot_curve(x,y1,y2,caption):
    
    fig, axs = plt.subplots(1,2)

    axs[0].plot(x, y1)
    axs[0].set_xlabel('$\it{S}$', fontname="Times New Roman", fontsize=10)
    y_label = 'Call ' + caption
    y_joint = np.concatenate((y1, y2))
    axs[0].set_ylim([y_joint.min(),y_joint.max()])
    if caption =='Delta':
        axs[0].set_ylim([-1,1])

    axs[0].set_ylabel(y_label, fontname="Times New Roman", fontsize=10)
    axs[0].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

    axs[1].plot(x, y2)
    axs[1].set_xlabel('$\it{S}$', fontname="Times New Roman", fontsize=10)
    y_label = 'Put ' + caption
    axs[1].set_ylim([y_joint.min(),y_joint.max()])
    if caption == 'Delta':
        axs[1].set_ylim([-1,1])
    axs[1].set_ylabel(y_label, fontname="Times New Roman", fontsize=10)
    axs[1].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

# end of function

blsprice_vec = np.vectorize(blsprice)
blsdelta_vec = np.vectorize(blsdelta)
blsgamma_vec = np.vectorize(blsgamma)

S_array  = np.linspace(20,80,50);

K = 50;    # strike price
r = 0.03;  # risk-free rate
vol = 0.5; # volatility 
tau = 0.5;     # time to maturity

#%% option vs S

plt.close('all')

Call_array, Put_array = blsprice_vec(S_array, K, tau, r, vol)
caption = 'price'
plot_curve(S_array,Call_array,Put_array,caption)

#%% Delta vs S

Call_Delta_array, Put_Delta_array = blsdelta_vec(S_array, K, tau, r, vol)
caption = 'Delta'
plot_curve(S_array,Call_Delta_array,Put_Delta_array,caption)

#%% Gamma vs S

Gamma_array = blsgamma_vec(S_array, K, tau, r, vol)
caption = 'Gamma'
plot_curve(S_array,Gamma_array,Gamma_array,caption)
