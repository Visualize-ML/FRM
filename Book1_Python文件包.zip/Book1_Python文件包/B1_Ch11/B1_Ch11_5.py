# B1_Ch11_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from sympy import lambdify, diff, exp, latex
from sympy.abc import x, y
import numpy as np
from matplotlib import pyplot as plt 
import math
from matplotlib import cm

def mesh_square(x0,y0,r,num):
    
    # generate mesh using polar coordinates
 
    rr = np.linspace(-r,r,num)
    xx,yy = np.meshgrid(rr,rr);
 
    xx = xx + x0; 
    yy = yy + y0;
    
    return xx, yy

def plot_surf(xx,yy,zz,caption):

    norm_plt = plt.Normalize(zz.min(), zz.max())
    colors = cm.coolwarm(norm_plt(zz))

    fig = plt.figure()
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(xx,yy,zz,
    facecolors=colors, shade=False)
    surf.set_facecolor((0,0,0,0))
    # z_lim = [zz.min(),zz.max()]
    # ax.plot3D([0,0],[0,0],z_lim,'k')
    plt.show()

    plt.tight_layout()
    ax.set_xlabel('$\it{x}$',fontname = 'Times New Roman')
    ax.set_ylabel('$\it{y}$',fontname = 'Times New Roman')

    ax.set_zlabel('$%s$' % latex(caption), fontname = 'Times New Roman')


    ax.xaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.yaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.zaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})

    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams["font.size"] = "10"

#%% Initialization

x0  = 0;  # center of the mesh
y0  = 0;  # center of the mesh
r   = 2;  # radius of the mesh
num = 40; # number of mesh grids
xx,yy = mesh_square(x0,y0,r,num); # generate mesh

#%% plot f(x,y)

plt.close('all')

f_xy = x*exp(- x**2 - y**2);

f_xy_fcn = lambdify([x,y],f_xy)

f_xy_zz = f_xy_fcn(xx,yy)

caption = f_xy

plot_surf(xx,yy,f_xy_zz,caption)

#%% plot partial df/dx

df_dx = f_xy.diff(x)
df_dx_fcn = lambdify([x,y],df_dx)

df_dx_zz = df_dx_fcn(xx,yy)

caption = df_dx

plot_surf(xx,yy,df_dx_zz,caption)

#%% plot partial df/dy

df_dy = f_xy.diff(y)
df_dy_fcn = lambdify([x,y],df_dy)

df_dy_zz = df_dy_fcn(xx,yy)

caption = df_dy

plot_surf(xx,yy,df_dy_zz,caption)

#%% plot partial d2f/dx/dy

df_dxdy = f_xy.diff(x,y)
# df_dxdy = df_dy.diff(x)
# df_dxdy = df_dx.diff(y)

df_dxdy_fcn = lambdify([x,y],df_dxdy)

df_dxdy_zz = df_dxdy_fcn(xx,yy)

caption = df_dxdy

plot_surf(xx,yy,df_dxdy_zz,caption)

