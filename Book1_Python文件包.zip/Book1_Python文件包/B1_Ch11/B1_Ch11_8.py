# B1_Ch11_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def blsprice(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    
    Call = norm.cdf(d1, loc=0, scale=1)*St - \
        norm.cdf(d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    Put  = -norm.cdf(-d1, loc=0, scale=1)*St + \
        norm.cdf(-d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    return Call, Put


def blsdelta(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    Delta_call  = norm.cdf(d1, loc=0, scale=1)
    Delta_put   = -norm.cdf(-d1, loc=0, scale=1)
    return Delta_call, Delta_put

def blsgamma(St, K, tau, r, vol):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
        
    Gamma = norm.pdf(d1)/St/vol/math.sqrt(tau);

    return Gamma

def plot_curve(x,y1,y2,x0,y0,caption):
    
    fig, axs = plt.subplots(1,2)

    axs[0].plot(x, y1)
    axs[0].plot(x, y2)
    axs[0].plot(x0, y0, 'xr', markersize = 12)
    axs[0].set_xlabel('$\it{S}$', fontname="Times New Roman", fontsize=10)
    y_label = caption + ' price'
    axs[0].set_ylabel(y_label, fontname="Times New Roman", fontsize=10)
    axs[0].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

    axs[1].plot(x, y1 - y2)
    axs[1].plot(x0, 0, 'xr', markersize = 12)
    plt.axhline(y=0, color='k', linewidth = 0.5)
    axs[1].fill_between(x, y1 - y2, 0, facecolor = np.divide([219, 238, 243], 255))
    axs[1].set_xlabel('$\it{S}$', fontname="Times New Roman", fontsize=10)
    axs[1].set_ylabel('Error', fontname="Times New Roman", fontsize=10)
    axs[1].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

# end of function

blsprice_vec = np.vectorize(blsprice)
blsdelta_vec = np.vectorize(blsdelta)
blsgamma_vec = np.vectorize(blsgamma)

S_array  = np.linspace(20,80,50);

K = 50;    # strike price
r = 0.03;  # risk-free rate
vol = 0.5; # volatility 
tau = 0.5;     # time to maturity

S_0 = 50;  # expansion point
C_0, P_0 = blsprice_vec(S_0, K, tau, r, vol)
Delta_C_0, Delta_P_0 = blsdelta_vec(S_0, K, tau, r, vol)
Gamma_0 = blsgamma_vec(S_0, K, tau, r, vol)

Call_array, Put_array = blsprice_vec(S_array, K, tau, r, vol)

#%% Delta approximation

plt.close('all')

Call_delta_apprx = Delta_C_0*(S_array - S_0) + C_0
caption = 'Call'
plot_curve(S_array,Call_array,Call_delta_apprx,S_0,C_0,caption)

Put_delta_apprx = Delta_P_0*(S_array - S_0) + P_0
caption = 'Put'
plot_curve(S_array,Put_array,Put_delta_apprx,S_0,P_0,caption)


#%% Delta-Gamma approximation

Call_delta_gamma_apprx = Delta_C_0*(S_array - S_0) + Gamma_0*np.power((S_array - S_0),2)/2 + C_0
caption = 'Call'
plot_curve(S_array,Call_array,Call_delta_gamma_apprx,S_0,C_0,caption)

Put_delta_gamma_apprx = Delta_P_0*(S_array - S_0) + Gamma_0*np.power((S_array - S_0),2)/2 + P_0
caption = 'Put'
plot_curve(S_array,Put_array,Put_delta_gamma_apprx,S_0,P_0,caption)
