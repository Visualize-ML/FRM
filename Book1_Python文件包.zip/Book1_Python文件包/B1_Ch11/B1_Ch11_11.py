# B1_Ch11_11.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np

from pymoo.model.problem import Problem
from pymoo.algorithms.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.visualization.scatter import Scatter
import matplotlib.pyplot as plt

def mesh_square(x0,y0,r,num):

# generate mesh using polar coordinates
 
    rr = np.linspace(-r,r,num)

    xx,yy = np.meshgrid(rr,rr);
 
    xx = xx + x0; 
    yy = yy + y0;

    return xx, yy

class MyProblem(Problem):

    def __init__(self):
        super().__init__(n_var=2,
                         n_obj=2,
                         n_constr=1,
                         xl=np.array([-1, -1]),
                         xu=np.array([1.5, 1.5]))

    def _evaluate(self, x, out, *args, **kwargs):
        
        
        sigma_1 = 0.3;
        sigma_2 = 0.4;
        rho = 0.5;
        Er1 = 0.2;
        Er2 = 0.1;
        f1 = (sigma_1**2*x[:, 0] ** 2 + 
              sigma_2**2*x[:, 1] ** 2 + 
              2*sigma_1*sigma_2*rho*x[:, 0]*x[:, 1])
        
        f2 = -(Er1*x[:, 0] + Er2*x[:, 1])
        g1 = (x[:, 0] + x[:, 1] - 1) ** 2 - 1e-5

        out["F"] = np.column_stack([f1, f2])
        out["G"] = g1
        

problem = MyProblem()
algorithm = NSGA2(pop_size=200)

res = minimize(problem,
               algorithm,
               ("n_gen", 100),
               verbose=True,
               seed=1)

results = res.F
opt_weights = res.X
opt_variance = results[:,0]
opt_Erp = -results[:,1]

#%% visualization of Pareto front and efficient frontier

plt.close('all')

fig, ax = plt.subplots()

plt.scatter(results[:,0],results[:,1],marker = 'x')
plt.show()

ax.set_xlabel("$\it{f}_1$")
ax.set_ylabel("$\it{f}_2$")

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

fig, ax = plt.subplots()

plt.scatter(opt_variance, opt_Erp,marker = 'x')
plt.show()

ax.set_xlabel("$\it{\sigma}_p^2$")
ax.set_ylabel("$\it{E(r_p)}$")

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

fig, ax = plt.subplots()

plt.scatter(np.sqrt(opt_variance), opt_Erp, marker = 'x')
plt.show()

ax.set_xlabel("$\it{\sigma}_p$")
ax.set_ylabel("$\it{E(r_p)}$")

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

#%% confourf of portfolio variance

x0  = 0;  # center of the mesh
y0  = 0;  # center of the mesh
r   = 1.5;  # radius of the mesh
num = 30; # number of mesh grids
xx,yy = mesh_square(x0,y0,r,num); # generate mesh

sigma_1 = 0.3;
sigma_2 = 0.4;
rho = 0.5;
Er1 = 0.2;
Er2 = 0.1;

zz = sigma_1**2*np.multiply(xx,xx) + \
    sigma_2**2*np.multiply(yy,yy) + \
    2*sigma_1*sigma_2*rho*np.multiply(xx,yy);

w1 = np.linspace(-1.5,1.5,10)
w2 = 1.0 - w1; 

var = sigma_1**2*np.multiply(w1,w1) + \
    sigma_2**2*np.multiply(w2,w2) + \
    2*sigma_1*sigma_2*rho*np.multiply(w1,w2);


fig, ax = plt.subplots()

cntr2 = ax.contourf(xx,yy,zz, levels = 15, cmap="RdBu_r")
plt.plot(opt_weights[:,0],opt_weights[:,1],linestyle = 'none', marker = 'x', color = 'r')
plt.plot(w1,w2,'k',linewidth = 1.5)
fig.colorbar(cntr2, ax=ax)
plt.show()

ax.set_xlabel('$\it{w}_1$')
ax.set_ylabel('$\it{w}_2$')
ax.axis('square')
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim([-r,r])
ax.set_ylim([-r,r])

#%% confourf of portfolio expected return

Erp = 0.2*w1 + 0.1*w2;

zz = 0.2*xx + 0.1*yy;

fig, ax = plt.subplots()

cntr2 = ax.contourf(xx,yy,zz, levels = 15, cmap="RdBu_r")
plt.plot(w1,w2,'k',linewidth = 1.5)
fig.colorbar(cntr2, ax=ax)
plt.show()
plt.plot(opt_weights[:,0],opt_weights[:,1],linestyle = 'none', marker = 'x', color = 'r')

ax.set_xlabel('$\it{w}_1$')
ax.set_ylabel('$\it{w}_2$')
ax.axis('square')
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim([-r,r])
ax.set_ylim([-r,r])
