# B1_Ch11_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from sympy import latex, lambdify, limit, log
from sympy.abc import x
import numpy as np
from matplotlib import pyplot as plt 

f_x = log(x + 1)/x

x_array = np.linspace(-0.8,2,100)

f_x_fcn = lambdify(x,f_x)
f_x_array = f_x_fcn(x_array)

f_x_0_limit = limit(f_x,x,0)

f_x_array = f_x_fcn(x_array)

#%% visualization

plt.close('all')

fig, ax = plt.subplots()

ax.plot(x_array, f_x_array, linewidth = 1.5) 
ax.axhline(y = f_x_0_limit, color = 'r')
ax.plot(0,f_x_0_limit, color = 'r', marker = 'x', markersize = 12)
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim(x_array.min(),x_array.max())

ax.set_xlabel('$\it{x}$',fontname = 'Times New Roman')
ax.set_ylabel('$%s$' % latex(f_x), fontname = 'Times New Roman')
