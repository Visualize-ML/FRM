# B1_Ch11_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy.stats import norm
from mpl_toolkits.mplot3d import axes3d
import matplotlib.tri as tri
from matplotlib.font_manager import FontProperties

font = FontProperties()
font.set_family('serif')
font.set_name('Times New Roman')
font.set_size(8)

# Delta of European option

def blsprice(St, K, tau, r, vol, q):
    '''
    St: current price of underlying asset
    K:  strike price
    tau: time to maturity
    r: annualized risk-free rate
    vol: annualized asset price volatility
    '''
    
    d1 = (math.log(St / K) + (r - q + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    
    Call = norm.cdf(d1, loc=0, scale=1)*St*math.exp(-q*tau) - \
        norm.cdf(d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    Put  = -norm.cdf(-d1, loc=0, scale=1)*St*math.exp(-q*tau) + \
        norm.cdf(-d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    return Call, Put

def plot_curve(S_array,Call_array,Put_array,S,Call0,Put0,text):
    
    fig, axs = plt.subplots(1,2)

    axs[0].plot(S_array, Call_array)
    axs[0].plot(S, Call0,'rx', markersize = 12)
    x_label = '$\it{' + text + '}$'
    axs[0].set_xlabel(x_label, fontname="Times New Roman", fontsize=8)
    y_label = '$\it{C}$($\it{' + text + '}$)'
    axs[0].set_ylabel(y_label, family="Times New Roman", fontsize=8)
    axs[0].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

    axs[1].plot(S_array, Put_array)
    axs[1].plot(S, Put0,'rx', markersize = 12)
    axs[1].set_xlabel(x_label, family="Times New Roman", fontsize=8)
    y_label = '$\it{P}$($\it{' + text + '}$)'
    axs[1].set_ylabel(y_label, fontname="Times New Roman", fontsize=8)
    axs[1].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

# end of function

blsprice_vec = np.vectorize(blsprice)

S = 50;    # spot price
S_array  = np.linspace(20,80,26);

K = 50;    # strike price
K_array  = np.linspace(20,80,26);

r = 0.03;  # risk-free rate
r_array  = np.linspace(0.01,0.05,26);

vol = 0.5; # volatility 
vol_array  = np.linspace(0.01,0.9,26);

q = 0;     # continuously compounded yield of the underlying asset
q_array  = np.linspace(0,0.02,26);

tau = 1;     # time to maturity
tau_array  = np.linspace(0.1,1,26);

Call0, Put0 = blsprice_vec(S, K, tau, r, vol, q)

#%% option vs S

plt.close('all')

Call_array, Put_array = blsprice_vec(S_array, K, tau, r, vol, q)

plot_curve(S_array,Call_array,Put_array,S,Call0,Put0,'S')

#%% option vs K

Call_array, Put_array = blsprice_vec(S, K_array, tau, r, vol, q)

plot_curve(K_array,Call_array,Put_array,K,Call0,Put0,'K')

#%% option vs tau, time to maturity

Call_array, Put_array = blsprice_vec(S, K, tau_array, r, vol, q)

plot_curve(tau_array,Call_array,Put_array,tau,Call0,Put0,'\u03C4')

#%% option vs r, risk-free rate

Call_array, Put_array = blsprice_vec(S, K, tau, r_array, vol, q)

plot_curve(r_array,Call_array,Put_array,r,Call0,Put0,'r')

#%% option vs vol

Call_array, Put_array = blsprice_vec(S, K, tau, r, vol_array, q)

plot_curve(vol_array,Call_array,Put_array,vol,Call0,Put0,'\sigma')

#%% option vs q, continuous dividend

Call_array, Put_array = blsprice_vec(S, K, tau, r, vol, q_array)

plot_curve(q_array,Call_array,Put_array,q,Call0,Put0,'q')
