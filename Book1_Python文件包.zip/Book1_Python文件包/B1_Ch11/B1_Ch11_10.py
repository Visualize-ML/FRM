# B1_Ch11_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np
from scipy.optimize import minimize, LinearConstraint, Bounds
import matplotlib.pyplot as plt

def min_var_obj(w, *args):
    
    
    sigma_1, sigma_2, rho = args
    w1 = w[0];
    w2 = w[1];
    
    obj = sigma_1**2*w1**2 + \
    sigma_2**2*w2**2 + \
    2*sigma_1*sigma_2*rho*w1*w2;
    return obj

def mesh_square(x0,y0,r,num):

# generate mesh using polar coordinates
 
    rr = np.linspace(-r,r,num)

    xx,yy = np.meshgrid(rr,rr);
 
    xx = xx + x0; 
    yy = yy + y0;

    return xx, yy

#%% optimization

sigma_1 = 0.3;
sigma_2 = 0.4;
rho = 0.5;

x0 = [0,0]; # initial guess
linear_constraint = LinearConstraint([1,1],[1],[1])

bounds = Bounds([-1, -1], [1.5, 1.5])

# Pass in a tuple with the wanted arguments a, b, c
res = minimize(min_var_obj, x0,
               args=(sigma_1,sigma_2,rho),
               method='trust-constr',
               bounds = bounds,
               constraints=[linear_constraint])
optimized_x = res.x;

print("==== Optimized weights ====")
print(res.x)

print("==== Optimized objective ====")
print(res.fun)

#%% Visualize contourf of portfolio variance and volatility

x0  = 0;  # center of the mesh
y0  = 0;  # center of the mesh
r   = 1;  # radius of the mesh
num = 30; # number of mesh grids
xx,yy = mesh_square(x0,y0,r,num); # generate mesh

plt.close('all')


zz = sigma_1**2*np.multiply(xx,xx) + \
    sigma_2**2*np.multiply(yy,yy) + \
    2*sigma_1*sigma_2*rho*np.multiply(xx,yy);

w1 = np.linspace(-1,1,10)
w2 = 1.0 - w1; 

var = sigma_1**2*np.multiply(w1,w1) + \
    sigma_2**2*np.multiply(w2,w2) + \
    2*sigma_1*sigma_2*rho*np.multiply(w1,w2);


fig, ax = plt.subplots()

cntr2 = ax.contourf(xx,yy,zz, levels = 15, cmap="RdBu_r")
plt.plot(w1,w2,'k',linewidth = 1.5)
fig.colorbar(cntr2, ax=ax)
plt.show()
plt.plot(optimized_x[0],optimized_x[1], 'rx', markersize = 12)

ax.set_xlabel('$\it{w}_1$')
ax.set_ylabel('$\it{w}_2$')
ax.axis('square')
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim([-r,r])
ax.set_ylim([-r,r])

fig, ax = plt.subplots()

cntr2 = ax.contourf(xx,yy,np.sqrt(zz), levels = 15, cmap="RdBu_r")
plt.plot(w1,w2,'k',linewidth = 1.5)
fig.colorbar(cntr2, ax=ax)
plt.show()
plt.plot(optimized_x[0],optimized_x[1], 'rx', markersize = 12)

ax.set_xlabel('$\it{w}_1$')
ax.set_ylabel('$\it{w}_2$')
ax.axis('square')
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim([-r,r])
ax.set_ylim([-r,r])
