# B1_Ch11_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from sympy import latex, lambdify, diff, sin
from sympy.abc import x
import numpy as np
from matplotlib import pyplot as plt 


# f_x = x**2 - 2
f_x = x**3/3 - x/3
# f_x = sin(x)

x_array = np.linspace(-2,2,100)
f_x.evalf(subs = {x: 0})

f_x_fcn = lambdify(x,f_x)
f_x_array = f_x_fcn(x_array)

#%% 1st and 2nd order derivatives

f_x_1_diff = diff(f_x,x)
f_x_1_diff_fcn = lambdify(x,f_x_1_diff)

f_x_1_diff_array = f_x_1_diff_fcn(x_array)

f_x_2_diff = diff(f_x,x,2)
f_x_2_diff_fcn = lambdify(x,f_x_2_diff)

f_x_2_diff_const = f_x_2_diff_fcn(x_array)

#%% plot first order derivative of quadratic function

plt.close('all')

fig, ax = plt.subplots(2,1)

ax[0].plot(x_array, f_x_array, linewidth = 1.5) 
ax[0].set_xlabel("$\it{x}$")
ax[0].set_ylabel('$%s$' % latex(f_x))

ax[0].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

ax[1].plot(x_array, f_x_1_diff_array, linewidth = 1.5) 
ax[1].set_xlabel("$\it{x}$")
ax[1].set_ylabel('$%s$' % latex(f_x_1_diff))

ax[1].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
x_lim = ax[1].get_xlim()
