# B1_Ch11_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from sympy import latex, lambdify, diff, sin, log, exp, series
from sympy.abc import x
import numpy as np
from matplotlib import pyplot as plt 

f_x = exp(x) # y + 1 = exp(r)
x_array = np.linspace(-2,2,100)

f_x = log(x + 1) # ln(y + 1) = r
x_array = np.linspace(-0.8,2,100)

x_0 = 0

y_0 = f_x.evalf(subs = {x: x_0})

f_x_fcn = lambdify(x,f_x)
f_x_array = f_x_fcn(x_array)

#%% Visualization

plt.close('all')

fig, ax = plt.subplots()

ax.plot(x_array, f_x_array, 'k', linewidth = 1.5) 
ax.plot(x_0, y_0, 'xr', markersize = 12) 
ax.set_xlabel("$\it{x}$")
ax.set_ylabel("$\it{f}(\it{x})$")

order_array = np.arange(2,8)

for order in order_array:

    f_series = f_x.series(x,x_0,order).removeO()
    f_series_fcn = lambdify(x,f_series)
    f_series_array = f_series_fcn(x_array)
    ax.plot(x_array, f_series_array, linewidth = 0.5) 

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
ax.set_xlim(x_array.min(),x_array.max())
