# B1_Ch11_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from sympy import lambdify, diff, evalf
from sympy.abc import x
import numpy as np
from matplotlib import pyplot as plt 


f_x = x**2 - 2
f_x = x**3/3 - x/3
# f_x = sin(x)

x_array   = np.linspace(-2,2,100)
x_0_array = np.linspace(-1.5,1.5,12)
f_x.evalf(subs = {x: 0})

f_x_fcn = lambdify(x,f_x)
f_x_array = f_x_fcn(x_array)

#%% plot tangent lines

plt.close('all')

f_x_1_diff = diff(f_x,x)
f_x_1_diff_fcn = lambdify(x,f_x_1_diff)

fig, ax = plt.subplots()

ax.plot(x_array, f_x_array, linewidth = 1.5) 
ax.set_xlabel("$\it{x}$")
ax.set_ylabel("$\it{f}(\it{x})$")

for x_0 in x_0_array:
    
    y_0 = f_x.evalf(subs = {x: x_0})
    x_t_array = np.linspace(x_0-0.5, x_0+0.5, 10)
    a = f_x_1_diff.evalf(subs = {x: x_0})
    
    tangent_f = a*(x - x_0) + y_0
    
    tangent_f_fcn = lambdify(x,tangent_f)
    tangent_array = tangent_f_fcn(x_t_array)
    
    ax.plot(x_t_array, tangent_array, linewidth = 0.25, color = 'r') 
    ax.plot(x_0,y_0,marker = 'x', color = 'r')

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
plt.axis('equal')
