# B1_Ch9_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import t, norm 
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

listn = [1, 5, 10, 30, 50, 100]
x = np.linspace(-6, 6, 1000)

rows = 2
cols = 3
fig, ax = plt.subplots(rows, cols, figsize=(14,8))
fign = 0

for i in range(0, rows):
    for j in range(0, cols):
        sns.lineplot(x=x, y=t.pdf(x, listn[fign]), label='t', ax=ax[i, j], color='b', alpha=0.58)
        ax[i, j].fill_between(x, t.pdf(x, listn[fign]), alpha=0.58, color='lightblue')
        sns.lineplot(x=x, y=norm.pdf(x, 0, 1), label='Std Norm', ax=ax[i, j], color='red')
        ax[i, j].set_xticks([-4, 0, 4])
        ax[i, j].set_xticklabels(['-4', '0', '4'])
        ax[i, j].set_yticks([0.0, 0.4, 0.2])
        ax[i, j].set_title(label= "df = " + str(listn[fign]))
        fign+=1

fig.suptitle('t Distribution')
