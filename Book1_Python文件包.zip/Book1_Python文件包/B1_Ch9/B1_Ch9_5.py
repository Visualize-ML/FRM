# B1_Ch9_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import bernoulli 
import numpy as np
import matplotlib.pyplot as plt

# maximum toss number
N = 500
# list of trial numbers
trials_total = []
# list of faceup probablity in each trial
prob_faceup = []
for trialnumber in range(1, N+1):
    faceup = 0
    for _ in range(trialnumber):
        if bernoulli.rvs(0.5, size=1) == 1:
            faceup = faceup + 1
    prob_faceup.append(faceup/trialnumber)
    trials_total.append(trialnumber)
# plot
plt.plot(trials_total, prob_faceup, linewidth = 0.5)

plt.gca().spines['left'].set_position('zero')
plt.gca().spines['bottom'].set_position('zero')
# draw y=0.5 red line
plt.axhline(y=0.5, xmin=0.03, xmax=1, color='r', linestyle='--')
plt.yticks(np.arange(0.0, 1.1, step=0.1))
plt.gca().get_yticklabels()[5].set_color('r')

plt.title('Probability of face up in coin toss')
plt.xlabel('Toss number')
plt.ylabel('Probability of face up')

plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')