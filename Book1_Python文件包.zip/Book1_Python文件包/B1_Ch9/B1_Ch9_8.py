# B1_Ch9_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import ttest_ind, t

alpha = 0.05

stockreturn1 = [-0.020809662379123517, 0.00846703325245679, -0.000447501087096569, 0.0037943429167992537, 0.00337077454971646, 0.0006366568709006426, -0.001967167012908333, -0.003026737458921125, 0.0040596182036833905, 0.0024232318939352293, 0.0011785909968373698, 0.0012210301746806707, -0.004508716349038044, 0.0008052363515955729, 0.006508926423269834]

stockreturn2 = [-0.001844371674326828, -0.002070621212762691, 0.01316396325231195, 0.0014103778581735504, 9.433813027959204e-05, 0.005497221072897629, 0.003311408623482226, 6.701621195870366e-05, -0.0037197388299609058, 0.00022932086310833988, -0.0011259319781000698, 0.0016769041143169794, -0.0008123268983916132, 0.0007101444324377759, -0.00043462154134144004]

# calculate cirtical value
df = len(stockreturn1)+len(stockreturn2)-2
critical_value = t.ppf(1.0-alpha, df)
print('critical_value=%.3f' % (critical_value))

# calculate t stastics and p value
t_stat, p = ttest_ind(stockreturn1, stockreturn2)
print('t-statistic=%.3f, p_value=%.3f' % (t_stat, p))

# conclusion via t statastics
if abs(t_stat) <= critical_value:
    print('Cannot reject Null Hypothesis -- The mean of these two samples are the same.')
else:
    print('Reject Null Hypothesis -- The mean of these two samples are different.')
    
# conclusion via p value
if p <= alpha:
    print('Reject Null Hypothesis -- The mean of these two samples are different.')
else:
    print('Cannot reject Null Hypothesis -- The mean of these two samples are the same.')
