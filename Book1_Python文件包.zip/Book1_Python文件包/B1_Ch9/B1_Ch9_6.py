# B1_Ch9_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

# Central Limit Theorem
import matplotlib.pyplot as plt
import scipy.stats as stats

# sample size
samplesize = 30

# different number of sampling
numofsample = [10,50,100,500,1000,5000]
# a list of sample mean
meansample = []

# for each number of sampling (10 to 5000)
for i in numofsample:
    # collect mean of each sample
    eachmeansample = []
    # for each sampling
    for j in range(0,i):
        # sampling 30 sample
        rvs = stats.uniform.rvs(size=samplesize)
        # collect mean of each sample
        eachmeansample.append(sum(rvs)/len(rvs))
    # add mean of each sampling to the list
    meansample.append(eachmeansample)

# draw the graphs
rows = 2
cols = 3
fig, ax = plt.subplots(rows, cols, figsize=(14,8))
n = 0

for i in range(0, rows):
    for j in range(0, cols):
        ax[i, j].hist(meansample[n], bins=200, density=True, alpha=0.2)
        ax[i, j].set_title(label="N: " + str(numofsample[n]))
        n+=1