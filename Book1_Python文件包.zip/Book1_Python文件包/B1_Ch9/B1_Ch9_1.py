# B1_Ch9_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

B1_Ch9_1_A.py
from pandas_datareader import data
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

stocks = ['FB', 'NFLX', 'AMZN', 'GLD', 'GE', 'NKE', 'FORD']
df = data.DataReader(stocks, 'yahoo', '2019-1-1', '2019-12-31')['Adj Close']
dflog = np.log(df)
stockreturn= dflog.pct_change()
stockreturn = stockreturn[1:]

# covariance and correlation
stockcov = stockreturn.cov()
stockcorr = stockreturn.corr()
pd.options.display.float_format = '${:,.6f}'.format
print(stockcov)
print(stockcorr)


B1_Ch9_1_B.py
# generate heat map
from  matplotlib.colors import LinearSegmentedColormap
import seaborn as sns

cmap=LinearSegmentedColormap.from_list('rb',["r", "w", "b"], N=256) 

sns.heatmap(stockreturn.corr(), cmap=cmap, vmax=1.0, vmin=-1.0)
plt.yticks(rotation=0) 
plt.xticks(rotation=90) 



