# B1_Ch9_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

B1_Ch9_9_A.py
from scipy import stats

alpha = 0.05

p_value = stats.binom_test(14, n=20, p=0.5, alternative='greater')
print('p_value=%.3f' % p_value)

if p_value <= alpha:
    print('Reject Null Hypothesis -- Unfair coin')
else:
    print('Cannot reject Null Hypothesis -- Fair coin')

    
    
B1_Ch9_9_B.py
p_value = stats.binom_test(14, n=20, p=0.5, alternative='two-sided')
print('p_value=%.3f' % p_value)

if p_value <= alpha/2:
    print('Reject Null Hypothesis -- Unfair coin')
else:
    print('Cannot reject Null Hypothesis -- Fair coin')
