# B1_Ch9_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import f 
import numpy as np
import seaborn as sns

listmn = [[5,10], [10,5], [50, 50], [100, 100]]

customized_palette = ["#3C9DFF","#B7DEE8", "#0070C0","#313695"]
sns.set_palette(customized_palette)

x = np.linspace(0, 5, 1000)
for mn in listmn: 
    ax = sns.lineplot(x=x, y=f.pdf(x, mn[0], mn[1]), label='m='+str(mn[0])+',n='+str(mn[1]))

ax.set_title('F Distribution')
ax.legend(frameon=False)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')

ax.spines['left'].set_position('zero')
ax.spines['bottom'].set_position('zero')