# B1_Ch9_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from  pandas_datareader import data
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm 

df = data.DataReader('AAPL', 'yahoo', '2019-1-1', '2019-12-31')['Adj Close']
# log return
dflog = np.log(df)
stockreturn = dflog.pct_change()
stockreturn = stockreturn[1:]
# mean and std
mean, sigma = np.mean(stockreturn), np.std(stockreturn, ddof=1)

confidence_level_list = [0.68, 0.95, 0.997]
customized_palette = ["#3C9DFF","#B7DEE8", "#0070C0"]
i=0
for confidence_level in confidence_level_list:    
    confidence_interval = norm.interval(confidence_level, loc=mean, scale=sigma)
    interval_label = str(confidence_level_list[i])+' confidence interval: ['+str(r'{0:.3f}'.format(confidence_interval[0]))+','+str(r'{0:.3f}'.format(confidence_interval[1]))+']'
    plt.plot((confidence_interval[0], confidence_interval[0]), (0, norm.pdf(confidence_interval[0], loc=mean, scale=sigma)), color=customized_palette[i], linestyle='--')

    plt.plot((confidence_interval[1], confidence_interval[1]), (0, norm.pdf(confidence_interval[1], loc=mean, scale=sigma)), color=customized_palette[i], linestyle='--')
    plt.annotate(interval_label, 
                  xy=(confidence_interval[0], norm.pdf(confidence_interval[1], loc=mean, scale=sigma)), xycoords='data',
                  xytext=(confidence_interval[1], norm.pdf(confidence_interval[1], loc=mean, scale=sigma)), textcoords='data',
                  arrowprops=dict(arrowstyle="<|-|>",
                                  connectionstyle="arc3",
                                  mutation_scale=20,
                                  fc="w")
                    )   

    i+=1

    print(str(confidence_level*100)+"% "+"Confidence Interval: ["+ str(round(confidence_interval[0],3))+","+str(round(confidence_interval[1],3))+"]")

x = np.linspace(norm.ppf(0.0001, loc=mean, scale=sigma),
                norm.ppf(0.9999, loc=mean, scale=sigma), 1000)
plt.plot(x, norm.pdf(x, loc=mean, scale=sigma), color='r', label='norm pdf')

plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')
plt.gca().spines['bottom'].set_position('zero')
