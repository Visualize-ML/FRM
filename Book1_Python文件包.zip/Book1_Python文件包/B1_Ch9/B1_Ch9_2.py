# B1_Ch9_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from scipy.stats import chi2 
import numpy as np
import seaborn as sns

listn = [1, 5, 10, 30, 50]
x = np.linspace(0, 70, 500)
sns.set_palette('pastel')

for n in listn: 
    ax = sns.lineplot(x=x, y=chi2.pdf(x, n), label='n = '+str(n))
    ax.fill_between(x, chi2.pdf(x, n), alpha=0.58)

ax.set_title('Chi-square Distribution')
ax.legend(frameon=False)
ax.set_ylim(0.0, 0.2)
ax.set_yticks([0.0, 0.1, 0.2])
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')

ax.spines['left'].set_position('zero')
ax.spines['bottom'].set_position('zero')