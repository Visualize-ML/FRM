# B1_Ch1_19.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%%fromkeys()
keys =("brand","model","year")
values =("Ford","Mustang","2020")
car =dict.fromkeys(keys,values)
print(car)
#%%values()
print(car.values())
#%%keys()
print(car.keys())
#%%pop()method
print(car.pop("model"))
print(car)
#%%popitem()method
print(car.popitem())
#%%items()
print(car.items())
#%%There are two ways to update the values
car.update({"color": "White"})
car["brand"]="BMW"
print(car)
#%%Get the value for a specific key
print(car.get("model"))
print(car["year"])
