# B1_Ch1_15.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% Use a explicit function for filtering
def radius_filter(r):
    return True if 3.14*r**2 > 10 else False
Radius = [ 1, 2, 5, 10 ]
r_filter = filter(radius_filter,Radius)
print(r_filter)
print(list(r_filter))
#%% List comprehension with lambada() and filter()function, full form
Radius = [ 1, 2, 5, 10 ]
Radius_filtered = list( filter( lambda r : True if 3.14*r**2 > 10 else
False, Radius) ) # type convert the filter
print(Radius_filtered)
#%% List comprehension with lambada() and filter()function, simplified form
Radius = [ 1, 2, 5, 10 ]
Degree_C_filtered = list( filter( lambda r : 3.14*r**2 > 10, Radius) )
print(Radius_filtered)
