# B1_Ch1_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Add 4 spaces (an extra level of indentation) to distinguish arguments from the rest.
#%%
# Code cell: Vasicek Model
import numpy as np
import matplotlib.pyplot as plt
def vasicek(r0,k,theta,sigma, T=1., N=10,seed=500):
    np.random.seed(seed)
    dt = T/float(N)
    rates = [r0]
    for i in range(N):
        dr = k*(theta-rates[-1])*dt+sigma*np.random.normal()
        rates.append(rates[-1]+dr)
    return range(N+1), rates
x,y = vasicek(0.02,0.25,0.02,0.01,20.,500)
fig,ax=plt.subplots()
ax.plot(x,y)
ax.set(xlabel='Time step',ylabel='Interest rate',title='Vasicek Model')
plt.show()
# %%
# Code cell: CIR model
import math
import matplotlib.pyplot as plt
def cir(r0,k,theta,sigma,T=1.,N=10,seed=500):
    np.random.seed(seed)
    dt = T/float(N)
    rates = [r0]
    for i in range(N):
        dr=k*(theta-rates[-1])*dt+\
            sigma*math.sqrt(rates[-1])*np.random.normal()
        rates.append(rates[-1]+dr)
    return range(N+1),rates
x,y = cir(0.02,0.25,0.02,0.01,20,500)
fig,ax=plt.subplots()
ax.plot(x,y)
ax.set(xlabel='Time step',ylabel='Interest rate',title='CIR model')
plt.show()

