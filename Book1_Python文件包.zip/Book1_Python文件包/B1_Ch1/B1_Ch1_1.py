# B1_Ch1_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
data =np.random.randint(100,size=16).reshape(4,4)

with open('data.txt', 'w') as outfile:
    for row in data:
        for column in row:
            outfile.write(f'{column:3.0f}')
        outfile.write('\n')
