# B1_Ch1_13.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# List comprehension example #1
h_letters = [ letter for letter in 'human' ]
print( h_letters)#Out: ['h', 'u', 'm', 'a', 'n']
# List comprehension example #2
number_list = [ x for x in range(20) if x % 2 == 0]
print(number_list) # Out: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]
# List comprehension example #3
num_list = [y for y in range(100) if y % 2 == 0 if y % 5 == 0]
print(num_list)# Out: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]
# List comprehension example #4
h_letters = list(map(lambda x: x, 'human'))
print(h_letters)# Out: ['h', 'u', 'm', 'a', 'n']
