# B1_Ch1_16.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Nested loop
List1 = []
for x in [1, 2]:
    for y in [4, 5]:
        List1.append(x * y)

print(List1)# Out: [4, 5, 8, 10]

# Nested loop is replaced by comprehension

List2 = [x * y for x in [1, 2] for y in [4, 5]]
print(List2)# Out: [4, 5, 8, 10]
