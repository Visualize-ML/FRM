# B1_Ch1_17.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Set cannot hold duplicated elements
List = [1,1,2,2,3,3,4,4,5,10,10]
A = set(List)
print(A)#{1, 2, 3, 4, 5, 10}
B = set(range(6))
print(B)#{0, 1, 2, 3, 4, 5}
#set union
print(A|B)#{0, 1, 2, 3, 4, 5, 10}
print(A.union(B))#{0, 1, 2, 3, 4, 5, 10}
#set intersection
print(A&B)#{1, 2, 3, 4, 5}
print(A.intersection(B))#{1, 2, 3, 4, 5}
#set set difference
print(B-A)#{0}
print(B.difference(A))#{0}
#set set symmetric difference
print(A^B)#{0, 10}
print(A.symmetric_difference(B))#{0, 10}
