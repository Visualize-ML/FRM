# B1_Ch1_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Example 1, flaoting point
print((1.1 + 2.2) == 3.3)#Out:False
print(1.1+2.2)#Out: 3.3000000000000003

# Example 2, fractions
import fractions
print(fractions.Fraction(1.5)) # Output: 3/2
print(fractions.Fraction(5)) # Output: 5
print(fractions.Fraction(1,3)) # Output: 1/3

# Example 3, Bolleans
x = (1 == True) # True and False are both case-sensitive
y = (1 == False)
a = True + 4
b = False + 10
print("x is", x)
print("y is", y)
print("a:", a)
print("b:", b)
print(bool(0))# Output False
a =[];
b = ['']
print(bool(a))# Output False
print(bool(b))# Output True
print(bool(1))# Output True
print(bool(-1908))# Output True
print(bool("Hello!"))# Output True
