# B1_Ch1_18.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% create a dictionary using two lists
keys = ["Jack", "John", "Josh"] 
values = [20, 25, 22]
stu = dict(zip(keys, values))
print ("Students' names and ages are' : " +  str(stu))
#Students' names and ages are' : {'Jack': 20, 'John': 25, 'Josh': 22}
#%% create a dictionary using two tuples
keys = tuple(["Jack", "John", "Josh"])
values = tuple([20, 25, 22])
stu = dict(zip(keys, values))
print ("Students' names and ages are' : " +  str(stu))
#Students' names and ages are' : {'Jack': 20, 'John': 25, 'Josh': 22}
#%% create a dictionary using two sets
keys = set(["Jack", "John", "Josh"])
values = set([20, 25, 22])
stu = dict(zip(keys, values))
print ("Students' names and ages are' : " +  str(stu))
#Students' names and ages are' : {'Josh': 25, 'John': 20, 'Jack': 22}
