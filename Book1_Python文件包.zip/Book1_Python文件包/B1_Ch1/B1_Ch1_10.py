# B1_Ch1_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% insert()function
aList = [123, 'xyz', 'zara', 'abc']
aList.insert( 3, 2009)
print ("Final List : ", aList) # Out: Final List :  [123, 'xyz', 'zara', 2009, 'abc']
#%% append()function
list1 = ['James', 'Bryant', 'Anthony']
list2= ['Lisa','Jack','Wade']
list1.extend(list2)  
print ("The extened list is：", list1)
#%% extend() function
#%% extend() function
E1 = ['a', 'b', 'c']
A1 = ['a', 'b', 'c']
t = ['d', 'e']
E1.append(t)
A1.extend(t)
print(E1)
print(A1)
