# B1_Ch1_11.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% Ways to delete elements in a list
# pop() function
t = ['a','b','c','d','e','f']
x = t.pop(1)
print(t) # Out: ['a','c','d','e','f']
print(x) # Out: b

# del() function
del t[1]
print(t) # Out: ['a','d','e','f']
del t[1:3]
print(t) # Out: ['a','f']

# remove() function
t.remove('a')
print(t) # Out: ['f']
