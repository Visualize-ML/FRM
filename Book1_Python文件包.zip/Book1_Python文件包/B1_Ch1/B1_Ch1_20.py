# B1_Ch1_20.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
a = [0, 1, 2, 3]
# List comprehension
List_comprehension = [i*10 for i in a]
print(List_comprehension)
# Set comprehension
Set_comprehension = {i*10 for i in a}
print(Set_comprehension)
# Tuple comprehension
Tuple_comprehension = (i*10 for i in a)
print(Tuple_comprehension)
# Dictionary comprehension
Dic_comprehension = {x: x**2 for x in (1, 2, 3)}
print(Dic_comprehension)
print(type(List_comprehension))#Out: <class 'list'>
print(type(Set_comprehension))#Out: <class 'set'>
print(type(Tuple_comprehension))#Out: <class 'generator'>
print(type(Dic_comprehension))#Out: <class 'dict'>
print(next(Tuple_comprehension))#0
print(next(Tuple_comprehension))#10
print(next(Tuple_comprehension))#20
print(next(Tuple_comprehension))#30
