# B1_Ch1_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import timeit
# Record list execution time
List_setup = 'List = range(10**6)'
List_code = '10**6 in List'
Run_number = 10**9
List_time = timeit.timeit(stmt=List_code, setup=List_setup, number=Run_number)
print("List execution time = %f"%List_time)#List execution time = 223.004438

# Record tuple execution time
Tuple_setup = 'Tuple = set(range(10**6))'
Tuple_code = '10**6 in Tuple'
Tuple_time = timeit.timeit(stmt=Tuple_code, setup=Tuple_setup, number=Run_number)
print("Tuple execution time = %f"%Tuple_time)#Tuple execution time = 100.206919

# Size comparison of a list and a tuple
List = list(range(10**6))
Tuple = tuple(range(10**6))
print("Size of the list is %d"%List.__sizeof__())# 8000040
print("Size of the tuple is %d"%Tuple.__sizeof__())#8000024
