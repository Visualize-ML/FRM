# B1_Ch1_12.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% Example #1 shows how to use index() function
guests = ['Christopher','Susan','Bill','Satya']

#this will return the index in the list 
#where the name Bill is found 
print(guests.index('Bill'))
aList = [123, 'xyz', 'zara', 'abc'];
print ("Index for xyz : ", aList.index( 'xyz' ))
print ("Index for zara : ", aList.index( 'zara' ))
# Out:Index for xyz :  1
# Out: Index for zara :  2

#%% Example #2 shows how to use count() function
aList = [123, 'xyz', 'zara', 'abc', 123];
print ("Count for 123 : ", aList.count(123))
print ("Count for zara : ", aList.count('zara'))
# Out: Count for 123 : 2
# Out: Count for zara : 1

#%% Example #3 shows how to use min() function
list1, list2 = [123, 'xyz', 'zara', 'abc'], [456, 700, 200]
print ("min value element : ", min(list2))
print ("min value element : ", min(list1)) # error

#%% Example#4 shows how to use sort() function
aList = ['xyz', 'zara', 'abc', 'xyz']
aList.sort()
print ("List : ", aList) # Out: List :  ['abc', 'xyz', 'xyz', 'zara']
