# B1_Ch1_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Add 4 spaces (an extra level of indentation) to distinguish arguments from the rest.
def long_func_name(
        var1, 
        var2, 
        var3,
        var4):
    print(var1)

var1, var2, var3, var4 = 1, 2, 3,4
# Aligned with opening delimiter.
long_func_name(var1, var2,
               var3, var4)

# Hanging indents should add a level.
foo = long_func_name(
    var1, var2,
    var3, var4)
