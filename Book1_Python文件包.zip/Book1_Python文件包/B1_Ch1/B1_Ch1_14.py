# B1_Ch1_14.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% Define a function explicitly for creating a list
def convertDeg(degrees):
    converted = [ ]
    for degree in degrees:
        result = (9/5) * degree + 32
        converted.append(result)
    return converted
temps = [ 15, 20, 25, 30 ]
converted_temps = convertDeg(temps)
print(converted_temps)

#%% List comprehension with lambda() and map() functions
Degree_C = [ 15, 20, 25, 30 ]
Degree_F = list( map( lambda C : (9/5) * C + 32,temps) ) 
print(Degree_F)
