# B1_Ch1_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
class People(object):
    def _eat(self):
        print('I am eating')
    def __run(self):
        print('I can run')

class Student(People):
    def torun(self):
        self.__run() #AttributeError: 'Student' object has no attribute '_Student__run'

s = Student()
s.torun()  
p = People()
p.__run()   #error: it cannot be accessed externally
