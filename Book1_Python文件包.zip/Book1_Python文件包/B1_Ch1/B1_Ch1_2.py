# B1_Ch1_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Indentation example
def is_prime(a):
    if type(a) != int:
        print("Your input is not an integer")
    if a <=3:
        print("The input number is too small")
    else:
        if a %2 ==0:
            print("This is an even number")
        else:
            b = int(a/2.)+1
            for i in range(3,b,2):
                if a % i ==0:
                    print("The input number can be divided by %2d"%i)
                    break
                if i>=b-2:
                    print("The input number is a prime number")
is_prime(2)#Out: The input number is too small
is_prime(16)#Out: This is an even number
is_prime(81)#Out: The input number can be divided by  3
is_prime(89)#Out: The input number is a prime number
