# B1_Ch1_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#Indexing of a dictionary
Dict = {"John":20,"Theresa":22,"Tom":20}
print(Dict["Tom"])#20

#Indexing of a list, a string, a tuple
List,String = [1,2,3],"123"
Tuple, Set= tuple(List),set(List)
print(List[1])#2
print(Tuple[1])#2
print(String[1])#2
print(Set[1])#'set' object is not subscriptable
