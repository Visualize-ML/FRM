# B1_Ch1_21.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#%% Dictionary comprehension example
fruits = ['apple', 'mango', 'banana','cherry']
Dict1 = {f:len(f) for f in fruits}
print(Dict1)#{'apple': 5, 'mango': 5, 'banana': 6, 'cherry': 6}
Dict2 = {f:i for i,f in enumerate(fruits)}
Dict3 = {v:k for k,v in Dict2.items()}
print(Dict2)#{'apple': 0, 'mango': 1, 'banana': 2, 'cherry': 3}
print(Dict3)#{0: 'apple', 1: 'mango', 2: 'banana', 3: 'cherry'}
Remove_dict = {0,1}
Dict_updated = {key:fruits[key] for key in Dict3.keys()-Remove_dict}
print(Dict_updated)#{2: 'banana', 3: 'cherry'}
