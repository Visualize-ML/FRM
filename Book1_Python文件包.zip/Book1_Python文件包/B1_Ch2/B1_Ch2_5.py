# B1_Ch2_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
Original_list = [0,1,[2,3]]
print(id(Original_list))

#Use slicing
List_cloning1 = Original_list[:]
print(id(List_cloning1))

#Use extend() method
List_cloning2 = []
List_cloning2.extend(Original_list)
print(id(List_cloning2))

#Use list() function
List_cloning3 = list(Original_list)
print(id(List_cloning3))

#Use list comprehension
List_cloning4 = [i for i in Original_list]
print(id(List_cloning4))

#Use copy() function
List_cloning5 = Original_list.copy()
print(id(List_cloning5))

Original_list.append(5)
print(Original_list)
print(List_cloning1,List_cloning2,List_cloning3,List_cloning4,List_cloning5)

Original_list[2].remove(3)
print(List_cloning1,List_cloning2,List_cloning3,List_cloning4,List_cloning5)
