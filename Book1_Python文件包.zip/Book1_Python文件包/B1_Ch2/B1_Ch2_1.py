# B1_Ch2_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Example 1: Single or double quotes can be used
print('Hickory Dickory Dock! The mouse ran up the clock') #single quote
print("Hickory Dickory Dock! The mouse ran up the clock") #double quote
# Out: Hickory Dickory Dock! The mouse ran up the clock

# Example 2: force a new line
# Use "\n" to force a new line
print('Hickory Dickory Dock!\nThe mouse ran up the clock') 
# Out:  Hickory Dickory Dock!
#       The mouse ran up the clock
# Use triple quotes to force a new line
print("""Hickory Dickory Dock! 
The mouse ran up the clock""")
# Out:  Hickory Dickory Dock!
#       The mouse ran up the clock
# Example 3: Use \
print("Hickory Dickory Dock!\
The mouse ran up the clock")
