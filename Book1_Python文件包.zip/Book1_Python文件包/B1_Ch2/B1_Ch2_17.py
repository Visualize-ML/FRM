# B1_Ch2_17.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Define the function to calculate its integration:
def f1(x):
    return x ** 4 * (1 - x) ** 4 / (1 + x ** 2)
def f2(x):
    return x ** 4 +x**3+x**2
#define a function to do integration of f(x)
# The start and end points for the integration can be changed.
def trap(f, n,start=0,end=1):
    h = (end-start) / float(n)
    intgr = 0.5 * h * (f(start) + f(end))
    for i in range(1, int(n)):
        intgr = intgr + h * f(i * h+start)
    return intgr
print(trap(f1, 100,start=2,end=3))
print(trap(f1, 100,start=1,end=2))
print(trap(f2, 100))
print(trap(f2, 100,start=5,end=9))