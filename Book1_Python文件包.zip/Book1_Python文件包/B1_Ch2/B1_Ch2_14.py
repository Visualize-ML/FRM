# B1_Ch2_14.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import csv
import numpy as np
from copy import deepcopy
import pandas as pd
#%% Generate the names of the files
fre_list = np.arange(533.33,13333.25+533.33,533.33)
for i in np.arange(25):
    if fre_list[i]>10000:
        fre_list[i]=np.around(fre_list[i],1)
fre_list_round = [np.int(np.fix(i)) for i in fre_list]
#%% Generate the random data for the files
for name in fre_list_round:
    data1 = np.random.rand(1000,2)
    data2 = np.random.rand(1000,2)
    data1 = [complex(x,y) for x in data1[:,0] for y in data1[:,1]]
    data2 = [complex(x,y) for x in data2[:,0] for y in data2[:,1]]
    data = np.transpose(np.array([data1,data2]))
    pd.DataFrame(data).to_csv("{}.csv".format(name),index=False, header=False)
#%%
for name in fre_list_round:
    with open('{}.csv'.format(name),'r') as file:
        reader =list(csv.reader(file))
        result = np.array(reader)
        da = deepcopy(result[1:,1:])
        da = da.astype(complex)
    for i in np.arange(len(da[:,0])):
        for j in np.arange(len(da[0,:])):
           da[i,j] = da[i,j]*100
    df = pd.DataFrame (da)
    filepath = '{}_10timies.xlsx'.format(name)
    df.to_excel(filepath, index=False, header=False)
