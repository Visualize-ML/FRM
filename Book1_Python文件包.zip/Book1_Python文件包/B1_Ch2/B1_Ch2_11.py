# B1_Ch2_11.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Methods to search something in an information pool
#%% Method #1,for loop with break and else structure
car = {"Ford":2020, "Toyota":2019,"Nissan":2018}
found_brand = None
for key in car.keys():
    if key == "BMW":
        found_brand = key
        print("BMW is found")
        break
else:
    print("BMW is not found.")
#%% Method 2, define a function to search
def find_brand(brand, Objects):
    for obj in Objects.keys():
        if obj == brand:
            print("{0} is found".format(obj))
car = {"Ford":2020, "Toyota":2019,"Nissan":2018}
brand = "Nissan"
find_brand(brand,car)
#%% Method3, use list comprehension
car = {"Ford":2020, "Toyota":2019,"Nissan":2018}
matching_brand = [obj for obj in car.keys() if obj == "Toyota"]
if matching_brand:
    print("{} is found".format(matching_brand[0]))
else:
    print("Toyota is not found")
