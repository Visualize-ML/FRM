# B1_Ch2_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
A = {'Name': 'John', 'Born': 1992}
B = A
print(B is A)# Out: True
print(id(A))# Out:2433131563032
print(id(B))# Out:2433131563032
print(id(A)==id(B))# Out: True
B ['Height'] = 180
print(A)#Out: {'Name': 'John', 'Born': 1992, 'Height': 180}
print(B)#Out: {'Name': 'John', 'Born': 1992, 'Height': 180}

C = {'Name': 'John', 'Born': 1992, 'Height': 180}
print(C==A)# Out: True
print(C is A)# Out: False
print(id(C))#Out:2433131575240
print(id(A))#Out:2433131563032
