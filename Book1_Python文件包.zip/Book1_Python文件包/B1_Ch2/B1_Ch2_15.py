# B1_Ch2_15.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
File = open("Week.txt",'w')
Week = 'Monday\nTuesday\nWednesday\nThursday\nFriday\nSasturday\nSunday'
File.write(Week)
File.close()
File1=open("Week.txt" ,'r' )
Day1 = File1.readline()
print(Day1)#Out:Monday
Day2 = File1.readline()
print(Day2)#Out:Tuesday
Day3 = File1.readline()
print(Day3)#Out:Wednesday
Day4 = File1.readline()
print(Day4)#Out:Thursday
Day5 = File1.readline()
print(Day5)#Out:Friday
Weekend = File1.readlines()
print(Weekend)#Out: ['Saturday\n', 'Sunday']
#% The second method to print the content in each line
for f in File1:
    print(f)
File1.close()
File2 =open("Week.txt" ,'r+' )
Weeklist = File2.read()
File2.write("\nA week has 7 days")
File2.close()
File3 =open("Week.txt" ,'r+' )
Weeklist2 = File3.read()
File3.close()
