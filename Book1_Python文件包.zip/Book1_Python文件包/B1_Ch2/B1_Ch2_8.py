# B1_Ch2_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
num = 1
if num >= 0 and num <= 10:
    print("The number is between 0 and 10")
num =2
if num < 0 or num > 10:
    print("The number is smaller than 0 or larger than 10")
else:
    print('undefine')
num = 8
if (num >= 0 and num <= 5) or (num >= 10 and num <= 15):    
    print('hello')
else:
    print ('undefine')
