# B1_Ch2_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
x = True
y = False
# Output: x and y is False
print('x and y is',x and y)

# Output: x or y is True
print('x or y is',x or y)

# Output: not x is False
print('not x is',not x)
x =n= 3
print(x > 0 and x < 10  )
# is true only if x is greater than 0 and less than 10

print(n%2 == 0 or n%3 == 0 )
# is true if either or both of the conditions is true, 
# that is, if the number is divisible by 2 or 3
