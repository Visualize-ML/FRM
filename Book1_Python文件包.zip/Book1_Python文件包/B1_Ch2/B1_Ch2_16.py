# B1_Ch2_16.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
with open('file.txt', 'w+') as f:
    f.write('Hello, John!')
with open('file.txt', 'r') as f1, open('file2.txt', 'w') as f2:
    txt = f1.read()
    f2.write(txt)
