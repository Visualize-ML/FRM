# B1_Ch2_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#Methods for achieving switch structure
#%%Method1: use 
def week(i):
        switcher={
                0:'Sunday',
                1:'Monday',
                2:'Tuesday',
                3:'Wednesday',
                4:'Thursday',
                5:'Friday',
                6:'Saturday'
             }
        return switcher.get(i,"Invalid day of week")
print(week(2))
#%% Method2: use class
class week(object):
          def indirect(self,i):
                   method_name='number_'+str(i)
                   method=getattr(self,method_name,lambda :'Invalid')
                   return method()
          def number_1(self):
                   print('Monday')
          def number_2(self):
                   print('Tuesday')
          def number_3(self):
                   print('Wednesday')
          def number_4(self):
                   print('Thursday')
          def number_5(self):
                   print('Friday')
          def number_6(self):
                   print('Saturday')
          def number_7(self):
                   print('Sunday')
w = week()
w.indirect(1)
