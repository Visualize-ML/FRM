# B1_Ch2_13.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#% Generator example
def Fibonacci(max):
    a,b,c =0,0,1
    while a < max:
        yield b
        b,c =c,b+c
        a += 1
Fib = Fibonacci(100)
print(Fib)
print(type(Fib)) #<class 'generator'>
while True:
    try:
        print(next(Fib))
    except StopIteration:
        break
for i in Fib:
    print(i**2)
