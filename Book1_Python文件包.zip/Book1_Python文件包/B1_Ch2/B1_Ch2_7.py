# B1_Ch2_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
#if... else example
num = int(input("Please enter a number"))
if num > 1:
   for i in range(2,num):
       if (num % i) == 0:
           print(num,"This is not a prime number")
           print(i,"multiplied by ",num//i,"makes",num)
           break
   else:
       print(num,"This is a prime number")
# A prime number is larger than 1
else:
   print(num,"This is not a prime number")
