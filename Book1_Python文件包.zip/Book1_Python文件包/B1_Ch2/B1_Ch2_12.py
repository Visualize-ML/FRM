# B1_Ch2_12.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# A list is an iterable
for city in ["Beijing", "Toronto", "Shanghai"]: 
    print(city) 
print("\n") 
# A tuple is an iterable
for city in ("Chongqing", "Guangzhou", "Shenzhen"): 
    print(city) 
print("\n")
# A tuple is an iterable
for char in "We love FRM and Python": 
    print(char, end = " ")
print("\n")
# A range object is an iterable
for i in range(5): 
    print(i**2, end = " ")
print("\n")
