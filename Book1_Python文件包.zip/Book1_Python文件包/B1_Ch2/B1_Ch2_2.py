# B1_Ch2_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
# Example of string function
message = 'hello world' 

# Find  the index of the first character
print(message.find('world')) 
# Out: 6

# count() function is used to count the number of a specific character
print(message.count('o')) 
# Out: 2

# capitalize() can capitalize the initial character of the string
print(message.capitalize()) 
#  Hello world

# replace() function
print(message.replace('hello','Hi')) 
# Hi world

# title() function can capitalize the initial character of each word
str = "this is string example....wow!!!";
print (str.title()) # Out: This Is String Example....Wow!!
# split() function to break a sentence in to words
s = 'Eat more bananas, will u?'
t = s.split()
print(t) # Out: ['Eat', 'more', 'bananas,', 'will', 'u?']
s = 'bananas-are-good-for-you'
delimiter = '-'
t = s.split(delimiter)
print(t) #Out: ['bananas', 'are', 'good', 'for', 'you']
# join() function
t = ['bananas', 'are', 'good', 'for', 'you']
delimiter = ' '
s = delimiter.join(t) # Out: bananas are good for you
