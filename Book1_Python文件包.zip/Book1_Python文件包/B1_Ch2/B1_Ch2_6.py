# B1_Ch2_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
from copy import deepcopy
a=[['Jack',21],['Theresa']]
b=a.copy()
c=deepcopy(a)
print([id(x) for x in a])#Out: [192455504, 192457944]
print([id(x) for x in b])#Out: [192455504, 192457944]
print([id(x) for x in c])#Out: [192451408, 192457064]
#a[0]= ['Durant',23]
a[1].append(22)
print(a)
#Out:[['Jack', 21], ['Theresa', 22]]
print([id(x) for x in a])
#Ou: [192451528, 192457944]
print(b)
#Out: [['Jack', 21], ['Theresa', 22]]
print([id(x) for x in b])
#Out: [192455504, 192457944]
print(c)
#Out: [['Jack', 21], ['Theresa']]
print([id(x) for x in c])
#Out: [192451408, 192457064]
