# B1_Ch2_18.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
try:
    import random
    rand_num = int(random.random()*10)
    value = input("Please enter a number between 0 and 9:\n")
    input_value = int(value)
except ValueError as error:
    print("The value is invalid %s"%error)
else:
    if input_value <0 or input_value >9:
        print("Input invalid. Please enter a number between 0 and 9")
    elif input_value ==rand_num:
        print("Your guess is correct!You Win!")
    else:
        print("Nope!The random value was %s"%rand_num)
