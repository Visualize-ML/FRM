# B1_Ch10_11.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm

def mesh_square(x0,y0,r,num):
    
    # generate mesh using polar coordinates
 
    rr = np.linspace(-r,r,num)
    xx,yy = np.meshgrid(rr,rr);
 
    xx = xx + x0; 
    yy = yy + y0;
    
    return xx, yy

def plot_surf(xx,yy,zz,caption):

    norm_plt = plt.Normalize(zz.min(), zz.max())
    colors = cm.coolwarm(norm_plt(zz))

    fig = plt.figure()
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(xx,yy,zz,
    facecolors=colors, shade=False)
    surf.set_facecolor((0,0,0,0))
    # z_lim = [zz.min(),zz.max()]
    # ax.plot3D([0,0],[0,0],z_lim,'k')
    plt.show()

    plt.tight_layout()
    ax.set_xlabel('$\it{x}$')
    ax.set_ylabel('$\it{y}$')
    ax.set_zlabel('$\it{f}$($\it{x}$,$\it{y}$)')
    ax.set_title(caption)


    ax.xaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.yaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.zaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})

    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams["font.size"] = "10"

def plot_contourf(xx,yy,zz,caption):
    
    fig, ax = plt.subplots()

    cntr2 = ax.contourf(xx,yy,zz, levels = 15, cmap="RdBu_r")

    fig.colorbar(cntr2, ax=ax)
    plt.show()

    ax.set_xlabel('$\it{x}$')
    ax.set_ylabel('$\it{y}$')

    ax.set_title(caption)
    ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
    
#%% initialization

x0  = 0;  # center of the mesh
y0  = 0;  # center of the mesh
r   = 2;  # radius of the mesh
num = 30; # number of mesh grids
xx,yy = mesh_square(x0,y0,r,num); # generate mesh

#%% f(x,y) = y
plt.close('all')

zz1 = yy;
caption = '$\it{f} = \it{y}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = -x

zz1 = -xx;
caption = '$\it{f} = -\it{x}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = x + y

zz1 = xx + yy;
caption = '$\it{f} = \it{x} + \it{y}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = -x + y

zz1 = -xx + yy;
caption = '$\it{f} = -\it{x} + \it{y}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)
