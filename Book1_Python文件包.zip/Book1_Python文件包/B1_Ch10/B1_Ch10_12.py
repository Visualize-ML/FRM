# B1_Ch10_12.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm

def mesh_circ(x0,y0,r,num):
    
    # generate mesh using polar coordinates
 
    theta = np.linspace(0,2*math.pi,num)
    r = np.linspace(0,r,num);

    theta_matrix,r_matrix = np.meshgrid(theta,r);
 
    xx = np.multiply(np.cos(theta_matrix), r_matrix) + x0; 
    yy = np.multiply(np.sin(theta_matrix), r_matrix) + y0;
    
    return xx, yy

def plot_surf(xx,yy,zz,caption):

    norm_plt = plt.Normalize(zz.min(), zz.max())
    colors = cm.coolwarm(norm_plt(zz))

    fig = plt.figure()
    ax = fig.gca(projection='3d')
    surf = ax.plot_surface(xx,yy,zz,
    facecolors=colors, shade=False)
    surf.set_facecolor((0,0,0,0))
    # z_lim = [zz.min(),zz.max()]
    # ax.plot3D([0,0],[0,0],z_lim,'k')
    plt.show()

    plt.tight_layout()
    ax.set_xlabel('$\it{x}$')
    ax.set_ylabel('$\it{y}$')
    ax.set_zlabel('$\it{f}$($\it{x}$,$\it{y}$)')
    ax.set_title(caption)


    ax.xaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.yaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
    ax.zaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})

    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams["font.size"] = "10"

def plot_contourf(xx,yy,zz,caption):
    
    fig, ax = plt.subplots()

    cntr2 = ax.contourf(xx,yy,zz, levels = 15, cmap="RdBu_r")

    fig.colorbar(cntr2, ax=ax)
    plt.show()

    ax.set_xlabel('$\it{x}$')
    ax.set_ylabel('$\it{y}$')

    ax.set_title(caption)
    ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
    
#%% initialization

x0  = 0;  # center of the mesh
y0  = 0;  # center of the mesh
r   = 2;  # radius of the mesh
num = 30; # number of mesh grids
xx,yy = mesh_circ(x0,y0,r,num); # generate mesh

#%% f(x,y) = x^2 + y^2, circular paraboloid
plt.close('all')

zz1 = np.multiply(xx, xx) + np.multiply(yy, yy);
caption = '$\it{f} = \it{x}^2 + \it{y}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = - x^2 - y^2, circular paraboloid

zz1 = -np.multiply(xx, xx) - np.multiply(yy, yy);
caption = '$\it{f} = -\it{x}^2 - \it{y}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = (x^2 + y^2)^(1/2), circular cone

zz1 = np.sqrt(np.multiply(xx, xx) + np.multiply(yy, yy));
caption = '$\it{f} = (\it{x}^2 + \it{y}^2)^{1/2}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = -(x^2 + y^2)^(1/2), circular cone

zz1 = -np.sqrt(np.multiply(xx, xx) + np.multiply(yy, yy));
caption = '$\it{f} = -(\it{x}^2 + \it{y}^2)^{1/2}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = x^2 + xy + y^2, elliptic paraboloid

zz1 = np.multiply(xx, xx) + np.multiply(xx, yy) + np.multiply(yy, yy);
caption = '$\it{f} = \it{x}^2 + \it{xy} + \it{y}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = - x^2 + xy - y^2, elliptic paraboloid

zz1 = -np.multiply(xx, xx) + np.multiply(xx, yy) - np.multiply(yy, yy);
caption = '$\it{f} = -\it{x}^2 + \it{xy} - \it{y}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = x^2 - y^2, hyperbolic paraboloid, saddle surface

zz1 = np.multiply(xx, xx) - np.multiply(yy, yy);
caption = '$\it{f} = \it{x}^2 - \it{y}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = x*y, hyperbolic paraboloid, saddle surface

zz1 = np.multiply(xx, yy);
caption = '$\it{f} = \it{xy}$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = x^2, valley surface

zz1 = np.multiply(xx, xx);
caption = '$\it{f} = \it{x}^2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)

#%% f(x,y) = -x^2/2 + xy - y^2/2, ridge surface

zz1 = -np.multiply(xx, xx)/2.0 + np.multiply(xx, yy) - np.multiply(yy, yy)/2.0;
caption = '$\it{f} = -\it{x}^2/2 + \it{xy} - \it{y}^2/2$';
plot_surf (xx,yy,zz1,caption)
plot_contourf (xx,yy,zz1,caption)
