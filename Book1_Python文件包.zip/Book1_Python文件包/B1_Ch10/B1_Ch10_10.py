# B1_Ch10_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

from matplotlib import pyplot as plt 
from sympy import plot_implicit, symbols, Eq
x, y = symbols('x y')


def plot_curve(Eq_sym):

    h_plot = plot_implicit(Eq_sym, (x, -3, 3), (y, -3, 3)) 
    h_plot.show()

#%% plot linear, quadratic, and cubic functions

plt.close('all')

#%% Parabola 

Eq_sym = Eq(x**2 - y,2)
plot_curve(Eq_sym)

Eq_sym = Eq(x**2 + y,2)
plot_curve(Eq_sym)

Eq_sym = Eq(x - y**2,-2)
plot_curve(Eq_sym)

Eq_sym = Eq(x + y**2,2)
plot_curve(Eq_sym)


#%% Ellipse 

Eq_sym = Eq(x**2/4 + y**2,1)
plot_curve(Eq_sym)

Eq_sym = Eq(x**2 + y**2/4,1)
plot_curve(Eq_sym)

Eq_sym = Eq(5*x**2/8 -3*x*y/4 + 5*y**2/8,1)
plot_curve(Eq_sym)

Eq_sym = Eq(5*x**2/8 +3*x*y/4 + 5*y**2/8,1)
plot_curve(Eq_sym)

#%% Hyperbola 

Eq_sym = Eq(-x**2 + y**2,1)
plot_curve(Eq_sym)

Eq_sym = Eq(x**2 - y**2,1)
plot_curve(Eq_sym)

Eq_sym = Eq(x*y,1)
plot_curve(Eq_sym)

Eq_sym = Eq(-x*y,1)
plot_curve(Eq_sym)
