# B1_Ch10_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, interp2d
import numpy as np
from matplotlib import cm

IV = [[0.306, 0.302, 0.298, 0.294],
      [0.290, 0.287, 0.282, 0.278],
      [0.281, 0.277, 0.273, 0.269],
      [0.287, 0.284, 0.279, 0.275],
      [0.300, 0.296, 0.292, 0.288]]


# surface of implied volatility
 
tau = [0.25, 0.375, 0.5, 0.625]; 
# time to maturity
 
Moneyness = [0.9, 0.95, 1, 1.05, 1.1]; 
# Moneyness, S/K

xx,yy = np.meshgrid(tau,Moneyness)

x_array = np.squeeze(np.asarray(xx))
y_array = np.squeeze(np.asarray(yy))
z_array = np.squeeze(np.asarray(IV))

f_linear = interp2d(tau,Moneyness,IV) # default = linear
f_cubic  = interp2d(tau,Moneyness,IV, kind = 'cubic')

x_q = np.linspace(0.25, 0.625 ,30)
y_q = np.linspace(0.9,  1.1   ,30)

xx_q,yy_q = np.meshgrid(x_q,y_q)

zz_q_linear = f_linear(x_q,y_q)
zz_q_cubic  = f_cubic(x_q,y_q)

#%% visualization

plt.close('all')

# Normalize to [0,1]
norm = plt.Normalize(zz_q_linear.min(), zz_q_linear.max())
colors = cm.coolwarm(norm(zz_q_linear))

fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(xx_q, yy_q, zz_q_linear,
    facecolors=colors, shade=False)
surf.set_facecolor((0,0,0,0))

ax.scatter(x_array, y_array, z_array, c='k', marker='x')

plt.show()

plt.tight_layout()
ax.set_xlabel('Time to maturity')
ax.set_ylabel('Moneyness')
ax.set_zlabel('Vol')

ax.xaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
ax.yaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
ax.zaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = "10"
ax.view_init(30, 30)

# Normalize to [0,1]
norm = plt.Normalize(zz_q_cubic.min(), zz_q_cubic.max())
colors = cm.coolwarm(norm(zz_q_cubic))

fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(xx_q, yy_q, zz_q_cubic,
    facecolors=colors, shade=False)
surf.set_facecolor((0,0,0,0))

ax.scatter(x_array, y_array, z_array, c='k', marker='x')

plt.show()

plt.tight_layout()
ax.set_xlabel('Time to maturity')
ax.set_ylabel('Moneyness')
ax.set_zlabel('Vol')

ax.xaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
ax.yaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})
ax.zaxis._axinfo["grid"].update({"linewidth":0.25, "linestyle" : ":"})

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = "10"
ax.view_init(30, 30)
