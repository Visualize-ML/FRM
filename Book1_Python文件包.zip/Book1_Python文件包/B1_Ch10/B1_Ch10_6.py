# B1_Ch10_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

def pvfix(y_p, nper, pmt, fv):
    
    '''
    r_p : periodic interest rate
    nper: number of payment periods
    pmt : periodic payment
    fv  : payment received other than pmt 
    in the end of the last period
    '''
    pv = pmt*((1.0 + y_p)**nper - 1.0)/(1.0 + y_p)**nper/y_p + \
    fv/(1.0 + y_p)**nper;
    
    return pv

y = 0.05;  # annual interest rate
m = 4;     # compounding frequency
T = 5;     # years
c = 10;    # annual payment
pmt = c/m  # periodic payment
fv = 100;  # payment at the end

PV = pvfix(y/m, m*T, pmt, fv)
