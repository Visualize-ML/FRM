# B1_Ch10_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np
from matplotlib import pyplot as plt 

L = 252   # lookback window, 252 business days in a year

lambda_94 = 0.94; 

i_days = range(0,L);

weights = (1.0 - lambda_94)/(1 - lambda_94**L)*np.power(lambda_94,i_days)

plt.close('all')

fig, ax = plt.subplots()

plt.plot(i_days, weights, linewidth = 1.5) 
plt.plot(i_days[0], weights[0], marker = 'x',markersize = 12) 
plt.axhline(y=weights[0]/2, color='r', linewidth = 0.5)
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

x_label = "Lookback days, $\it{i}$" 
ax.set_xlabel(x_label)
y_label = "Weight" 
ax.set_ylabel(y_label)
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = "10"


lambda_array = np.linspace (0.99,0.9,num = 19)

HL = np.log(1.0/2.0)/np.log(lambda_array)

fig, ax = plt.subplots()

plt.xlabel("$\it{\lambda}$") 
plt.ylabel("Half life") 
plt.plot(lambda_array, HL, marker = 'x',markersize = 12) 

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = "10"
