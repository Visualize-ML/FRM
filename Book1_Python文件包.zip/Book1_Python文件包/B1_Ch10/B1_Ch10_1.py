
# B1_Ch10_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
import matplotlib.pyplot as plt

def eff_rr(r, m):
    
    '''
    r = annual rate, scalar numeric decimal
    m = number of compounding periods per year
    '''
    
    eff_rate = (1 + r/m)**m - 1;
    
    return eff_rate
    
m_array = [1, 2, 4, 12, 52, 252]
r = 0.05;


eff_rr_vec = np.vectorize(eff_rr)
eff_rr_array = eff_rr_vec(r,m_array)

eff_rr_from_continuous = math.exp(r) - 1;

fig, ax = plt.subplots()

plt.xlabel("Number of compounding periods, $\it{m}$") 
plt.ylabel("Effective rate of return") 
plt.plot(m_array,eff_rr_array,marker = 'x', markersize = 12, linewidth = 1.5) 
plt.axhline(y=eff_rr_from_continuous, color='r', linestyle='--')
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

plt.show()
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
