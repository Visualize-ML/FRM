# B1_Ch10_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np

CFs = [-400, 120, 80, 180, 100];
CFs_flip = CFs[::-1]

roots = np.roots(CFs_flip)
mask = (roots.imag == 0) & (roots.real > 0)

x = roots[mask].real

irr_replicated = 1/x - 1

irr_result = np.irr(CFs)
print("IRR = " + str(round(irr_result,5)))
