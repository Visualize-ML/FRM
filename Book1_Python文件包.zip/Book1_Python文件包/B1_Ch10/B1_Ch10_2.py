# B1_Ch10_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

# B1_Ch10_2_A.py

import pandas as pd
import numpy as np
import pandas_datareader as web
import matplotlib.pyplot as plt
import scipy.stats as stats
import statsmodels.api as sm
import pylab
import matplotlib.mlab as mlab

df = web.get_data_yahoo('TSLA', start = '2020-01-01', end = '2020-12-31')

#%% Plot price level of stock
plt.close('all')

fig, ax = plt.subplots()

df['Adj Close'].plot()
plt.xlabel('Date')
plt.ylabel('Adjusted closing price')
plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

#%% simple return of stock price

# daily returns
daily_simple_returns_pct = df['Adj Close'].pct_change()
# daily returns are not in the format of percentage.
values = daily_simple_returns_pct[1:]
mu, sigma = stats.norm.fit(values)

fig, ax = plt.subplots()

ax.plot(daily_simple_returns_pct,marker='x')
plt.axhline(y=0, color='k', linestyle='-')
plt.axhline(y=mu, color='r', linestyle='--')
plt.axhline(y=mu + sigma, color='r', linestyle='--')
plt.axhline(y=mu - sigma, color='r', linestyle='--')
plt.axhline(y=mu + 2*sigma, color='r', linestyle='--')
plt.axhline(y=mu - 2*sigma, color='r', linestyle='--')
plt.xlabel('Date')
plt.ylabel('Daily simple return')
plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

#%% Distribution of daily simple returns

label = '$\it{\mu}$ = %.4f, $\it{\sigma}$ = %.4f' % (mu, sigma)

fig, ax = plt.subplots()
ax.hist(values, bins=30, rwidth=0.85)
y_lim = ax.get_ylim()
plt.plot([mu,mu],y_lim,'r')
plt.plot([mu + sigma,mu + sigma],0.75*np.asarray(y_lim),'r')
plt.plot([mu - sigma,mu - sigma],0.75*np.asarray(y_lim),'r')
plt.plot([mu + 2.0*sigma,mu + 2.0*sigma],0.5*np.asarray(y_lim),'r')
plt.plot([mu - 2.0*sigma,mu - 2.0*sigma],0.5*np.asarray(y_lim),'r')
plt.plot([mu + 3.0*sigma,mu + 3.0*sigma],0.25*np.asarray(y_lim),'r')
plt.plot([mu - 3.0*sigma,mu - 3.0*sigma],0.25*np.asarray(y_lim),'r')
plt.title(label)
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
plt.xlabel('Daily simple return')
plt.ylabel('Frequency')

# add a normal fit PDF curve

fig, ax = plt.subplots()
# the histogram of the data
n, bins, patches = plt.hist(values, 30, density=1, rwidth=0.85)
y_lim = ax.get_ylim()
best_fit_line = stats.norm.pdf(bins, mu, sigma)
plt.plot(bins, best_fit_line, 'r-', linewidth=2)

plt.plot([mu,mu],y_lim,'r')
plt.plot([mu + sigma,mu + sigma],0.75*np.asarray(y_lim),'r')
plt.plot([mu - sigma,mu - sigma],0.75*np.asarray(y_lim),'r')

plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10
plt.xlabel('Daily simple return')
plt.ylabel('Probability')
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

#%% weekly simple returns

wkly_simple_returns_pct = df['Adj Close'].pct_change(periods = 5)
# not percentage
values = wkly_simple_returns_pct[5:]
mu, sigma = stats.norm.fit(values)

fig, ax = plt.subplots()

ax.plot(wkly_simple_returns_pct,marker='x')
plt.axhline(y=0, color='k', linestyle='-')
plt.xlabel('Date')
plt.ylabel('Weekly simple return')

plt.axhline(y=mu, color='r', linestyle='--')
plt.axhline(y=mu + sigma, color='r', linestyle='--')
plt.axhline(y=mu - sigma, color='r', linestyle='--')
plt.axhline(y=mu + 2*sigma, color='r', linestyle='--')
plt.axhline(y=mu - 2*sigma, color='r', linestyle='--')

plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])


# B1_Ch10_2_B.py

#%% daily log return of stock price

df_adj_close = df['Adj Close']; 

# shift moves dates back by 1
# daily log returns
df_log_r = df.apply(lambda x: np.log(x) - np.log(x.shift(1)))
daily_log_returns = df_log_r['Adj Close'];

fig, ax = plt.subplots()

ax.plot(daily_log_returns,marker='x')
plt.axhline(y=0, color='k', linestyle='-')
plt.xlabel('Date')
plt.ylabel('Daily log return')
plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

#%% distribution of daily log returns

values = daily_log_returns[1:]
mu, sigma = stats.norm.fit(values)

label = '$\it{\mu}$ = %.4f, $\it{\sigma}$ = %.4f' % (mu, sigma)

fig, ax = plt.subplots()
ax.hist(values, bins=30, rwidth=0.85)
y_lim = ax.get_ylim()
plt.plot([mu,mu],y_lim,'r')
plt.plot([mu + sigma,mu + sigma],0.75*np.asarray(y_lim),'r')
plt.plot([mu - sigma,mu - sigma],0.75*np.asarray(y_lim),'r')
plt.plot([mu + 2.0*sigma,mu + 2.0*sigma],0.5*np.asarray(y_lim),'r')
plt.plot([mu - 2.0*sigma,mu - 2.0*sigma],0.5*np.asarray(y_lim),'r')
plt.plot([mu + 3.0*sigma,mu + 3.0*sigma],0.25*np.asarray(y_lim),'r')
plt.plot([mu - 3.0*sigma,mu - 3.0*sigma],0.25*np.asarray(y_lim),'r')
plt.title(label)
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
plt.xlabel('Daily log return')
plt.ylabel('Frequency')


fig, ax = plt.subplots()

stats.probplot(values, dist="norm", plot=pylab)
pylab.show()
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
plt.xlabel('Normal distribution')
plt.ylabel('Empirical distribution of daily log return')
#%% shift moves dates back by 5
# weekly log returns
df_log_r_wkly = df.apply(lambda x: np.log(x) - np.log(x.shift(5)))
wkly_log_returns = df_log_r_wkly['Adj Close'];

fig, ax = plt.subplots()

ax.plot(wkly_log_returns,marker='x')
plt.axhline(y=0, color='k', linestyle='-')
plt.xlabel('Date')
plt.ylabel('Weekly log return')
plt.show()
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
