# B1_Ch10_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, interp2d
import numpy as np

tenors = [0.5, 1, 2, 5, 10, 15, 30]
IR     = [0.02, 0.03, 0.038, 0.04, 0.048, 0.046, 0.044]

f_linear = interp1d(tenors,IR) # default is 'linear'
f_cubic  = interp1d(tenors,IR,kind = 'cubic') 


tenors_x = [4, 8, 20, 25]
tenors_vec = np.linspace(0.5,30,50)
IR_linear_y     = f_linear(tenors_x)
IR_linear_y_vec = f_linear(tenors_vec)

IR_cubic_y     = f_cubic(tenors_x)
IR_cubic_y_vec = f_cubic(tenors_vec)

#%% visualization

plt.close('all')

fig, ax = plt.subplots()

plt.xlabel("Tenor (year)") 
plt.ylabel("Interest rate") 
plt.plot(tenors,IR,marker = 'o', linewidth = 1.5, linestyle="None") 
plt.plot(tenors_x,IR_linear_y, color = 'r', marker = 'x', linestyle="None", markersize = 12) 
plt.plot(tenors_vec,IR_linear_y_vec, color = 'b') 

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

plt.show()
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

fig, ax = plt.subplots()

plt.xlabel("Tenor (year)") 
plt.ylabel("Interest rate") 
plt.plot(tenors,IR,marker = 'o', linewidth = 1.5, linestyle="None") 
plt.plot(tenors_x,IR_cubic_y, color = 'r', marker = 'x', linestyle="None", markersize = 12) 
plt.plot(tenors_vec,IR_cubic_y_vec, color = 'b') 

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

plt.show()
ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
