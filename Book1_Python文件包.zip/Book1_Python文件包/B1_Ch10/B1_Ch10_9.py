# B1_Ch10_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import math
import numpy as np
from matplotlib import pyplot as plt 

St_array = np.linspace(20,80,300);
K = 50; # strike price

# payoff of European call option
C_payoff = np.maximum(St_array - K, 0)

# payoff of European put option
P_payoff = np.maximum(K - St_array, 0)

plt.close('all')

fig, ax = plt.subplots()

plt.xlabel("Underlying price, $\it{S}$") 
plt.ylabel("European Put payoff, $\it{C}$") 
plt.plot(St_array,C_payoff, linewidth = 1.5) 
plt.plot(K,0,'xr',linewidth = 0.25,markersize=12)
plt.plot([K,K],[0,np.max(C_payoff)],'r--',linewidth = 0.25)

plt.axis('equal')

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
# plt.grid(True)

plt.show()

fig, ax = plt.subplots()

plt.xlabel("Underlying price, $\it{S}$") 
plt.ylabel("European Put payoff, $\it{P}$") 
plt.plot(St_array,P_payoff,linewidth = 1.5) 
plt.plot(K,0,'xr',linewidth = 0.25,markersize=12)
plt.plot([K,K],[0,np.max(P_payoff)],'r--',linewidth = 0.25)

plt.axis('equal')

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10

ax.grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
# plt.grid(True)

plt.show()
