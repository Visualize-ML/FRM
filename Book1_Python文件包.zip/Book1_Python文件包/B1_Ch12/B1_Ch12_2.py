# B1_Ch12_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np
import matplotlib.pyplot as plt

coupon_rate = 0.1
Par = 1000
n = 10
ytm = np.arange(0,0.2,0.005)
pv = 0

for i in range(n):
    pv = Par*coupon_rate/(1+ytm)**i + pv 

plt.plot(ytm,pv)
plt.xlabel('YTM',fontsize=8)
plt.ylabel('Price',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')

