# B1_Ch12_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import numpy as np
import matplotlib.pyplot as plt

todaysDate = ql.Date(18, 8, 2020)
tenor_tmp =[0, 1, 3, 6, 12, 24, 3*12, 5*12, 7*12, 10*12, 15*12, 20*12, 25*12, 30*12]
spotDates = [ todaysDate + ql.Period(x,ql.Months) for x in tenor_tmp ]
spotRates = [0.0, 0.005, 0.0075, 0.01, 0.012, 0.015, 0.018, 0.025, 0.03, 0.032, 0.035, 0.038, 0.0385, 0.0375]
dayCount = ql.Thirty360()
calendar = ql.UnitedStates()
interpolation = ql.Linear()
compounding = ql.Compounded
compoundingFrequency = ql.Semiannual

issueDate = ql.Date(18, 8, 2020)
maturityDate = ql.Date(18, 8, 2045)
tenor = ql.Period(ql.Semiannual)
bussinessConvention = ql.Unadjusted
dateGeneration = ql.DateGeneration.Backward
monthEnd = False
schedule = ql.Schedule (issueDate, maturityDate, tenor, calendar, bussinessConvention,
                            bussinessConvention , dateGeneration, monthEnd)

# Now lets build the coupon
couponRate1 = .05
coupons1 = [couponRate1]

# Now lets construct the FixedRateBond
settlementDays = 0
faceValue = 100
fixedRateBond1 = ql.FixedRateBond(settlementDays, faceValue, schedule, coupons1, dayCount)

ql.Settings.instance().evaluationDate = todaysDate
spotCurve = ql.ZeroCurve(spotDates, spotRates, dayCount, calendar, interpolation,
                             compounding, compoundingFrequency)
spotCurveHandle = ql.RelinkableYieldTermStructureHandle(spotCurve)
# create a bond engine with the term structure as input;
# set the bond to use this bond engine
bondEngine = ql.DiscountingBondEngine(spotCurveHandle)
fixedRateBond1.setPricingEngine(bondEngine)

# Finally the price
P0 = fixedRateBond1.dirtyPrice()
print(P0)

nodes = [ 0, 2, 5, 10, 20, 30 ]  # the durations
dates = [ todaysDate + ql.Period(n,ql.Years) for n in nodes ]
spreads = [ ql.SimpleQuote(0.0) for n in nodes ] # null spreads to begin
new_curve = ql.SpreadedLinearZeroInterpolatedTermStructure(
    ql.YieldTermStructureHandle(spotCurve),
    [ ql.QuoteHandle(q) for q in spreads ],
    dates)
spotCurveHandle.linkTo(new_curve)
bondEngine = ql.DiscountingBondEngine(spotCurveHandle)
fixedRateBond1.setPricingEngine(bondEngine)

delta_y = 0.005
for i in range(4):   
    if i == 0: # 2
        spreads[i].setValue(-delta_y) #0.005 50 bps
        spreads[i + 1].setValue(-delta_y) #0.005 50 bps
        P_down = fixedRateBond1.dirtyPrice()
        print(P_down)
        
        spreads[i].setValue(delta_y) #0.005 50 bps
        spreads[i + 1].setValue(delta_y) #0.005 50 bps
        P_up = fixedRateBond1.dirtyPrice()
        print(P_up)
        
        duration = (P_down - P_up)/(2*P0*delta_y) 
        print(duration)
        
        spreads[i].setValue(0) #0.005 50 bps
        spreads[i + 1].setValue(0) #0.005 50 bps
        
    elif i == 3:#20
        plt.figure(i)
        spreads[i + 1].setValue(-delta_y) #0.005 50 bps
        spreads[i + 2].setValue(-delta_y) #0.005 50 bps
        P_down = fixedRateBond1.dirtyPrice()
        print(P_down)
        
        spreads[i + 1].setValue(delta_y) #0.005 50 bps
        spreads[i + 2].setValue(delta_y) #0.005 50 bps
        P_up = fixedRateBond1.dirtyPrice() 
        print(P_up)
        
        duration = (P_down - P_up)/(2*P0*delta_y) 
        print(duration)
        
        spreads[i + 1].setValue(0.0) #0.005 50 bps
        spreads[i + 2].setValue(0.0) #0.005 50 bps
        
    else:#5 10
        plt.figure(i)
        spreads[i + 1].setValue(-delta_y) #0.005 50 bps
        P_down = fixedRateBond1.dirtyPrice()
        print(P_down)
        
        spreads[i + 1].setValue(delta_y) #0.005 50 bps
        P_up = fixedRateBond1.dirtyPrice() 
        print(P_up)
        
        duration = (P_down - P_up)/(2*P0*delta_y) 
        print(duration)
        spreads[i + 1].setValue(0.0) #0.005 50 bps







