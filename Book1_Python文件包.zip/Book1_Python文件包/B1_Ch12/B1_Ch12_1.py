# B1_Ch12_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import numpy as np
import matplotlib.pyplot as plt

r = 0.05
pv = 1000
m = np.arange(1,100)
fv = pv*(1+r/m)**m

plt.figure()
plt.plot(m,fv)
plt.xlabel('Annual compounding frequency',fontsize=8)
plt.ylabel('Future value',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')
