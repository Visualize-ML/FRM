# B1_Ch12_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import numpy as np
import matplotlib.pyplot as plt

todaysDate = ql.Date(15, 1, 2015)
spotDates = [ql.Date(15, 1, 2015),ql.Date(15, 1, 2016), ql.Date(15, 1, 2017),ql.Date(15, 1, 2018),ql.Date(15, 1, 2019),ql.Date(15, 1, 2020)]
spotRates = [0.027, 0.035, 0.042,0.047,0.052,0.055]
dayCount = ql.Thirty360()
calendar = ql.UnitedStates()
interpolation = ql.Linear()
compounding = ql.Compounded
compoundingFrequency = ql.Annual

issueDate = ql.Date(15, 1, 2015)
maturityDate = ql.Date(15, 1, 2020)
tenor = ql.Period(ql.Semiannual)
calendar = ql.UnitedStates()
bussinessConvention = ql.Unadjusted
dateGeneration = ql.DateGeneration.Backward
monthEnd = False
schedule = ql.Schedule (issueDate, maturityDate, tenor, calendar, bussinessConvention,
                            bussinessConvention , dateGeneration, monthEnd)

# Now lets build the coupon
dayCount = ql.Thirty360()
couponRate1 = .085
coupons1 = [couponRate1]

couponRate2 = .03
coupons2 = [couponRate2]

# Now lets construct the FixedRateBond
settlementDays = 0
faceValue = 100
fixedRateBond1 = ql.FixedRateBond(settlementDays, faceValue, schedule, coupons1, dayCount)
fixedRateBond2 = ql.FixedRateBond(settlementDays, faceValue, schedule, coupons2, dayCount)

dirtyPrice1 = np.zeros(1826)
cleanPrice1 = np.zeros(1826)
dirtyPrice2 = np.zeros(1826)
cleanPrice2 = np.zeros(1826)

for i in range(1826):
    ql.Settings.instance().evaluationDate = todaysDate + i
    spotCurve = ql.ZeroCurve(spotDates, spotRates, dayCount, calendar, interpolation,
                                 compounding, compoundingFrequency)
    spotCurveHandle = ql.YieldTermStructureHandle(spotCurve)

    # create a bond engine with the term structure as input;
    # set the bond to use this bond engine
    bondEngine = ql.DiscountingBondEngine(spotCurveHandle)
    fixedRateBond1.setPricingEngine(bondEngine)
    fixedRateBond2.setPricingEngine(bondEngine)

    # Finally the price
    fixedRateBond1.NPV()
    dirtyPrice1[i] = fixedRateBond1.dirtyPrice()
    cleanPrice1[i] = fixedRateBond1.cleanPrice()
    
    fixedRateBond2.NPV()
    dirtyPrice2[i] = fixedRateBond2.dirtyPrice()
    cleanPrice2[i] = fixedRateBond2.cleanPrice()

for c in fixedRateBond1.cashflows():
    print('%20s %12f' % (c.date(), c.amount())) 
    
for c in fixedRateBond2.cashflows():
    print('%20s %12f' % (c.date(), c.amount())) 


plt.plot(dirtyPrice1)
plt.plot(cleanPrice1)
plt.plot(dirtyPrice2)
plt.plot(cleanPrice2)
plt.xlabel('Time',fontsize=8)
plt.ylabel('Price',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')



