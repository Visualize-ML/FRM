# B1_Ch12_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import numpy as np
import matplotlib.pyplot as plt

todaysDate = ql.Date(1, 7, 2020)
ql.Settings.instance().evaluationDate = todaysDate
dayCount = ql.Thirty360()
calendar = ql.UnitedStates()
interpolation = ql.Linear()
compounding = ql.Compounded
compoundingFrequency = ql.Annual

issueDate = ql.Date(1, 7, 2020)
maturityDate = ql.Date(15, 7, 2025)
tenor = ql.Period(ql.Semiannual)
calendar = ql.UnitedStates()
bussinessConvention = ql.Unadjusted
dateGeneration = ql.DateGeneration.Backward
monthEnd = False
schedule = ql.Schedule (issueDate, maturityDate, tenor, calendar, bussinessConvention,
                            bussinessConvention , dateGeneration, monthEnd)

# Now lets build the coupon
dayCount = ql.Thirty360()
couponRate = .04
coupons = [couponRate]

# Now lets construct the FixedRateBond
settlementDays = 3
faceValue = 100
fixedRateBond = ql.FixedRateBond(settlementDays, faceValue, schedule, coupons, dayCount)

delta_y_base = 0.0001
ytm = np.arange(5.0,7.0,delta_y_base)*0.01
approxPrice = np.zeros(len(ytm))
dirtyPrice = np.zeros(len(ytm))


P0 = fixedRateBond.dirtyPrice(0.06,fixedRateBond.dayCounter(), compounding, ql.Semiannual)
P_up = fixedRateBond.dirtyPrice(0.060 + delta_y_base,fixedRateBond.dayCounter(), compounding, ql.Semiannual)
P_down = fixedRateBond.dirtyPrice(0.060 - delta_y_base,fixedRateBond.dayCounter(), compounding, ql.Semiannual)
duration = (P_down - P_up)/(2*P0*delta_y_base)

for i in range(len(ytm)):
    delta_y = ytm[i] - 0.06
    approxPrice[i] = P0*(1-duration*delta_y)
    dirtyPrice[i] = fixedRateBond.dirtyPrice(ytm[i],fixedRateBond.dayCounter(), compounding, ql.Semiannual)
    
plt.figure(1)    
plt.plot(ytm*100, dirtyPrice,label='Analytical',color = 'b')
plt.plot(ytm*100, approxPrice,color ='r',label='Duration approx')
plt.plot(6, P0,'x',color ='k',fillstyle='none',label='P0')
plt.legend(loc='upper right')
plt.xlabel('Yield, y(%)',fontsize=8)
plt.ylabel('Dirty Price (USD)',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')

plt.figure(2) 
plt.plot(ytm*100, approxPrice-dirtyPrice,color ='b')
plt.xlabel('Yield Shift, in bps',fontsize=8)
plt.ylabel('Error (USD)',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')







