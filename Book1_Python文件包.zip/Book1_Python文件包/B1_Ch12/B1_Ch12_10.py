# B1_Ch12_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import numpy as np
import matplotlib.pyplot as plt

def value_bond(a, s, grid_points, bond):
    model = ql.HullWhite(ts_handle, a, s)
    engine = ql.TreeCallableFixedRateBondEngine(model, grid_points)
    bond.setPricingEngine(engine)
    return bond

calc_date = ql.Date(16,8,2016)
ql.Settings.instance().evaluationDate = calc_date
day_count = ql.ActualActual(ql.ActualActual.Bond)
callability_schedule_call = ql.CallabilitySchedule()
callability_schedule_put = ql.CallabilitySchedule()
call_price = 100.0
call_date = ql.Date(15,ql.September,2016);
null_calendar = ql.NullCalendar();
for i in range(0,2):
    callability_price  = ql.CallabilityPrice(
        call_price, ql.CallabilityPrice.Clean)
    callability_schedule_call.append(
            ql.Callability(callability_price, 
                           ql.Callability.Call,
                           call_date))
    callability_schedule_put.append(
            ql.Callability(callability_price, 
                           ql.Callability.Put,
                           call_date))

    call_date = null_calendar.advance(call_date, 12, ql.Months);
    
issue_date = ql.Date(16,ql.September,2015)        
maturity_date = ql.Date(15,ql.September,2017)
calendar = ql.UnitedStates(ql.UnitedStates.GovernmentBond)
tenor = ql.Period(ql.Quarterly)
accrual_convention = ql.Unadjusted

schedule = ql.Schedule(issue_date, maturity_date, tenor,
                       calendar, accrual_convention, accrual_convention,
                       ql.DateGeneration.Backward, False)    

settlement_days = 0
face_amount = 100
accrual_daycount = ql.ActualActual(ql.ActualActual.Bond)
coupon = 0.0825

bond = ql.FixedRateBond(
    settlement_days, face_amount,
    schedule, [coupon], accrual_daycount)

callable_bond = ql.CallableFixedRateBond(
    settlement_days, face_amount,
    schedule, [coupon], accrual_daycount,
    ql.Following, face_amount, issue_date,
    callability_schedule_call)

puttable_bond = ql.CallableFixedRateBond(
    settlement_days, face_amount,
    schedule, [coupon], accrual_daycount,
    ql.Following, face_amount, issue_date,
    callability_schedule_put)

rate = np.arange(0.0,0.18,0.001)
bond_price = np.zeros(len(rate))
callable_bond_price = np.zeros(len(rate))
puttable_bond_price = np.zeros(len(rate))

for i in range(len(rate)):
    ts = ql.FlatForward(calc_date, 
                        rate[i], 
                        day_count, 
                        ql.Compounded, 
                        ql.Semiannual)
    ts_handle = ql.YieldTermStructureHandle(ts)
    
    bondEngine = ql.DiscountingBondEngine(ts_handle)
    bond.setPricingEngine(bondEngine)

    callable_bond_price[i] = value_bond(0.03, 0.1, 80, callable_bond).cleanPrice()
    puttable_bond_price[i] = value_bond(0.03, 0.1, 80, puttable_bond).cleanPrice()
    bond_price[i] = bond.cleanPrice()

plt.figure(1)    
plt.plot(rate*100, bond_price)
plt.plot(rate*100, callable_bond_price)
plt.xlabel('Interest Rate (%)',fontsize=8)
plt.ylabel('Bond Price ($)',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')

plt.figure(2)
plt.plot(rate*100, bond_price)
plt.plot(rate*100, puttable_bond_price)
plt.xlabel('Interest Rate (%)',fontsize=8)
plt.ylabel('Bond Price ($)',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')


