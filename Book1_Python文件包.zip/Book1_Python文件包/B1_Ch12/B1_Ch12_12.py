# B1_Ch12_12.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import numpy as np
import matplotlib.pyplot as plt

todaysDate = ql.Date(10, 7, 2017)
ql.Settings.instance().evaluationDate = todaysDate
dayCount = ql.Thirty360()
calendar = ql.UnitedStates()
interpolation = ql.Linear()
compounding = ql.Compounded
compoundingFrequency = ql.Annual

issueDate = ql.Date(15, 1, 2017)
maturityDate = ql.Date(15, 1, 2020)
tenor = ql.Period(ql.Semiannual)
calendar = ql.UnitedStates()
bussinessConvention = ql.Unadjusted
dateGeneration = ql.DateGeneration.Backward
monthEnd = False
schedule = ql.Schedule (issueDate, maturityDate, tenor, calendar, bussinessConvention,
                            bussinessConvention , dateGeneration, monthEnd)

# Now lets build the coupon
dayCount = ql.Thirty360()
couponRate = .1
coupons = [couponRate]

# Now lets construct the FixedRateBond
settlementDays = 3
faceValue = 100
fixedRateBond = ql.FixedRateBond(settlementDays, faceValue, schedule, coupons, dayCount)

ytm = np.arange(0,0.2,0.01)
duration_mod = np.zeros(len(ytm))
dirtyPrice = np.zeros(len(ytm))
convexity = np.zeros(len(ytm))

for i in range(len(ytm)):
    y=ytm[i]
    duration_mod[i] = ql.BondFunctions.duration(fixedRateBond,y,ql.ActualActual(), ql.Compounded, ql.Annual, ql.Duration.Modified)
    convexity[i] = ql.BondFunctions.convexity(fixedRateBond,y,ql.ActualActual(), ql.Compounded, ql.Annual)
    dirtyPrice[i] = fixedRateBond.dirtyPrice(ytm[i],fixedRateBond.dayCounter(), compounding, ql.Semiannual)
    
plt.figure(1)
plt.subplot(311)    
plt.plot(ytm, dirtyPrice)
plt.xlabel('Yield To Maturity',fontsize=8)
plt.ylabel('Bond Price',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)

plt.subplot(312)    
plt.plot(ytm, duration_mod)
plt.xlabel('Yield To Maturity',fontsize=8)
plt.ylabel('Modified Duration',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)

plt.subplot(313)   
plt.plot(ytm, convexity)
plt.xlabel('Yield To Maturity',fontsize=8)
plt.ylabel('Convexity',fontsize=8)
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.subplots_adjust(hspace=0.5)
