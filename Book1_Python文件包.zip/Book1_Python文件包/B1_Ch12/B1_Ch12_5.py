# B1_Ch12_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############

import QuantLib as ql
import matplotlib.pyplot as plt

calc_date = ql.Date(15, 1, 2020)
ql.Settings.instance().evaluationDate = calc_date

data = [
    ('15-01-2020', '15-04-2020', 0, 97.5),
    ('15-01-2020', '15-07-2020', 0, 94.9),
    ('15-01-2020', '15-01-2021', 0, 90.0),
    ('15-01-2020', '15-07-2021', 8.0,96.0),
    ('15-01-2020', '15-01-2022', 12.0, 101.6),
]

helpers = []
day_count = ql.Thirty360()
settlement_days = 0
face_amount = 100

for issue_date, maturity, coupon, price in data:
    price = ql.QuoteHandle(ql.SimpleQuote(price))
    issue_date = ql.Date(issue_date, '%d-%m-%Y')
    maturity = ql.Date(maturity, '%d-%m-%Y')
    schedule = ql.MakeSchedule(issue_date, maturity, ql.Period(ql.Semiannual))
    helper = ql.FixedRateBondHelper(price, settlement_days, face_amount, schedule, [coupon / 100], day_count)
    helpers.append(helper)
    
yieldcurve = ql.PiecewiseLogCubicDiscount(calc_date, helpers, day_count)   
spots = []
tenors = []

for d in yieldcurve.dates():
    yrs = day_count.yearFraction(calc_date, d)
    print(yrs)
    compounding = ql.Compounded
    # compounding = ql.Simple
    freq = ql.Semiannual
    freq = ql.Quarterly
    freq = ql.Daily
    # freq = ql.Continuous
    zero_rate = yieldcurve.zeroRate(yrs, compounding, freq)
    tenors.append(yrs)
    eq_rate = zero_rate.equivalentRate(day_count,
                                       ql.Compounded,
                                       freq,
                                       calc_date,
                                       d).rate()
    spots.append(eq_rate)
    

plt.plot(tenors,spots,'x-')
plt.xlabel('Tenor',fontsize=8)
plt.ylabel('Rate',fontsize=8) 
plt.gca().spines['right'].set_visible(False)
plt.gca().spines['top'].set_visible(False)
plt.gca().yaxis.set_ticks_position('left')
plt.gca().xaxis.set_ticks_position('bottom')




