# B1_Ch4_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
from sympy import symbols, sympify
import sympy

u1, u2, u3, u4, v1, v2 = symbols('u1 u2 u3 u4 v1 v2')

equationsList = ["sin(u1)+4", "(u2*3)+4", "log(u3)+6*v1", "(u4*3)+v2"]

expressions = [sympify(expr) for expr in equationsList]

values = {u1: 1, u2: 2, u3: 3, u4: 4, v1: -1, v2: -2}

for expression in expressions:
    print('{:10s} ->  {:4d}'.format(str(expression),
                                    int(expression.subs(values))))
