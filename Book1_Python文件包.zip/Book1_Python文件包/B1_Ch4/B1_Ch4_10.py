# B1_Ch4_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import sympy as sym
from sympy import symbols, Matrix
x,y=symbols('x y')

f11,f12,f13=x*y,1,sym.exp(x)+y
f21,f22,f23=x**2,y**2,sym.sin(x)
f31,f32,f33=sym.exp(x)*y,x**2+y**2,sym.log(x)

M=Matrix([[f11,f12,f13],[f21,f22,f23],[f31,f32,f33]])

# Evaluate the values of the symbolic matrix at x = 1,y=2
points = {x:1,y:2}
values = M.subs(points)
print(f'The symbolic matrix at x=1,y=2 is equal to: \n {values}')

# Calculate the derivative of Matrix with respect to x
M_diff_x = sym.diff(M,x)
print(f'dM/dx is\n {M_diff_x}')

# Calculate the derivative of Matrix with respect to y
M_diff_y = sym.diff(M,y)
print(f'dM/dy is\n {M_diff_y}')

# Calculte the derivative of Matrix M with respect to x and then y
M_diff_xy = sym.diff(M_diff_x,y)
print(f'dM/dxdy is\n {M_diff_xy}')

# Calculate the indefinite integral of M with respect to x
M_integration_x = sym.integrate(M,(x,0,1))
print(f'The integral of M for x in the range of (1,2) is {M_integration_x}')

# Calculate the indefinite integral of M in the ranges of (0,1) for x and y
M_integration_xy = sym.integrate(M_integration_x,(y,0,1))
print(f'The integral of M for x and y in the range of (0,1) is {M_integration_xy}')
