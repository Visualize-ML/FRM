# B1_Ch4_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
from scipy.linalg import ldl
A = np.array([[2, -1, 0],
               [-1, 2, -1],
               [0, -1, 2]])
eigenvalues, eigenvectors = np.linalg.eig(A)
print(f'Check if Matrix A is positive-definite by using the eigenvalues: \n {eigenvalues}')
print(f'Check if Matrix A is a Hermitian matrix or not: \n A.T=\n{A.T}')
L, D, P = ldl(A)
print(f'L matrix is: \n {L}')
print(f'D matrix is: \n {D}')
print(f'Check if A=LDL.T:\n {np.isclose(L@D@L.T-A,0)}')
