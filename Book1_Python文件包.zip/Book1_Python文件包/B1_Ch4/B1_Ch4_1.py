# B1_Ch4_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
a=np.arange(9).reshape(3,3)-1

#max()
print(a.max(axis=1))#Out: [1 4 7], Return the max value in each row
print(np.max(a,axis=0))#Out: [5 6 7], Return the max value in each column
print(a.max())#Out: 7, Return the max value of the whole matrix

#argmax()
print(a.argmax(axis=1))#Out: [2 2 2], Return the indices of the maximum values along each row
print(np.argmax(a,axis=0))#Out: Out: [2 2 2], Return the indices of the maximum values along each column
print(a.argmax())#Out: 8, Return the index of the max value of the whole matrix

#sum()
print(a.sum())#Out: 27, Calculate the sum of all the element of the matrix
print(np.sum(a,axis=0))#Out: [6 9 12],Calculate the sum of each column
print(a.sum(axis=1))#Out: [0 9 18],Calculate the sum of eac row

#all()
print(a.all())#Out: False, Test whether all array elements are True
print(a.all(axis=0))#Out: False, Test whether all array elements in each column are True
print(np.all(a,axis=1))#Out: False, Test whether all array elements in each row are True

#any()
print(a.any())#Out: True, Test whether any array elements are True
print(a.any(axis=0))#Out: [ True  True  True], Test whether any array elements in each column are True
print(np.any(a,axis=1))#Out: [ True  True  True], Test whether any array elements in each row are True

#clip()
print(a.clip(3,6))
#Out: [[3 3 3],[3 3 4], [5 6 6]]

#ptp()
print(a.ptp())#Out: 8, return the range of values (maximum - minimum) of the matrix.
print(a.ptp(axis=0))#Out: [6 6 6], return the range of values (maximum - minimum) in each column.
print(a.ptp(axis=1))#Out: [2 2 2], return the range of values (maximum - minimum) in each row.

