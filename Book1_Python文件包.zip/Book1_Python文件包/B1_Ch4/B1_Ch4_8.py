# B1_Ch4_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import sympy as sym
from sympy import *
from sympy import Eq, And
import math
import numpy as np
import matplotlib.pyplot as plt
from sympy.plotting import plot,PlotGrid
plt.close('all')

x,y = symbols('x y')

f_x = 3*sin(x)-x
f_x_diff = sym.diff(f_x,x)
f_x_diff2 = sym.diff(f_x,x,2)

p1 = sym.plot(f_x,(x,-2*sym.pi,2*sym.pi),show=False,title=f_x)
p2 = sym.plot(f_x_diff,(x,-2*sym.pi,2*sym.pi),show=False,title=f_x_diff)
p3 = sym.plot(f_x_diff2,(x,-2*sym.pi,2*sym.pi),show=False,title=f_x_diff2)

zero_point = acos(1/3)
zero_point_v = [(-zero_point+2*math.pi),-(-zero_point+2*math.pi),zero_point,-zero_point]
zero_point_v.sort()

for i in zero_point_v:
    p = sym.plot_implicit(Eq(x,i),(x,-6,6),(y,-8,8),show=False)
    p1.extend(p)
    p2.extend(p)

plot_range = [-6]+zero_point_v+[6]
for i in range(len(plot_range)-1):
    if f_x_diff.evalf(subs={x: plot_range[i]+0.1})>0:
        pp1 = sym.plot_implicit(And(y<f_x_diff,y>0),
                                (x,plot_range[i],plot_range[i+1]),
                                (y,-8,8),
                                line_color='blue',
                                show=False)
        pp2 = sym.plot_implicit(And(y<f_x,y>0),
                                (x,plot_range[i],
                                 plot_range[i+1]),
                                (y,-8,8),
                                line_color='blue',
                                show=False)
        pp3 = sym.plot_implicit(And(y>f_x,y<0),
                                (x,plot_range[i],plot_range[i+1]),
                                (y,-8,8),
                                line_color='blue',
                                show=False)
    else:
        pp1 = sym.plot_implicit(And(y>f_x_diff,y<0),
                                (x,plot_range[i],plot_range[i+1]),
                                (y,-8,8),
                                line_color='red', 
                                show=False)
        pp2 = sym.plot_implicit(And(y<f_x,y>0),
                                (x,plot_range[i],plot_range[i+1]),
                                (y,-8,8),
                                line_color='red',
                                show=False)
        pp3 = sym.plot_implicit(And(y>f_x,y<0),
                                (x,plot_range[i],
                                 plot_range[i+1]),
                                (y,-8,8),
                                line_color='red',
                                show=False) 
    p2.extend(pp1)
    p1.extend(pp2)
    p1.extend(pp3)
    
p1.xlim=(-6,6)
p2.xlim=(-6,6)
p1.ylim=(-10,10)
p2.ylim=(-6,3)

p1.show()
p2.show()
p3.show()

def f1(x):
    return -3*math.sin(x)
def trap(f, n,start,end):
    h = (end-start) / float(n)
    intgr = 0.5 * h * (f(start) + f(end))
    for i in range(1, int(n)):
        intgr = intgr + h * f(i * h+start)
    return intgr

Integral_sympy = integrate(f_x_diff2,(x,0,2*math.pi))
Integral_trap = trap(f1,n=1000,start = 0,end=2*math.pi)
print(f'The integration of {f_x_diff2} by using SymPy integration fuction is: {Integral_sympy}')
print(f'The integration of {f_x_diff2} by using trapezium rule is: {np.round(Integral_trap)}')
