# B1_Ch4_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import sympy as sym
x, y, z = sym.symbols("x y z")
f1 = 2*sym.sin(x)
f2 = sym.sin(x)+y**2+sym.log(z)

value1 =f1.evalf(subs={x: 2.4})
value2=f2.evalf(subs={x: 1,y:2,z:3})

f3 = f1.subs(x,x**2)
f4 = f2.subs({x:x**2,y:sym.cos(y),z:sym.tan(z)})
print(value1)
print(value2)
print(f3)
print(f4)
