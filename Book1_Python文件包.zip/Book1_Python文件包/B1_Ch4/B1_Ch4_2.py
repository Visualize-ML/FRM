# B1_Ch4_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
from scipy.linalg import pascal
# Use left array division to solve
A = pascal(3)
B = np.array([3,1,4]).reshape(3,1,)
x1,resid,rank,s = np.linalg.lstsq(A,B)
print(f'Calculating left array division by lstsq() function: {x1}')
x2=np.linalg.solve(A,B)
print(f'Calculating left array division by solve() function: {x2}')
x3=(np.linalg.inv(A))@B
print(f'Calculating left array division by the inverse of the matrix: {x3}')
# Use right array division solve xA=b
A = np.array([[1,1,3], [2,0,4], [-1,6,-1]])
B = np.array([2,19,8])

x=B@np.linalg.inv(A)
print(f'Calculating right array division by the inverse of the matrix: {x}')
