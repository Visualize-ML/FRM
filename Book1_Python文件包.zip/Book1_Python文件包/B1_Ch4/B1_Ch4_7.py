# B1_Ch4_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
From sympy import symbols
from sympy.plotting import plot
import sympy as sym
import matplotlib.pyplot as plt
x=symbols('x')

plot1=plot(sym.sin(x)/x,(x,-15,15),show=True)

plot1.xlabel='x'
plot1.ylabel='f(x)'
plot2=plot(sym.sin(x)/x,(x,-50,50),nb_of_points=1000,adaptive=False)

plot3=plot(sym.sin(x)/x,(x,-500,500),nb_of_points=1000,adaptive=False)
plot2.show()
plot3.show()
plot2.xlabel='x'
plot2.ylabel='f(x)'
plot3.xlabel='x'
plot3.ylabel='f(x)'
limit1=sym.limit(sym.sin(x)/x,x,0)
limit2=sym.limit(sym.sin(x)/x,x,sym.oo)
print(f'When x approaches 0, f(x) approaches {limit1}')
print(f'When x approaches ∞, f(x) approaches {limit2}')
