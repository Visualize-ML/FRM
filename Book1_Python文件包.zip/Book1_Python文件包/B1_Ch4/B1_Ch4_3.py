# B1_Ch4_2.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
A=np.array([[3,2,4],[2,0,2],[4,2,3]])
eigenvalues, eigenvectors = np.linalg.eig(A)
eigenvalues=eigenvalues.round(1)
index =['first','second','third']
for i, eigenvalue in enumerate(eigenvalues):
    print(f'The {index[i]} eigenvalue is \n {eigenvalue}')
    print(f'The eigenvectors for the {index[i]} eigenvalue are: \n {eigenvectors[:,i]}')
    print('Validation:')
    print(f'Ax={A@eigenvectors[:,i]}')
    print(f'\u03BBx={eigenvalue*eigenvectors[:,i]}')
