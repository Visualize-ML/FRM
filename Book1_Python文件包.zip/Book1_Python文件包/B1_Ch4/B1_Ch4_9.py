# B1_Ch4_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import sympy as sym
from sympy import symbols
from sympy.plotting import plot3d, PlotGrid
import numpy as np
import matplotlib.pyplot as plt
x, y = symbols("x y")

plt.close('all')

f_xy = x**2*y**2
# Calculate df(x,y)/dx
f_xy_diff_x = sym.diff(f_xy,x)
# Calculate df(x,y)/dy
f_xy_diff_y = sym.diff(f_xy,y)
# Calculate df(x,y)/dxdy
f_xy_diff_xy = sym.diff(f_xy_diff_x,y)

print(f'f(xy)={f_xy}')
print(f'df/dx={f_xy_diff_x}')
print(f'df/dy={f_xy_diff_y}')
print(f'df/dxdy={f_xy_diff_xy}')

# Evaluate f(x,y) at x=1,y=1
value1=f_xy.evalf(subs={x: 1,y:1})
print(f'f(xy) at x=1,y=1 is equal to {value1}')

# Calculate the integration of f(x,y) along x = [-1,1]
Integration1 = sym.integrate(f_xy,(x,-1,1))
# Calculate the integration of f(x,y) along y = [-1,1]
Integration2 = sym.integrate(f_xy,(y,-1,1))
# Calculate the integration of f(x,y) along x = [-1,1] and y = [-1,1]
Integration3 = sym.integrate(f_xy,(x,-1,1),(y,-1,1))
print(f'Calculate the integration of f(x,y) along x = [-1,1] : {Integration1}')
print(f'Calculate the integration of f(x,y) along x = [-1,1] : {Integration2}')
print(f'Calculate the integration of f(x,y) along x = [-1,1] and y = [-1,1]: {Integration3}')

p1=plot3d(f_xy,(x,-2,2),(y,-2,2),show=False)
p2=plot3d(f_xy_diff_x,(x,-2,2),(y,-2,2),show=False)
p3=plot3d(f_xy_diff_y,(x,-2,2),(y,-2,2),show=False)
p4=plot3d(f_xy_diff_xy,(x,-2,2),(y,-2,2),show=True)
PlotGrid(4,1,p1,p2,p3,p4)
