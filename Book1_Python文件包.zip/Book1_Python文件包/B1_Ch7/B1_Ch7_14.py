# B1_Ch7_14.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
# Pie chart, where the slices will be ordered and plotted counter-clockwise:
labels = 'Salaries and Wages', 'Office Equipment and Supplies', 'Rents', 'Marketing'
sizes = [40, 20, 25, 15]
explode = (0.1, 0.1, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
ax1.set_title('Operating Expenses of a company, unexploded')
plt.show()

fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
ax1.set_title('Operating Expenses of a company, partially exploded')
plt.show()
