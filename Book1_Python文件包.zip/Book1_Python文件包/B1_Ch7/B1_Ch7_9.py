# B1_Ch7_9.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
import numpy as np
import matplotlib

plt.close('all')
x1 = np.linspace(0, 2 * np.pi, 50)
y1 = np.exp(0.5*np.sin(x1))*np.sin(3*x1)

fig,ax = plt.subplots(2,1,figsize=(13/2.54,2*7/2.54))
font = {'family':'Times New Roman','weight':'normal', 'size'   : 8}
matplotlib.rc('font', **font)

#subplot#1
markerline1, stemlines1, baseline1 =ax[0].stem(x1, y1, use_line_collection=False,bottom = -0.5)
plt.setp(markerline1, fillstyle = 'none',mec = 'g')
plt.setp(stemlines1, color = 'b',linewidth = 1)
plt.setp(baseline1,color = 'r',linestyle = '--')

#subplot#2
x2 = np.linspace(0.1,2*np.pi,10)
x3 = np.linspace(0.5,2*np.pi,9)
markerline2, stemlines2, baseline2 =ax[1].stem(x2, np.cos(x2), use_line_collection=False)
markerline3, stemlines3, baseline2 =ax[1].stem(x3, np.sin(x3), use_line_collection=False)
plt.setp(markerline2, marker = 'v',fillstyle = 'none',mec = 'c')
plt.setp(stemlines2, color = 'm',linewidth = 1)
