# B1_Ch7_15.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import pandas_datareader as pdr
plt.close('all')

tickers = ['goog', 'amzn']
df = pdr.DataReader(tickers, data_source='yahoo', start='2020-01-01', end='2020-12-30')

goog_Q1_mean= np.mean(df['Adj Close']['goog']['2020-01-02':'2020-03-31'])
goog_Q2_mean= np.mean(df['Adj Close']['goog']['2020-04-01':'2020-06-30'])
goog_Q3_mean= np.mean(df['Adj Close']['goog']['2020-07-01':'2020-08-30'])
goog_Q4_mean= np.mean(df['Adj Close']['goog']['2020-09-01':'2020-12-30'])
amzn_Q1_mean= np.mean(df['Adj Close']['amzn']['2020-01-02':'2020-03-31'])
amzn_Q2_mean= np.mean(df['Adj Close']['amzn']['2020-04-01':'2020-06-30'])
amzn_Q3_mean= np.mean(df['Adj Close']['amzn']['2020-07-01':'2020-08-30'])
amzn_Q4_mean= np.mean(df['Adj Close']['amzn']['2020-09-01':'2020-12-30'])

labels = ['Q1', 'Q2', 'Q3', 'Q4']
goog_means = [goog_Q1_mean, goog_Q2_mean, goog_Q3_mean, goog_Q4_mean]
amazn_means = [amzn_Q1_mean, amzn_Q2_mean, amzn_Q3_mean, amzn_Q4_mean]

x = np.arange(len(labels))  # the label locations
width = 0.35  # the width of the bars

#Bar chart using Matplotlib
fig, ax = plt.subplots(2,1)
ax[0].bar(x - width/2, goog_means, width, label='Google')
ax[0].bar(x + width/2, amazn_means, width, label='Amazon')
ax[0].set_ylabel('Adjusted closing price')
ax[0].set_xticks(x)
ax[0].set_xticklabels(labels)
ax[0].legend()

ax[1].barh(x - width/2, goog_means, width, label='Google')
ax[1].barh(x + width/2, amazn_means, width, label='Amazon')
ax[1].set_xlabel('Adjusted closing price')
ax[1].set_yticks(x)
ax[1].set_yticklabels(labels)
ax[1].legend()
#%% bar chart by using seaborn
plt.subplot
price = goog_means + amazn_means
stock = ['Google']*4 + ['Amazon']*4
Quarter = labels*2
df = pd.DataFrame({'Quarter':Quarter,'Adjusted closing price':price,'Stock':stock})
fig, ax = plt.subplots(2,1)
sns.barplot(x='Quarter', y='Adjusted closing price',hue='Stock',data=df,ci=None,palette="Set2",ax=ax[0])
sns.barplot(y='Quarter', x='Adjusted closing price',hue='Stock',data=df,ci=None,palette="Set2",ax=ax[1])
#%% bar chart by using pandas
df = pd.DataFrame({'Google':goog_means,'Amazon':amazn_means},index=labels)
fig, ax = plt.subplots(2,1)
df.plot.bar(rot=0,color={'Google':'red','Amazon':'blue'},ax=ax[0])
ax[0].set_ylabel("Adjusted closing price")
df.plot.barh(rot=0,color={'Google':'red','Amazon':'blue'},ax=ax[1])
ax[1].set_xlabel("Adjusted closing price")
