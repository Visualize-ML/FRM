# B1_Ch7_17.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib.pyplot as plt
import math
from matplotlib.widgets import Slider, Button

fig, ax = plt.subplots()
plt.subplots_adjust(bottom=0.4)
t = np.arange(0.0, 1.0, 0.001)
a0,f0,fi0,p0 = 7,4,0,0
delta_f = 5.0
s = a0 * np.sin(2 * np.pi * f0 * t + fi0) + p0
l, = plt.plot(t, s, lw=2)
ax.margins(x=0)
plt.xlabel('Time [s]')
plt.ylabel(r'$\it{sin(t)}$')

axcolor = 'lightgoldenrodyellow'
axfreq = plt.axes([0.25, 0.1, 0.65, 0.03], facecolor=axcolor)
axamp = plt.axes([0.25, 0.15, 0.65, 0.03], facecolor=axcolor)
axfi = plt.axes([0.25, 0.2, 0.65, 0.03], facecolor=axcolor)
axp = plt.axes([0.25, 0.25, 0.65, 0.03], facecolor=axcolor)

sfreq = Slider(axfreq, 'Frequency', 0.1, 30.0, valinit=f0, valstep=delta_f)
samp = Slider(axamp, 'Amplitude', 0.1, 10.0, valinit=a0,valstep = 0.5)
sfi = Slider(axfi,'Phase',0,2*math.pi,valinit=fi0,valstep = math.pi/20)
sp = Slider(axp,'Offset',0,4,valinit=p0,valstep = 0.5)

def update(val):
    amp = samp.val
    freq = sfreq.val
    fi = sfi.val
    p = sp.val
    l.set_ydata(amp*np.cos(2*np.pi*freq*t+fi)+p)
    fig.canvas.draw_idle()
sfreq.on_changed(update)
samp.on_changed(update)
sfi.on_changed(update)
sp.on_changed(update)

resetax = plt.axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')

def reset(event):
    sfreq.reset()
    samp.reset()
button.on_clicked(reset)
plt.show()
