# B1_Ch7_3.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib.pyplot as plt
import math
 
x1 = np.linspace(0, 6, 20)
x2 = np.linspace(0,4*math.pi,60)
y1 = np.exp(x1)-5
y2 = np.sin(x2)*5

fig,ax1 = plt.subplots(figsize=(11/2.54,7/2.54))
ax1.plot(x1, y1,'b',linewidth = 1)
ax1.set_xlabel('X1',color = 'b')
ax1.set_ylabel('Y1',color='b')
#Add the second y axis
ax2=ax1.twiny()
ax2.set_xlabel('X2',color='r')
ax2.plot(x2, y2,'r:')

plt.show()
