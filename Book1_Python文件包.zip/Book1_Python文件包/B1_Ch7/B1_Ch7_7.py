# B1_Ch7_7.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats
import matplotlib as mp
plt.close('all')

font = {'family':'Times New Roman','weight':'normal', 'size'   : 10}
mp.rc('font', **font)

plt.figure(1)
plt.subplot()
data = np.random.normal(10, 3, 1200)
_, bins, _ = plt.hist(data, 20, density=1, alpha=1,fill=0)
mu, sigma = scipy.stats.norm.fit(data)
best_fit_line = scipy.stats.norm.pdf(bins, mu, sigma)
plt.plot(bins, best_fit_line,'b--')
plt.xlabel('x')
plt.ylabel('PDF of a Normal Disctribution')
fig_title = r'$\frac{1}{3\sqrt{2\pi}}e^{-\frac{1}{2}(\frac{\mathit{x}-10}{3})^2}$'
plt.title(fig_title)

df_list = [1,2,6,20]
linstyles = ['k:','-b','r--','g-.']
x = np.linspace(-4,4,100)
fig, axs = plt.subplots(2, 1)
pdf_title = (r'$pdf(x)=\frac{\Gamma(\frac{\nu+1}{2})}{\sqrt{\nu\pi}\Gamma(\frac{\nu}{2})}(1+\frac{x^2}{\nu})^{-(\frac{\nu+1}{2})}$')
axs[0].set_xlabel(r'$\mathit{x}$')
axs[0].set_ylabel('pdf(x) of student t distribution')
axs[0].set_title(pdf_title)
ax_legend=[r'$\nu=1$',r'$\nu=2$',r'$\nu=6$',r'$\nu=20$']
axs[1].set_xlabel (r'$\mathit{x}$')
axs[1].set_title('cdf(x) of student t distribution')
axs[1].set_ylabel('cdf(x) of student t distribution')
fig.tight_layout(pad=1)
for mu,line,legend in zip(df_list,linstyles,ax_legend):
    norm_pdf = scipy.stats.t.pdf(x, mu)
    axs[0].plot(x, norm_pdf,line,label=legend)
    norm_cdf = scipy.stats.t.cdf(x, mu)
    axs[1].plot(x, norm_cdf,line,label=legend)

axs[0].legend(loc="upper right")
axs[1].legend(loc="lower right")
