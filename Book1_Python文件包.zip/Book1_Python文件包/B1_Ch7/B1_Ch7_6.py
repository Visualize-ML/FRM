# B1_Ch7_6.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import pandas_datareader as pdr
import numpy as np
import matplotlib.pyplot as plt
plt.close('all')

tickers = ['goog', 'amzn']
df = pdr.DataReader(tickers, data_source='yahoo', start='2020-01-01', end='2020-12-30')
fig, ax = plt.subplots()
ax.plot(df.index,df['Adj Close']['goog'],label='Google')
ax.plot(df.index,df['Adj Close']['amzn'],label='Amazon')
goog_mean= np.mean(df['Adj Close']['goog'])
amzn_mean = np.mean(df['Adj Close']['amzn'])
ax.set_xlabel('Date')
ax.set_ylabel('Adjusted closing price')
[ax.axhline(y=i, color = j) for i,j in zip([goog_mean,amzn_mean],['blue','orange']) ]
fig.text(0.15,0.62,'The average price of Amazon')
fig.text(0.67,0.22,'The average price of Google')
ax.legend(loc='upper left')
