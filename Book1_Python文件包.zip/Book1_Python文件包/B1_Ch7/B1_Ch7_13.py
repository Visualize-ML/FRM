# B1_Ch7_13.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
from matplotlib import cm,ticker

plt.close('all')
# Gamma of European option

def blsgamma(St, K, tau, r, vol, q):
    d1 = (math.log(St / K) + (r - q + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
        
    Gamma = math.exp(-q*tau)*norm.pdf(d1)/St/vol/math.sqrt(tau);

    return Gamma
    
# Initialize
tau_array = np.linspace(0.1,1,20);
St_array  = np.linspace(20,80,20);
tau_Matrix,St_Matrix = np.meshgrid(tau_array,St_array)

Delta_call_Matrix = np.empty(np.size(tau_Matrix))
Delta_put_Matrix  = np.empty(np.size(tau_Matrix))

K = 60;    # strike price
r = 0.025;  # risk-free rate
vol = 0.45; # volatility 
q = 0;     # continuously compounded yield of the underlying asset

blsgamma_vec = np.vectorize(blsgamma)
Gamma_Matrix = blsgamma_vec(St_Matrix, K, tau_Matrix, r, vol, q)

fig = plt.figure(figsize=(8,12))
ax1 = fig.add_subplot(2, 1, 1, projection='3d')
sur=ax1.plot_surface(tau_Matrix, St_Matrix, Gamma_Matrix, cmap='coolwarm')
sur.set_facecolor((0,0,0,0))
cb = fig.colorbar(sur,ax=ax1, shrink=0.4, aspect=10)
tick_locator = ticker.MaxNLocator(nbins=5)
cb.locator = tick_locator
cb.update_ticks()

ax1.set_xticks([0,0.2,0.4,0.6,0.8])
ax1.set_yticks([10,30,50,70,90])
ax1.set_zticks([0,0.02,0.04])
ax1.set_xlabel('Time to maturity (year)')
ax1.set_ylabel('Underlying price')
ax1.set_zlabel('Gamma')

ax2 = fig.add_subplot(2, 1, 2, projection='3d')
ax2.plot_wireframe(tau_Matrix, St_Matrix, Gamma_Matrix, linewidth=1)
ax2.set_xlabel('Time to maturity (year)')
ax2.set_ylabel('Underlying price')
ax2.set_zlabel('Gamma')
#%%
fig = plt.figure(figsize=(8,12))
ax1 = fig.add_subplot(2, 1, 1, projection='3d')
ax1.contour(tau_Matrix, St_Matrix, Gamma_Matrix, levels = 20, zdir='x', \
          offset=0.2, cmap=cm.coolwarm)
ax1.view_init(azim=0, elev=0)
ax1.set_xticks([])
ax1.w_xaxis.line.set_lw(0.)
ax1.set_ylabel('Underlying price')
ax1.set_zlabel('Gamma')

norm = plt.Normalize(Gamma_Matrix.min(), Gamma_Matrix.max())
colors = cm.coolwarm(norm(Gamma_Matrix))
ax2 = fig.add_subplot(2, 1, 2, projection='3d')
sur=ax2.plot_surface(tau_Matrix, St_Matrix, Gamma_Matrix, facecolors=colors, shade=False)
sur.set_facecolor((0,0,0,0))
ax2.contour(tau_Matrix, St_Matrix, Gamma_Matrix, levels = 20, zdir='x', \
          offset=0, cmap=cm.coolwarm)
ax2.set_xlabel('Time to maturity (year)')
ax2.set_ylabel('Underlying price')
ax2.set_zlabel('Gamma')
