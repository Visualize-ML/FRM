# B1_Ch7_11.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt
import math

mpl.rcParams['legend.fontsize'] = 10

fig = plt.figure(figsize=plt.figaspect(0.5))
ax1 = fig.add_subplot(1, 2, 1, projection='3d')
t = np.linspace(0, 10*math.pi, 100)
x = np.sin(t)
y = np.cos(t)
ax1.plot(x, y, t, 'o-',markerfacecolor='#D9FFFF')
ax1.set_xticks([-1,0,1])
ax1.set_yticks([-1,0,1])
ax1.set_zticks([0,10,20,30])

ax2 = fig.add_subplot(1, 2, 2, projection='3d')
t = np.linspace(-10, 10, 1000)
x = np.exp(-1*t/10)*np.sin(5*t)
y = np.exp(-1*t/10)*np.cos(5*t)
ax2.plot(x, y, t, markerfacecolor='#D9FFFF')
ax2.set_xticks([-2,-1,0,1,2])
ax2.set_yticks([-2,-1,0,1,2])
ax2.set_zticks([-10,-5,0,5,10])
plt.show()
