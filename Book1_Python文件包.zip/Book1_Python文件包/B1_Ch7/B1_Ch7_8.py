# B1_Ch7_8.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
plt.close('all')
fig,ax = plt.subplots(2,1,figsize=(13/2.54,2*7/2.54))
font = {'family':'Times New Roman','weight':'normal', 'size'   : 8}
matplotlib.rc('font', **font)
x = np.linspace(0, 2 * np.pi)
y_sin = np.sin(x)
y_cos = np.cos(x)
#subplot_1
ax[0].errorbar(x, y_sin, 0.2)
ax[0].errorbar(x, y_cos, 0.2)
ax[0].set(xlabel='X', ylabel='Y')
#subplot_2
ax[1].plot(x,y_sin,x,y_cos)
ax[1].fill_between(x,y_sin+0.2, y_sin-0.2,alpha=0.2)
ax[1].fill_between(x,y_cos+0.2, y_cos-0.2,alpha=0.2)
ax[1].set(xlabel='X', ylabel='Y')
