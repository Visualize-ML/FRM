# B1_Ch7_4.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mp

plt.close('all')
font = {'family':'Times New Roman','weight':'normal', 'size'   : 10}
mp.rc('font', **font)

t = np.linspace(-5,5,300)
y1 = np.sin(t)+np.random.ranf(size = t.size)*0.2
y2 = np.sin(t ** 2)
n = 500
normal_2D_data =  np.random.normal(0, 2, (n, 2)) 
T = np.arctan2(normal_2D_data[:, 0],normal_2D_data[:, 1]) # for color value

#plot #1
fig, axs = plt.subplots(1, 2,figsize=(8,5))
axs[0].plot(t,y1)
axs[0].set_xlim(-6,6)
axs[0].set_ylim(-1,2)
axs[0].set_xlabel(r'$\mathit{x}_1$')
axs[0].set_ylabel(r'$\mathit{y}_1$')
axs[0].set_title('Plot#1')
axs[0].set_yticks([-1.5,-1,0,1,1.5])
axs[1].scatter(normal_2D_data[:, 0], normal_2D_data[:, 1], s=10, c=T, edgecolors = 'none',alpha=.6, cmap='Set1')
axs[1].set_xlim(-7,7)
axs[1].set_ylim(-6,6)
axs[1].set_xlabel(r'$\mathit{x}_2$')
axs[1].set_ylabel(r'$\mathit{y}_2$')
axs[1].set_title('Plot#2')

#plot #2
plt.figure(2,figsize=(8,6))
plt.subplot(211)
plt.xlim(-6,6)
plt.ylim(-1.5,1.5)
plt.xlabel(r'$\mathit{x}_1$')
plt.ylabel(r'$\mathit{y}_1$')
plt.title('Plot#1')
plt.plot(t,y1)
plt.show()

plt.subplot(212)
plt.scatter(normal_2D_data[:, 0], normal_2D_data[:, 1], s=10, c=T, edgecolors = 'none',alpha=.6, cmap='Set1')
plt.show()
plt.xlim(-7,7)
plt.ylim(-6,6)
plt.xlabel(r'$\mathit{x}_2$')
plt.ylabel(r'$\mathit{y}_2$')
plt.title('Plot#2')

#plot #3
fig, axs = plt.subplots(1, 3,sharex=True,sharey=True,figsize=(8,5))
axs[0].plot(t,y1*5)
axs[0].set_xlim(-6,6)
axs[0].set_ylim(-7,7)
axs[0].set_xlabel(r'$\mathit{x}_1$')
axs[0].set_ylabel(r'$\mathit{y}_1$')
axs[0].set_title('Plot#1')

axs[1].plot(t,y2*5)
axs[1].set_xlim(-6,6)
axs[1].set_ylim(-6,6)
axs[1].set_xlabel(r'$\mathit{x}_2$')
axs[1].set_ylabel(r'$\mathit{y}_2$')
axs[1].set_title('Plot#2')

axs[2].scatter(normal_2D_data[:, 0], normal_2D_data[:, 1], s=10, c=T, edgecolors = 'none',alpha=.6, cmap='Set1')
axs[2].set_xlim(-7,7)
axs[2].set_ylim(-6,6)
axs[2].set_xlabel(r'$\mathit{x}_3$')
axs[2].set_ylabel(r'$\mathit{y}_3$')
axs[2].set_title('Plot#3')

#plot #4
fig,ax=plt.subplots(figsize=(8,8))
ax.axis('off')
fig.add_subplot(3,1,1) 
plt.plot(t,y1*5)
plt.xlim(-5,5)
plt.ylim(-5,5)
plt.yticks([-5,0,5])
plt.xlabel(r'$\mathit{x}_1$')
plt.ylabel(r'$\mathit{y}_1$')
plt.title('Plot#1')

fig.add_subplot(3,1,2) 
plt. plot(t,y2*5)
plt.xlim(-5,5)
plt.ylim(-5,5)
plt.yticks([-5,0,5])
plt.xlabel(r'$\mathit{x}_2$')
plt.ylabel(r'$\mathit{y}_2$')
plt.title('Plot#2')

fig.add_subplot(3,1,3) 
plt.scatter(normal_2D_data[:, 0], normal_2D_data[:, 1], s=10, c=T, edgecolors = 'none',alpha=.6, cmap='Set1')
plt.xlim(-7,7)
plt.ylim(-6,6)
plt.xlabel(r'$\mathit{x}_3$')
plt.ylabel(r'$\mathit{y}_3$')
plt.yticks([-6,-2,2,6])
plt.title('Plot#3')

#plot #5
fig,ax=plt.subplots()
fig.add_subplot()
ax.axis('off')
ax.set_xlabel('x')
ax.set_ylabel('y')
plt.plot(t,y1*5)
plt.xlim(-5,5)
plt.title('Plot')
left, bottom, width, height = 0.3, 0.65, 0.25, 0.2
ax2=fig.add_axes([left,bottom,width,height])
ax2.plot(t,y1*5)
ax2.set_xlabel('x')
ax2.set_ylabel('y')
