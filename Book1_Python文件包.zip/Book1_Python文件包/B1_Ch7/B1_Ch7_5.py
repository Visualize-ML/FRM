# B1_Ch7_5.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt

fig, axs = plt.subplots(2, 2)

axs[0,0].plot([0, 10], [2, 2])
axs[0,0].plot([3, 3], [0, 5])
axs[0,0].set_xlim([0,10])
axs[0,0].set_ylim([0,5])

axs[0,1].axhline(3)
axs[0,1].axvline(5)
axs[0,1].set_xlim([0,10])
axs[0,1].set_ylim([0,5])

axs[1,0].vlines([3, 7],[0],[5],'r',linestyle = ':')
axs[1,0].hlines([1, 4],[0],[10],'b',linestyle = '--')
axs[1,0].set_xlim([0,10])
axs[1,0].set_ylim([0,5])

axs[1,1].axhspan(2.5,3, color = 'r')
axs[1,1].axvspan(5,6,color = 'b')
axs[1,1].set_xlim([0,10])
axs[1,1].set_ylim([0,5])
