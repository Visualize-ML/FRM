# B1_Ch7_1.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import numpy as np
import matplotlib as mp
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
# Fixing random state for reproducibility
np.random.seed(19680801)

t = np.arange(0, 30, 0.01)
nse1 = np.random.randn(len(t))                 # white noise 1
nse2 = np.random.randn(len(t))                 # white noise 2

# Two signals with a coherent part at 2Hz and a random part
s1 = np.sin(2 * np.pi * 2 * t) + nse1
s2 = np.sin(2 * np.pi * 2 * t) + nse2

fig,ax = plt.subplots(figsize=(11/2.54,7/2.54))
plt.plot(t, s1, t, s2)

font = {'family':'Times New Roman','weight':'normal', 'size'   : 8}
mp.rc('font', **font)
mp.rcParams['axes.linewidth'] = 0.5
ax.set_xlim(0,2)
ax.set_ylim(-4,4)
ax.set(xlabel='Time [s]', ylabel='Magnitude',title='Figure Title: White Noise')
ax.xaxis.set_major_locator(MultipleLocator(0.5))
ax.xaxis.set_minor_locator(MultipleLocator(0.25))
ax.yaxis.set_major_locator(MultipleLocator(1))
ax.yaxis.set_minor_locator(MultipleLocator(0.5))
ax.tick_params(which='major', length=7,width = 0.5)
ax.tick_params(which='minor', length=4,width = 0.5)
ax.grid(linewidth=0.5,linestyle='--')
plt.legend(['White noise 1', 'White noise 2'],edgecolor = 'none', facecolor = 'none',loc='upper center')
plt.show()
