# B1_Ch7_10.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
import numpy as np
import math
import matplotlib
plt.close('all')
dx = 0.01; dy = 0.01
x = np.linspace(-2*math.pi,2*math.pi,100)
y = np.linspace(0,4*math.pi,100)
X,Y = np.meshgrid(x,y)
def f1(x,y):
    return (np.sin(x)+np.cos(y))
def f2(x,y):
    return (x*np.sin(x)+y*np.cos(y))
fig,ax = plt.subplots(2,1,figsize=(13/2.54,2*7/2.54))
#subplot #1
C1 = ax[0].contour(X,Y,f1(X,Y),cmap = 'cool')
#plt.clabel(C, inline=1, fontsize=10)
ax[0].set(xlabel='X', ylabel='Y')
# The following code is used to plot the continuous colorbar
norm= matplotlib.colors.Normalize(vmin=C1.cvalues.min(), vmax=C1.cvalues.max())
sm = plt.cm.ScalarMappable(norm=norm, cmap = C1.cmap)
sm.set_array([])
fig.colorbar(sm, ax=ax[0],ticks=C1.levels)
#subplot #2
C2 = ax[1].contourf(X,Y,f2(X,Y),cmap = 'RdBu_r')
ax[1].set(xlabel='X', ylabel='Y')
fig.colorbar(C2,ax=ax[1])
