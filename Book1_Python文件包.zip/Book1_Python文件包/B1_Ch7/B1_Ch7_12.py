# B1_Ch7_13.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
import numpy as np
import mpl_toolkits.mplot3d.art3d as art3d

z = np.linspace(0,4*np.pi,300)
x = 2*np.cos(z) + np.random.rand(1,300)
y = np.cos(x) + np.random.rand(1,300)

fig = plt.figure()
ax = fig.add_subplot(121, projection='3d')
ax.scatter(x, y, z)

ax = fig.add_subplot(1, 2, 2, projection='3d')
N = 100
theta = np.linspace(0, 2*np.pi, N, endpoint=False)
x = np.cos(theta)
y = np.sin(theta)
z = range(N)
for xi, yi, zi in zip(x, y, z):        
    line=art3d.Line3D(*zip((xi, yi, 0), (xi, yi, zi)), marker='o', markevery=(1, 1))
    ax.add_line(line)
ax.set_xlim3d(-1, 1)
ax.set_ylim3d(-1, 1)
ax.set_zlim3d(0, N)    
plt.show()
