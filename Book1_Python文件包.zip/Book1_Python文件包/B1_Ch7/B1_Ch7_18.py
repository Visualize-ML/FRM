# B1_Ch7_18.py

###############
# Prepared by Jianbin Liang, Ran An, and Wei Lu,
# Editor-in-chief: Weisheng Jiang, and Sheng Tu
# Book 1  |  Financial Risk Management with Python
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2021
###############
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
import math
import numpy as np
from scipy.stats import norm
from matplotlib.font_manager import FontProperties

font = FontProperties()
font.set_family('serif')
font.set_name('Times New Roman')
font.set_size(12)

S0 = 50;    # spot price
S_array  = np.linspace(20,80,26);
delta_S = S_array[1]-S_array[0];

K0 = 50;    # strike price
K_array  = np.linspace(20,80,26);
delta_K = K_array[1]-K_array[0];

r0 = 0.03;  # risk-free rate
r_array  = np.linspace(0.01,0.05,26);
delta_r = r_array[1]-r_array[0];

vol0 = 0.5; # volatility 
vol_array  = np.linspace(0.01,0.9,26);
delta_vol = vol_array[1]-vol_array[0];

q0 = 0;     # continuously compounded yield of the underlying asset
q_array  = np.linspace(0,0.02,26);
delta_q = q_array[2]-q_array[1];

tau0 = 1;     # time to maturity
tau_array  = np.linspace(0.1,1,26);
delta_tau = tau_array[2]-tau_array[1];

# Delta of European option

def blsprice(St, K, tau, r, vol, q):
    
    d1 = (math.log(St / K) + (r - q + 0.5 * vol ** 2)\
          *tau) / (vol * math.sqrt(tau));
    d2 = d1 - vol*math.sqrt(tau);
    
    Call = norm.cdf(d1, loc=0, scale=1)*St*math.exp(-q*tau) - \
        norm.cdf(d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    Put  = -norm.cdf(-d1, loc=0, scale=1)*St*math.exp(-q*tau) + \
        norm.cdf(-d2, loc=0, scale=1)*K*math.exp(-r*tau)
        
    return Call, Put

def plot_curve(S_array,Call_array,Put_array,text):
    
    fig, axs = plt.subplots(1,3,figsize=(13,7))

    a1, = axs[0].plot(S_array, Call_array)
    x_label = '$\it{' + text + '}$'
    axs[0].set_xlabel(x_label, fontname="Times New Roman", fontsize=12)
    y_label = '$\it{C}$($\it{' + text + '}$)'
    axs[0].set_ylabel(y_label, family="Times New Roman", fontsize=12)
    axs[0].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])

    a2,=axs[1].plot(S_array, Put_array)
    axs[1].set_xlabel(x_label, family="Times New Roman", fontsize=12)
    y_label = '$\it{P}$($\it{' + text + '}$)'
    axs[1].set_ylabel(y_label, fontname="Times New Roman", fontsize=12)
    axs[1].grid(linestyle='--', linewidth=0.25, color=[0.5,0.5,0.5])
    axs[2].axis('off')
    return fig,a1,a2,axs[2]

def plot_contour(S_array,Call_array,Put_array,label1,label2):
    
    fig, axs = plt.subplots(1,3,figsize=(13,7))
    cntr1 = axs[0].contourf(S_Matrix, tau_Matrix, Call_Matrix, levels = 20, cmap="RdBu_r")
    cntr2 = axs[1].contourf(S_Matrix, tau_Matrix, Put_Matrix, levels = 20, cmap="RdBu_r")
    fig.colorbar(cntr2, ax=axs[1])
    fig.colorbar(cntr1, ax=axs[0])
    axs[2].axis('off')
    x_label1 = '$\it{' + label1 + '}$'
    axs[0].set_xlabel(x_label1, fontname="Times New Roman", fontsize=12)
    y_label1 = '$\it{C}$($\it{' + label1+','+label2+ '}$)'
    axs[0].set_ylabel(y_label1, family="Times New Roman", fontsize=12)
    x_label2 = '$\it{' + label2 + '}$'
    axs[1].set_xlabel(x_label2, fontname="Times New Roman", fontsize=12)
    y_label1 = '$\it{P}$($\it{' + label1+','+label2+ '}$)'
    axs[1].set_ylabel(y_label1, family="Times New Roman", fontsize=12)    
    plt.show()
    return fig,axs[0],axs[1],axs[2]

blsprice_vec = np.vectorize(blsprice)
#%% option vs S

plt.close('all')

Call_array, Put_array = blsprice_vec(S_array, K0, tau0, r0, vol0, q0)

S_plot,S_ax1,S_ax2,a3 = plot_curve(S_array,Call_array,Put_array,'S')

axcolor = 'lightgoldenrodyellow'
ax_K = plt.axes([0.7, 0.7+0.1, 0.2, 0.03], facecolor=axcolor)
ax_r = plt.axes([ 0.7,0.55+0.1, 0.2, 0.03], facecolor=axcolor)
ax_vol = plt.axes([ 0.7,0.4+0.1, 0.2, 0.03], facecolor=axcolor)
ax_q = plt.axes([ 0.7, 0.25+0.1,0.2, 0.03], facecolor=axcolor)
ax_tau = plt.axes([ 0.7, 0.1+0.1,0.2, 0.03], facecolor=axcolor)

K_slider = Slider(ax_K, r'$\it{K}$', K_array[0], K_array[-1], valinit=K0, valstep=delta_K)
r_slider = Slider(ax_r, r'$\it{r}$', r_array[0], r_array[-1], valinit=r0, valstep=delta_r)
vol_slider = Slider(ax_vol, r'$\it{vol}$', vol_array[0], vol_array[-1], valinit=vol0, valstep=delta_vol)
q_slider = Slider(ax_q, r'$\it{q}$', q_array[0], q_array[-1], valinit=q0, valstep=delta_q)
tau_slider = Slider(ax_tau,  r'$\it{tau}$', tau_array[0], tau_array[-1], valinit=tau0, valstep=delta_tau)

def update(val):
    K = K_slider.val
    tau = tau_slider.val
    r = r_slider.val
    vol = vol_slider.val
    q = q_slider.val
    Call_array, Put_array = blsprice_vec(S_array, K, tau, r, vol, q)
    S_ax1.set_ydata(Call_array)
    S_ax2.set_ydata(Put_array)
    S_plot.canvas.draw_idle()

K_slider.on_changed(update)
tau_slider.on_changed(update)
r_slider.on_changed(update)
q_slider.on_changed(update)
vol_slider.on_changed(update)

resetax = plt.axes([0.75, 0.1, 0.1, 0.04])
button1 = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')

def reset1(event):
    K_slider.reset()
    tau_slider.reset()
    r_slider.reset()
    vol_slider.reset()
    q_slider.reset()
    
button1.on_clicked(reset1)
#%%
S_Matrix,tau_Matrix = np.meshgrid(S_array,tau_array)
Call_Matrix, Put_Matrix = blsprice_vec(S_Matrix, K0, tau_Matrix, r0, vol0, q0)
C_plot,C_ax1,C_ax2,C_ax3 = plot_contour(S_array,Call_Matrix,Put_Matrix,'S','Tau')


ax_K2 = plt.axes([0.7, 0.7+0.1, 0.2, 0.03], facecolor=axcolor)
ax_r2 = plt.axes([ 0.7,0.55+0.1, 0.2, 0.03], facecolor=axcolor)
ax_vol2 = plt.axes([ 0.7,0.4+0.1, 0.2, 0.03], facecolor=axcolor)
ax_q2 = plt.axes([ 0.7, 0.25+0.1,0.2, 0.03], facecolor=axcolor)

K_slider2 = Slider(ax_K2, r'$\it{K}$', K_array[0], K_array[-1], valinit=K0, valstep=delta_K)
r_slider2 = Slider(ax_r2, r'$\it{r}$', r_array[0], r_array[-1], valinit=r0, valstep=delta_r)
vol_slider2 = Slider(ax_vol2, r'$\it{vol}$', vol_array[0], vol_array[-1], valinit=vol0, valstep=delta_vol)
q_slider2 = Slider(ax_q2, r'$\it{q}$', q_array[0], q_array[-1], valinit=q0, valstep=delta_q)

def update(val):
    K = K_slider2.val
    r = r_slider2.val
    vol = vol_slider2.val
    q = q_slider2.val
    Call_Matrix, Put_Matrix = blsprice_vec(S_Matrix, K, tau_Matrix, r, vol, q)
    C_ax1.cla()
    C_ax2.cla()
    C_ax1.contourf(S_Matrix, tau_Matrix, Call_Matrix, levels = 20, cmap="RdBu_r")
    C_ax2.contourf(S_Matrix, tau_Matrix, Put_Matrix, levels = 20, cmap="RdBu_r")

K_slider2.on_changed(update)
r_slider2.on_changed(update)
q_slider2.on_changed(update)
vol_slider2.on_changed(update)

resetax = plt.axes([0.75, 0.2, 0.1, 0.04])
button2 = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')

def reset2(event):
    K_slider2.reset()
    r_slider2.reset()
    vol_slider2.reset()
    q_slider2.reset() 
button2.on_clicked(reset2)
