% B3_Ch11_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_6.m
clc; clear all; close all
 
N = 1e3;
NL = 20;
 
% Generate ARIMA(2,1,2)
randn('state',0) 

MdlARIMA = arima('AR',{0.6 -0.6},'MA',{-0.5 0.5},'D',1, ...
'Constant',0,'Variance',1);

yarima = simulate(MdlARIMA,N);
 
yarima_diff = diff(yarima);
 
% ACF and PACF of ARIMA
figure
subplot(3,1,1)
plot(yarima_diff)
ylabel("Simulated Time Series of ARIMA(2,1,2) after differencing")
subplot(3,1,2)
autocorr(yarima_diff,'NumLags',NL)
subplot(3,1,3)
parcorr(yarima_diff,'NumLags',NL)

