% B3_Ch11_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc

%% B3_Ch11_11_A.m
Mdl = varm


%% B3_Ch11_11_B.m
Mdl = varm(2,1)


%% B3_Ch11_11_C.m
% Generate VAR(1) model with known coefficients
c  = [0.05; -0.05];

AR = {[.5 0.1; 0.2 0.1]};

Covariance = eye(2);
 
Mdl = varm('Constant',c,'AR',AR,'Covariance',Covariance)

