% B3_Ch11_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_1.m
clc; clear all; close all
 
q = 1;
theta = -0.5;
mu = 0;
sigma = 1;
N = 100;
 
randn('state',0)
X1 = MAfun(mu, sigma, q, theta, N);
 
randn('state',0)
X2 = MAfun(mu, sigma, q, 1.5, N);
 
figure
plot(X1, '-b')
hold on
plot(X2, '-r')
legend('MA(1), \theta=-0.5, MAfun()',...
    'MA(1), \theta=1.5, MAfun()')
hold off
 
Mdl = arima('MA',{-0.5},'Constant',mu,'Variance',sigma);
randn('state',0)
Y = simulate(Mdl,N);
 
figure
plot(X1, '-b')
hold on
plot(Y, 'or')
legend('MA(1), \theta=-0.5, MAfun()', ...
    'MA(2), \theta=-0.5, arima()')
hold off
 
function X = MAfun(mu, sigma, q, theta, N)
% N has to be greater than q
X = [];
noise_vec = zeros(1,q+1);
 
for t=1:N
    
    noise_t = sigma*randn(1);
    
    noise_vec = [noise_t, noise_vec(1:end-1)];
    
    X(t) = mu + noise_vec*[1, theta]';
    
end
X = X';
end

