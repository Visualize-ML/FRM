% B3_Ch11_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch11_10_A.m
clc; clear all; close all
 
% Import MATLAB data
load Data_CreditDefaults
 
% Take regressor data
X = Data(:,1:4);         
XTbl = DataTable(:,1:4); 
RegressorNames = series(1:4); 

T = size(X,1); 
 
% Take regressand data        
y = Data(:,5);           
RegressandName = series{5};    
 
% Convert dates to serial date numbers:
dateNums = datenum([dates,ones(T,2)]);
 
% Plot regressors
figure;
plot(dateNums,X,'LineWidth',2)
ax = gca;
ax.XTick = dateNums(1:2:end);
datetick('x','yyyy','keepticks')
recessionplot;
xlabel('Year') 
ylabel('Regressor Level')
legend(RegressorNames,'Location','NW')
axis('tight')
grid('on')
 
% Plot regressand:
figure;
hold('on');
plot(dateNums,y,'k','LineWidth',2);
plot(dateNums,y-detrend(y),'m--')
hold('off');
ax = gca;
ax.XTick = dateNums(1:2:end);
datetick('x','yyyy','keepticks')
recessionplot;
xlabel('Year') 
ylabel('Regressand Level')
legend(RegressandName,'Linear Trend','Location','NW')
axis('tight');
grid('on');


%% B3_Ch11_10_B.m
% Direct estimation
XI = [ones(T,1),X];
Estimate = XI\y


%% B3_Ch11_10_C.m
% Use fitlm() function
XITbl = ...
[table(ones(T,1),'VariableNames',{'Const'}),XTbl];

Mdl = fitlm(DataTable)


