% B3_Ch11_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_4.m
clc; clear all; close all
 
N = 1e3;
NL = 20;
 
% Generate ARMA(2,2)
randn('state',0) 

MdlARMA = arima('AR',{0.6 -0.6},'MA',{-0.5 0.5}, ...
'Constant',0,'Variance',1);

yarma = simulate(MdlARMA,N);

