% B3_Ch11_12.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_12_A.m
close all; clear all; clc

% Import MATLAB data
load Data_USEconModel
 
% Plot
figure;
plot(DataTable.Time,DataTable.CPIAUCSL);
ylabel('Consumer Price Index');
xlabel('Time');
 
figure;
plot(DataTable.Time,DataTable.UNRATE);
ylabel('Unemployment Rate (%)');
xlabel('Time');


%% B3_Ch11_12_B.m
% Convert "price" to "return"
% i.e., growth rate of CPI
CPIgrwoth = price2ret(DataTable.CPIAUCSL);
 
% Plot
figure;
plot(DataTable.Time(2:end),CPIgrwoth);
ylabel('CPI Growth Rate (%)');
xlabel('Time');


%% B3_Ch11_12_C.m
% Take unemployment rate
UR = DataTable.UNRATE(2:end);
 
% Generate VAR(4) model
Mdl = varm(2,4);

EstMdl = estimate(Mdl,[CPIgrwoth UR]);
 
summarize(EstMdl)


%% B3_Ch11_12_D.m
EstMdl.AR{2}

