% B3_Ch11_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch11_2.m
clc; clear all; close all
 
p = 1;
phi = -0.5;
c = 0;
sigma = 1;
N = 100;
 
randn('state',0)
X1 = ARfun(c, sigma, p, phi, N);
 
randn('state',0)
X2 = ARfun(c, sigma, p, 0.8, N);
 
figure
plot(X1, '-b')
hold on
plot(X2, '-r')
legend('AR(1), \phi=-0.5, ARfun()',...
    'AR(1), \phi=0.5, ARfun()')
hold off
 
Mdl = arima('AR',{-0.5},'Constant',c,'Variance',sigma);
randn('state',0)
Y = simulate(Mdl,N);
 
figure
plot(X1, '-b')
hold on
plot(Y, 'or')
legend('AR(1), \phi=0.5, ARfun()', ...
    'AR(1), \phi=0.5, arima()')
hold off
 
function X = ARfun(c, sigma, p, phi, N)
% N has to be greater than p
X = [];
x_vec = zeros(1,p);
 
for t=1:N
    
    xt = sigma*randn(1);
      
    X(t) = c + xt + x_vec*phi';
    
    x_vec = [X(t), x_vec(1:end-1)];
    
end
X = X';
end

