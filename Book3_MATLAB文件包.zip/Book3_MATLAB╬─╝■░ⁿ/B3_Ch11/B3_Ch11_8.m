% B3_Ch11_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_8_A.m
% Generate GARCH/ARCH model with known coefficients
Mdl = garch('Constant',0.001,'GARCH',0.55,...
'ARCH',0.1,'Offset',0)


%% B3_Ch11_8_B.m
Mdl = garch('Constant',0.001,'GARCH',0.55,...
'ARCH',0.1,'Offset',0.6)


%% B3_Ch11_8_C.m
Mdl = garch('Constant',0.001,'GARCH',{0.15,0.25},...
    'ARCH',{0.1,0.01,0.2},'Offset',0.6) 


%% B3_Ch11_8_D.m
Mdl = garch('Constant',0.001,'GARCH',0.55,...
    'ARCH',0.1,'Offset',0, 'Distribution', 't')
