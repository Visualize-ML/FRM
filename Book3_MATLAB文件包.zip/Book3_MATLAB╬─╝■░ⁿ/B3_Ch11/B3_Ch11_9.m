% B3_Ch11_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_9_A.m
close all; clear all; clc

% Import MATLAB data
load Data_Danish;
Nreturn = DataTable.RN;
 
% Plot
figure;
plot(dates,Nreturn);
hold on;
plot([dates(1) dates(end)],[0 0],'r:'); 
hold off;
ylabel('Nominal return (%)');
xlabel('Year');

%% B3_Ch11_9_B.m
% Generate GARCH(1,1)
Mdl = garch('GARCHLags',1,'ARCHLags',1,'Offset',NaN);


%% B3_Ch11_9_C.m
% Estimate model coefficients
EstMdl = estimate(Mdl,Nreturn);

EstMdl

%% B3_Ch11_9_D.m
% Simulate volatility
Nobs = numel(Nreturn); 
Npath = 1e2;    
randn('state',0);
 
[Variance_sim,Return_sim] = ...
    simulate(EstMdl,Nobs,'NumPaths',Npath);
 
Variance_bar = mean(Variance_sim,2);
Variance_CI = quantile(Variance_sim,[0.025 0.975],2);
 
Return_bar = mean(Return_sim,2);
Return_CI = quantile(Return_sim,[0.025 0.975],2);
 
figure;
subplot(2,1,1);
h1 = plot(dates,Variance_sim,'Color',0.8*ones(1,3));
hold on;
h2 = plot(dates,Variance_bar,'k-','LineWidth',1);
h3 = plot(dates,Variance_CI,'r-','LineWidth',1);
hold off;
title('Simulated Variances \sigma^2');
ylabel('Variance');
xlabel('Year');
 
subplot(2,1,2);
h1 = plot(dates,Return_sim,'Color',0.8*ones(1,3));
hold on;
h2 = plot(dates,Return_bar,'k-','LineWidth',1);
h3 = plot(dates,Return_CI,'r-','LineWidth',1);
hold off;
title('Simulated Nominal Returns');
ylabel('Nominal return (%)');
xlabel('Year');
legend([h1(1) h2 h3(1)],...
    {'Simulated path' 'Mean' 'Confidence bounds'},...
'FontSize',7,'Location','NorthWest');


%% B3_Ch11_9_E.m
%% Forecast volatility
numPeriods = 10;
 
vF = forecast(EstMdl,numPeriods,'Y0',Nreturn);
v = infer(EstMdl,Nreturn);
 
figure;
plot(dates,v,'b-','LineWidth',2);
hold on;
plot(dates(end):dates(end) + 10,[v(end);vF],'r','LineWidth',2);
ylabel('Volatility Squared, \sigma^2');
xlabel('Year');
legend({'Estimated \sigma^2','Forecasted \sigma^2'},...
    'Location','Best');

