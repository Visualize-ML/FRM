% B3_Ch11_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_7_A.m
clc; clear all; close all
 
N = 1e3;
t = (1:N)';
 
randn('state',0) ;
 
% Trend Stationary
y1 = randn(N,1) + .3*t;
 
% Difference Stationary
Mdl2 = arima('D',1,'Constant',0.3,'Variance',1);
y2 = simulate(Mdl2,N,'Y0',0);
 
% AR(1)
Mdl3 = arima('AR',0.99,'Constant',0.3,'Variance',1);
y3 = simulate(Mdl3,N,'Y0',0);
 
% Plot
y = [y1 y2 y3];
figure;
subplot(2,1,1)
plot1 = plot(y(1:100,:));
plot1(1).LineWidth = 2;
plot1(3).LineStyle = '-';
plot1(3).LineWidth = 2;
 
title '{\bf First 100 Points of Each Series}';
legend('Trend Stationary','Difference Stationary','AR(1)',...
    'location','northwest');
 
subplot(2,1,2)
plot2 = plot(y);
plot2(1).LineWidth = 2;
plot2(3).LineStyle = '-';
plot2(3).LineWidth = 2;
 
title '{\bf Each Entire Series}';
legend('Trend Stationary','Difference Stationary','AR(1)',...
   'location','northwest');


%% B3_Ch11_7_B.m
% Augmented Dicky-Fuller test
hY1_adf = adftest(y1, 'model','ts','lags',2,'alpha',0.05)
 
hY2_adf = adftest(y2, 'model','ts', 'lags',2,'alpha',0.05)
 
hY3_adf = adftest(y3, 'model','ard', 'lags',2,'alpha',0.05)


%% B3_Ch11_7_C.m
% KPSS test
hY1_KPSS = kpsstest(y1, 'lags',2, 'trend',true,'alpha',0.05)
 
hY2_KPSS = kpsstest(y2, 'lags',2, 'trend',true)
 
hY3_KPSS = kpsstest(y3, 'lags',2, 'trend',true)


%% B3_Ch11_7_D.m
% Variance Ratio test
hY1_vr = vratiotest(y1)
 
hY2_vr = vratiotest(y2,'IID',true,'alpha',0.05)
 
hY3_vr = vratiotest(y3,'IID',true,'alpha',0.05)


