% B3_Ch11_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch11_3.m
clc; clear all; close all
 
N = 1e3;
NL = 20;
 
% Generate MA process
randn('state',0) 

MdlMA = arima('MA',{-0.5 0.5},'Constant',0,'Variance',1);
yma = simulate(MdlMA,N);
 
% ACF and PACF of MA
[acf_ma,lags_acfma,bounds_acfma] = ...
    autocorr(yma,'NumMA',2,'NumLags',NL);
 
[pacf_ma,lags_pacfma,bounds_pacfma] = ...
    parcorr(yma,'NumLags',NL);
 
figure
subplot(2,1,1)
autocorr(yma,'NumMA',2,'NumLags',NL)

subplot(2,1,2)
parcorr(yma,'NumLags',NL)
 
% Generate AR process
randn('state',0) 

MdlAR = arima('AR',{0.6 -0.6},'Constant',0,'Variance',1);
yar = simulate(MdlAR,N);
 
% ACF and PACF of AR
[acf_ar,lags_acfar,bounds_acfar] = ...
    autocorr(yar,'NumMA',2,'NumLags',NL);
 
[pacf_ar,lags_pacfar,bounds_acfar] = ...
    parcorr(yar,'NumAR',2,'NumLags',NL);
 
figure
subplot(2,1,1)
autocorr(yar,'NumLags',NL)

subplot(2,1,2)
parcorr(yar,'NumAR',2,'NumLags',NL);
