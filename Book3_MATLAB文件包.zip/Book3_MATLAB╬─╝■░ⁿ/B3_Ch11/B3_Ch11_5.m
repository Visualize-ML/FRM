% B3_Ch11_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch11_5.m
clc; clear all; close all
 
N = 1e3;
NL = 20;

% Generate ARIMA(2,1,2)
randn('state',0) 

MdlARIMA = arima('AR',{0.6 -0.6},'MA',{-0.5 0.5},'D',1, ...
'Constant',0,'Variance',1);

yarima = simulate(MdlARIMA,N);

