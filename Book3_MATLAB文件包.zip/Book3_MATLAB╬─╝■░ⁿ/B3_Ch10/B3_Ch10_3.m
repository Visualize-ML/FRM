% B3_Ch10_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_3_B.m
close all; clear all; clc;

% Input parameters
randn('state',0);
S0 = 45;
mu = 0.12;
sigma = 0.4;
T = 1;
Nt = 2^8;
N = 50;

Paths = zeros(N, 1+Nt);

randn('state',0)
paths = BrownianBridge_GBM(S0, mu, sigma, T, Nt, N);

% Plot
figure;
subplot(1,2,1)
for i=1:3
    plot(1:length(paths(i,:)), paths(i,:))
    hold on;
end
hold off;
xlim([1, Nt]);

subplot(1,2,2)
for i=1:N
    plot(1:length(paths(i,:)), paths(i,:))
    hold on;
end
hold off;
xlim([1, Nt]);


%% B3_Ch10_3_A.m
function Paths = BrownianBridge_GBM(S0, mu, sigma, T, Nt, N)
% check-point: ensure Nt is a power of 2
if round(log2(Nt)) ~= log2(Nt)
    fprintf('ERROR: Nt must be a power of 2\n');
    return
end

dt = T/Nt;
nudt = (mu-0.5*sigma^2)*dt;
Paths = zeros(N, Nt+1);

for k = 1:N
    
    W = BrownianBridge_Wiener(T,Nt);
    
    Increments = nudt + sigma*diff(W');
    LogPaths = cumsum([log(S0) , Increments]);
    Paths(k,:) = exp(LogPaths);
    
end

Paths(:,1) = S0;
end

% User function
function Paths = BrownianBridge_Wiener(T, Nt)
% check-point: ensure Nt is a power of 2
N_nodes = log2(Nt);
if round(N_nodes) ~= N_nodes
    fprintf('ERROR: Nt must be a power of 2\n');
    return
end
 
% create paths
Paths = zeros(Nt+1,1);
Paths(1) = 0;
Paths(Nt+1) = sqrt(T)*randn;
TJump = T;
IJump = Nt;
 
for k=1:N_nodes

    left = 1;
    i = IJump/2 + 1;
right = IJump + 1;

    for j=1:2^(k-1)
        a = 0.5*(Paths(left) + Paths(right));
        b = 0.5*sqrt(TJump);
        Paths(i) = a + b*randn;
        right = right + IJump;
        left = left + IJump;
        i = i + IJump;
end

    IJump = IJump/2;
TJump = TJump/2;

end
 
end
