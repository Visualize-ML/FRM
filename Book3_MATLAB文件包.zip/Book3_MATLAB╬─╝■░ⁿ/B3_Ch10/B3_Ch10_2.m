% B3_Ch10_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_2_B.m
close all; clear all; clc;
 
% Input parameters
randn('state',0);
N = 1e4;
T = 1;
Nt = 4;
Paths = zeros(N, 1+Nt);
 
for i=1:N
    Paths(i,:) = BrownianBridge_Wiener(T, Nt);
end


% Plot
figure
subplot(1,2,1)
plot(0:Nt, Paths(1:5e2, :),'color', [0,0.6,1]);
ylim([-4,4])
hold all
line([0,Nt],[0, 0],'color',[0,0.4,1],'linewidth',1);
for i=1:Nt
    line([i,i], [-4, 4], ...
        'color',[0,0.4,1],'LineWidth',0.5,...
        'LineStyle','--','color','r');
end
hold off
xticks([0 1 2 3 4])
xticklabels({'t_0','t_1','t_2','t_3','t_4'})
 
subplot(1,2,2)
% Set plot specifications
colors = {'r' 'b' 'g' 'm'};
lines = {'-','-.','--',':'};
 
% Generate kernel distribution objects and plot
for j=1:Nt
    pd = fitdist(Paths(:,j),'kernel');
    x = -4:0.01:4;
    y = pdf(pd,x);
    plot(x,y,'Color',colors{j},'LineStyle',lines{j},...
        'LineWidth', 1)
    hold on
end
legend('t_1','t_2','t_3','t_4')
hold off
 
% User function
function Paths = BrownianBridge_Wiener(T, Nt)
% check-point: ensure Nt is a power of 2
N_nodes = log2(Nt);
if round(N_nodes) ~= N_nodes
    fprintf('ERROR: Nt must be a power of 2\n');
    return
end
 
% create paths
Paths = zeros(Nt+1,1);
Paths(1) = 0;
Paths(Nt+1) = sqrt(T)*randn;
TJump = T;
IJump = Nt;
 
for k=1:N_nodes

    left = 1;
    i = IJump/2 + 1;
right = IJump + 1;

    for j=1:2^(k-1)
        a = 0.5*(Paths(left) + Paths(right));
        b = 0.5*sqrt(TJump);
        Paths(i) = a + b*randn;
        right = right + IJump;
        left = left + IJump;
        i = i + IJump;
end

    IJump = IJump/2;
TJump = TJump/2;

end
 
end


%% B3_Ch10_2_A.m
function SPaths=PricePathsFast(S0,mu,sigma,T,Nt,N)
dt = T/Nt;
nudt = (mu-0.5*sigma^2)*dt;
sidt = sigma*sqrt(dt);
 
Increments = nudt + sidt*randn(N, Nt);
LogPaths = cumsum([log(S0)*ones(N,1) , Increments] , 2);
 
SPaths = exp(LogPaths);
Spaths(:,1) = S0;
end


