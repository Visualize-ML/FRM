% B3_Ch10_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_7_B.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 3/12;
sigma = 0.4;
H = 30;
 
Nt = 90;
N = 5e4;
 
% Compute option price
randn('state',0)
[P_DO_Cond, CI_DO_Cond, N_OUT_Cond] =...
    DOPutMC_Cond(S0, K, r, T, sigma, H, Nt, N );
 
randn('state',0)
[P_DO, CI_DO, N_OUT] =...
    DOPut_MC(S0, K, r, T, sigma, H, Nt, N);
 
P_DO_Cond
P_DO
 
CI_DO_Cond
CI_DO
 
(CI_DO_Cond(2)-CI_DO_Cond(1))/(CI_DO(2)-CI_DO(1))


%% B3_Ch10_7_A.m
function [Pdo,CI,N_DO] = ...
    DOPutMC_Cond(S0,K,r,T,sigma,H,Nt,N)
 
dt = T/Nt;
[Call_vanilla, Put_vanilla] = blsprice(S0,K,r,T,sigma);
 
% Generate price paths and payoffs for down&in option
N_DO = 0;
P_DI = zeros(N,1);
Tsteps = zeros(N,1);
StockVals = zeros(N,1);
 
for i = 1:N
    % Generate price paths
Path = PricePaths(S0,r,sigma,T,Nt,1);

    % Find the 1st time-point when S lower than H
    t_DO = min(find( Path <= H ));
    
    if not(isempty(t_DO))
        N_DO = N_DO + 1;
        Tsteps(N_DO) = (t_DO-1) * dt;
        StockVals(N_DO) = Path(t_DO);
    end
    
end
 
if (N_DO > 0)
    
    [C_vanilla_DI, P_vanilla_DI] = ...
        blsprice(StockVals(1:N_DO),K,r,...
        T-Tsteps(1:N_DO),sigma);
    
    P_DI(1:N_DO) = exp(-r*Tsteps(1:N_DO)).* P_vanilla_DI;
    
end
 
[Pdo, aux, CI] = normfit(Put_vanilla - P_DI);
end


% User function
function SPaths=PricePaths(S0,mu,sigma,T,Nt,N)
SPaths = zeros(N, 1+Nt);
SPaths(:,1) = S0;
dt = T/Nt;
 
nudt = (mu-0.5*sigma^2)*dt;
sidt = sigma*sqrt(dt);
 
for i=1:N
    for j=1:Nt
        SPaths(i,j+1)=SPaths(i,j)*exp(nudt + sidt*randn);
    end
end
end

function [P,CI,N_OUT] = ...
    DOPut_MC(S0,K,r,T,sigma,H,Nt,N)

Payoff = zeros(N,1);
N_OUT = 0;
 
for i=1:N
    % Generate price paths 
    Path = PricePaths(S0,r,sigma,T,Nt,1);
    % Check cases of "down and out"
    check = any(Path <= H);
    
    if check == 0
        Payoff(i) = max(0, K - Path(Nt+1));
    else
        Payoff(i) = 0;
        N_OUT = N_OUT + 1;
    end
end
 
[P,aux,CI] = normfit( exp(-r*T) * Payoff);
end
