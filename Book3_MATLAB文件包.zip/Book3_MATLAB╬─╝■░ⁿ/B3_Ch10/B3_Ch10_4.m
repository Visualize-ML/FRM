% B3_Ch10_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_4_B.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 7/12;
sigma = 0.4;
 
Nt = 7;
N = 5e4;
 
% Compute option price
randn('state',0)
[P1, CI, Paths, PayoffDist] = ...
    AsianCall_MC(S0,K,r,T,sigma,Nt,N);

P1

CIB1 = (CI(2) - CI(1))/P1
 
% Plot
figure(1)
subplot(2,1,1)
histogram(PayoffDist, 100);
title('Frequency of Simulated Payoffs')
 
subplot(2,1,2)
plot(sort(PayoffDist));
title('Sorted Payoffs from Simulation')
 
figure(2)
hax = axes;
 
Savg = mean(Paths(:, 2:(Nt+1)), 2);
Savgavg = mean(Savg);
 
histogram(Savg, 'normalization', 'pdf')
hold all
line([K, K], get(hax, 'YLim'),...
    'color', [1 0.6 0], 'linewidth', 2);
line([Savgavg, Savgavg], get(hax, 'YLim'),...
    'color', [0 0 1], 'linewidth', 2);
 
h = legend('Distribution of $$\overline{S}$$',...
    'Expectation of $$\overline{S}$$, E($$\overline{S}$$)',...
    'Strike Price, K');
set(h,'Interpreter','latex')
 
hold off


%% B3_Ch10_4_A.m
function [P,CI,Paths,PayoffDist] = ...
    AsianCall_MC(S0,K,r,T,sigma,Nt,N)
Payoff = zeros(N,1);
Paths = zeros(N,Nt+1);
 
for i=1:N
Paths(i,:) = PricePaths(S0,r,sigma,T,Nt,1);

    Payoff(i) = max(0, mean(Paths(i, 2:(Nt+1))) - K);
end
 
PayoffDist = exp(-r*T) * Payoff;
 
[P,aux,CI] = normfit(PayoffDist);
 
end

% User function
function SPaths=PricePaths(S0,mu,sigma,T,Nt,N)
SPaths = zeros(N, 1+Nt);
SPaths(:,1) = S0;
dt = T/Nt;
 
nudt = (mu-0.5*sigma^2)*dt;
sidt = sigma*sqrt(dt);
 
for i=1:N
    for j=1:Nt
        SPaths(i,j+1)=SPaths(i,j)*exp(nudt + sidt*randn);
    end
end
end

