% B3_Ch10_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_6_C.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 3/12;
sigma = 0.4;
H = 45;
 
Nt = 90;
N = 5e4;
 
% Compute option price
randn('state',0)
% Down-and-out put option
[P_DO, CI_DO, N_OUT] =...
DOPut_MC(S0, K, r, T, sigma, H, Nt, N)

% Down-and-in put option
[P_DI, CI_DI, N_IN] =...
    DIPut_MC(S0, K, r, T, sigma, H, Nt, N)
 
% Sum of down-and-out and down-and-in put options
P_DO + P_DI
 
% Vanilla put option
[Call,Put] = blsprice(S0,K,r,T,sigma);
 
Put



%% B3_Ch10_6_A.m
function [P,CI,N_OUT] = ...
    DOPut_MC(S0,K,r,T,sigma,H,Nt,N)

Payoff = zeros(N,1);
N_OUT = 0;
 
for i=1:N
    % Generate price paths 
    Path = PricePaths(S0,r,sigma,T,Nt,1);
    % Check cases of "down and out"
    check = any(Path <= H);
    
    if check == 0
        Payoff(i) = max(0, K - Path(Nt+1));
    else
        Payoff(i) = 0;
        N_OUT = N_OUT + 1;
    end
end
 
[P,aux,CI] = normfit( exp(-r*T) * Payoff);
end


%% B3_Ch10_6_B.m
function [P,CI,N_IN] = ...
    DIPut_MC(S0,K,r,T,sigma,H,Nt,N)

Payoff = zeros(N,1);
N_IN = 0;
 
for i=1:N
    % Generate price paths
    Path = PricePaths(S0,r,sigma,T,Nt,1);
    % Check cases of "down and in"
    check = any(Path <= H);
    
    if check ~= 0
        Payoff(i) = max(0, K - Path(Nt+1));
        N_IN = N_IN + 1;
    else
        Payoff(i) = 0;        
    end
end
 
[P,aux,CI] = normfit( exp(-r*T) * Payoff);
end


% User function
function SPaths=PricePaths(S0,mu,sigma,T,Nt,N)
SPaths = zeros(N, 1+Nt);
SPaths(:,1) = S0;
dt = T/Nt;
 
nudt = (mu-0.5*sigma^2)*dt;
sidt = sigma*sqrt(dt);
 
for i=1:N
    for j=1:Nt
        SPaths(i,j+1)=SPaths(i,j)*exp(nudt + sidt*randn);
    end
end
end
