% B3_Ch10_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_8_B.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 3/12;
sigma = 0.4;
 
Nt = 5e4;
dS = 0.5;
 
% Compute call option delta
randn('state',0)
[CallDelta, CI, Delta_Dist] = ...
    CallDelta_MC(S0, K, r, T, sigma, dS, Nt);
 
RealCallDelta = blsdelta(S0, K, r, T, sigma);
 
% Increase "Nt"
randn('state',0)
CallDeltaSeries = [];
NtSeries = 10.^(2:8);
 
for i = 1:length(NtSeries)
    CallDeltaSeries(i) =...
        CallDelta_MC(S0, K, r, T, sigma, dS, NtSeries(i));
end
 
% Plot
figure
scatter(1:length(CallDeltaSeries), CallDeltaSeries);
hold on
plot(CallDeltaSeries, '-.b');
hold on
line([1, length(CallDeltaSeries)],...
    [RealCallDelta, RealCallDelta], 'color', 'red')
xlim([1, length(CallDeltaSeries)])
xticklabels({'10^2','10^3','10^4','10^5','10^6',...
'10^7','10^8'})


%% B3_Ch10_8_A.m
function [Delta, CI, Delta_Dist] = ...
    CallDelta_MC(S0,K,r,T,sigma,dS,Nt)
 
mu_t = (r - 0.5*sigma^2)*T;
sigma_t = sigma * sqrt(T);
 
% Path of S0-dS
Path1 = max(0, (S0-dS)*exp(mu_t+sigma_t*randn(Nt,1))-K);
% Path of S0+dS
Path2 = max(0, (S0+dS)*exp(mu_t+sigma_t*randn(Nt,1))-K);
 
% Central finite difference
Delta_Dist = exp(-r*T)*(Path2 - Path1)/(2*dS);
 
[Delta, dummy, CI] = normfit(Delta_Dist);
end

