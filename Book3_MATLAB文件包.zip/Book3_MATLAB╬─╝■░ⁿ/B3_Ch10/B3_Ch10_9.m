% B3_Ch10_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_9_B.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 3/12;
sigma = 0.4;
 
Nt = 5e4;
dS = 0.5;
 
% Compute call option delta
randn('state',0)
[CallDelta1, CI1, Delta_Dist1] = ...
    CallDelta_MC(S0, K, r, T, sigma, dS, Nt);
 
randn('state',0)
[CallDelta2, CI2, Delta_Dist2] = ...
    CallDeltaCRN_MC(S0, K, r, T, sigma, dS, Nt);
 
RealCallDelta = blsdelta(S0, K, r, T, sigma);
 
% Compare confidence interval
RealCallDelta

CallDelta1
 
CallDelta2
 
100*((CI2(2)-CI2(1))/(CI1(2)-CI1(1))-1)


%% B3_Ch10_9_A.m
function [Delta, CI, Delta_Dist] =...
    CallDeltaCRN_MC(S0,K,r,T,sigma,dS,Nt)
mu_t = (r - 0.5*sigma^2)*T;
sigma_t = sigma * sqrt(T);
 
%Generate common random number
RandomNumber = randn(Nt,1);
 
% Path of S0-dS
Path1 = max(0, (S0 - dS)*exp(mu_t+sigma_t*RandomNumber)-K);
% Path of S0+dS
Path2 = max(0, (S0 + dS)*exp(mu_t+sigma_t*RandomNumber)-K);
 
% Central finite difference
Delta_Dist = exp(-r*T)*(Path2 - Path1)/2/dS;
 
[Delta, dummy, CI] = normfit(Delta_Dist);
end


%% B3_Ch10_8_A.m
function [Delta, CI, Delta_Dist] = ...
    CallDelta_MC(S0,K,r,T,sigma,dS,Nt)
 
mu_t = (r - 0.5*sigma^2)*T;
sigma_t = sigma * sqrt(T);
 
% Path of S0-dS
Path1 = max(0, (S0-dS)*exp(mu_t+sigma_t*randn(Nt,1))-K);
% Path of S0+dS
Path2 = max(0, (S0+dS)*exp(mu_t+sigma_t*randn(Nt,1))-K);
 
% Central finite difference
Delta_Dist = exp(-r*T)*(Path2 - Path1)/(2*dS);
 
[Delta, dummy, CI] = normfit(Delta_Dist);
end
