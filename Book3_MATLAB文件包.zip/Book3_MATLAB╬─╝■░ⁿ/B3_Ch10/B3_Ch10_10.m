% B3_Ch10_10

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch10_10_C.m
close all; clear all; clc;
 
% correlated eps1 and eps2
rhoseries = [-1,-0.5,0,0.5,0.7,1];
Nt_tmp = 3e2;
 
esp1 = zeros(length(rhoseries),Nt_tmp);
esp2 = zeros(length(rhoseries),Nt_tmp);
 
for i = 1:length(rhoseries)
[eps1_tmp, eps2_tmp] = birand(rhoseries(i),Nt_tmp);

    esp1(i,:)=eps1_tmp;
esp2(i,:)=eps2_tmp;

end
 
% plot
figure
for i = 1:length(rhoseries)
    subplot(3,2,i)
    scatter(esp1(i,:),esp2(i,:),8)
    xlim([-5,5])
    ylim([-5,5])
    xlabel('\epsilon_1')
    ylabel('\epsilon_2')
    title(join(["Correlation Coefficient \rho_A_B = ", ...
        num2str(rhoseries(i))]))
end


%% B3_Ch10_10_A.m
function p = ...
    ExchangeOption(Sa0,Sb0,sigma_a,sigma_b,rho,T,r)
% calculate sigma_ab
sigma_ab = ...
    sqrt(sigma_b^2 + sigma_a^2 - 2*rho*sigma_b*sigma_a);
% calculate d1
d1 = (log(Sa0/Sb0) + 0.5*T*sigma_ab^2)/(sigma_ab*sqrt(T));
% calculate d2
d2 = d1 - sigma_ab*sqrt(T);
 
% calculate price
p = Sa0*normcdf(d1) - Sb0*normcdf(d2);
 
end


%% B3_Ch10_10_B.m
function [eps1, eps2] = birand(rho, Nt)
 
eps1 = randn(1,Nt);
 
eps2 = rho*eps1 + sqrt(1-rho^2)*randn(1,Nt);
 
end



