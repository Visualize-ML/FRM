% B3_Ch10_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_5_B.m
close all; clear all; clc;
 
% Input parameters
S0 = 55;
K = 50;
r = 0.12;
T = 7/12;
sigma = 0.4;
 
Nt = 7;
N = 5e4;
Ncv = 5e3;
 
% Compute option price
randn('state',0)
[P2, CI, PayoffDist] = AsianCallCV_MC(S0,K,r,T,sigma,Nt,N,Ncv);

P2

CIB2 = (CI(2) - CI(1))/P2
 
% Plot
figure
subplot(2,1,1)
histogram(PayoffDist, 100);
title('Frequency of Simulated Payoffs')
 
subplot(2,1,2)
plot(sort(PayoffDist));
title('Sorted Payoffs from Simulation')


%% B3_Ch10_5_A.m
function [P,CI,PayoffDist] =...
    AsianCallCV_MC(S0,K,r,T,sigma,Nt,N,Ncv)
% Set control parameter
% Control variable "Y": sum of stock prices
PathsCV = PricePaths(S0,r,sigma,T,Nt,Ncv);
Y = sum(PathsCV,2);
 
% Compute parameter "c"
PP = mean(PathsCV(:,2:(Nt+1)) , 2);
PayoffCV = exp(-r*T) * max(0, PP - K);
MatCov = cov(Y, PayoffCV);
 
c = - MatCov(1,2) / var(Y);
 
dt = T / Nt;
Yavg = S0 * (1 - exp((Nt + 1)*r*dt)) / (1 - exp(r*dt));
 
% Compute result using control variate
PayoffDist = zeros(N,1);
 
for i=1:N
   Paths = PricePaths(S0,r,sigma,T,Nt,1);
   Payoff = exp(-r*T) * max(0, mean(Paths(2:(Nt+1))) - K);
   PayoffDist(i) = Payoff + c * (sum(Paths) - Yavg);
end
 
[P,aux,CI] = normfit(PayoffDist);
 
end


% User function
function SPaths=PricePaths(S0,mu,sigma,T,Nt,N)
SPaths = zeros(N, 1+Nt);
SPaths(:,1) = S0;
dt = T/Nt;
 
nudt = (mu-0.5*sigma^2)*dt;
sidt = sigma*sqrt(dt);
 
for i=1:N
    for j=1:Nt
        SPaths(i,j+1)=SPaths(i,j)*exp(nudt + sidt*randn);
    end
end
end
