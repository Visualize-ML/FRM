% B3_Ch10_11.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch10_11_B.m
close all; clear all; clc;
 
% Input parameters
Sa0 = 50;
Sb0 = 60;
sigma_a = 0.3;
sigma_b = 0.4;
 
rho = 0.7;
T = 5/12;
r = 0.12;
 
Nt = 1e3;
 
% Analytical solution
P_real = ExchangeOption(Sa0, Sb0, sigma_a, sigma_b, rho, T, r);
 
P_real

% Run simulation
randn('state',0)

[P_MC, ci, Sa, Sb] = ...
    ExchangeOption_MC(Sa0, Sb0, sigma_a, sigma_b,...
    rho, T, r,Nt);
 
P_MC
 
100*(P_MC/P_real-1)

% Plot
figure
scatter(Sa,Sb);
xlabel('S_A_,_T')
ylabel('S_B_,_T')
 
figure
histogram(Sa, 'normalization', 'pdf' );
hold on
histogram(Sb, 'normalization', 'pdf' );
hold off
legend('Asset A Price, S_A_,_T',...
'Asset B Price, S_B_,_T')


%% B3_Ch10_11_A.m
function [p,ci] = ...
    ExchangeOption_MC(Sa0,Sb0,sigma_a,sigma_b,rho,T,r,Nt)
 
[eps1, eps2] = birand(rho,Nt);
 
Sa_t = Sa0*exp((r - 0.5*sigma_a^2)*T + sigma_a*sqrt(T)*eps1);

Sb_t = Sb0*exp((r - 0.5*sigma_b^2)*T + sigma_b*sqrt(T)*eps2);
 
DiscPayoff = exp(-r*T)*max(Sa_t-Sb_t, 0);

[p,s,ci] = normfit(DiscPayoff); 
end
