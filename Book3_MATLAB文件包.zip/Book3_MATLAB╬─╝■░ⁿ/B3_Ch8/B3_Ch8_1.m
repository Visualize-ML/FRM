% B3_Ch8_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch8_1.m
close all; clear all; clc
 
% Define example function
% f(x) = x^2+x*sin(x)
syms f(x)
f(x) = x^2+x*sin(x)
% Obtain 1st-order differential function
df = diff(f,x)
 
% Define limitation ratio
syms g(x,h)
g(x,h)=(f(x+h)-f(x))/h;
 
% Fix x to be 3 and let h vary from 1e-4 to 10
h_val=[0.0001, 0.001, 0.01, 0.1, 1, 5, 10];
x_val=[6, 6, 6, 6, 6, 6, 6];
g_val=double(g(x_val, h_val));
 
% Plot
figure
% Plot f(x) and its differential function df(x)
x_val_fig = 1:0.1:11;
subplot(2,1,1)
plot(x_val_fig, f(x_val_fig), 'g', 'linewidth', 1.5)
xlabel('x')
set(gcf, 'color', 'w')
 
hold on
plot(x_val_fig, df(x_val_fig), 'b', 'linewidth', 1.5)
hold on
line([6,6], [0, f(11)], 'color', 'red', 'linestyle', '--')
hold on
line([min(x_val_fig), max(x_val_fig)], [f(6), f(6)], ...
    'color', 'green', 'linestyle', '--')
hold on
line([min(x_val_fig), max(x_val_fig)], [df(6), df(6)], ...
    'color', 'blue', 'linestyle', '--')
legend('f(x)', 'df(x)', 'x=6', 'y=f(6)', 'y=df(6)', ...
    'Location', 'best')
 
subplot(2,1,2)
semilogx(h_val, g_val, ...
    '--ro', 'markersize', 6, 'linewidth', 1.5)
hold on
line([min(h_val), max(h_val)], [df(6), df(6)], ...
    'color', 'blue', 'linestyle', '--')
legend('g(6, h)', 'y=df(6)', 'Location', 'best')
xlabel('h')



