% B3_Ch8_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B3_Ch8_5_B.m
close all; clear all; clc
 
% Initialize variable values
S0=60;
Smax=120;
TT=24/12;
K=50;
r=0.3;
sigma=0.3;
 
% Configure grid steps
dS=0.5;
dt=1/1008;
vec_T=TT:(-TT/50):0;
 
tol=1e-3;
omega=1.5;
 
val_TT=zeros(round(Smax/dS)+1, length(vec_T));
val_bls=zeros(round(Smax/dS)+1, length(vec_T));
 
% Call MATLAB and user-defined functions
i=1;
for T=vec_T
    
    for dS = dS
        for dt = dt
            
            % CN method solution: American put
            [P_CN, P_vetS, P_val0]=...
                CN_AmPutCK(S0,K,r,T,sigma,Smax,dS,dt,omega,tol);
            val_TT(:, i)=P_val0;
            
            % BLS matlab solution: put and call
            [C_ref,P_ref]=blsprice(P_vetS, K, r, T, sigma);
            val_bls(:, i)=P_ref;
            
        end
    end
    
    i=i+1;
    
end
 
% Resample vec_T for sparse plotting
vec_T_down = downsample(vec_T, 5);
P_vetS_down = downsample(P_vetS, 3);
 
val_TT_down = downsample(val_TT, 3);
val_TT_down = downsample(val_TT_down', 5);
val_TT_down=val_TT_down';
 
val_bls_down = downsample(val_bls, 3);
val_bls_down = downsample(val_bls_down', 5);
val_bls_down = val_bls_down';
 
i=1;
 
for vec_t = [vec_T_down(2), vec_T_down(10)]     
    
    figure(i)
    [X,Y]=meshgrid(vec_T_down, P_vetS_down); 
    
    subplot(2,1,1)
    mesh(X,Y,val_TT_down, 'FaceAlpha', 0.0)
    hold on
    mesh(X,Y,val_bls_down, 'FaceAlpha', 0.0)
    xlabel('Time to Maturity')
    ylabel('Underlying Asset Price')
    zlabel('Option Value')
    
    xlim([0, TT])
    ylim([0, Smax])
    zlim([0, K])
 
    % Plot cross-section at T-t
    patch([vec_t,vec_t,vec_t,vec_t],...
        [0,Smax,Smax,0],[0,0,K,K],'w', 'FaceAlpha', 0.0)
    Xp=vec_t*ones(length(P_vetS_down), 1);
    Yp=P_vetS_down;
    Zp=val_TT_down(:, vec_T_down==vec_t);
    plot3(Xp, Yp, Zp, 'r', 'linewidth', 2)
    
    Xbls=vec_t*ones(length(P_vetS_down), 1);
    Ybls=P_vetS_down;
    Zbls=val_bls_down(:, vec_T_down==vec_t);
    plot3(Xbls, Ybls, Zbls, 'b', 'linewidth', 2)       
    grid off
    view(129, 12)
    
    subplot(2,1,2)
    plot(P_vetS_down, Zp, 'r', 'linewidth', 2)
    hold on
    plot(P_vetS_down, Zbls, 'b', 'linewidth', 2)
    legend('American Put','European Put')
    xlabel(['Time to Maturity: ', ...
        num2str(round(vec_t, 2)),' Year'])
    ylabel('Underlying Asset Price')
    xlim([0, Smax])
    ylim([0, K])
    
    set(gcf,'units', 'centimeters','position',[5,5,9,12],...
        'color', 'w')
    
    i=i+1;
 
end


%% B3_Ch8_5_A.m
function [price, vetS, val0]= ...
    CN_AmPutCK(S0,K,r,T,sigma,Smax,dS,dt,omega,tol)

% Configure grid and increments
M = round(Smax/dS);
dS = Smax/M;
N = round(T/dt);
dt = T/N;

% vectors for Gauss-Seidel update
oldval = zeros(M-1,1);
newval = zeros(M-1,1);

vetS = linspace(0,Smax,M+1)';
veti = 0:M;
vetj = 0:N;

% Configure boundary conditions
payoff = max(K-vetS(2:M),0);
newval = payoff;

pastval = payoff;
boundval = K * ones(1, N+1);

% Configure coefficients
% alpha:a; beta:b; gamma:c
a = 0.25*dt*( sigma^2*(veti.^2) - r*veti );
b = -dt*0.5*( sigma^2*(veti.^2) + r );
c = 0.25*dt*( sigma^2*(veti.^2) + r*veti );
M2 = diag(a(3:M),-1) + diag(1+b(2:M)) + diag(c(2:M-1),1);

% Implement Gauss-Seidel with SOR method
aux = zeros(M-1,1);

for j=N:-1:1
    aux(1) = a(2) * (boundval(1,j) + boundval(1,j+1));
    
    % set up right hand side and initialize
    rhs = M2*pastval(:) + aux;
    oldval = pastval;
    error = realmax;
    
    while tol < error
        newval(1) = max ( payoff(1), ...
            oldval(1) + omega/(1-b(2)) * (...
            rhs(1) - (1-b(2))*oldval(1) + c(2)*oldval(2)));
        
        for k=2:M-2
            newval(k) = max ( payoff(k), ...
                oldval(k) + omega/(1-b(k+1)) * (...
                rhs(k) + a(k+1)*newval(k-1) - ...
                (1-b(k+1))*oldval(k) + c(k+1)*oldval(k+1)));
        end
        
        newval(M-1) = max( payoff(M-1),...
            oldval(M-1) + omega/(1-b(M)) * (...
            rhs(M-1) + a(M)*newval(M-2) - ...
            (1-b(M))*oldval(M-1)));
        error = norm(newval - oldval);
        oldval = newval;
    end
    
    pastval = newval;
end

newval = [boundval(1) ; newval ; 0];
% return price, possibly by linear interpolation outside the grid
price = interp1(vetS, newval, S0);
val0=newval;
end


