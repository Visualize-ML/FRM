% B3_Ch8_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch8_3_C.m
close all; clear all; clc
 
% Initialize variable values
S0=60;
Smax=120;
T=5/12;
K=50;
r=0.2;
sigma=0.3;
 
% Configure grid steps
vec_dS=[3, 1.5, 0.5];
vec_dt=[1/252, 1/504, 1/1008];
 
% Call MATLAB and user-defined functions
i=1;
for dS = vec_dS
    for dt = vec_dt
        
        % Implicit method solution: put
        [P_impl, P_vetS, P_val0]=...
            Impl_EuPut(S0, K, r, T, sigma, Smax, dS, dt);
        
        % Implicit method solution: call
        [C_impl, C_vetS, C_val0]=...
            Impl_EuCal(S0, K, r, T, sigma, Smax, dS, dt);
        
        % BLS matlab solution: put and call
        [C_ref,P_ref]=blsprice(C_vetS, K, r, T, sigma);
        
        % Calculate mean absolute error
        P_mae = mean(abs(P_val0-P_ref));
        C_mae = mean(abs(C_val0-C_ref));
        
        % Plotting
        figure(1)
        subplot(3,3,i)
        plot(P_vetS, P_ref, 'r', 'LineWidth', 1.5)
        hold on
        plot(P_vetS, P_val0, 'b', 'LineWidth', 0.25)
        set(gcf, 'color', 'w')
        
        if P_mae < 1
            xlabel(['MAE=',num2str(round(P_mae, 6))],...
                'FontSize', 8)
        end
        
        figure(2)
        subplot(3,3,i)
        plot(C_vetS, C_ref, 'r', 'LineWidth', 1.5)
        hold on
        plot(C_vetS, C_val0, 'b', 'LineWidth', 0.25)
        set(gcf, 'color', 'w')
        
        if C_mae < 1
            xlabel(['MAE=',num2str(round(C_mae, 6))], ...
                'FontSize', 8)
        end
        
        i=i+1;
        
    end
end
 

%% B3_Ch8_3_A.m
function [price, vetS, val0] =...
    Impl_EuPut(S0,K,r,T,sigma,Smax,dS,dt)

% Configure grid and increments
M = round(Smax/dS);
dS = Smax/M;
N = round(T/dt);
dt = T/N;

val = zeros(M+1,N+1);
vetS = linspace(0,Smax,M+1)';
veti = 0:M;
vetj = 0:N;

% Configure boundary conditions
% boundary: t=T
val(:,N+1) = max(K-vetS,0);
% boundary: S=0
val(1,:) = K*exp(-r*dt*(N-vetj));
% boudnary: S=Smax
val(M+1,:) = 0;

% Configure coefficients
% alpha:a; beta:b; gamma:c
a = 0.5*(r*dt*veti-sigma^2*dt*(veti.^2));
b = 1+sigma^2*dt*(veti.^2)+r*dt;
c = -0.5*(r*dt*veti+sigma^2*dt*(veti.^2));

%coeff: matrix A
coeff = diag(a(3:M),-1) + diag(b(2:M)) + diag(c(2:M-1),1);
[L,U] = lu(coeff);

% Solve Black-Scholes backward in time
% aux: vector g_j
aux = zeros(M-1,1);

for j=N:-1:1
    aux(1) = - a(2) * val(1,j);
    aux(M-1) = -c(M)*val(M+1,j);
    
    val(2:M,j) = U \ (L \ (val(2:M,j+1) + aux));
end

% Return price
% Apply linear interpolation value off the grid
price = interp1(vetS, val(:,1), S0);
val0=val(:,1);
end


%% B3_Ch8_3_B.m
function [price, vetS, val0] =...
    Impl_EuCal(S0,K,r,T,sigma,Smax,dS,dt)

% Configure grid and increments
M = round(Smax/dS);
dS = Smax/M;
N = round(T/dt);
dt = T/N;

val = zeros(M+1,N+1);
vetS = linspace(0,Smax,M+1)';
veti = 0:M;
vetj = 0:N;

% Configure boundary conditions
% boundary: t=T
val(:,N+1) = max(vetS-K,0);
% boundary: S=0
val(1,:) = 0;
% boudnary: S=Smax
val(M+1,:) = Smax-K*exp(-r*dt*(N-vetj));

% Configure coefficients
% alpha:a; beta:b; gamma:c
a = 0.5*(r*dt*veti-sigma^2*dt*(veti.^2));
b = 1+sigma^2*dt*(veti.^2)+r*dt;
c = -0.5*(r*dt*veti+sigma^2*dt*(veti.^2));

%coeff: matrix A
coeff = diag(a(3:M),-1) + diag(b(2:M)) + diag(c(2:M-1),1);
[L,U] = lu(coeff);

% Solve Black-Scholes backward in time
% aux: vector g_j
aux = zeros(M-1,1);

for j=N:-1:1
    aux(1) = - a(2) * val(1,j);
    aux(M-1) = -c(M) * val(M+1,j);
    
    val(2:M,j) = U \ (L \ (val(2:M,j+1) + aux));
end

% Return price
% Apply linear interpolation value off the grid
price = interp1(vetS, val(:,1), S0);
val0=val(:,1);
end

