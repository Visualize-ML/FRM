% B3_Ch8_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch8_2_C.m
clear all; close all; clc
 
% Initialize variable values
S0=60;
Smax=120;
T=5/12;
K=50;
r=0.2;
sigma=0.3;
 
% Configure grid steps
vec_dS=[3, 1.5, 0.5];
vec_dt=[1/252, 1/504, 1/1008];
 
% Call MATLAB and user-defined functions
i=1;
for dS = vec_dS
    for dt = vec_dt
        
        % Explicit method solution: put
        [P_expl, P_vetS, P_val0]=...
            Expl_EuPut(S0, K, r, T, sigma, Smax, dS, dt);
        
        % Explicit method solution: call
        [C_expl, C_vetS, C_val0]=...
            Expl_EuCal(S0, K, r, T, sigma, Smax, dS, dt);
        
        % BLS matlab solution: put and call
        [C_ref,P_ref]=blsprice(C_vetS, K, r, T, sigma);
        
        % Calculate mean absolute error
        P_mae = mean(abs(P_val0-P_ref));
        C_mae = mean(abs(C_val0-C_ref));
        
        % Plotting
        figure(1)
        subplot(3,3,i)
        plot(P_vetS, P_ref, 'r', 'LineWidth', 1)
        hold on
        plot(P_vetS, P_val0, 'b', 'LineWidth', 0.25)
        set(gcf, 'color', 'w')
        
        if P_mae < 1
            xlabel(['MAE=',num2str(round(P_mae, 6))],...
                'FontSize', 8)
        end
        
        figure(2)
        subplot(3,3,i)
        plot(C_vetS, C_ref, 'r', 'LineWidth', 1)
        hold on
        plot(C_vetS, C_val0, 'b', 'LineWidth', 0.25)
        set(gcf, 'color', 'w')
        
        if C_mae < 1
            xlabel(['MAE=',num2str(round(C_mae, 6))], ...
                'FontSize', 8)
        end
        
        i=i+1;
        
    end
end


%% B3_Ch8_2_A.m
function [price, vetS, val0] = ...
    Expl_EuCal(S0,K,r,T,sigma,Smax,dS,dt)

% Configure grid and increments
M = round(Smax/dS);
dS = Smax/M;
N = round(T/dt);
dt = T/N;

val = zeros(M+1,N+1);
vetS = linspace(0,Smax,M+1)';
veti = 0:M;
vetj = 0:N;

% Configure boundary conditions
% boundary: t=T
val(:,N+1) = max(vetS-K,0);
% boundary: S=0
val(1,:) = 0;
% boudnary: S=Smax
val(M+1,:) = Smax-K*exp(-r*dt*(N-vetj));

% Configure coefficients
% alpha:a; beta:b; gamma:c
a = 0.5*dt*(sigma^2*veti - r).*veti;
b = 1- dt*(sigma^2*veti.^2 + r);
c = 0.5*dt*(sigma^2*veti + r).*veti;

% Solve Black-Scholes backward in time
for j=N:-1:1
    for i=2:M
        val(i,j) = a(i)*val(i-1,j+1) + b(i)*val(i,j+1)+ ...
            c(i)*val(i+1,j+1);
    end
end

% Return price
% Apply linear interpolation value off the grid
price = interp1(vetS, val(:,1), S0);
val0=val(:,1);
end


%% B3_Ch8_2_B.m
function [price, vetS, val0]= ...
    Expl_EuPut(S0,K,r,T,sigma,Smax,dS,dt)

% Configure grid and increments
M = round(Smax/dS);
dS = Smax/M;
N = round(T/dt);
dt = T/N;

val = zeros(M+1,N+1);
vetS = linspace(0,Smax,M+1)';
veti = 0:M;
vetj = 0:N;

% Configure boundary conditions
% boundary: t=T
val(:,N+1) = max(K-vetS,0);
% boundary: S=0
val(1,:) = K*exp(-r*dt*(N-vetj));
% boudnary: S=Smax
val(M+1,:) = 0;

% Configure coefficients
% alpha:a; beta:b; gamma:c
a = 0.5*dt*(sigma^2*veti - r).*veti;
b = 1- dt*(sigma^2*veti.^2 + r);
c = 0.5*dt*(sigma^2*veti + r).*veti;

% Solve Black-Scholes backward in time
for j=N:-1:1
    for i=2:M
        val(i,j) = a(i)*val(i-1,j+1) + b(i)*val(i,j+1)+ ...
            c(i)*val(i+1,j+1);
    end
end

% Return price
% Apply linear interpolation value off the grid
price = interp1(vetS, val(:,1), S0);
val0=val(:,1);

end


