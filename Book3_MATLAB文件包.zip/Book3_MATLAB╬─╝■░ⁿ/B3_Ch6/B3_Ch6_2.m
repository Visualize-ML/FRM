% B3_Ch6_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch6_2_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC, 
% Apple Inc. (AAPL) and US Unemployment Rate
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
filename_usur = ...
    'SeriesReport-20180716183946_76b2e9_US_UR.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_usur = readtable(filename_usur, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f');
 
%% Integrate to one table
data_xy = innerjoin(table_sp500(:,{'Date','AdjClose'}), ...
    table_aapl(:, {'Date','AdjClose'}), 'keys', 'Date');
data_xy = innerjoin(data_xy, table_usur, 'keys', 'Date');
data_xy.Properties.VariableNames = ...
    {'Date','SP500','AAPL', 'UR'};
 
% Historical US Unemployment and Apple Inc. Stock
figure(1)
yyaxis left
plot(data_xy.Date, data_xy.UR)
xlabel('Date'); ylabel('US Unemployment Rate, %');
 
yyaxis right
plot(data_xy.Date, data_xy.AAPL); 
ylabel('Apple Inc. Stock, USD');
hold on; set(gcf,'color','w');
 
%% Extract data from specific table field within 
% specific time horizon
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
data_xy = data_xy(data_xy.Date >= startdate & ...
    data_xy.Date <= enddate, :);
 
%% Fit into regressional model
% Solve matrix-form equation
x = data_xy(:,{'SP500', 'UR'});
y = data_xy.AAPL;
X = [ones(length(y), 1), table2array(x)];
 
B = X\y;
 

%% B3_Ch6_2_B.m
% Using the function "fitlm"
% With intercept b0
mdl = fitlm(data_xy, 'AAPL ~ SP500 + UR');
 
mdl_UR = fitlm(data_xy, 'AAPL ~ UR');
 
mdl_SP500 = fitlm(data_xy, 'AAPL ~ SP500');
 
mdl_SP500_UR = fitlm(data_xy, 'SP500 ~ UR');


%% B3_Ch6_2_C.m
%% Plotting
figure(2)
subplot(2,2,1)
plot(data_xy.UR, data_xy.SP500, 'bx', ...
    data_xy.UR, mdl_SP500_UR.Fitted, 'r-') 
legend('Raw', 'Fitted', 'Location', 'best')
xlabel('US Unemployment Rate, %')
ylabel('S&P 500 Index, USD')
title('')
 
subplot(2,2,2)
plot(data_xy.SP500, data_xy.AAPL, 'bx', ...
    data_xy.SP500, mdl_SP500.Fitted, 'r-')
legend('Raw', 'Fitted', 'Location', 'best')
xlabel('S&P 500 Index, USD')
ylabel('Apple Inc. Stock, USD')
title('')
 
subplot(2,2,3)
plot(data_xy.UR, data_xy.AAPL, 'bx', ...
    data_xy.UR, mdl_UR.Fitted, 'r-')
legend('Raw', 'Fitted', 'Location', 'best')
xlabel('US Unemployment Rate, %')
ylabel('Apple Inc. Stock, USD')
title('')
 
subplot(2,2,4)
plot(mdl.Fitted, data_xy.AAPL, 'rx')
xlabel('Fitted Apple Inc. Stock, USD')
ylabel('Apple Inc. Stock, USD')
title('')
set(gcf,'color','w');
