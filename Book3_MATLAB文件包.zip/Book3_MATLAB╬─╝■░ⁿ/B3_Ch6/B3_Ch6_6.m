% B3_Ch6_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch6_6_A.m
clear all; close all; clc
 
% Read in historicaldata of S&P500 index
filename = ...
    'SP500_2001_2005.csv';
table_sp500 = readtable(filename, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false);
numrow = size(table_sp500,1);
 
table_model = table_sp500(1:numrow-10,:);
table_test = table_sp500(numrow-9:numrow,:);
 
% Take data for regression
Y = table_model.Direction_Digit;
X = [table_model.Lag1, table_model.Lag2, table_model.Lag3];
Xt = [table_test.Lag1, table_test.Lag2, table_test.Lag3];


%% B3_Ch6_6_B.m
% Logistic regression using regress()
Y1 = 0.5*Y+0.25;
Y1 = log(Y1./(1-Y1));
X1 = [ones(size(X, 1), 1), X];
 
b1 = regress(Y1, X1);
Ypred1 = [ones(size(Xt,1), 1), Xt]*b1;
Ypred1 = exp(Ypred1)./(1+exp(Ypred1)) > 0.5;
 

%% B3_Ch6_6_C.m
% Logistic regression using glmfit()
[b2,dev,stats] = glmfit(X,Y, 'binomial', 'link', 'logit');

Ypred2 = glmval(b2, Xt,'logit');
Ypred2 = Ypred2>0.5;
 

%% B3_Ch6_6_D.m
% Logistic regression using fitglm()
mdl_a = fitglm(X, Y, 'Distribution', 'binomial');
 
mdl_b = fitglm(table_model,...
    'Direction_Digit ~ Lag1+Lag2+Lag3',...
    'Distribution', 'binomial');
 
Ypred3 = predict(mdl_a, Xt);
Ypred3 = Ypred3>0.5;
 

%% B3_Ch6_6_E.m
% Display coefficients
[b1,b2,mdl_a.Coefficients.Estimate]


%% B3_Ch6_6_F.m
% Display forecast
[Ypred1, Ypred2, Ypred3]

