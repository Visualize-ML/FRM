% B3_Ch6_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%


%% B3_Ch6_7_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC, 
% Apple Inc. (AAPL) and US Unemployment Rate
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
filename_usur = ...
    'SeriesReport-20180716183946_76b2e9_US_UR.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_usur = readtable(filename_usur, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f');
 
%% Integrate to one table
data_xy = innerjoin(table_sp500(:,{'Date','AdjClose'}), ...
    table_aapl(:, {'Date','AdjClose'}), 'keys', 'Date');
data_xy = innerjoin(data_xy, table_usur, 'keys', 'Date');
data_xy.Properties.VariableNames = ...
    {'Date','SP500','AAPL', 'UR'};
 
% Calculatate return of SP500 and APPL
data_xy.SP500_Return = ...
    [NaN; diff(data_xy.SP500)]./data_xy.SP500;
 
data_xy.AAPL_Return = ...
    [NaN; diff(data_xy.AAPL)]./data_xy.AAPL;
 
%% Extract data from specific table field within 
% specific time horizon
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
data_xy = data_xy(data_xy.Date >= startdate & ...
    data_xy.Date <= enddate, :);
 
% Take matrix form
x=data_xy{:,5};
X = [ones(length(x), 1), x];
 
y=data_xy{:,6};
 
%% Fit into regressional model
% OLS with intercept
[b_ols, stats_ols] = regress(y, X);
 
% RLS
[b_rls, stats_rls] = robustfit(x, y, 'bisquare',4.685,'on');
 
%% Plot
figure
scatter(x, y, 'fill'); 
hold on
plot(x,b_ols(1)+b_ols(2)*x,'r');
plot(x,b_rls(1)+b_rls(2)*x,'g');
xlabel('S&P Index Return')
ylabel('Apple Inc. Stock Return')
legend('Data','Ordinary Least Squares','Robust Regression', 'location', 'Best')
set(gcf,'color','w');


%% B3_Ch6_7_B.m
% GLM with intercept
[b_mle, dev_mle, stats_mle] = glmfit(x, y);


%% B3_Ch6_7_C.m
% Stepwise regression
mdl_stepwise = stepwiselm(data_xy(:, 2:6));


%% B3_Ch6_7_D.m
mdl_stepwise = stepwiselm(data_xy{:, 2:5}, data_xy{:, 6});


%% B3_Ch6_7_F.m
mdl_stepwise = stepwiselm(data_xy(:, 2:6), ...
    'AAPL_Return ~ 1 + SP500_Return + SP500 + AAPL + UR')


%% B3_Ch6_7_G.m
mdl_stepwise = stepwiselm(data_xy(:, 2:6), ...
'AAPL_Return ~ SP500_Return - 1')
