% B3_Ch6_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch6_3_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC) 
% and Apple Inc. (AAPL)
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
 
%%
% Extract data from specific table field within 
% specific time horizon
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
data_sp500 = table_sp500(table_sp500.Date >= startdate & ...
    table_sp500.Date <= enddate,{'Date','AdjClose'});
data_aapl = table_aapl(table_aapl.Date >= startdate & ...
    table_aapl.Date <= enddate,{'Date','AdjClose'});
 
% Fit into regressional model
x = data_sp500.AdjClose;
y = data_aapl.AdjClose;
 
% With intercept b0
X = [ones(length(x), 1), x];
b = X\y;
ycal_2 = X*b;
k = 1;
n = length(y);
 
%%
% Goodness of fitting
yresid = y - ycal_2;
% Sum of Squares for Regression (SSR)
SSR = sum((ycal_2-mean(y)).^2);
% Sum of Squares for Error (SSE)
SSE = sum(yresid.^2);
% Sum of Squares for Total (SST)
SST = (length(y)-1)*var(y);
 
% R-squared & Adjusted R-squared
Rsquared = SSR/SST;
Rsquared_Adjusted = 1-SSE/SST*(n-1)/(n-k-1);
 
%RMSE
RMSE = sqrt(SSE/(n-k-1));
 
%%
% Using the function "fitlm"
% With intercept b0
data_xy = table(data_sp500.Date, ...
    data_sp500.AdjClose, data_aapl.AdjClose);
data_xy.Properties.VariableNames = {'Date','SP500','AAPL'};
 
% With intercept b0
mdl = fitlm(data_xy, 'AAPL ~ SP500');
 
mdl.SSE
SSE
mdl.SSR
SSR
mdl.SST
SST
mdl.Rsquared.Ordinary
Rsquared
mdl.Rsquared.Adjusted 
Rsquared_Adjusted
mdl.RMSE
RMSE


%% B3_Ch6_3_B.m
mdl.ModelCriterion.AIC
mdl.ModelCriterion.AICc
mdl.ModelCriterion.CAIC
mdl.ModelCriterion.BIC

