% B3_Ch6_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch6_4_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC, 
% Apple Inc. (AAPL) and US Unemployment Rate
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
filename_usur = ...
    'SeriesReport-20180716183946_76b2e9_US_UR.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_usur = readtable(filename_usur, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f');
 
%% Integrate to one table
data_xy = innerjoin(table_sp500(:,{'Date','AdjClose'}), ...
    table_aapl(:, {'Date','AdjClose'}), 'keys', 'Date');
data_xy = innerjoin(data_xy, table_usur, 'keys', 'Date');
data_xy.Properties.VariableNames = ...
    {'Date','SP500','AAPL', 'UR'};
 
%% Extract data from specific table field within 
% specific time horizon
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
data_xy = data_xy(data_xy.Date >= startdate & ...
    data_xy.Date <= enddate, :);
 
%% Fit into regressional model
% Using the function "fitlm"
% With intercept b0
mdl_AAPL_SP500 = ...
    fitlm(data_xy, 'AAPL ~ SP500');
 
mdl_AAPL_UR = ...
    fitlm(data_xy, 'AAPL ~ UR');
 
mdl_AAPL_SP500_UR = ...
fitlm(data_xy, 'AAPL ~ SP500 + UR');


%% B3_Ch6_4_B.m
% Check statistic tests
disp(mdl_AAPL_SP500)
disp(mdl_AAPL_UR)
disp(mdl_AAPL_SP500_UR)

mdl_AAPL_SP500

