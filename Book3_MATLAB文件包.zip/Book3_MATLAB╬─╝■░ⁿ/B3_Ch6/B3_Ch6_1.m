% B3_Ch6_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch6_1_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC) 
% and Apple Inc. (AAPL)
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
 
% Take common period
mindate = max(min(table_aapl.Date), min(table_sp500.Date));
maxdate = min(max(table_aapl.Date), max(table_sp500.Date));
 
table_sp500 = table_sp500(table_sp500.Date >= mindate &...
    table_sp500.Date <= maxdate, :);
table_aapl = table_aapl(table_aapl.Date >= mindate &...
    table_aapl.Date <= maxdate, :);
 
% Historical S&P 500 and Apple Inc. Stock
figure(1)
yyaxis left
plot(table_sp500.Date, table_sp500.AdjClose)
xlabel('Date'); 
ylabel('S&P 500 Index, USD');
 
yyaxis right
plot(table_aapl.Date, table_aapl.AdjClose); 
ylabel('Apple Inc. Stock, USD');
hold on;
set(gcf,'color','w');
 
%%
% Extract data from specific table field within 
% specific time horizon
 
% past 20 years
% startdate = datetime('1998-06-01');
% enddate = datetime('2018-06-01');
 
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
% past 5 years
% startdate = datetime('2013-06-01');
% enddate = datetime('2018-06-01');
 
data_sp500 = table_sp500(table_sp500.Date >= startdate & ...
    table_sp500.Date <= enddate,{'Date','AdjClose'});
data_aapl = table_aapl(table_aapl.Date >= startdate & ...
    table_aapl.Date <= enddate,{'Date','AdjClose'});
 
% Fit into regressional model
x = data_sp500.AdjClose;
y = data_aapl.AdjClose;
 
% Without intercept b0
format long
 
b1 = x\y;
ycal_1 = b1*x;
 
% Regression of Apple Inc. Stock over S&P500 Index without
% intercept b0
figure(2)
scatter(x, y)
hold on
plot(x, ycal_1)
xlabel('S&P Index, USD')
ylabel('Apple Inc. Stock, USD')
set(gcf,'color','w');
 
% With intercept b0
X = [ones(length(x), 1), x];
b = X\y;
ycal_2 = X*b;
 
% Regression of Apple Inc. Stock over S&P500 Index 
% with intercept b0
hold on
plot(x, ycal_2, '--')
legend('Data', 'Fitted without intercept', ...
    'Fitted with intercept','Location','best');
 

%% B3_Ch6_1_B.m
% Using the function "polyfit"
p = polyfit(x, y, 1);
ycal_3 = polyval(p, x);
 

%% B3_Ch6_1_C.m
% Using the function "regress"
% With intercept
[b2,bint,r,rint,stats] = regress(y,x);
 
% Without intercept
X = [ones(length(x), 1), x];
[b3,bint,r,rint,stats] = regress(y,X);
 

%% B3_Ch6_1_D.m
% Using the function "fitlm"
% With intercept b0
data_xy = table(data_sp500.Date, ...
    data_sp500.AdjClose, data_aapl.AdjClose);
data_xy.Properties.VariableNames = {'Date','SP500','AAPL'};
 
% Without intercept b0
mdl = fitlm(data_xy, 'AAPL ~ SP500', 'Intercept', false); 
mdl = fitlm(data_xy, 'AAPL ~ SP500-1');
 
% With intercept b0
mdl = fitlm(data_xy, 'AAPL ~ SP500');
