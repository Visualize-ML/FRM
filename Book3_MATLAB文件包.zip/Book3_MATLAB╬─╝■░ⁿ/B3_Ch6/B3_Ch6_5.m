% B3_Ch6_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch6_5_A.m
close all; clear all; clc

% Read in historical monthly data of S&P500 index (^GSPC, 
% Apple Inc. (AAPL) and US Unemployment Rate
filename_sp500 = ...
    '^GSPC_SP500_Monthly_YahooFinance_1950_2018.csv';
filename_aapl = ...
    'AAPL_AppleStock_Monthly_YahooFinance_1980_2018.csv';
filename_usur = ...
    'SeriesReport-20180716183946_76b2e9_US_UR.csv';
 
table_sp500 = readtable(filename_sp500, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_aapl = readtable(filename_aapl, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f%f%f%f%f%f');
table_usur = readtable(filename_usur, ...
    'Delimiter', ',', 'ReadVariableNames', ...
    true, 'ReadRowNames', false, ...
    'Format', '%{yyyy-MM-dd}D%f');
 
%% Integrate to one table
data_xy = innerjoin(table_sp500(:,{'Date','AdjClose'}), ...
    table_aapl(:, {'Date','AdjClose'}), 'keys', 'Date');
data_xy = innerjoin(data_xy, table_usur, 'keys', 'Date');
data_xy.Properties.VariableNames = ...
    {'Date','SP500','AAPL', 'UR'};
 
% Calculatate return of SP500 and APPL
data_xy.SP500_Return = ...
    [NaN; diff(data_xy.SP500)]./data_xy.SP500;
 
data_xy.AAPL_Return = ...
    [NaN; diff(data_xy.AAPL)]./data_xy.AAPL;
 
%% Extract data from specific table field within 
% specific time horizon
% past 10 years
startdate = datetime('2008-06-01');
enddate = datetime('2018-06-01');
 
data_xy = data_xy(data_xy.Date >= startdate & ...
    data_xy.Date <= enddate, :);
 
%% Fit into regressional model
% Using the function "fitlm"
% With intercept b0
mdl_AAPL_SP500 = ...
    fitlm(data_xy, 'AAPL ~ SP500');
 
mdl_AAPL_Return_SP500_Return = ...
    fitlm(data_xy, 'AAPL_Return ~ SP500_Return');
 
mdl_AAPL_SP500_UR = ...
    fitlm(data_xy, 'AAPL ~ SP500 + UR');
 
mdl_AAPL_Return_SP500_Return_UR = ...
    fitlm(data_xy, 'AAPL_Return ~ SP500_Return + UR');
 
%% Plotting
figure(1)
scatter(mdl_AAPL_SP500.Fitted, mdl_AAPL_SP500.Residuals.Raw) 
xlabel('Fitted Values')
ylabel('Residuals')
title('AAPL ~ SP500')
xlim([-200 200])
ylim([-50 50])
hold on
plot([-200, 200], [0, 0], 'r-')
set(gcf,'color','w');
 
figure(2)
scatter(mdl_AAPL_SP500_UR.Fitted, ...
    mdl_AAPL_SP500_UR.Residuals.Raw) 
xlabel('Fitted Values')
ylabel('Residuals')
title('AAPL ~ SP500 + UR')
xlim([-200 200])
ylim([-50 50])
hold on
plot([-200, 200], [0, 0], 'r-')
set(gcf,'color','w');
 
figure(3)
scatter(mdl_AAPL_Return_SP500_Return.Fitted, ...
    mdl_AAPL_Return_SP500_Return.Residuals.Raw) 
xlabel('Fitted Values')
ylabel('Residuals')
title('AAPL Return ~ SP500 Return')
xlim([-0.2 0.2])
ylim([-0.4 0.4])
hold on
plot([-0.4, 0.4], [0, 0], 'r-')
set(gcf,'color','w');
 
figure(4)
scatter(mdl_AAPL_Return_SP500_Return_UR.Fitted, ...
    mdl_AAPL_Return_SP500_Return_UR.Residuals.Raw) 
xlabel('Fitted Values')
ylabel('Residuals')
title('AAPL Return ~ SP500 Return + UR')
xlim([-0.2 0.2])
ylim([-0.4 0.4])
hold on
plot([-0.4, 0.4], [0, 0], 'r-')
set(gcf,'color','w');


%% B3_Ch6_5_B.m
figure(5)
binnum = 20;
subplot(2,2,1)
hist(mdl_AAPL_SP500.Residuals.Raw, binnum)
title('AAPL ~ SP500')
xlim([-25 25])
ylim([0, 30])
hold on
plot([0, 0], [0, 30], 'r-')
 
subplot(2,2,3)
hist(mdl_AAPL_SP500_UR.Residuals.Raw, binnum)
title('AAPL ~ SP500 + UR')
xlim([-25 25])
ylim([0, 30])
hold on
plot([0, 0], [0, 30], 'r-')
 
subplot(2,2,2)
hist(mdl_AAPL_Return_SP500_Return.Residuals.Raw, binnum)
title('AAPL Return ~ SP500 Retrun')
xlim([-0.5 0.5])
ylim([0, 30])
hold on
plot([0, 0], [0, 30], 'r-')
 
subplot(2,2,4)
hist(mdl_AAPL_Return_SP500_Return_UR.Residuals.Raw, binnum)
title('AAPL Return ~ SP500 Return + UR')
xlim([-0.5 0.5])
ylim([0, 30])
hold on
plot([0, 0], [0, 30], 'r-')
set(gcf,'color','w');
 

%% B3_Ch6_5_C.m
figure(6)
subplot(2,2,1)
normplot(mdl_AAPL_SP500.Residuals.Raw)
title('AAPL ~ SP500')
hold on
 
subplot(2,2,3)
normplot(mdl_AAPL_SP500_UR.Residuals.Raw)
title('AAPL ~ SP500 + UR')
hold on
 
subplot(2,2,2)
normplot(mdl_AAPL_Return_SP500_Return.Residuals.Raw)
title('AAPL Return ~ SP500 Retrun')
hold on
 
subplot(2,2,4)
normplot(mdl_AAPL_Return_SP500_Return_UR.Residuals.Raw)
title('AAPL Return ~ SP500 Return + UR')
hold on
set(gcf,'color','w');

