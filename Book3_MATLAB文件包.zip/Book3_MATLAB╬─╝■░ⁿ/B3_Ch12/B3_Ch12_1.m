% B3_Ch12_1.m


%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B3_Ch12_1_A.m

%% Prepare data
% download stock prices from Yahoo Finance
 
clc; close all; clear all
 
price = hist_stock_data('09092018','09092019'...
    ,'GOOG','AAPL','F','GM','IBM');

% price = hist_stock_data('09092018','09092019'...
%     ,'GOOG','AAPL','F','GM','TSLA');

% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
GOOG_S = price(1).AdjClose;
AAPL_S = price(2).AdjClose;
F_S    = price(3).AdjClose;
GM_S   = price(4).AdjClose;
IBM_S  = price(5).AdjClose;
 
GOOG_log_r = diff(log(GOOG_S));
AAPL_log_r = diff(log(AAPL_S));
F_log_r    = diff(log(F_S));
GM_log_r   = diff(log(GM_S));
IBM_log_r  = diff(log(IBM_S));
 
index = 1;
S_levels = [GOOG_S(end), AAPL_S(end), ...
    F_S(end), GM_S(end),IBM_S(end)];
shares = [1,5,100,20,10];
% calculate position PVs and weights
PV_i = S_levels.*shares;
PV_sum = sum(PV_i);
 
Weights = PV_i/PV_sum; % row vector
 
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = PV_i;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
txt = {'GOOG: ';'AAPL: ';'FORD: ';'GM: ';'IBM: '};
combinedtxt = strcat(txt,percentValues);
title(['Portfolio PV = ',num2str(PV_sum),' USD'])
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
 
subplot(1,2,2)
 
bar(PV_i,'b')
text([1:length(PV_i)], PV_i', num2str(PV_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Market value [USD]'); box off; grid off
name = {'GOOG';'AAPL';'FORD';'GM';'IBM'};
set(gca,'xticklabel',name)
xtickangle(45)
 
S_matrix = [GOOG_S, AAPL_S, F_S, GM_S, IBM_S];
S_portfolio = S_matrix*shares';
S_matrix = [S_matrix,S_portfolio];
 
% calculate log returns
Returns = [GOOG_log_r, AAPL_log_r, ...
    F_log_r, GM_log_r, IBM_log_r];
 
R_portfolio = diff(log(S_portfolio));
R_matrix = [Returns,R_portfolio];
 
name2 = {'GOOG';'AAPL';'FORD';'GM';'IBM';'Portfolio'};
 
figure(index); index = index + 1;
 
for i = 1:6
    subplot(2,3,i)
    plot(dates,S_matrix(:,i));
    box off; grid off
    datetick('x','mmm','keeplimits')
    xlim([dates(1),dates(end)]);
    title(name2{i})
end
 
figure(index); index = index + 1;
 
for i = 1:6
    subplot(2,3,i)
    plot(dates(2:end),R_matrix(:,i),'.'); hold on
    plot(dates(2:end),zeros(size(dates(2:end))),'r'); 
    box off; grid off
    datetick('x','mmm','keeplimits')
    xlim([dates(1),dates(end)]);
    title(name2{i}); ylim([-0.1,0.1])
end
%% calculate variance-covariance matrix
MU = mean(Returns);
 
R_demean = Returns - ones(size(Returns))*diag(MU);
 
[L, ~] = size(R_demean);
R = R_demean/sqrt(L-1); % or divided by sqrr(L)
SIGMA = R'*R; 
% cov(Returns)
RHO = corr(Returns);
 
figure(index); index = index + 1;
xvalues = name;
yvalues = xvalues;
h = heatmap(xvalues,yvalues,cov(Returns));
h.Title = 'Variance-covariance matrix matrix';
 
figure(index); index = index + 1;
xvalues = name;
yvalues = xvalues;
h = heatmap(xvalues,yvalues,RHO);
h.Title = 'Correlation matrix';
 
figure(index); index = index + 1;
xvalues = name2;
yvalues = xvalues;
h = heatmap(xvalues,yvalues,cov(R_matrix));
vol_series = sqrt(diag(cov(R_matrix)));
h.Title = 'Variance-covariance matrix with portfolio';
 
figure(index); index = index + 1;
xvalues = name2;
yvalues = xvalues;
h = heatmap(xvalues,yvalues,corr(R_matrix));
h.Title = 'Correlation matrix with portfolio';


% B3_Ch12_1_B.m

%% Position VaR, and undiversified VaR
% undiversified VaR (sum of position VaRs)
 
figure(index); index = index + 1;
alpha = 0.95; % confidence level
z_alpha = norminv(alpha,0,1);
z_ES_alpha = normpdf(norminv(alpha,0,1))./(1-alpha);
 
for i = 1:6
    subplot(2,3,i)
    histfit(R_matrix(:,i),20); hold on
    VaR_95 = -vol_series(i)*z_alpha;
    
    ES_95 = -vol_series(i)*z_ES_alpha;
    y_lim = ylim;
    plot([VaR_95,VaR_95],y_lim,'r'); hold on
    plot([ES_95,ES_95],y_lim,'r'); hold on
    box off; grid off
    title(name2{i}); 
    xlim([-0.1,0.1])
end
 
J = 1; % holding period = 1 day
VaR_i = PV_sum.*sqrt(J).*abs(Weights).*...
    sqrt(diag(SIGMA))'.*z_alpha;

ES_i  = PV_sum.*sqrt(J).*abs(Weights).*...
    sqrt(diag(SIGMA))'.*normpdf(norminv(alpha,0,1))./(1-alpha);

VaR_undiversified = sum(VaR_i);
ES_undiversified  = sum(ES_i);
 
figure(index); index = index + 1;
yyaxis left
bar(VaR_i,0.4,'b'); Y = VaR_i;
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45)
ylabel('Position VaR [USD]'); box off; grid off
set(gca,'xticklabel',name)
 
yyaxis right
Y = VaR_i./PV_i;
plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.015,0.05])
ylabel('Position VaR/position PV'); box off; grid off
set(gca,'xticklabel',name)
 
figure(index); index = index + 1;
 
yyaxis left
bar(ES_i,0.4,'b'); Y = ES_i;
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45)
ylabel('Position ES [USD]'); box off; grid off
set(gca,'xticklabel',name)
 
yyaxis right
Y = ES_i./PV_i;
plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.03,0.05])
ylabel('Position ES/position PV'); box off; grid off
set(gca,'xticklabel',name)
%% Diversified VaR
VaR_diversified = z_alpha*...
    sqrt(Weights*SIGMA*Weights')*...
    PV_sum*sqrt(J);

ES_diversified  = normpdf(norminv(alpha,0,1))/(1-alpha)...
    *sqrt(Weights*SIGMA*Weights')*PV_sum*sqrt(J);

% plot undiversified VaR versus diversified VaR
figure(index); index = index + 1;
subplot(1,2,1)
Y = [VaR_undiversified,VaR_diversified];
bar(Y,0.4)
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,200])
labels = {'Undiversified';'Diversified'}
ylabel('VaR [USD]'); box off; grid off
set(gca,'xticklabel',labels)
 
subplot(1,2,2)
Y = [ES_undiversified,ES_diversified];
bar(Y,0.4)
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,200])
labels = {'Undiversified';'Diversified'}
ylabel('ES [USD]'); box off; grid off
set(gca,'xticklabel',labels)


% B3_Ch12_1_C.m

%% Incremental VaR
 
IVaR_i = [];
IES_i  = [];
VaR_minus_i = [];
ES_minus_i = [];
 
for i = 1:length(Weights)
    W_minus_i = Weights;
    W_minus_i(i) = [];
    SIGMA_minus_i = SIGMA;
    SIGMA_minus_i(:,i) = [];
    SIGMA_minus_i(i,:) = [];
    
    VaR_minus_i_temp = z_alpha*sqrt(W_minus_i*...
        SIGMA_minus_i*W_minus_i')*PV_sum*sqrt(J);
    
    ES_minus_i_temp  = normpdf(norminv(alpha,0,1))...
        /(1-alpha)*sqrt(W_minus_i*SIGMA_minus_i...
        *W_minus_i')*PV_sum*sqrt(J);
    
    IVaR_i = [IVaR_i, VaR_diversified - VaR_minus_i_temp];
    IES_i = [IES_i, ES_diversified - ES_minus_i_temp];

    VaR_minus_i = [VaR_minus_i,VaR_minus_i_temp];
    ES_minus_i = [ES_minus_i,ES_minus_i_temp];
    
end
 
figure(index); index = index + 1;
subplot(1,2,1)
Y = IVaR_i; bar(Y,'b');
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylim([0,35]); xtickangle(45)
ylabel('Incremental VaR [USD]'); box off; grid off
set(gca,'xticklabel',name)
 
subplot(1,2,2)
Y = IES_i;
bar(Y,'b'); ylim([0,35])
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Incremental ES [USD]'); box off; grid off
set(gca,'xticklabel',name); xtickangle(45)
 
figure(index); index = index + 1;
subplot(1,2,1)
Y = [VaR_minus_i; IVaR_i]'; bar(Y,'stacked');
text([1:length(VaR_minus_i)], VaR_minus_i', ...
    num2str(VaR_minus_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
text([1:length(IVaR_i)], (IVaR_i+VaR_minus_i)', ...
    num2str(IVaR_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylim([0,160]); xtickangle(45)
ylabel('VaR[USD]'); box off; grid off
set(gca,'xticklabel',name)
title(['Diversified VaR = ',num2str(VaR_diversified)])
 
subplot(1,2,2)
Y = [ES_minus_i; IES_i]';
bar(Y,'stacked'); ylim([0,160])
text([1:length(ES_minus_i)], ES_minus_i', ...
    num2str(ES_minus_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
text([1:length(IES_i)], (IES_i+ES_minus_i)', ...
    num2str(IES_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('ES [USD]'); box off; grid off
set(gca,'xticklabel',name); xtickangle(45)
title(['Diversified ES = ',num2str(ES_diversified)])

% B3_Ch12_1_D.m

%% Marginal VaR and ES
 
MVaR_i = z_alpha*PV_sum*sqrt(J)*Weights*SIGMA...
    /sqrt(Weights*SIGMA*Weights');

MES_i = normpdf(norminv(alpha,0,1))/(1-alpha)...
    *PV_sum*sqrt(J)*Weights*SIGMA...
    /sqrt(Weights*SIGMA*Weights');
 
MVaR_i_per_USD = MVaR_i/PV_sum;
MES_i_per_USD = MES_i/PV_sum;
 
figure(index); index = index + 1;
 
yyaxis left
Y = MVaR_i; bar(Y,0.4,'b');
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,200])
ylabel('Marginal VaR by weight [USD]')
set(gca,'xticklabel',name); box off; grid off
 
yyaxis right
Y = MVaR_i_per_USD; plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.015,0.05])
ylabel('Marginal VaR by dollar'); box off; grid off
set(gca,'xticklabel',name)
 
figure(index); index = index + 1;
 
yyaxis left
Y = MES_i; bar(Y,0.4,'b');
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,200])
ylabel('Marginal ES by weight [USD]')
set(gca,'xticklabel',name); box off; grid off
 
yyaxis right
Y = MES_i_per_USD; plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.015,0.05])
ylabel('Marginal ES by dollar'); box off; grid off
set(gca,'xticklabel',name)

% B3_Ch12_1_E.m

%% Component VaR and ES
 
CVaR_i = Weights.*MVaR_i;

CES_i  = Weights.*MES_i;
 
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = CVaR_i;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
combinedtxt = strcat(txt,percentValues);
 
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
title(['Diversified VaR = ',num2str(VaR_diversified)])
subplot(1,2,2)
 
bar(Y,'b'); ylim([0 200])
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Component VaR [USD]'); box off; grid off
set(gca,'xticklabel',name)
xtickangle(45); ylim([0,40])
 
 
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = CES_i;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
combinedtxt = strcat(txt,percentValues);
 
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
title(['Diversified ES = ',num2str(ES_diversified)])
 
subplot(1,2,2)
 
bar(Y,'b')
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Component ES [USD]'); box off; grid off
set(gca,'xticklabel',name)
xtickangle(45)
 
figure(index); index = index + 1;
 
yyaxis left
Y = CVaR_i;
bar(Y,0.4,'b');
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,40])
ylabel('Component VaR [USD]')
set(gca,'xticklabel',name); box off; grid off
 
yyaxis right
Y = CVaR_i./PV_i;
plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.015,0.05])
ylabel('Component VaR/position PV'); box off; grid off
set(gca,'xticklabel',name)
 
figure(index); index = index + 1;
 
yyaxis left
Y = CES_i;
bar(Y,0.4,'b');
text([1:length(Y)], Y', num2str(Y','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0,40])
ylabel('Component ES [USD]')
set(gca,'xticklabel',name); box off; grid off
 
yyaxis right
Y = CES_i./PV_i;
plot(Y,'rx-');
text([1:length(Y)], Y', num2str(Y','%0.3f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtickangle(45); ylim([0.015,0.05])
ylabel('Component ES/position PV'); box off; grid off
set(gca,'xticklabel',name)

