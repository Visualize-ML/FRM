% B3_Ch12_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

% B3_Ch12_3_A.m

clc; close all; clear all
 
price = hist_stock_data('09092014','09092019'...
    ,'GOOG','AAPL','F','GM','IBM');

% price = hist_stock_data('09092018','09092019'...
%     ,'GOOG','AAPL','F','GM','TSLA');

% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
GOOG_S = price(1).AdjClose;
AAPL_S = price(2).AdjClose;
F_S    = price(3).AdjClose;
GM_S   = price(4).AdjClose;
IBM_S  = price(5).AdjClose;
 
GOOG_log_r = diff(log(GOOG_S));
AAPL_log_r = diff(log(AAPL_S));
F_log_r    = diff(log(F_S));
GM_log_r   = diff(log(GM_S));
IBM_log_r  = diff(log(IBM_S));
 
Data = [GOOG_S, AAPL_S, F_S, GM_S, IBM_S];
S_baseline = [GOOG_S(end), AAPL_S(end), ...
    F_S(end), GM_S(end),IBM_S(end)];
shares = [1,5,100,20,10];
% calculate position PVs and weights
PV_i = S_baseline.*shares;
PV_sum = sum(PV_i);
series = {'GOOG';'AAPL';'FORD';'GM';'IBM'};
weights = PV_i/PV_sum; % row vector
%% Plot relative price for the 5 stocks in the portfolio
index = 1;
figure(index); index = index + 1;
plot(dates, ret2price(price2ret(Data)))
box off; grid off
datetick('x','mmm/yy','keeplimits')
xlim([dates(1),dates(end)]);
xlabel('Date'); legend boxoff
ylabel('Stock relative prices')
title ('Relative daily stock closings')
legend(series, 'Location', 'best')
 
returns = price2ret(Data);    
% Logarithmic returns
T       = size(returns,1);    
% number of returns (i.e., historical sample size)
 
mean_returns = mean(returns)';
std_returns  = std(returns)';
skew_returns = skewness(returns)';
kurt_returns = kurtosis(returns)';

% B3_Ch12_3_B.m

%% change index_stock to examine each stock price
 
index_stock = 1;
 
figure(index); index = index + 1;
subplot(2,1,1)
plot(dates(1:end), Data(:,index_stock)); hold on
box off; grid off
datetick('x','mmm/yy','keeplimits')
xlim([dates(1),dates(end)]);
xlabel('Date'); axis tight
ylabel(['Price of ' series(index_stock)])
title('Daily closing price')
 
subplot(2,1,2)
plot(dates(2:end), returns(:,index_stock),'.'); hold on
plot(dates(2:end), zeros( size(returns(:,index_stock))),'r'); hold on
box off; grid off
datetick('x','mmm/yy','keeplimits')
xlim([dates(2),dates(end)]);
xlabel('Date'); axis tight
ylabel(['Return of ' series(index_stock)])
title('Daily log returns')
 

figure(index); index = index + 1;
histfit(returns(:,index_stock)); hold on
xlabel('Log returns')
ylabel('Frequency'); grid off; box off
 
figure(index); index = index + 1;
subplot(1,2,1)
autocorr(returns(:,index_stock))
title('Sample ACF of returns')
% study the autocorrelation of stock daily log returns
box off; grid off
 
subplot(1,2,2)
autocorr(returns(:,index_stock).^2)
title('Sample ACF of squared returns')
% study the autocorrelation of daily log return squared
box off; grid off
 
% To produce a series of i.i.d. observations, fit a first order
% autoregressive model to the conditional mean of 
% the returns of each equity
 
model     = arima('AR', NaN, 'Distribution', 't', 'Variance', gjr(1,1));
num_assets  = size(Data,2);        
% number of stocks
residuals = NaN(T, num_assets);    
% preallocate storage
variances = NaN(T, num_assets);
fit       = cell(num_assets,1);
 
options   = optimset('fmincon');
options   = optimset(options, 'Display', ...
    'off', 'Diagnostics', 'off', ...
    'Algorithm','sqp','TolCon',1e-7);
 
for i = 1:num_assets

    fit{i} = estimate(model, returns(:,i), ...
        'Display', 'off', 'Options', options);

    [residuals(:,i), variances(:,i)] = infer(fit{i}, returns(:,i));

end
 
figure(index); index = index + 1;
subplot(2,1,1)
plot(dates(2:end), residuals(:,index_stock),'.'); hold on
plot(dates(2:end), zeros(size(residuals(:,index_stock))),'r')
datetick('x','mmm/yy','keeplimits')
xlim([dates(2),dates(end)]);
xlabel('Date'); axis tight
ylabel('Residual'); box off
title ('Filtered residuals')
 
subplot(2,1,2)
plot(dates(2:end), sqrt(variances(:,index_stock)))
datetick('x','mmm/yy','keeplimits')
xlim([dates(2),dates(end)]);
xlabel('Date'); axis tight
ylabel('Volatility'); box off
title ('Filtered conditional standard deviations')
 
residuals = residuals ./ sqrt(variances);
 
figure(index); index = index + 1;
subplot(1,2,1)
autocorr(residuals(:,index_stock))
title('Sample ACF of standardized residuals')
box off; grid off
 
subplot(1,2,2)
autocorr(residuals(:,index_stock).^2)
title('Sample ACF of squared standardized residuals')
box off; grid off
 
nPoints      = 200;      
% number of sampled points in each region of the CDF
tailFraction = 0.1;      
% Decimal fraction of residuals allocated to each tail
 
tails = cell(num_assets,1);  
% Cell array of Pareto tail objects
 
for i = 1:num_assets

    tails{i} = paretotails(residuals(:,i),...
        tailFraction, 1 - tailFraction, 'kernel');

end
 
minProbability = cdf(tails{index_stock},...
    (min(residuals(:,index_stock))));

maxProbability = cdf(tails{index_stock}, ...
    (max(residuals(:,index_stock))));
 
pLowerTail = linspace(minProbability  , ...
    tailFraction    , nPoints); 
% sample lower tail
pUpperTail = linspace(1 - tailFraction, ...
    maxProbability  , nPoints); 
% sample upper tail
pInterior  = linspace(tailFraction    , ...
    1 - tailFraction, nPoints); 
% sample interior
 
figure(index); index = index + 1;
subplot(1,2,1)
hold all
plot(icdf(tails{index_stock}, pLowerTail),...
    pLowerTail, 'red'  , 'LineWidth', 2)
plot(icdf(tails{index_stock}, pInterior) ,...
    pInterior , 'black', 'LineWidth', 2)
plot(icdf(tails{index_stock}, pUpperTail),...
    pUpperTail, 'blue' , 'LineWidth', 2)
 
xlabel('Standardized residual')
ylabel('Empirical CDF')
 
legend({'Pareto lower tail' 'Kernel smoothed interior' ...
    'Pareto upper tail'}, 'Location', 'best')
legend boxoff; axis tight; grid off; box off
 
subplot(1,2,2)
[P,Q] = boundary(tails{index_stock});  
% cumulative probabilities & quantiles at boundaries
y = sort(residuals(residuals(:,index_stock) > Q(2), ...
    index_stock) - Q(2)); 
% sort exceedances
% plot(y, (cdf(tails{index_stock}, y + Q(2)) - P(2))/P(1))
plot(y, cdf(tails{index_stock}, y + Q(2)) - P(2)+0.9)
[F,x] = ecdf(y); hold on 
% empirical CDF
stairs(x, F*tailFraction + 1 - tailFraction, 'r')
 
legend('Fitted generalized Pareto CDF',...
    'Empirical CDF','Location','SouthEast');
xlabel('Exceedance'); ylabel('Probability')
title('Upper tail of standardized residuals')
axis tight; grid off; box off; legend boxoff

% B3_Ch12_3_C.m

%% Calibrate the t Copula
 
U = zeros(size(residuals));
 
for i = 1:num_assets
    U(:,i) = cdf(tails{i}, residuals(:,i)); 
    % transform margin to uniform
end
 
figure(index); index = index + 1;
[~,ax] = plotmatrix(U); 
title('Transformed returns prior to fitting a Copula');
 
for i = 1:num_assets
    ylabel(ax(i,1),series{i});
    xlabel(ax(end,i),series{i});
end
 
[R, DoF] = copulafit('t', U, 'Method', 'approximateml'); 
% fit the copula
 
% Simulate returns with a t Copula
 
s = RandStream.getGlobalStream();
reset(s)
 
num_sims = 2000; 
% number of independent random trials
J_holding = 10; 
% VaR forecast horizon
 
Z = zeros(J_holding, num_sims, num_assets); 
% standardized residuals array
U = copularnd('t', R, DoF, J_holding * num_sims);
% t copula simulation
 
for j = 1:num_assets
    Z(:,:,j) = reshape(icdf(tails{j}, U(:,j)), J_holding, num_sims);
end
 
Y0 = returns(end,:);
% presample returns
Z0 = residuals(end,:);
% presample standardized residuals
V0 = variances(end,:);
% presample variances
 
sim_returns = zeros(J_holding, num_sims, num_assets);
 
for i = 1:num_assets
    sim_returns(:,:,i) = filter(fit{i}, Z(:,:,i), ...
        'Y0', Y0(i), 'Z0', Z0(i), 'V0', V0(i));
end
 
sim_returns = permute(sim_returns, [1 3 2]);
 
J_day_sim_returns = zeros(num_sims, 1);
 
% convert daily stock returns to J-day portfolio returns
for i = 1:num_sims
    J_day_sim_returns(i) = sum(log(1 + ...
        (exp(sim_returns(:,:,i)) - 1) * weights'));
end
 
%% Summarize the Results
 
alpha = 0.95;
VaR = -quantile(J_day_sim_returns, 1-alpha);

ES  = -mean(J_day_sim_returns(J_day_sim_returns < -VaR));
 
disp(' ')
fprintf('Maximum sim loss:   %4.4f%s\n'   , ...
    -100*min(J_day_sim_returns), '%')
fprintf('Maximum sim profit: %4.4f%s\n\n' , ...
    100*max(J_day_sim_returns), '%')
fprintf(['Holding period, J: ',num2str(J_holding),' days\n'])
fprintf('-------------\n')
fprintf('95%% copula VaR: %4.2f%s\n'  ,  100 * VaR, '%')
fprintf('95%% copula  ES: %4.2f%s\n'  ,  100 * ES, '%')
 
MU = mean(returns);
SIGMA = cov(returns);
z_alpha = norminv(alpha,0,1);
z_ES_alpha = normpdf(norminv(alpha,0,1))./(1-alpha);
 
VaR2 = z_alpha*sqrt(weights*SIGMA*weights')*...
    sqrt(J_holding) - weights*MU'*J_holding;
 
ES2 = z_ES_alpha*sqrt(weights*SIGMA*weights')*...
    sqrt(J_holding) - weights*MU'*J_holding;
 
fprintf('-------------\n')
fprintf('95%% multivariate normal VaR: %4.2f%s\n' ...
    ,  100 * VaR2, '%')
fprintf('95%% multivariate normal  ES: %4.2f%s\n' ...
    ,  100 * ES2, '%')
fprintf('-------------\n')
 
figure(index); index = index + 1;
subplot(2,1,1)
histfit(J_day_sim_returns); hold on
xlabel('Simulated log returns, J = 5 days')
ylabel('Frequency'); grid off; box off
y_lim = ylim;
plot([-VaR,-VaR],y_lim,'r')
plot([-VaR2,-VaR2],y_lim,'r')
 
subplot(2,1,2)
histfit(J_day_sim_returns); hold on
xlabel('Simulated log returns, J = 5 days')
ylabel('Frequency'); grid off; box off
y_lim = ylim;
 
plot([-ES,-ES],y_lim,'b')
plot([-ES2,-ES2],y_lim,'b')
