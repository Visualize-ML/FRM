% B3_Ch12_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url); series = 'SP500';
startdate = '09/09/2014';
% beginning of date range for historical data
enddate = '09/09/2019'; % to be updated
% ending of date range for historical data
 
d = fetch(c,series,startdate,enddate);
% display description of data structure
 
SP500 = d.Data(:,2); date_series = d.Data(:,1);
 
SP500_non_NaN_index = ~isnan(SP500);
S = SP500(SP500_non_NaN_index);
date_series_rm_NaN = date_series(SP500_non_NaN_index);
 
[X,interval] = tick2ret (S,...
    date_series_rm_NaN,'Continuous');
dates = date_series_rm_NaN(2:end);
 
index = 1;
figure(index); index = index + 1;
plot(dates,X,'.'); hold on
plot(dates,zeros(size(dates)),'r')
ylabel('Daily log return'); xlabel('Year')
datetick('x','yyyy','keeplimits')
axis tight; grid off; box off
 
% X_sorted = sort(X,'ascend');
threshold = -0.015;
index_below_POT = find(X < threshold);
index_above_POT = find(X > threshold);
extremes_POT = X(index_below_POT);
 
figure(index); index = index + 1;
plot(dates(index_above_POT),X(index_above_POT),'.b'); hold on
stem(dates(index_below_POT),X(index_below_POT),'xr','MarkerSize',10); hold on
plot(dates,zeros(size(dates)),'r'); hold on
plot(dates,ones(size(dates))*threshold,'r'); hold on
ylabel('Daily log return'); xlabel('Year')
datetick('x','yyyy','keeplimits')
axis tight; grid off; box off
 
%% Block minima
 
box_length = 20;
num_boxes = ceil(length(X)/box_length);
index_EVT = [];
for i = 1:num_boxes
    box_start = 1+(i-1)*box_length;
    box_end   = box_start + box_length - 1;
    if box_end > length(X)
        box_end = length(X);
    else
    end
    
    X_rolling_box = nan(size(X)); 
    X_rolling_box(box_start:box_end) = X(box_start:box_end);
    [~,index_EVT_temp] = min(X_rolling_box);
    index_EVT = [index_EVT,index_EVT_temp];
    
end
 
extremes_EVT = X(index_EVT);
 
figure(index); index = index + 1;
X_removed_EVT = X;
X_removed_EVT (index_EVT) = NaN;
plot(dates,X_removed_EVT,'.b'); hold on
stem(dates(index_EVT),X(index_EVT),'xr','MarkerSize',10); hold on
plot(dates,zeros(size(dates)),'r'); hold on
ylabel('Daily log return'); xlabel('Year')
datetick('x','yyyy','keeplimits')
axis tight; grid off; box off
 
%% EVaR under EVT
 
[paramEsts,~] = gevfit(extremes_EVT);
 
k_MLE     = paramEsts(1);    % Shape parameter
sigma_MLE = paramEsts(2);    % Scale parameter
mu_MLE    = paramEsts(3);    % Location parameter
n = length(extremes_EVT); 
alpha = 0.95;
EVT_VaR_EVT =  mu_MLE - sigma_MLE/k_MLE*(1-(-n*log(alpha))^(-k_MLE))
 
lowerBnd = mu_MLE-sigma_MLE./k_MLE;
 
ymin = 1.1*min(extremes_EVT);
 
figure(index); index = index + 1;
step_size = 0.002; 
hist(extremes_EVT,-0.05:step_size:0);
hold on
xgrid = linspace(ymin,lowerBnd,100);
PDF = gevpdf(xgrid,k_MLE,sigma_MLE,mu_MLE);
plot(xgrid,step_size*length(extremes_EVT)*PDF,'r'); hold on
y_lim = ylim;
plot([EVT_VaR_EVT,EVT_VaR_EVT],y_lim,'r')
xlabel('Extreme values'); ylabel('Frequency');
xlim([ymin lowerBnd]); box off
line_1 = ['k = ',num2str(k_MLE),'; \sigma = ',...
    num2str(sigma_MLE),'; \mu = ',num2str(mu_MLE)];
line_2 = ['EVaR = ',num2str(EVT_VaR_EVT)];
title({line_1;line_2})

