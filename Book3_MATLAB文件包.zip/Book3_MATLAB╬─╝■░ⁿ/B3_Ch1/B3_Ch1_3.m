% B3_Ch1_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
price = hist_stock_data('01012017','01012019','GM','F','MCD','IBM');
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
GM_price = price(1).AdjClose;
Ford_price = price(2).AdjClose;
McDon_price = price(3).AdjClose;
IBM_price = price(4).AdjClose;
 
GM_daily_log_return    = diff(log(GM_price));
% also price2ret can be used
Ford_daily_log_return  = diff(log(Ford_price));
McDon_daily_log_return = diff(log(McDon_price));
IBM_daily_log_return   = diff(log(IBM_price));
 
%%
D_whole = [];
 
D_whole = [GM_daily_log_return, Ford_daily_log_return, ...
    McDon_daily_log_return, IBM_daily_log_return];
L = 250;
D = D_whole(end-L+1:end,:);
 
lambda = 0.94;  L_array = [1:L]';
 
MU = mean(D);
EWA_array = lambda.^((L_array - 1)/2)*...
    sqrt((1-lambda)/(1 - lambda^L));
 
SMA_array = sqrt(ones(size(L_array))./L);
 
MU_ewma = (EWA_array.*EWA_array)'*D;
MU_2    = (SMA_array.*SMA_array)'*D;
 
D_de_simple_mean = D - ones(size(D))*diag(MU);
D_de_ewa_mean    = D - ones(size(D))*diag(MU_ewma);
[L, ~] = size(D);
R = D_de_simple_mean/sqrt(L-1); % n or n-1
COV_simple = R'*R;  COV_matlab = cov(D);
 
EWMA_matrix = diag(EWA_array);
R_ewma_de_SA = EWMA_matrix*D_de_simple_mean;
R_ewma_de_EWA = EWMA_matrix*D_de_ewa_mean;
R_ewma_no_demean = EWMA_matrix*D;
 
COV_EWMA_de_SA = R_ewma_de_SA'*R_ewma_de_SA;
COV_EWMA_de_EWA = R_ewma_de_EWA'*R_ewma_de_EWA;
COV_EWMA_no_demean = R_ewma_no_demean'*R_ewma_no_demean;
 
figure(1)
subplot(2,2,1)
cdata = COV_simple;
xvalues = {'GM','FORD','MCD','IBM'};
yvalues = xvalues;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'Simple variance-covariance';
 
subplot(2,2,2)
cdata = COV_EWMA_no_demean;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA variance-covariance, no demean';
 
subplot(2,2,3)
cdata = COV_EWMA_de_SA;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA variance-covariance, de-simple mean';
 
subplot(2,2,4)
cdata = COV_EWMA_de_EWA;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA variance-covariance, de-exponentially-weighted mean';
 
STD = diag(sqrt(diag(COV_simple)));
CORR = inv(STD)*COV_simple*inv(STD);
CORR_matlab = corr(D);
 
STD_EWMA_de_SA = diag(sqrt(diag(COV_EWMA_de_SA)));
CORR_EWMA_de_SA = inv(STD_EWMA_de_SA)*COV_EWMA_de_SA*inv(STD_EWMA_de_SA);
 
STD_EWMA_de_EWA = diag(sqrt(diag(COV_EWMA_de_EWA)));
CORR_EWMA_de_EWA = inv(STD_EWMA_de_EWA)*COV_EWMA_de_EWA*inv(STD_EWMA_de_EWA);
 
STD_EWMA_no_demean = diag(sqrt(diag(COV_EWMA_no_demean)));
CORR_EWMA_no_demean = inv(STD_EWMA_no_demean)*COV_EWMA_no_demean*inv(STD_EWMA_no_demean);
 
figure(2)
subplot(2,2,1)
cdata = CORR;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'Simple correlation';
 
subplot(2,2,2)
cdata = CORR_EWMA_no_demean;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA correlation, no demean';
 
subplot(2,2,3)
cdata = CORR_EWMA_de_SA;
xvalues = {'GM','FORD','MCD','IBM'};
yvalues = {'GM','FORD','MCD','IBM'};
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA correlation, de-simple mean';
 
subplot(2,2,4)
cdata = CORR_EWMA_de_EWA;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'EWMA correlation, de-exponentially-weighted mean';
