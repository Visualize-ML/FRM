% B3_Ch1_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
price = hist_stock_data('01012017','01012019','GM','F','MCD','IBM');
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
GM_price = price(1).AdjClose;
Ford_price = price(2).AdjClose;
McDon_price = price(3).AdjClose;
IBM_price = price(4).AdjClose;
 
GM_daily_log_return    = diff(log(GM_price));
% also price2ret can be used
Ford_daily_log_return  = diff(log(Ford_price));
McDon_daily_log_return = diff(log(McDon_price));
IBM_daily_log_return   = diff(log(IBM_price));
 
%%
D_whole = [];
 
L = 250;
D_whole = [GM_daily_log_return, Ford_daily_log_return, ...
    McDon_daily_log_return, IBM_daily_log_return];
D = D_whole(end-L+1:end,:);
 
 
D_demean = detrend(D, 'constant');
 
COV_manual = D_demean'*D_demean/(L-1);
COV_matlab = cov(D);
 
figure(1)
subplot(1,2,1)
cdata = COV_matlab;
xvalues = {'GM','FORD','MCD','IBM'};
yvalues = xvalues;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'MATLAB covariance matrix';
 
subplot(1,2,2)
cdata = COV_manual;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'Manual covariance matrix';
 
%%
 
STD = diag(sqrt(diag(COV_manual)));
CORR_manual = inv(STD)*COV_manual*inv(STD);
CORR_matlab = corr(D);
 
figure(2)
subplot(1,2,1)
cdata = CORR_manual;
xvalues = {'GM','FORD','MCD','IBM'};
yvalues = xvalues;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'MATLAB correlation matrix';
 
subplot(1,2,2)
cdata = CORR_matlab;
h = heatmap(xvalues,yvalues,cdata);
h.Title = 'Manual correlation matrix';
