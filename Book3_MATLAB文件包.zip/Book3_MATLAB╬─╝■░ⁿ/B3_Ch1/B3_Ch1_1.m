% B3_Ch1_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% rotate clockwise
 
x = [1, 0, -1, -1, 1]+1;
y = [1, -1, -1, 1, 1]+1;
original_shape = [x',y'];
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
subplot(2,2,1)
plot_shape(original_shape,'bx-')
 
subplot(2,2,2)
theta = pi/4;
rotate = [cos(theta) -sin(theta); 
sin(theta) cos(theta)]

rotated_shape = original_shape*rotate;
plot_shape(rotated_shape,'rx-')
 
subplot(2,2,3)
theta = pi/2;
rotate = [cos(theta) -sin(theta); 
    sin(theta) cos(theta)]
rotated_shape = original_shape*rotate;
plot_shape(rotated_shape,'rx-')
 
subplot(2,2,4)
theta = pi*2/3;
rotate = [cos(theta) -sin(theta); 
    sin(theta) cos(theta)]
rotated_shape = original_shape*rotate;
plot_shape(rotated_shape,'rx-')
 
%% Rotate first, then scale
figure(fig_i)
fig_i = fig_i + 1;
subplot(2,2,1)
plot_shape(original_shape,'bx-'); hold on
theta = pi/6;
R = [cos(theta) -sin(theta); 
    sin(theta) cos(theta)];
R_shape = original_shape*R;
plot_shape(R_shape,'rx-')
 
subplot(2,2,2)
S = [1/2,0; 0, 2];
R_S_shape = R_shape*S;
plot_shape(R_S_shape,'rx-')
 
% Scale first, then rotate
 
subplot(2,2,3)
plot_shape(original_shape,'bx-'); hold on
S_shape = original_shape*S;
plot_shape(S_shape,'rx-')
 
subplot(2,2,4)
S_R_shape = S_shape*R;
plot_shape(S_R_shape,'rx-')
 
%% Reflect
x = [1, 0, -1, -1, 1]+1.5;
y = [1, -1, -1, 1, 1]+0.5;
original_shape = [x',y'];
 
figure(fig_i)
fig_i = fig_i + 1;
subplot(2,2,1)
plot_shape(original_shape,'bx-'); hold on
lx = 1; ly = 1;

reflect = 1/(lx^2 + ly^2)*[lx^2 - ly^2, 2*lx*ly; 
    2*lx*ly, ly^2 - lx^2];
reflected_shape = original_shape*reflect;
plot_shape(reflected_shape,'rx-')
 
 
subplot(2,2,2)
plot_shape(original_shape,'bx-'); hold on
lx = 1; ly = -1;
reflect = 1/(lx^2 + ly^2)*[lx^2 - ly^2, 2*lx*ly; 
    2*lx*ly, ly^2 - lx^2];
reflected_shape = original_shape*reflect;
plot_shape(reflected_shape,'rx-')
 
subplot(2,2,3)
plot_shape(original_shape,'bx-'); hold on
lx = 1; ly = 2;
reflect = 1/(lx^2 + ly^2)*[lx^2 - ly^2, 2*lx*ly; 
    2*lx*ly, ly^2 - lx^2];
reflected_shape = original_shape*reflect;
plot_shape(reflected_shape,'rx-')
 
 
subplot(2,2,4)
plot_shape(original_shape,'bx-'); hold on
lx = 1; ly = -2;
reflect = 1/(lx^2 + ly^2)*[lx^2 - ly^2, 2*lx*ly; 
    2*lx*ly, ly^2 - lx^2];
reflected_shape = original_shape*reflect;
plot_shape(reflected_shape,'rx-')
 
%% Orthogonal projection
x = [1, 0, -1, -1, 1]+3;
y = [1, -1, -1, 1, 1];
original_shape = [x',y'];
 
figure(fig_i)
fig_i = fig_i + 1;
subplot(2,2,1)
plot_shape(original_shape,'bx-'); hold on
x = [-4:4];
ux = 1; uy = 1;
y = uy/ux*x;
plot(x,y,'k'); hold on
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points = original_shape*project;
plot_shape(projected_points,'xr'); hold on
xh=[original_shape(:,1) projected_points(:,1)];
yh=[original_shape(:,2) projected_points(:,2)];
plot(xh',yh','k')
 
subplot(2,2,2)
plot_shape(original_shape,'bx-'); hold on
x = [-4:4];
ux = 1; uy = -1;
y = uy/ux*x;
plot(x,y,'k'); hold on
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points = original_shape*project;
plot_shape(projected_points,'xr'); hold on
xh=[original_shape(:,1) projected_points(:,1)];
yh=[original_shape(:,2) projected_points(:,2)];
plot(xh',yh','k')
 
subplot(2,2,3)
plot_shape(original_shape,'bx-'); hold on
x = [-4:4];
ux = 1; uy = 2;
y = uy/ux*x;
plot(x,y,'k'); hold on
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points = original_shape*project;
plot_shape(projected_points,'xr'); hold on
xh=[original_shape(:,1) projected_points(:,1)];
yh=[original_shape(:,2) projected_points(:,2)];
plot(xh',yh','k')
 
subplot(2,2,4)
plot_shape(original_shape,'bx-'); hold on
x = [-4:4];
ux = 1; uy = -4;
y = uy/ux*x;
plot(x,y,'k'); hold on
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points = original_shape*project;
plot_shape(projected_points,'xr'); hold on
xh=[original_shape(:,1) projected_points(:,1)];
yh=[original_shape(:,2) projected_points(:,2)];
plot(xh',yh','k')
 
 
function plot_shape(points,style)
plot(points(:,1),points(:,2),style,...
    'LineWidth',1)
xlim([-4,4]); ylim([-4,4]); 
xticks([-4:4]);yticks([-4:4]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
grid on; 
% grid minor
end 
