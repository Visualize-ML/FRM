% B3_Ch7_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
t_current = repmat(datenum('30-Apr-2008'),[6 1]);
T_maturity = [datenum('07-Mar-2009');datenum('07-Mar-2011');...
datenum('07-Mar-2013');datenum('07-Sep-2016');...
datenum('07-Mar-2025');datenum('07-Mar-2036')];
% 6 bonds in the market
tau_array = datenum(T_maturity - t_current)/365; 
% between(t_current,T_maturity,'years')
 
CleanPrice = [100.1;100.1;100.8;96.6;103.3;96.3];
CouponRate = [0.0400;0.0425;0.0450;0.0400;0.0500;0.0425];
Instruments = [t_current T_maturity CleanPrice CouponRate];
tenor_points = datenum('30-Apr-2008'):180:datenum('07-Mar-2036');
Yield = bndyield(CleanPrice,CouponRate,t_current,T_maturity);

tenors_array = datenum(tenor_points - t_current)/365; 
 
NSModel = IRFunctionCurve.fitNelsonSiegel...
    ('Zero',datenum('30-Apr-2008'),Instruments);
 
NSModel.Parameters
% [Beta0,Beta1,Beta2,lambda1]
 
interpolated_IR = getParYields(NSModel, tenor_points);
% Get par yields for input dates for IRFunctionCurve
 
figure(1)
plot(tenors_array(1,:), interpolated_IR,'b')
hold on
scatter(tau_array,Yield,'or');
box off; xlabel('Tenor [year]')
ylabel('Zero rate')

SVEModel = IRFunctionCurve.fitSvensson...
    ('Zero',datenum('30-Apr-2008'),Instruments);
 
SVEModel.Parameters
% [Beta0,Beta1,Beta2,Beta3,lambda,lambda].
 
interpolated_IR = getParYields(SVEModel, tenor_points);
% Get par yields for input dates for IRFunctionCurve
 
figure(2)
plot(tenors_array(1,:), interpolated_IR,'b')
hold on
scatter(tau_array,Yield,'or');
box off; xlabel('Tenor [year]')
ylabel('Zero rate')

CustomKnots = augknt(0:5:30,4);
% use the AUGKNT function to construct the knots 
% for a cubic spline at every 5 years
Smooth_spline_Model = IRFunctionCurve.fitSmoothingSpline...
    ('Zero',datenum('30-Apr-2008'),Instruments,...
    @(t) 1000,'knots', CustomKnots);
 
Smooth_spline_Model.Parameters
% [Beta0,Beta1,Beta2,Beta3,lambda,lambda].
 
interpolated_IR = getParYields(Smooth_spline_Model, tenor_points);
% Get par yields for input dates for IRFunctionCurve
 
figure(3)
plot(tenors_array(1,:), interpolated_IR,'b')
hold on
scatter(tau_array,Yield,'or');
box off; xlabel('Tenor [year]')
ylabel('Zero rate')
