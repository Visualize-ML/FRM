% B3_Ch7_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% STEP 0: generate original data
clear all; close all; clc
 
rho = 0.75;
std1 = 1; std2 = 2;
cov12 = std1*std2*rho;
SIGMA = [std1^2, cov12
         cov12 , std2^2];
 
L_matrix = chol(SIGMA);
 
LL = 200;
D = randn(LL,2);
D = D*L_matrix+repmat([1,2],LL,1);
 
figure(1)
c = linspace(1,10,length(D));
scatter(D(:,1), D(:,2),[],c); hold on
X_mean = mean(D);
plot(X_mean(1),X_mean(2),'rx','MarkerSize', 12)
daspect([1,1,1]); axis equal
xlabel('x_1'); ylabel('x_2')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-4,6]); ylim([-3,7]); 
 
%% STEP 1: center the original data
 
D_centered = bsxfun(@minus, D, mean(D)); 
% demeaned
% Center the data using mean values
 
figure(2)
scatter(D_centered(:,1), D_centered(:,2),[],c); hold on
plot(0,0,'rx','MarkerSize', 12)
daspect([1,1,1]); axis equal
xlabel('z_1'); ylabel('z_2')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-5,5]); ylim([-5,5]); 
% C = cov(X);
 
%% STEP 2: Calculate eigenvectors and eigenvalues
 
[eigenVectors,eigenValues] = eig(cov(D_centered));
% eigenvectors V and eigenvalues D of the covariance matrix C
 
figure(3)
scatter(D_centered(:,1),D_centered(:,2),[],c); hold on
line([0 eigenVectors(1,1)],...
    [0 eigenVectors(2,1)],'Color','r'); hold on
line([0 eigenVectors(1,2)],...
    [0 eigenVectors(2,2)],'Color','r'); hold on
plot(0,0,'rx','MarkerSize', 12)
% eigenvectors are unit vectors and orthogonal
 
axis equal
xlabel('z_1'); ylabel('z_2')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-5,5]); ylim([-5,5]); 
 
norm(eigenVectors(:,1))
norm(eigenVectors(:,2))
%% STEP 3: rotate the centered data
[~,index] = sort(diag(eigenValues),'descend');
eigenVectors_sorted = eigenVectors(:,index);
D_prime = D_centered * eigenVectors_sorted;
 
figure(4)
scatter(D_prime(:,1),D_prime(:,2),[],c); hold on
plot(0,0,'rx','MarkerSize', 12)
axis equal
xlabel('PC_1'); ylabel('PC_2')
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
xlim([-5,5]); ylim([-5,5]); 
 
corrcoef(D_prime)
variance = eigenValues/sum(eigenValues(:))
% obtain variances by normalizing the eigenvalues
 
[coeff,D_prime3,latend,tsd,variance2] = pca(D)
% variance for the two principal components

