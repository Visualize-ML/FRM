% B3_Ch7_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
% tickers list: https://en.wikipedia.org/wiki/List_of_S%26P_500_companies
% GM: General Motors
% F: Ford Motor
% MCD: McDonald's Corp.
% IBM:  International Business Machines
 
stocks = {'GM','F','MCD','IBM'};
 
price = hist_stock_data('01012017','01012019',stocks);
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
GM_price = price(1).AdjClose;
Ford_price = price(2).AdjClose;
McDon_price = price(3).AdjClose;
IBM_price = price(4).AdjClose;
 
GM_daily_log_return=diff(log(GM_price));
% also price2ret can be used
Ford_daily_log_return=diff(log(Ford_price));
McDon_daily_log_return=diff(log(McDon_price));
IBM_daily_log_return=diff(log(IBM_price));
log_returns = [GM_daily_log_return, Ford_daily_log_return,...
    McDon_daily_log_return,IBM_daily_log_return];
 
%% plot the original data
 
stocks_label = ['GM  ';'FORD';'MCD ';'IBM '];
 
figure(1)
boxplot(log_returns,'Orientation','horizontal',...
    'Labels',stocks_label)
xlabel('Log returns'); box off
%% Compute principal components
 
C = corr(log_returns,log_returns);
% check pairwise correlation
 
% When all variables are in the same unit,
% it is appropriate to compute principal components for raw data.
% When the variables are in different units or
% the difference in the variance of different columns is substantial,
% scaling of the data or use of weights
% is often preferable.
 
% Perform the principal component analysis by
% using the inverse variances of the ratings as weights.
 
var_weights = 1./var(log_returns);
[wcoeff,score,latent,tsquared,explained,mu] = pca(log_returns,...
    'VariableWeights',var_weights);
% Or equivalently:
%
% [wcoeff,score,latent,tsquared,explained] = pca(ratings,...
% 'VariableWeights','variance');
 
 
% The first three principal component coefficient vectors are:
c3 = wcoeff(:,1:3);
 
% These coefficients are weighted,
% hence the coefficient matrix is not orthonormal.
%
% Transform coefficients.
% Transform the coefficients so that they are orthonormal.
 
coefforth = inv(diag(std(log_returns)))*wcoeff;
 
I = coefforth'*coefforth;
I(1:3,1:3)
 
% Component scores.
% The second output, score, contains the coordinates of
% the original data in the new coordinate system
% defined by the principal components.
% The score matrix is the same size as
% the input data matrix. You can also obtain the
% component scores using the orthonormal coefficients
% and the standardized ratings as follows.
 
cscores = zscore(log_returns)*coefforth;
 
% Plot component scores
% Visualize both the orthonormal principal component coefficients
% for each variable and the principal component scores for
% each observation in a single plot.
 
figure(2)
biplot(coefforth(:,1:2),'Scores',score(:,1:2),...
    'Varlabels',stocks_label);
% stocks = {'GM','F','MCD','IBM'};
box off; grid off
daspect([1 1 1])
 
%% Create scree plot
% Make a scree plot of the percent variability explained
% by each principal component.
 
figure(3)
% pareto(explained)
bar(explained,0.4); hold on
text([1:length(explained)], explained, num2str(explained,'%0.2f'),...
    'HorizontalAlignment','center','VerticalAlignment','bottom')
box off
cum_var = cumsum(explained);
plot(cum_var,'-x'); hold on
unexplained_variance = 100 - cum_var;
plot(unexplained_variance,'-o')
text([1:length(cum_var)], cum_var, num2str(cum_var,'%0.2f'),...
    'HorizontalAlignment','center','VerticalAlignment','bottom')
xlabel('Principal components')
ylabel('Explained/cumulative variance [%]')
box off
 
 
%% Create a three-dimensional bi-plot.
% You can also make a bi-plot in three dimensions.
 
figure(4)
biplot(coefforth(:,1:3),'Scores',score(:,1:3),...
    'Varlabels',stocks_label);
box off; grid off
daspect([1 1 1]); view([45 30]);
 
figure(5)
subplot(2,2,1)
biplot(coefforth(:,1:3),'Scores',score(:,1:3),...
    'Varlabels',stocks_label);
box off; grid off; daspect([1 1 1]); 
daspect([1 1 1]); view([45 30]);
 
subplot(2,2,2)
biplot(coefforth(:,1:3),'Scores',score(:,1:3),...
    'Varlabels',stocks_label); daspect([1 1 1]); 
view([0,0,1]); box off; grid off
 
subplot(2,2,3)
biplot(coefforth(:,1:3),'Scores',score(:,1:3),...
    'Varlabels',stocks_label); daspect([1 1 1]); 
view([0,1,0]); box off; grid off
 
subplot(2,2,4)
biplot(coefforth(:,1:3),'Scores',score(:,1:3),...
    'Varlabels',stocks_label);daspect([1 1 1]); 
view([1,0,0]); box off; grid off
