% B3_Ch7_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Interest rate data
clc; close all; clear all
 
url = 'https://fred.stlouisfed.org/';
c = fred(url);
 
startdate = '01/01/2017';
% beginning of date range for historical data
enddate = '01/01/2019'; % to be updated
data_IR = [];
series_nodes = {'DGS1MO'; 'DGS3MO'; 'DGS6MO';...
    'DGS1'; 'DGS2'; 'DGS3'; 'DGS5';...
    'DGS10'; 'DGS20'; 'DGS30';};
 
for i = 1:length(series_nodes)
    
    series = series_nodes(i);
    DATA = fetch(c,series,startdate,enddate);
    data_IR(:,i) = DATA.Data(:,2);
    
end
 
data_IR(any(isnan(data_IR),2),:) = [];
data_IR = diff(data_IR)/100;
 
IR_categories = ['1M  ';'3M  ';'6M  ';'1Yr '; '2Yr ';...
    '3Yr ';'5Yr ';'10Yr';'20Yr';'30Yr'];
%% plot the original data
figure(1)
ax = gca;
boxplot(data_IR,'Orientation','horizontal',...
    'Labels',IR_categories)
xlabel('Daily difference'); box off
ax.XAxis.Exponent = 0;
%% Compute principal components
 
var_weights = 1./var(data_IR);
[wcoeff,score,latent,tsquared,explained] = pca(data_IR,...
    'VariableWeights',var_weights);
 
coefforth = inv(diag(std(data_IR)))*wcoeff;
 
figure(2)
original_dim = 1:10;
xticks(original_dim)
xticklabels({'1M','3M','6M','1Yr','2Yr',...
    '3Yr','5Yr','10Yr','20Yr','30Yr'})
plot(original_dim, coefforth(:,1),'r'); hold on
plot(original_dim, coefforth(:,2),'color',[0,200,75]./255); hold on
plot(original_dim, coefforth(:,3),'b')
legend('PC1','PC2','PC3'); box off
xlabel('Tenors'); ylabel('Component')
legend boxoff
 
 
%% Create scree plot
 
figure(3)
% pareto(explained)
bar(explained,0.4); hold on
text([1:length(explained)], explained, num2str(explained,'%0.2f'),...
    'HorizontalAlignment','center','VerticalAlignment','bottom')
box off
cum_var = cumsum(explained);
plot(cum_var,'-x')
text([1:length(cum_var)], cum_var, num2str(cum_var,'%0.2f'),...
    'HorizontalAlignment','center','VerticalAlignment','bottom')
xlabel('Principal components')
ylabel('Explained/cumulative variance [%]')
box off
 
%% Visualize the results
 
figure(4)
biplot(coefforth(:,1:2),'Scores',score(:,1:2),...
    'Varlabels',IR_categories);
box off; grid off
daspect([1 1 1])
 
 
%% moving window
L = 252;
 
figure(5)
 
for i = 1:length(data_IR) - 252 + 1
    
    data_IR_window = data_IR(i:i+L-1,:);
    var_weights = 1./var(data_IR_window);
    [wcoeff,score,latent,tsquared,explained] = pca(data_IR_window,...
        'VariableWeights',var_weights);
    coefforth = inv(diag(std(data_IR)))*wcoeff;
    
    original_dim = 1:10;
    xticks(original_dim)
    xticklabels({'1M','3M','6M','1Yr','2Yr',...
        '3Yr','5Yr','10Yr','20Yr','30Yr'})
    plot(original_dim, coefforth(:,1),'r'); hold on
    plot(original_dim, coefforth(:,2),'color',[0,200,75]./255); hold on
    plot(original_dim, coefforth(:,3),'b')
    box off
    xlabel('Tenors'); ylabel('Component')
    
end
