% B3_Ch7_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url); 
series1 = 'SP500';
series2 = 'NIKKEI225'; %
startdate = '09/09/2018';
% beginning of date range for historical data
enddate = '09/09/2019'; % to be updated
% ending of date range for historical data
 
d1 = fetch(c,series1,startdate,enddate);
d2 = fetch(c,series2,startdate,enddate);
% display description of data structure
 
SP500 = d1.Data(:,2); date_series = d1.Data(:,1);
NIKKEI225 = d2.Data(:,2);
 
SP500_non_NaN_index = ~isnan(SP500);
NIKKEI225_non_NaN_index = ~isnan(NIKKEI225);
combined_index = and(SP500_non_NaN_index,NIKKEI225_non_NaN_index);
SP500_rm_NaN = SP500(combined_index);
NIKKEI225_rm_NaN = NIKKEI225(combined_index);
date_series_rm_NaN = date_series(combined_index);
 
[X1,~] = tick2ret (SP500_rm_NaN,...
    date_series_rm_NaN,'Continuous');
 
[X2,~] = tick2ret (NIKKEI225_rm_NaN,...
    date_series_rm_NaN,'Continuous');
date_series_rm_NaN2 = date_series_rm_NaN(2:end);
%% Plot two levels
 
index = 1;
figure(index); index = index + 1;
subplot(2,1,1)
plot(date_series_rm_NaN, SP500_rm_NaN)
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(SP500_rm_NaN)*0.9,max(SP500_rm_NaN)*1.1])
xlabel('Time'); ylabel('S&P 500')
set(gcf,'color','white'); box off
 
subplot(2,1,2)
plot(date_series_rm_NaN, NIKKEI225_rm_NaN)
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(NIKKEI225_rm_NaN)*0.9,max(NIKKEI225_rm_NaN)*1.1])
xlabel('Time'); ylabel('NIKKEI 225')
set(gcf,'color','white'); box off
ax = gca; ax.YAxis.Exponent = 0;
 
%% Plot two log returns: X1 and X2
 
figure(index); index = index + 1;
subplot(2,1,1)
plot(date_series_rm_NaN2, X1,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(X1)*1.1,max(X1)*1.1])
xlabel('Time'); ylabel('Log returns of S&P 500, X_1')
set(gcf,'color','white'); box off
 
subplot(2,1,2)
plot(date_series_rm_NaN2, X2,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(X2)*1.1,max(X2)*1.1])
xlabel('Time'); ylabel('Log returns of NIKKEI 225, X_2')
set(gcf,'color','white'); box off

% B3_Ch7_2_B.m

%% Histogram of log returns
 
figure(index); index = index + 1;
X1_mean = mean(X1); 
X2_mean = mean(X2); 
X1_std = std(X1); 
X2_std = std(X2); 
X1_skew = skewness(X1); 
X2_skew = skewness(X2); 
X1_kurt = kurtosis(X1); 
X2_kurt = kurtosis(X2); 
 
subplot(1,2,1)
histfit(X1,20,'normal'); hold on
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', yt/numel(X1))
ylabel('PDF'); xlabel('X_1')
set(gcf,'color','white'); box off
line_1 = ['mean(X1) = ',num2str(X1_mean),...
    '; std(X1) = ',num2str(X1_std)];
line_2 = ['skew(X1) = ',num2str(X1_skew),...
    '; kurt(X1) = ',num2str(X1_kurt)];
title({line_1,line_2})
 
subplot(1,2,2)
histfit(X2,20,'normal'); hold on
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', yt/numel(X1))
ylabel('PDF'); xlabel('X_2')
set(gcf,'color','white'); box off
line_1 = ['mean(X2) = ',num2str(X2_mean),...
    '; std(X2) = ',num2str(X2_std)];
line_2 = ['skew(X2) = ',num2str(X2_skew),...
    '; kurt(X2) = ',num2str(X2_kurt)];
title({line_1,line_2})
 
figure(index); index = index + 1;
subplot(1,2,1)
histfit(X1,20,'kernel'); hold on
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', yt/numel(X1))
ylabel('PDF'); xlabel('X_1')
set(gcf,'color','white'); box off
 
subplot(1,2,2)
histfit(X2,20,'kernel'); hold on
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', yt/numel(X1))
ylabel('PDF'); xlabel('X_2')
set(gcf,'color','white'); box off
 
 
%% CDF of log returns
 
figure(index); index = index + 1;
subplot(1,2,1)
histogram(X1,20,'Normalization','CDF')
ylabel('CDF'); xlabel('X_1')
set(gcf,'color','white'); box off
 
subplot(1,2,2)
histogram(X2,20,'Normalization','CDF')
ylabel('CDF'); xlabel('X_2')
set(gcf,'color','white'); box off
 
%% Empirical and fitted CDF
 
figure(index); index = index + 1;
subplot(1,2,1)
[CDF_empirical_1,xi_1] = ecdf(X1);
x_grid = linspace(min(xi_1),max(xi_1),100);
CDF_fitted_1 = ksdensity(X1,x_grid,'function','cdf');
plot(x_grid,CDF_fitted_1,'b'); hold on
stairs(xi_1,CDF_empirical_1,'r');
hold off; xlabel('X_1'); ylabel('Empirical CDF');
set(gcf,'color','white'); box off
legend('Fitted CDF','Empirical CDF','location','best');
 
subplot(1,2,2)
[CDF_empirical_2,xi_2] = ecdf(X2);
x_grid = linspace(min(xi_2),max(xi_2),100);
CDF_fitted_2 = ksdensity(X2,x_grid,'function','cdf');
plot(x_grid,CDF_fitted_2,'b'); hold on
stairs(xi_2,CDF_empirical_2,'r');
hold off;
xlabel('X_2'); ylabel('Empirical CDF');
set(gcf,'color','white'); box off
legend('Fitted CDF','Empirical CDF','location','best');

% B3_Ch7_2_C.m

%% X1 to U1 mapping
 
U_1 = ksdensity(X1,X1,'function','cdf');
U_2 = ksdensity(X2,X2,'function','cdf');
 
figure(index); index = index + 1;
subplot(2,2,1)
plot(date_series_rm_NaN2, X1,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(X1)*1.1,max(X1)*1.1]); box off
xlabel('Time'); ylabel('Log returns, X_1')
 
subplot(2,2,3)
plot(date_series_rm_NaN2, U_1,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(U_1)*1.1,max(U_1)*1.1])
xlabel('Time'); ylabel('U_1')
set(gcf,'color','white'); box off
 
subplot(2,2,[2,4])
plot(X1,U_1,'.')
xlabel('X_1'); ylabel('U_1'); box off
 
%% X2 to U2 mapping
 
figure(index); index = index + 1;
subplot(2,2,1)
plot(date_series_rm_NaN2, X2,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(X2)*1.1,max(X2)*1.1]); box off
xlabel('Time'); ylabel('Log returns, X_2')
 
subplot(2,2,3)
plot(date_series_rm_NaN2, U_2,'.'); hold on
plot(date_series_rm_NaN2, zeros(size(date_series_rm_NaN2)),'r')
datetick('x','mmm yyyy','keeplimits')
xlim([date_series(1)-1,date_series(end)+1])
ylim([min(U_2)*1.1,max(U_2)*1.1])
xlabel('Time'); ylabel('U_2')
set(gcf,'color','white'); box off
 
subplot(2,2,[2,4])
plot(X2,U_2,'.')
xlabel('X_2'); ylabel('U_2'); box off
 
%% Histograms of U1 and U2
 
figure(index); index = index + 1;
 
subplot(1,2,1)
nbins = 10; % number of buckets or bins
h = histogram(U_1,nbins);
h.Normalization = 'probability';
 
ylabel('Probability'); xlabel('U_1')
set(gcf,'color','white'); box off
 
subplot(1,2,2)
nbins = 10; % number of buckets or bins
h = histogram(U_2,nbins);
h.Normalization = 'probability';
ylabel('Probability'); xlabel('U_2')
set(gcf,'color','white'); box off

% B3_Ch7_2_D.m

%% Study of comovement
% Scatterhist of X and PDF
 
figure(index); index = index + 1;
scatterhist(X1,X2,'NBins',20,'Kernel','overlay')
set(get(gca,'children'),'marker','.')
xlabel('X_1')
ylabel('X_2')
 
%% Scatterhist of X and CDF
figure(index); index = index + 1;
 
subplot(4,4,[2:4 6:8 10:12]); % Top right square
 
plot(X1,X2,'.')
set(gcf,'color','white')
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
[CDF_empirical_2,xi_2] = ecdf(X2);
stairs(xi_2,CDF_empirical_2,'r');
xlim(yl); view(90,-90); box off;
xlabel('X_2'); ylabel('U_2')
hYLabel = get(gca,'XLabel');
set(hYLabel,'rotation',0)
 
subplot(4,4,[14:16]); % Btm right
[CDF_empirical_1,xi_1] = ecdf(X1);
stairs(xi_1,CDF_empirical_1,'r');
xlim(xl); box off
xlabel('X_1'); ylabel('U_1')
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0)
 
%% Scatterhist of U and PDF
figure(index); index = index + 1;
scatterhist(U_1,U_2,'NBins',20)
set(get(gca,'children'),'marker','.')
xlabel('U_1'); ylabel('U_2')
 
%% Scatterhist of U and CDF
figure(index); index = index + 1;
subplot(4,4,[2:4 6:8 10:12]); % Top right square
 
scatter(U_1,U_2,'.')
set(gcf,'color','white')
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
[CDF_empirical_2,xi_2] = ecdf(U_2);
stairs(xi_2,CDF_empirical_2,'r');
xlim(yl); view(90,-90); box off;
xlabel('U_2'); ylabel('CDF')
 
subplot(4,4,[14:16]); % Btm right
[CDF_empirical_1,xi_1] = ecdf(U_1);
stairs(xi_1,CDF_empirical_1,'r');
xlim(xl); box off
xlabel('U_1'); ylabel('CDF')

% B3_Ch7_2_E.m

%% Kernel copula density contour
 
[b,Copula_PDF_fitted,c_u1,c_u2]=kde2d([U_1,U_2],20,[0,0],[1,1]);
% kde2d can be downloaded from:
% https://www.mathworks.com/matlabcentral/
% fileexchange/17204-kernel-density-estimation
figure(index); index = index + 1;
subplot(1,2,1)
plot(U_1,U_2,'.'); hold on
contour(c_u1,c_u2,Copula_PDF_fitted,[0:0.1:5],'ShowText','on')
xlabel('U_1'); ylabel('U_2')
 
subplot(1,2,2)
mesh(c_u1,c_u2,Copula_PDF_fitted)
xlabel('U_1'); ylabel('U_2'); zlabel('Fitted PDF')
grid off; box off
%% Copula fitting, copula PDF and copula CDF
rng default  % For reproducibility
% [Rho,nu] = copulafit('t',[U_1 U_2],'Method','ML')
alpha = copulafit('frank',[U_1 U_2],'Method','ML');
 
u = linspace(0+0.01,1-0.01,50);
[u1,u2] = meshgrid(u,u);
 
% Copula_PDF = copulapdf('t',[u1(:),u2(:)],Rho,nu);
Copula_PDF = copulapdf('frank',[u1(:),u2(:)],alpha);
Copula_PDF = reshape(Copula_PDF,size(u1));
% Copula_CDF = copulacdf('t',[u1(:),u2(:)],Rho,nu);
% Copula_CDF = reshape(Copula_CDF,size(u1));
 
figure(index); index = index + 1;
subplot(1,2,1)
contour(u1,u2,Copula_PDF,[0:0.1:5]);
xlabel('U1'); ylabel('U2')
 
subplot(1,2,2)
mesh(u1,u2,Copula_PDF);
xlabel('U1'); ylabel('U2'); zlabel('Copula PDF')
grid off; box off

% B3_Ch7_2_F.m

%% Simulations
num_sim = 5000;
% simulated = copularnd('t',Rho,nu,num_sim);
simulated = copularnd('frank',alpha,num_sim);
sim_U1 = simulated(:,1);
sim_U2 = simulated(:,2);
 
figure(index); index = index + 1;
scatterhist(sim_U1,sim_U2)
set(get(gca,'children'),'marker','.')
xlabel('Simulated U_1')
ylabel('Simulated U_2')
 
%% Simulated X
 
sim_X1 = ksdensity(X1,sim_U1,'function','icdf');
sim_X2 = ksdensity(X2,sim_U2,'function','icdf');
 
figure(index); index = index + 1;
scatterhist(sim_X1,sim_X2,'NBins',20,'Kernel','overlay')
set(get(gca,'children'),'marker','.')
xlabel('Simulated X_1')
ylabel('Simulated X_2')
 
%% Compare distributions
 
[h,p,ks2stat] = kstest2(X1,sim_X1)
[h,p,ks2stat] = kstest2(X2,sim_X2)
 
% h = kstest2(x1,x2) returns a test decision for the null hypothesis 
% that the data in vectors x1 and x2 are from the same continuous distribution, 
% using the two-sample Kolmogorov-Smirnov test. 
 
% The alternative hypothesis is that x1 and x2 
% are from different continuous distributions. 
% The result h is 1 if the test rejects the null hypothesis 
% at the 5% significance level, 
% and 0 otherwise (fails to reject the null hypothesis).
 
figure(index); index = index + 1;
subplot(1,2,1)
[CDF_empirical_1,xi_1] = ecdf(sim_X1);
stairs(xi_1,CDF_empirical_1,'r'); hold on
[CDF_empirical_1,xi_1] = ecdf(X1);
stairs(xi_1,CDF_empirical_1,'b'); hold on
xlabel('X_1 and simulated X_1')
ylabel('Emperical CDF'); box off
legend('Simulated','Emperical','Location','Best')
 
subplot(1,2,2)
[CDF_empirical_2,xi_2] = ecdf(sim_X2);
stairs(xi_2,CDF_empirical_2,'r'); hold on
[CDF_empirical_2,xi_2] = ecdf(X1);
stairs(xi_2,CDF_empirical_2,'b'); hold on
xlabel('X_2 and simulated X_2')
ylabel('Emperical CDF'); box off
legend('Simulated','Emperical','Location','Best')
