% B3_Ch7_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% linear regression and stress test
 
% Prepare data and download stock prices from Yahoo Finance
 
clc; close all; clear all
 
price = hist_stock_data('09092018','09092019'...
    ,'GOOG','AAPL','F','GM','IBM','^GSPC','^DJI');
% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, ...
    'InputFormat', 'yyyy-MM-dd');
GOOG_S = price(1).AdjClose;
AAPL_S = price(2).AdjClose;
F_S    = price(3).AdjClose;
GM_S   = price(4).AdjClose;
IBM_S  = price(5).AdjClose;
SP500_S  = price(6).AdjClose;
Dow_J_S  = price(7).AdjClose;
 
GOOG_log_r = diff(log(GOOG_S));
AAPL_log_r = diff(log(AAPL_S));
F_log_r    = diff(log(F_S));
GM_log_r   = diff(log(GM_S));
IBM_log_r  = diff(log(IBM_S));
SP500_log_r = diff(log(SP500_S));
Dow_J_log_r = diff(log(Dow_J_S));
 
S_baseline = [GOOG_S(end), AAPL_S(end), ...
    F_S(end), GM_S(end),IBM_S(end),...
    SP500_S(end),Dow_J_S(end)];
shares = [1,5,100,20,10];
% calculate position PVs and weights
PV_baseline = sum(S_baseline(1:5).*shares);
 
Returns = [GOOG_log_r, AAPL_log_r, ...
    F_log_r, GM_log_r, IBM_log_r,  ...
    SP500_log_r,Dow_J_log_r];
 
SIGMA = cov(Returns);
 
SIGMA_XX = SIGMA(end-1:end,end-1:end);
SIGMA_Xy = SIGMA(end-1:end,1:end-2);
 
PV_i_base = S_baseline(1:5).*shares;
 
index = 1;
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = PV_i_base;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
txt = {'GOOG: ';'AAPL: ';'FORD: ';'GM: ';'IBM: '};
combinedtxt = strcat(txt,percentValues);
title(['Baseline PV = ',num2str(PV_baseline),' USD'])
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
 
subplot(1,2,2)
 
bar(PV_i_base,'b')
text([1:length(PV_i_base)], PV_i_base', num2str(PV_i_base','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Market value [USD]'); box off; grid off
name = {'GOOG';'AAPL';'FORD';'GM';'IBM'};
set(gca,'xticklabel',name)
xtickangle(45)
 
figure(index); index = index + 1;
 
xvalues = {'GOOG','AAPL','FORD','GM','IBM','S&P 500','Dow Jones'};
yvalues = xvalues;
heatmap(xvalues,yvalues,SIGMA*1000)
title('Variance-covariance matrix, *0.001')
 
shocks_X = [-0.15,-0.1];
shocks_X = log(shocks_X + 1);
 
shocks_y = shocks_X*SIGMA_XX^(-1)*SIGMA_Xy
 
S_stressed = S_baseline(1:5).*exp(shocks_y);
S_stressed(6:7) = S_baseline(6:7).*exp(shocks_X);
 
percentage_drops = (S_stressed - S_baseline)./S_baseline
figure(index); index = index + 1;
for i = 1:2
    subplot(1,2,i)
    name_i = xvalues(i+5);
    bar([S_baseline(i+5); S_stressed(i+5)]',0.5)
    ylabel('Stock index'); box off; grid off
    title(name_i)
    name = {'Baseline';'Stressed'};
    set(gca,'xticklabel',name)
    xtickangle(45)
    title(name_i)
    ax = gca;
    ax.YAxis.Exponent = 0;
    
end
 
figure(index); index = index + 1;
for i = 1:5
    subplot(1,5,i)
    name_i = xvalues(i);
    bar([S_baseline(i); S_stressed(i)])
    ylabel('Stock [USD]'); box off; grid off
    title(name_i)
    name = {'Baseline';'Stressed'};
    set(gca,'xticklabel',name)
    xtickangle(45)
    ax = gca;
    ax.YAxis.Exponent = 0;
    
end
 
PV_stressed = sum(S_stressed(1:5).*shares);
figure(index); index = index + 1;
bar([PV_baseline;PV_stressed],0.5)
ylabel('Market value [USD]')
values = [PV_baseline,PV_stressed];
 
text([1:2], values',...
    num2str(values','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
box off; grid off
name = {'Baseline';'Stressed'};
set(gca,'xticklabel',name)
 
PV_drop = (PV_stressed - PV_baseline)/PV_baseline
 
PV_i_stress = S_stressed(1:5).*shares;
 
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = PV_i_stress;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
txt = {'GOOG: ';'AAPL: ';'FORD: ';'GM: ';'IBM: '};
combinedtxt = strcat(txt,percentValues);
title(['Stressed PV = ',num2str(PV_stressed),' USD'])
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
 
subplot(1,2,2)
 
bar(PV_i_stress,'b')
text([1:length(PV_i_stress)], PV_i_stress', num2str(PV_i_stress','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Market value [USD]'); box off; grid off
name = {'GOOG';'AAPL';'FORD';'GM';'IBM'};
set(gca,'xticklabel',name)
xtickangle(45)
ylim([0,1500])
 
delta_PV_i = abs(PV_i_stress - PV_i_base);
figure(index); index = index + 1;
 
subplot(1,2,1)
Y = delta_PV_i;
p = pie(Y);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
txt = {'GOOG: ';'AAPL: ';'FORD: ';'GM: ';'IBM: '};
combinedtxt = strcat(txt,percentValues);
title(['\Delta PV = ',num2str(PV_baseline - PV_stressed),' USD'])
pText(1).String = combinedtxt(1);
pText(2).String = combinedtxt(2);
pText(3).String = combinedtxt(3);
pText(4).String = combinedtxt(4);
pText(5).String = combinedtxt(5);
 
subplot(1,2,2)
 
bar(delta_PV_i,'b')
text([1:length(delta_PV_i)], delta_PV_i', num2str(delta_PV_i','%0.1f'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
ylabel('Loss under stress test [USD]'); box off; grid off
name = {'GOOG';'AAPL';'FORD';'GM';'IBM'};
set(gca,'xticklabel',name)
xtickangle(45)
ylim([0,400])
