% B3_Ch9_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_8.m
close all; clear all; clc;
 
% BlsMC input paramters
S0 = 45;
K = 50;
r = 0.03;
T = 5/12;
sigma = 0.5;
 
% Number of random numbers
N = 2e5;
Ncv = 5e3;
 
% Use Matlab Black-Schole model
Price = blsprice(S0, K, r, T, sigma)
 
% Use BlsMC
randn('state', 0)
[P1, CI1] = BlsMC(S0,K,r,T,sigma,N);
CIB1=(CI1(2) - CI1(1))/P1;
 
[P2, CI2] = BlsMC_CVM(S0,K,r,T,sigma,N - Ncv, Ncv);
CIB2=(CI2(2) - CI2(1))/P2;
 
% Standard error analysis
randn('state',0)
V1 = zeros(1e3,1);
V2 = V1;
 
for i = 1:length(V1)
    V1(i) = BlsMC(S0,K,r,T,sigma,N);
    V2(i) = BlsMC_CVM(S0,K,r,T,sigma,N-Ncv, Ncv);
end
 
% Calculate standard error
std1=sqrt(mean((V1 - Price).^2));
std2=sqrt(mean((V2 - Price).^2));
 
% Plot
fig=figure;
hax=axes;
h=[];

h(1)=histogram(V2, 'normalization', 'pdf' );
hold on
h(2)=histogram(V1, 'normalization', 'pdf' );
hold on
h(3)=line([Price, Price], get(hax, 'YLim'),...
    'color', [1 0 0], 'linewidth', 2);
hold on
h(4)=line([Price-std2, Price-std2],...
    get(hax, 'YLim'),'color', [0 1 0],...
    'linewidth', 1, 'linestyle', '--');
hold on
h(5)=line([Price+std2, Price+std2],...
    get(hax, 'YLim'),'color', [0 1 0],...
    'linewidth', 1, 'linestyle', '--');
 
hold on
h(6)=line([Price-std1, Price-std1],...
    get(hax, 'YLim'),'color', [0 1 1],...
    'linewidth', 1, 'linestyle', '--');
 
h(7)=line([Price+std1, Price+std1],...
    get(hax, 'YLim'),'color', [0 1 1],...
    'linewidth', 1, 'linestyle', '--');
 
legend(h([1:4,6]), 'with Control Variate Method', ...
    'without Control Variate Method',...
    'True Mean',...
    'STD with Control Variate Method',...
    'STD without Control Variate Method')
 
% BlsMC
function [Price, CI] = BlsMC(S0,K,r,T,sigma,Num)
nuT = (r - 0.5*sigma^2)*T;
siT = sigma * sqrt(T);
 
Payoff_PV = exp(-r*T)*max(0, S0*exp(nuT+siT*randn(Num,1))-K);
 
[Price, VarPrice, CI] = normfit(Payoff_PV);
end
 

% BlsMC + Control Variates Method
function [Price, CI] = BlsMC_CVM(S0,K,r,T,sigma,N,Ncv)
nuT = (r - 0.5*sigma^2)*T;
siT = sigma * sqrt(T);
 
% Compute parameter "c"
StockVals = S0*exp(nuT+siT*randn(Ncv,1));
OptionVals = exp(-r*T) * max(0 , StockVals-K);
 
MatCov = cov(StockVals, OptionVals);
Yvar = S0^2 * exp(2*r*T) * (exp(T * sigma^2) - 1);

c = - MatCov(1,2) / Yvar;
 
% Compute result using control variate
Yavg = S0 * exp(r*T);
 
NewStockVals = S0*exp(nuT+siT*randn(N,1));
NewOptionVals = exp(-r*T) * max(0, NewStockVals-K);
 
ControlVars = NewOptionVals + c * (NewStockVals-Yavg);
 
[Price, VarPrice, CI] = normfit(ControlVars);
end
