% B3_Ch9_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_1.m
close all; clear all; clc;
 
% reset rand generator to replicate same experiment results
rand('state',0)
 
% calculate true integral value
syms x
I = double(int(exp(2*x),0,1));
 
% start with small sample size
Im1 = [];
for i =1:50    
    Im1(i) = mean(exp(2*rand(1,10)));    
end
 
% increase sample size
m = [10, 0.5e2, 1e2, 0.5e3, 1e3, 0.5e4, 1e4, 1e5, 1e6, 1e7];
Im2 = [];
 
for i = 1:length(m)
    Im2(i) = mean(exp(2*rand(1,m(i))));
end
 
% plot
figure
scatter(1:length(Im1), Im1);
hold on
line([1, length(Im1)], [I, I], 'color', 'red')
xlim([1, length(Im1)])
 
figure
scatter(1:length(m), Im2);
hold on
plot(Im2, '-.b');
hold on
line([1, length(m)], [I, I], 'color', 'red')
xlim([1, length(m)])


