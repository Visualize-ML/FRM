% B3_Ch9_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_6.m
close all; clear all; clc;
 
% Reset random number generator
rand('seed', 0); 
 
% Box-Muller
N=1e4;
U1 = rand(N, 1);
U2 = rand(N, 1);
 
R_squared = -2*log(U1);
theta = 2*pi*U2;
 
X1 = sqrt(R_squared).*cos(theta);
Y1 = sqrt(R_squared).*sin(theta);
 
figure(1)
subplot(1,2,1)
myplot(X1, 'X1')
subplot(1,2,2)
myplot(Y1, 'Y1')
 
% Integrate Box-Muller with Acceptance-Rejection
V1 = 2*U1-1;
V2 = 2*U2-1;
S = V1.^2+V2.^2;
 
coe = sqrt(-2*log(S(S<1))./S(S<1));
X2 = coe.*V1(S<1);
Y2 = coe.*V1(S<1);
 
figure(2)
subplot(1,2,1)
myplot(X2, 'X2')
subplot(1,2,2)
myplot(Y2, 'Y2')
 
function myplot(X, Xtext)
histogram(X, 'normalization', 'pdf' )
xlim([-4.5,4.5])
ylim([0,0.45])
xlabel(Xtext)
hold on
X = sort(X);
plot(X, normpdf(X), ...
    'linewidth', 2, 'linestyle', '-')
hold off
end
