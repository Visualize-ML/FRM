% B3_Ch9_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_9.m
close all; clear all; clc;
 
% Input paramters
S0 = 45;
K = 50;
r = 0.05;
T1 = 2/12;
T2 = 7/12;
sigma = 0.5;
 
% Number of random numbers
N1 = 1e2;
N2 = 1e2;
 
% Vanilla options
[Call, Put] = blsprice(S0,K,r,T2,sigma);
 
randn('state',0);
[Price, CI] = ...
    ChooserMC(S0,K,r,T1,T2,sigma,N1,N2);
 
rand('state',0);
[PriceCond, CICond] = ...
    ChooserMC_Cond(S0,K,r,T1,T2,sigma,N1*N2);
 
% Display results
fprintf(1,'Call = %f Put = %f\n', Call, Put);
 
fprintf(1,'MC -> Price = %f CI = (%f, %f) \n', ...
    Price, CI(1), CI(2));
 
fprintf(1,'Ratio = %6.4f%%\n', ...
    100*(CI(2)-CI(1))/Price);
 
fprintf(1,'MC+Cond -> Price = %f CI = (%f, %f) \n', ...
    PriceCond, CICond(1), CICond(2));
 
fprintf(1,'Ratio = %6.4f%%\n', ...
    100*(CICond(2)-CICond(1))/PriceCond);
 
 
function [Price, CI] = ChooserMC(S0,K,r,T1,T2,sigma,N1,N2)
% Compute auxiliary quantities outside the loop
DeltaT = T2-T1;
muT1 = (r-sigma^2/2)*T1;
muT2 = (r-sigma^2/2)*(T2-T1);
siT1 = sigma*sqrt(T1);
siT2 = sigma*sqrt(T2-T1);
 
% Vector to contain payoffs
DiscountedPayoffs = zeros(N1*N2, 1);
 
% Sample at time T1
Samples1 = randn(N1,1);
PriceT1 = S0*exp(muT1 + siT1*Samples1);
 
for k=1:N1
    Samples2 = randn(N2,1);
    PriceT2 = PriceT1(k)*exp(muT2 + siT2*Samples2);
   
    ValueCall = exp(-r*DeltaT)*mean(max(PriceT2-K, 0));
    ValuePut = exp(-r*DeltaT)*mean(max(K-PriceT2, 0));
    
    if ValueCall > ValuePut
        DiscountedPayoffs(1+(k-1)*N2:k*N2) = ...
            exp(-r*T2)*max(PriceT2-K, 0);
    else
        DiscountedPayoffs(1+(k-1)*N2:k*N2) = ...
            exp(-r*T2)*max(K-PriceT2, 0);
    end
    
end
 
[Price, dummy, CI] = normfit(DiscountedPayoffs);
 
end


function [Price, CI] = ChooserMC_Cond(S0,K,r,T1,T2,sigma,N)
muT1 = (r-sigma^2/2)*T1;
siT1 = sigma*sqrt(T1);
 
Samples = randn(N,1);
PriceT1 = S0*exp(muT1 + siT1*Samples);
 
[calls, puts] = blsprice(PriceT1,K,r,T2-T1,sigma);
 
Values = exp(-r*T1)*max(calls, puts);
 
[Price, dummy, CI] = normfit(Values);
 
end
