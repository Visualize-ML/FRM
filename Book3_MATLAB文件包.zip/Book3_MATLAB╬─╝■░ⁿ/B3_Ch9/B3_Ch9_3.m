% B3_Ch9_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_3.m
close all; clear all; clc;
 
% exponential distribution generator by inverse transform 
% method with uniform distribution 
 
rand('state',0)
exprnd(1)
 
rand('state',0)
-log(rand)

