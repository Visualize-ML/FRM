% B3_Ch9_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_10_C.m
close all; clear all; clc;

% Input paramters
N = 1e3;
L = 10;

% Plot g(x) vs h(x)
sk = (0:(1/L):(1-1/L)) + 1/(2*L);
hvals = sqrt(1 - sk.^2);
hvals_sum = sum(hvals);
gx = L*hvals./hvals_sum;

figure
bar(sk, gx, 'Barwidth', 1);
hold on
h = bar(sk, ones(1,10), 'Barwidth', 1);
set(h, 'FaceColor', 'none', 'EdgeColor', [1, 0, 0]);
legend('g(x)','f(x)')
xlabel('x')
ylabel('Probability Density')

M = 100;

% MC
rand('seed',0)
PI1=[];
for i=1:M
    PI1(i) = PIcal(N);
end

% MC + Importance Sampling
rand('seed',0)
PI2=[];
for i=1:M
    PI2(i) = PIcal_IS(N, L);
end

% Plot
fig=figure;
hax=axes;
h=[];
h(1)=histogram(PI2, 'normalization', 'pdf' );
hold on
h(2)=histogram(PI1, 'normalization', 'pdf' );
hold on
h(3)=line([pi, pi], get(hax, 'YLim'),...
    'color', [1 0 0], 'linewidth', 2);
legend('with Importance Sampling Method', ...
    'without Importance Sampling Method', ...
    'True Mean')



%% B3_Ch9_10_A.m
function out = PIcal(m)

z = sqrt(1-rand(1,m).^2);
out = 4*sum(z)/m;

end

%% B3_Ch9_10_B.m
function out = PIcal_IS(m,L)

s = (0:(1/L):(1-1/L)) + 1/(2*L);
hvals = sqrt(1 - s.^2);
cs=cumsum(hvals);

for j=1:m
    loc = sum(rand*cs(L) > cs) +1;
    x = (loc-1)/L + rand/L;
    p = hvals(loc)/cs(L);
    
    est(j) = sqrt(1 - x.^2)/(p*L);
end

out = 4*sum(est)/m;

end

