% B3_Ch9_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_5.m
clear all; close all; clc;
 
% f(x)=30(x^4-2x^3+x^2)
x = 0:0.01:1;
y = 30 *(x.^4 - 2* x.^3 + x.^2);
 
% syms x
% int(x^4-2*x^3+x^2)
 
% plot f(x)
figure;
plot(x,y)
hold on;
line([0.4 0.4], [0 max(y)])
line([0.9 0.9], [0 max(y)])
 
plot(x, max(y) * ones(length(x)) )
text(0.45,0.1,'A')
text(0.85, 0.1, 'B')
text(0.6, 30 *(0.6^4 - 2 * 0.6^3 + 0.6^2) - 0.2, 'f(x)' )
text(0.7, max(y) - 0.05, 't(x)' )
hold off;
 
% Acceptance-rejection method
fmax = 30*(0.5^4-2*0.5^3+0.5^2);
tx = fmax;

c = double(int(sym(tx),0,1));

rx = tx/c;
 
% Reset random number generator
rand('state',0)
N = 1e5;
 
U = rand(N, 1);

Y = rx*rand(N, 1);
 
fY = 30 *(Y.^4 - 2* Y.^3 + Y.^2);
 
X = Y(U <= (fY./tx));
 
figure
histogram(X, 'normalization', 'pdf')
hold on
plot(x, y,'linewidth', 2, 'linestyle', '--')
text(0.58, tx, 'f(x)' )
xlabel(sprintf('X'));
ylabel(sprintf('Probability'));
 
% Check probability of acceptance
length(X)/N

1/c

