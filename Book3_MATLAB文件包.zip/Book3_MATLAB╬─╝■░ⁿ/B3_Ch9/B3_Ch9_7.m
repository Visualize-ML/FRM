% B3_Ch9_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_7.m
close all; clear all; clc;
 
% BlsMC input paramters
randn('state', 0);
S0 = 45;
K = 50;
r = 0.03;
T = 1;
sigma = 0.5;
 
% Number of random numbers
N = 2e6;
 
% Use Matlab Black-Schole model
call = blsprice(S0, K, r, T, sigma);
 
% Use BlsMC
[CallMC1, CI1] = BlsMC(S0, K, r, T, sigma, N);

CIB1=(CI1(2) - CI1(1))/CallMC1;
 
% Use BlsMC_ASM
randn('state',0);
[CallMC2, CI2] = BlsMC_ASM(S0, K, r, T, sigma, 0.5*N);

CIB2=(CI2(2) - CI2(1))/CallMC2;
 
% Reduction in variance
(CIB1-CIB2)/CIB1


% BlsMC
function [Price, CI] = BlsMC(S0,K,r,T,sigma,Num)
nuT = (r - 0.5*sigma^2)*T;
siT = sigma * sqrt(T);
 
Payoff_PV = exp(-r*T)*max(0, S0*exp(nuT+siT*randn(Num,1))-K);
 
[Price, VarPrice, CI] = normfit(Payoff_PV);
end


% BlsMC + Antithetic Sampling Method
function [Price, CI] = BlsMC_ASM(S0,K,r,T,sigma,Num)
nuT = (r - 0.5*sigma^2)*T;
siT = sigma * sqrt(T);
Veps = randn(Num,1);
 
Payoff1 = max( 0 , S0*exp(nuT+siT*Veps) - K);
Payoff2 = max( 0 , S0*exp(nuT+siT*(-Veps)) - K);
 
Payoff_PV = exp(-r*T) * 0.5 * (Payoff1+Payoff2);
 
[Price, VarPrice, CI] = normfit(Payoff_PV);
end
