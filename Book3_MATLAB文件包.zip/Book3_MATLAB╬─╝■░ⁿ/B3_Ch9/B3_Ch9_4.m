% B3_Ch9_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% B3_Ch9_4.m
close all; clear all; clc;
 
% Inverse transform with discrete distribution
rand('state',0)
values = 1:4;
probs = [0.2 0.3 0.4 0.1];
Num = 1e4;

samples = Discreternd(values, probs, Num);
 
% plot
figure
hist(samples,4)
hold on
for i=1:length(probs)
    line([1,4],[Num*probs(i), Num*probs(i)],...
        'color','red','linestyle','--')
    hold on
end
 
% Discrete rand
function samples = Discreternd(values, probs, Num)
% Get cumulative probabilities
cumprobs = cumsum(probs);
N = length(probs);
samples = zeros(Num,1);
 
for k=1:Num
    loc=sum(rand*cumprobs(N) > cumprobs) +1;
    samples(k)=values(loc);
end
 
end
