% B3_Ch3_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
X = linspace(-4,4,1000);
 
sigma = 1; % scale parameter
mu = 0;    % location parameter
 
k = 0;     % shape parameter
PDF_I = gevpdf(X,k,sigma,mu);
CDF_I = gevcdf(X,k,sigma,mu);
% k = 0, corresponding to the Type I case
% Gumbel law
 
k = 0.5;
PDF_II = gevpdf(X,k,sigma,mu);
CDF_II = gevcdf(X,k,sigma,mu);
% k > 0 corresponds to the Type II case
% Frechet Law
 
k = -0.5;  
PDF_III = gevpdf(X,k,sigma,mu);
CDF_III = gevcdf(X,k,sigma,mu);
% k < 0 corresponds to the Type III case
% Weibull law
 
figure(1)
plot(X,PDF_I, X,PDF_II, X,PDF_III)
legend({'k = 0, Type I: Gumbel law' ...
        'k > 0, Type II: Frechet Law'....
        'k < 0, Type III: Weibull law'},...
        'location','best')
box off; xlabel('X'); ylabel('PDF')
 
figure(2)
plot(X,CDF_I, X,CDF_II, X,CDF_III)
legend({'k = 0, Type I: Gumbel law' ...
        'k > 0, Type II: Frechet Law'....
        'k < 0, Type III: Weibull law'},...
        'location','best')
box off; xlabel('X'); ylabel('CDF')
