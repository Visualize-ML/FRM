% B3_Ch3_10.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
df = 4;
num_draws = 1000;
inv_gam_rnd = 1./gamrnd(df/2,2/df,num_draws,1);
t_mu = 0; t_var = 2;
 
t_rnd = t_mu + sqrt(inv_gam_rnd).*normrnd(0,sqrt(t_var),num_draws,1);
 
figure(1)
histfit(t_rnd); box off
xlabel('x'); ylabel('Frequency')
var(t_rnd)
