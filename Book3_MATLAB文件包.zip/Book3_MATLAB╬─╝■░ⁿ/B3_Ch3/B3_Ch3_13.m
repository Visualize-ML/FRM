% B3_Ch3_13.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
families = {'Clayton','Frank','Gumbel'};
 
rnd_u = linspace(0.001,1-0.001,50);
[u1,u2] = meshgrid(rnd_u,rnd_u);
num_sim = 500;
 
alphas = 1:1:10;
index = 1;
for j = 1:length(families)
    family = families(j);
    for i = 1:length(alphas)
        alpha = alphas(i);
        pdf_u = copulapdf(family,[u1(:),u2(:)],alpha);
        
        pdf_u = reshape(pdf_u,size(u1));
        rnd_u = copularnd(family,alpha,num_sim);
        
        figure(index); index = index + 1;
        
        subplot(1,2,1)
        contour(u1,u2,pdf_u,[0:0.2:5]);
        daspect([1,1,1])
        % mesh(u1,u2,pdf_u);
        xlabel('U1'); ylabel('U2'); zlabel('Copula PDF')
        zlim([0,10])
        title([[family{:}] '; \alpha = ',num2str(alpha)])
        
        subplot(1,2,2)
        plot(rnd_u(:,1),rnd_u(:,2),'.');
        xlabel('U1'); ylabel('U2');
        grid off; daspect([1,1,1])
        title([[family{:}] '; \alpha = ',num2str(alpha)])
    end
end

