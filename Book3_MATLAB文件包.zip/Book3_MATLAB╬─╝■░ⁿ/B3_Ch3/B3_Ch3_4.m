% B3_Ch3_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

rng('default');  
% For reproducibility
data = trnd(3,100,1);
pd_obj = paretotails(data,0.1,0.9)
% paretotails(x,pl,pu) returns the piecewise distribution 
% object pd, which consists of the empirical distribution 
% in the center and generalized Pareto distributions in the tails. 
% Specify the boundaries of the tails using the lower and upper tail 
% cumulative probabilities pl and pu, respectively.
 
figure(1)
probplot(data)
p = fitdist(data,'tlocationscale');
h = probplot(gca,p); 
set(h,'color','r','linestyle','-');
title('Probability plot')
legend('Normal','Data','t location-scale','Location','SE')
box off
 
figure(2)
x = linspace(-5,5);
plot(x,tcdf(x,3),'r')
hold on
plot(x,cdf(pd_obj,x),'b')
 
[p,q] = boundary(pd_obj);
plot(q,p,'bo')
legend('t distribution','Pareto tails object',...
    'Boundary points','Location','best')
hold off; box off; legend boxoff
