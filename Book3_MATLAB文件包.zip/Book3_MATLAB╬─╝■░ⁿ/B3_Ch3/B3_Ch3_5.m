% B3_Ch3_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
num_sim = 500; rho = .7;
SIGMA = [1 rho; rho 1];
rng default
Z = mvnrnd([0 0],SIGMA,num_sim);
U = normcdf(Z);
% U = copularnd('Gaussian',SIGMA,num_sim);
 
figure(1)
scatterhist(U(:,1),U(:,2),'Direction','out')
set(get(gca,'children'),'marker','.')
xlabel('U_1'); ylabel('U_2');
 
figure(2)
X = [tinv(U(:,1),3) tinv(U(:,2),3)];
scatterhist(X(:,1),X(:,2),'Direction','out')
set(get(gca,'children'),'marker','.')
xlabel('X_1'); ylabel('X_2')
 
figure(3)
X = [gaminv(U(:,1),2,1) tinv(U(:,2),3)];
scatterhist(X(:,1),X(:,2),'Direction','out')
set(get(gca,'children'),'marker','.')
xlabel('X_1'); ylabel('X_2')

