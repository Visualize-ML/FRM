% B3_Ch3_14.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
rho_pearson = -1:0.01:1;
tau_kendall = nan(size(rho_pearson));
rho_spearman = nan(size(rho_pearson));
 
for i = 1:length(rho_pearson)
    tau_kendall(i) = copulastat('Gaussian',...
        rho_pearson(i),'type','kendall');

    rho_spearman(i) = copulastat('Gaussian',...
        rho_pearson(i),'type','spearman');
end
 
figure(1)
subplot(1,2,1)
plot(rho_pearson,tau_kendall)
xlabel('Gaussian rho'); ylabel('Kendall tau')
grid off; box off
 
subplot(1,2,2)
plot(rho_pearson,rho_spearman)
xlabel('Gaussian rho'); ylabel('Spearman tau')
grid off; box off
