% B3_Ch3_12.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

num_sim = 500;
nu = 1;
rho_series = [-0.8,-0.1,0.1,0.8];
 
figure(1)
for i = 1:length(rho_series)
    rho = rho_series(i);
    T = mvtrnd([1 rho; rho 1], nu, num_sim);
    U = tcdf(T,nu);
    subplot(2,2,i);
    plot(U(:,1),U(:,2),'.');
    title(['rho = ',num2str(rho)]);
    xlabel('U1'); ylabel('U2');
end
 
figure(2)
 
for i = 1:length(rho_series)
    rho = rho_series(i);
    U = copularnd('t',[1 rho; rho 1], nu, num_sim);
 
    subplot(2,2,i);
    plot(U(:,1),U(:,2),'.');
    title(['rho = ',num2str(rho)]);
    xlabel('U1'); ylabel('U2');
end

