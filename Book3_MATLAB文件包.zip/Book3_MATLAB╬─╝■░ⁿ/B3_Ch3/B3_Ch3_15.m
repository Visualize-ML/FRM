% B3_Ch3_15.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Gaussian copula
clc; close all; clear all
 
num_rnd = 2000;
 
tau = copulastat('Gaussian',.8 ,'type','kendall')
 
num_steps = 100;
u = linspace(0,1,num_steps);
[u1,u2] = meshgrid(u,u);
 
rho = copulaparam('Gaussian',tau,'type','kendall')
U = copularnd('Gaussian',rho,num_rnd);
index = 1;
figure(index); index = index + 1;
scatterhist(U(:,1),U(:,2));
set(get(gca,'children'),'marker','.')
title(['Gaussian Copula, {\it\rho} = ',sprintf('%0.2f',rho)])
xlabel('U1'); ylabel('U2'); daspect([1,1,1])
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]); 
 
PDF = copulapdf('Gaussian',[u1(:),u2(:)],rho);
PDF = reshape(PDF,num_steps,num_steps);
figure(index); index = index + 1;
contour(u1,u2,PDF,[0:0.1:10]); colorbar
title(['Gaussian Copula, {\it\rho} = ',sprintf('%0.2f',rho)])
xlabel('U1'); ylabel('U2');
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
%% t copula
nu = 1.5;
rho = copulaparam('t',tau,nu,'type','kendall')
U = copularnd('t',rho,nu,num_rnd);
 
figure(index); index = index + 1;
scatterhist(U(:,1),U(:,2));
set(get(gca,'children'),'marker','.')
title(['t Copula, {\it\rho} = ',sprintf('%0.2f',rho)])
xlabel('U1'); ylabel('U2');
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
 
PDF = copulapdf('t',[u1(:),u2(:)],rho,nu);
PDF = reshape(PDF,num_steps,num_steps);
figure(index); index = index + 1;
contour(u1,u2,PDF,[0:0.1:10]); colorbar
title(['t Copula, {\it\rho} = ',sprintf('%0.2f',rho)])
xlabel('U1'); ylabel('U2');
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
 
%% Clayton copula
 
alpha = copulaparam('Clayton',tau,'type','kendall')
U = copularnd('Clayton',alpha,num_rnd);
figure(index); index = index + 1;
scatterhist(U(:,1),U(:,2));
set(get(gca,'children'),'marker','.')
title(['Clayton Copula, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2'); 
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
 
PDF = copulapdf('Clayton',[u1(:),u2(:)],alpha);
PDF = reshape(PDF,num_steps,num_steps);
 
figure(index); index = index + 1;
contour(u1,u2,PDF,[0:0.1:10]); colorbar
title(['Clayton Copula PDF, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2'); daspect([1,1,1])
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
%% Frank copula 
 
alpha = copulaparam('Frank',tau,'type','kendall');
U = copularnd('Frank',alpha,num_rnd);
 
figure(index); index = index + 1;
scatterhist(U(:,1),U(:,2));
set(get(gca,'children'),'marker','.')
title(['Frank Copula, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2');
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
 
PDF = copulapdf('Frank',[u1(:),u2(:)],alpha);
PDF = reshape(PDF,num_steps,num_steps);
 
figure(index); index = index + 1;
contour(u1,u2,PDF,[0:0.1:10]); colorbar
title(['Frank Copula PDF, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2'); daspect([1,1,1])
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
%% Gumbel copula
 
alpha = copulaparam('Gumbel',tau,'type','kendall');
U = copularnd('Gumbel',alpha,num_rnd);
 
figure(index); index = index + 1;
scatterhist(U(:,1),U(:,2));
set(get(gca,'children'),'marker','.')
title(['Gumbel Copula, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2');
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
 
PDF = copulapdf('Gumbel',[u1(:),u2(:)],alpha);
PDF = reshape(PDF,num_steps,num_steps);
 
figure(index); index = index + 1;
contour(u1,u2,PDF,[0:0.1:10]); colorbar
title(['Gumbel Copula PDF, {\it\alpha} = ',sprintf('%0.2f',alpha)])
xlabel('U1'); ylabel('U2'); daspect([1,1,1])
xticks([0, 0.5, 1]); yticks([0, 0.5, 1]);
