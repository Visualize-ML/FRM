% B3_Ch3_9.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
x = 0:0.01:5;
Alphas = [0.5,1,1,2,2,3];
Betas  = [0.5,0.5,1,1,2,1];
 
figure(1)
 
for i = 1:length(Alphas)
    alpha = Alphas(i);
    beta  = Betas(i);
    pdf_x = inv_gampdf(x,alpha,beta);
    plot(x,pdf_x); hold on
    legendCell{i} = ['\alpha = ',num2str(alpha),...
        '; \beta = ',num2str(beta)];
end
 
legend(legendCell)
 
ylim([0,2.5]); box off; legend boxoff
xlabel('x'); ylabel('Inverse Gamma PDF')
 
figure(2)
 
for i = 1:length(Alphas)
    alpha = Alphas(i);
    beta  = Betas(i);
    pdf_x = inv_gamcdf(x,alpha,beta);
    plot(x,pdf_x); hold on
    legendCell{i} = ['\alpha = ',num2str(alpha),...
        '; \beta = ',num2str(beta)];
end
 
legend(legendCell)
 
ylim([0,1]); box off; legend boxoff
xlabel('x'); ylabel('Inverse Gamma CDF')
 
function PDF = inv_gampdf(X,A,B)
 
PDF = B^A/gamma(A)*X.^(-A-1).*exp(-B./X);
 
end
 
function CDF = inv_gamcdf(X,A,B)
 
CDF = gammainc(B./X,A,'upper');
 
end
