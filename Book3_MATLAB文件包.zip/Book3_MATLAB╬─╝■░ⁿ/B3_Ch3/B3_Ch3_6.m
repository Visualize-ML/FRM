% B3_Ch3_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
num_sim = 1000; 
rho_12 = 0.8; rho_13 = 0.1; rho_23 = -0.5;
SIGMA = [1 rho_12 rho_13;
       rho_12 1 rho_23;
       rho_13 rho_23 1];
rng default
% Z = mvnrnd([0 0 0],SIGMA,num_sim);
% U = normcdf(Z);
U = copularnd('Gaussian',SIGMA,num_sim);
 
figure(1)
subplot(2,2,1)
scatter3(U(:,1),U(:,2),U(:,3),'.')
xlabel('U_1'); ylabel('U_2'); zlabel('U_3');
grid off; box off
 
subplot(2,2,2)
scatter3(U(:,1),U(:,2),U(:,3),'.')
xlabel('U_1'); ylabel('U_2'); zlabel('U_3');
grid off; box off; view([0,0,1])
 
subplot(2,2,3)
scatter3(U(:,1),U(:,2),U(:,3),'.')
xlabel('U_1'); ylabel('U_2'); zlabel('U_3');
grid off; box off; view([0,1,0])
 
subplot(2,2,4)
scatter3(U(:,1),U(:,2),U(:,3),'.')
xlabel('U_1'); ylabel('U_2'); ylabel('U_3');
grid off; box off; view([1,0,0])
 
X = [gaminv(U(:,1),2,1),gaminv(U(:,2),1,1),tinv(U(:,3),3)];
 
figure(2)
subplot(2,2,1)
scatter3(X(:,1),X(:,2),X(:,3),'.')
xlabel('X_1'); ylabel('X_2'); zlabel('X_3');
grid off; box off
xlim([0,10]); ylim([0,10]); zlim([-10,10])
 
subplot(2,2,2)
scatter3(X(:,1),X(:,2),X(:,3),'.')
xlabel('X_1'); ylabel('X_2'); zlabel('X_3');
grid off; box off; view([0,0,1])
xlim([0,10]); ylim([0,10]); zlim([-10,10])
 
subplot(2,2,3)
scatter3(X(:,1),X(:,2),X(:,3),'.')
xlabel('X_1'); ylabel('X_2'); zlabel('X_3');
grid off; box off; view([0,-1,0])
xlim([0,10]); ylim([0,10]); zlim([-10,10])
 
subplot(2,2,4)
scatter3(X(:,1),X(:,2),X(:,3),'.')
xlabel('X_1'); ylabel('X_2'); zlabel('X_3');
grid off; box off; view([1,0,0])
xlim([0,10]); ylim([0,10]); zlim([-10,10])
