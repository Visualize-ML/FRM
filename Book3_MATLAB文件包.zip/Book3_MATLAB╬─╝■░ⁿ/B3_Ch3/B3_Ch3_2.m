% B3_Ch3_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
rng default
blocksize = 50;
nblocks = 200;
X = trnd(3,blocksize,nblocks);
extreme_minma = min(X,[],1);
 
[paramEsts,paramCIs] = gevfit(extreme_minma);
 
k_MLE     = paramEsts(1);    % Shape parameter
sigma_MLE = paramEsts(2);    % Scale parameter
mu_MLE    = paramEsts(3);    % Location parameter
 
lowerBnd = mu_MLE-sigma_MLE./k_MLE;
 
ymin = 1.1*min(extreme_minma);
bins = floor(ceil(ymin)):floor(lowerBnd);
 
figure(1)
 
bar(bins,histc(extreme_minma,bins)/length(extreme_minma),'histc');
hold on
xgrid = linspace(lowerBnd,ymin,100);
PDF = gevpdf(xgrid,k_MLE,sigma_MLE,mu_MLE);
plot(xgrid,PDF,'r');
xlabel('Extreme values'); ylabel('PDF');
xlim([ymin lowerBnd]); box off
title(['k = ',num2str(k_MLE),'; \sigma = ',...
    num2str(sigma_MLE),'; \mu = ',num2str(mu_MLE)])
 
figure(2)
[CDF_empirical,xi] = ecdf(extreme_minma);
plot(xgrid,gevcdf(xgrid,k_MLE,sigma_MLE,mu_MLE),'-');
hold on;
stairs(xi,CDF_empirical,'r');
hold off;
xlabel('Extreme values'); ylabel('CDF');
xlim([ymin lowerBnd]); box off
legend('Fitted CDF','Empirical CDF','location','best');
