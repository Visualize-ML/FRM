% B3_Ch3_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
rng default
blocksize = 50;
nblocks = 200;
X = trnd(3,blocksize*nblocks,1);
u = 5; 
% u = -quantile(X,.0075)
X_hat = -X(X < -u) - u;
 
[paramEsts,paramCIs] = gpfit(X_hat);
 
k_MLE    = paramEsts(1);    % Shape parameter
beta_MLE = paramEsts(2);    % Scale parameter
 
lowerBnd = 0;
 
ymax = 1.1*max(X_hat);
bins = lowerBnd:ceil(ymax);
 
figure(1)
 
bar(bins,histc(X_hat,bins)/length(X_hat),'histc');
hold on
xgrid = linspace(lowerBnd,ymax,100);
PDF = gppdf(xgrid,k_MLE,beta_MLE);
plot(xgrid,PDF,'r');
xlabel('$$\hat{x}$$','Interpreter','Latex'); ylabel('PDF');
xlim([lowerBnd ymax]); box off
title(['k = ',num2str(k_MLE),'; \beta = ',...
    num2str(beta_MLE)])
 
figure(2)
[CDF_empirical,xi] = ecdf(X_hat);
plot(xgrid,gevcdf(xgrid,k_MLE,beta_MLE),'-');
hold on;
stairs(xi,CDF_empirical,'r');
hold off;
xlabel('$$\hat{x}$$','Interpreter','Latex'); ylabel('CDF');
xlim([lowerBnd ymax]); box off
legend('Fitted CDF','Empirical CDF','location','best');
