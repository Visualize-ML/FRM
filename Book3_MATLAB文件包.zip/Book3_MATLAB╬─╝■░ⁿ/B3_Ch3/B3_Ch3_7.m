% B3_Ch3_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
mu = [0 0];
rho = 0.6;
SIGMA = [1 rho;rho 1];
rng default
x1_grid = -3:.2:3;
x2_grid = -3:.2:3;
[X1_grid,X2_grid] = meshgrid(x1_grid,x2_grid);
X_grid = [X1_grid(:) X2_grid(:)];
 
PDF_X = mvnpdf(X_grid,mu,SIGMA);
num_sim = 500;
XX_rnd = mvnrnd(mu,SIGMA,num_sim);
X1_rnd = XX_rnd(:,1);
X2_rnd = XX_rnd(:,2);
PDF_X = reshape(PDF_X,length(x2_grid),length(x1_grid));
 
%% X PDF
index = 1;
figure(index); index = index + 1;
 
subplot(4,4,[2:4 6:8 10:12]); % Top right square
levels = [0.01,0.02,0.03,0.05,0.1,0.15];
contour(x1_grid,x2_grid,...
    PDF_X,levels,'ShowText','on'); hold on
plot(X1_rnd,X2_rnd,'.')
set(gcf,'color','white')
xlim([-3,3]); ylim([-3,3])
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
num_bins = 20;
 
subplot(4,4,[1 5 9]); % Top left
histfit(X2_rnd,num_bins);
xlim(yl); view(90,-90); box off;
xlabel('X_2'); ylabel('PDF')
 
subplot(4,4,[14:16]); % Btm right
histfit(X1_rnd,num_bins)
xlim(xl); box off
xlabel('X_1'); ylabel('PDF')
%% X CDF
CDF_X = mvncdf(X_grid,mu,SIGMA);
CDF_X = reshape(CDF_X,length(x2_grid),length(x1_grid));
figure(index); index = index + 1;
 
subplot(4,4,[2:4 6:8 10:12]); % Top right square
levels = [0.01,0.05,0.1:0.1:1];
contour(x1_grid,x2_grid,CDF_X,levels,'ShowText','on'); hold on
plot(X1_rnd,X2_rnd,'.')
xlim([-3,3]); ylim([-3,3])
set(gcf,'color','white')
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
[CDF_emprical_2,xi_2] = ecdf(X2_rnd);
stairs(xi_2,CDF_emprical_2,'r');
xlim(yl); view(90,-90); box off;
xlabel('X_2'); ylabel('U_2')
 
subplot(4,4,[14:16]); % Btm right
[CDF_emprical_1,xi_1] = ecdf(X1_rnd);
stairs(xi_1,CDF_emprical_1,'r');
xlim(xl); box off
xlabel('X_1'); ylabel('U_1')
 
%% One-to-one mapping, U to X
 
U_1_rnd = ksdensity(X1_rnd,X1_rnd,'function','cdf');
U_2_rnd = ksdensity(X2_rnd,X2_rnd,'function','cdf');
 
u1_grid = linspace(1e-3,1-1e-3,50);
u2_grid = linspace(1e-3,1-1e-3,50);
[U1,U2] = meshgrid(u1_grid,u2_grid);
 
U_PDF = copulapdf('Gaussian',[U1(:) U2(:)],SIGMA);
U_CDF = copulacdf('Gaussian',[U1(:) U2(:)],SIGMA);
U_PDF = reshape(U_PDF,size(U1));
U_CDF = reshape(U_CDF,size(U1));
 
 
%% Copula Density (PDF), density
 
figure(index); index = index + 1;
 
subplot(4,4,[2:4 6:8 10:12]); % Top right square
contour(u1_grid,u2_grid,U_PDF,...
    [0:0.2:1,1.2,1.3,1.5,2:10],'ShowText','on'); hold on
scatter(U_1_rnd,U_2_rnd,'.')
zlabel('PDF')
set(gcf,'color','white')
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
h = histogram(U_2_rnd,num_bins);
h.Normalization = 'probability';
 
xlim(yl); view(90,-90); box off;
xlabel('U_2'); ylabel('PDF')
 
subplot(4,4,[14:16]); % Btm right
h = histogram(U_1_rnd,num_bins);
h.Normalization = 'probability';
 
xlim(xl); box off
xlabel('U_1'); ylabel('PDF')
 
figure(index); index = index + 1;
 
mesh(u1_grid,u2_grid,U_PDF); hold on
zlabel('PDF'); xlabel('U_1'); ylabel('U_2')
set(gcf,'color','white'); grid off
%% Copula CDF
 
figure(index); index = index + 1;
subplot(4,4,[2:4 6:8 10:12]); % Top right square
contour(u1_grid,u2_grid,U_CDF,...
    [0:0.1:1],'ShowText','on'); hold on
scatter(U_1_rnd,U_2_rnd,'.')
zlabel('CDF')
set(gcf,'color','white')
yl=get(gca,'ylim'); xl=get(gca,'xlim');
 
subplot(4,4,[1 5 9]); % Top left
[CDF_emprical_2,xi_2] = ecdf(U_2_rnd);
stairs(xi_2,CDF_emprical_2,'r');
xlim(yl); view(90,-90); box off;
xlabel('U_2'); ylabel('CDF')
 
subplot(4,4,[14:16]); % Btm right
[CDF_emprical_1,xi_1] = ecdf(U_1_rnd);
stairs(xi_1,CDF_emprical_1,'r');
xlim(xl); box off
xlabel('U_1'); ylabel('CDF')
 
figure(index); index = index + 1;
 
mesh(u1_grid,u2_grid,U_CDF); hold on
zlabel('CDF'); xlabel('U_1'); ylabel('U_2')
set(gcf,'color','white'); grid off
