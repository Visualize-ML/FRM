% B3_Ch3_8.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
x = 0:0.01:12;
a = [0.5,1,3,5,5,7];
b  = [1,0.5,0.5,0.5,1,1];
 
figure(1)
 
for i = 1:length(a)
    a_i = a(i);
    b_i  = b(i);
    pdf_x = gampdf(x,a_i,b_i);
    plot(x,pdf_x); hold on
    legendCell{i} = ['a = ',num2str(a_i),...
        '; b = ',num2str(b_i)];
end
 
legend(legendCell)
 
ylim([0,0.6]); box off; legend boxoff
xlabel('x'); ylabel('Gamma PDF')
 
figure(2)
 
for i = 1:length(a)
    a_i = a(i);
    b_i  = b(i);
    pdf_x = gamcdf(x,a_i,b_i);
    plot(x,pdf_x); hold on
    legendCell{i} = ['a = ',num2str(a_i),...
        '; b = ',num2str(b_i)];
end
 
legend(legendCell)
 
ylim([0,1]); box off; legend boxoff
xlabel('x'); ylabel('Gamma CDF')
