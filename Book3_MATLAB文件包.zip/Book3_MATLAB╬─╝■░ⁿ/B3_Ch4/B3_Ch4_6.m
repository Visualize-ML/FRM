% B3_Ch4_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Irregular steps
% resample
 
tenors = [0.019231,0.038462,0.083333,0.25,0.5,1];
IRs = [0.0180 0.0195 0.0203 0.0235 0.0250 0.0272];
 
ts_in = timeseries(IRs', tenors');
reg_tenors = [1/12:1/12:1];
ts_out = resample(ts_in,reg_tenors);
tsindata = ts_in.Data;
 
figure(1)
subplot(2,1,1)
plot(tenors, IRs,'o-'); hold on
x_left = min(tenors);
x_right = max(tenors);
y_top = 0.03;
y_btm = 0.015;
xlim([x_left x_right])
ylim([y_btm y_top])
xlabel('Tenor (yr)')
ylabel('Interest rate')
 
subplot(2,1,2)
plot(reg_tenors, ts_out.Data,'x','MarkerSize',10)
x_left = min(tenors);
x_right = max(tenors);
y_top = 0.03;
y_btm = 0.015;
xlim([x_left x_right])
ylim([y_btm y_top])
xlabel('Tenor (yr)')
ylabel('Interest rate')
