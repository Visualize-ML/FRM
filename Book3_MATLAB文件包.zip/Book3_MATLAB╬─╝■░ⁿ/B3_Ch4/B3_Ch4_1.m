% B3_Ch4_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

x_points = [0.019231,0.038462,0.083333,0.25,0.5,1]';
y_points = [0.0180 0.0195 0.0203 0.0235 0.0250 0.0272]';
 
x_fine = 0:0.01:1;
 
figure(1)
 
subplot(1,2,1)
method = 'spline';
y_interpolated = interp1(x_points,y_points,x_fine,method);
plot(x_points,y_points,'o'); hold on
plot(x_fine, y_interpolated);box off
 
method = 'linear';
y_interpolated = interp1(x_points,y_points,x_fine,method);
plot(x_fine, y_interpolated);box off
xlabel('Tenor [year]'); ylabel('Interest rate'); 
title('Interpolation')
xlim([0 1]); ylim([0.015 0.03])
 
subplot(1,2,2)
 
% linear regression
F1 = [ones(size(x_points)),x_points];
b1 = regress(y_points,F1);
 
% quadratic regression
F2 = [ones(size(x_points)),x_points, x_points.^2];
b2 = regress(y_points,F2);
 
y_regressed2 = b2(1) + b2(2)*x_fine + b2(3)*x_fine.^2;
y_regressed1 = b1(1) + b1(2)*x_fine;
 
plot(x_points,y_points,'o'); hold on 
plot(x_fine,y_regressed1); hold on
plot(x_fine,y_regressed2)
 
xlabel('Tenor [year]'); ylabel('Interest rate'); 
title('Regression'); box off
xlim([0 1]); ylim([0.015 0.03])
