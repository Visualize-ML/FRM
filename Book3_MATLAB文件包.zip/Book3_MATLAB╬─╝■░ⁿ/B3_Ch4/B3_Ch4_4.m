% B3_Ch4_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
x = 0:0.2:2*pi;
y = sin(x);
xx = 0:0.01:2*pi;
yy = sin(xx);
 
y(y < 0.8 & y > 0.3) = NaN;
y(y > -0.6 & y < -0.1) = NaN;
 
% linear interpolation
[F,TF] = fillmissing(y,'linear','SamplePoints',x);
% 'spline' can be used as well
 
figure(1)
plot(x,y,'o'); hold on
plot(xx,yy,'k'); hold on
plot(x(TF),F(TF),'x','MarkerSize',10)
xlabel('x'); ylabel('sin(x)')
legend('Original data','sin(x)','Linearly filled')
set(gca, 'XAxisLocation', 'origin'); box off
 
% movmedian
 
[F,TF] = fillmissing(y,'movmedian',4);
 
figure(2)
plot(x,y,'o'); hold on
plot(xx,yy,'k'); hold on
plot(x(TF),F(TF),'x','MarkerSize',10)
xlabel('x'); ylabel('sin(x)')
legend('Original data','sin(x)','Move median')
set(gca, 'XAxisLocation', 'origin'); box off
 
% previous
 
[F,TF] = fillmissing(y,'previous');
 
figure(3)
plot(x,y,'o'); hold on
plot(xx,yy,'k'); hold on
plot(x(TF),F(TF),'x','MarkerSize',10)
xlabel('x'); ylabel('sin(x)')
legend('Original data','sin(x)','Filled with previous')
set(gca, 'XAxisLocation', 'origin'); box off
 
% next
 
[F,TF] = fillmissing(y,'next');
 
figure(4)
plot(x,y,'o'); hold on
plot(xx,yy,'k'); hold on
plot(x(TF),F(TF),'x','MarkerSize',10)
xlabel('x'); ylabel('sin(x)')
legend('Original data','sin(x)','Filled with next')
set(gca, 'XAxisLocation', 'origin'); box off
 
% nearest
 
[F,TF] = fillmissing(y,'nearest');
 
figure(5)
plot(x,y,'o'); hold on
plot(xx,yy,'k'); hold on
plot(x(TF),F(TF),'x','MarkerSize',10)
xlabel('x'); ylabel('sin(x)')
legend('Original data','sin(x)','Filled with nearest')
set(gca, 'XAxisLocation', 'origin'); box off
