% B3_Ch4_7.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% x_points = [1, 3, 8];
% y_points = [2, 6, 0];
 
x_points = [0.019231,0.038462,0.083333,0.25,0.5,1];
y_points = [0.0180 0.0195 0.0203 0.0235 0.0250 0.0272];
 
% x_points=[0,1,2, 3,4,5];
% y_points=[1 1 1 -1 -1 -1];
 
figure(1)
plot(x_points,y_points,'o'); 
hold on
 
num_int=21; 
 
for i=1:length(x_points)-1
    
    bin_i=linspace(x_points(i),x_points(i+1),num_int);
    
    for i_bin=1:num_int
        % Natural spline d(1) = 0
        y_quadratic(i_bin)=quadratic_spline(x_points,y_points,bin_i(i_bin),1); 
        % Quadratic spline with d(1) = d(2)
        y_quadratic_2(i_bin)=quadratic_spline(x_points,y_points,bin_i(i_bin),2); 
    end
    
    plot(bin_i,y_quadratic,'k'); 
    plot(bin_i,y_quadratic_2,'k--') 
end
 
legend('Data points','Natural quadratic', ...
    'Quadratic, d_1 = d_2') 
 
xlabel('x'), ylabel('y'),title('Quadratic Spline Interpolation'); 
 
%%
 
function f = quadratic_spline(x,y,xx,ioption)
 
n=length(x); 
 
if (xx<x(1)) || (xx>x(n))
    error('out of x range!');
end
 
d=1:1:n;
 
if ioption==1
    d(1)=0.0; % Natural quadratic spline condition
else
    d(1)=(y(2)-y(1))/(x(2)-x(1)); % for d(1) = d(2)
end
 
for i = 2:n
    d(i)=2.0*(y(i)-y(i-1))/(x(i)-x(i-1))-d(i-1);
end
 
for i = 1:n-1
    if (xx>=x(i)) && (xx<=x(i+1))
        m=i;
        break
    end
end
 
f = (xx-x(m))*(0.5*(d(m+1)-d(m))*(xx-x(m))/(x(m+1)-x(m)) ...
    +d(m)) + y(m);
end

