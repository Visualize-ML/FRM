% B3_Ch4_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% Remove outliers from data
clc; close all; clear all
 
time = -2*pi:0.1:2*pi;
A = sin(time);
% outliers
A(47) = 0.4;
A(78) = -0.2;
A(98) = 0.8;
A(6) = -0.5;
 
t = datetime(2018,1,1,0,0,0) + hours(0:length(time)-1);
 
figure(1)
TF = isoutlier(A,'movmedian',hours(5),'SamplePoints',t);
 
% TF = isoutlier(A,movmethod,window) specifies a moving method
% for detecting local outliers according to
% a window length defined by window.
% For example, isoutlier(A,'movmedian',5) returns true for
% all elements more than three local scaled MAD from the local
% median within a sliding window containing five elements.
 
stem(t,A,'.'); hold on
plot(t(TF),A(TF),'x')
legend('Data','Outlier'); box off
xlabel('Time'); ylabel('Data')
 
%% Replace outliers from data
 
figure(2)
 
subplot(2,2,1)
fill_method = 'clip';
plot_fcn(A,fill_method,t)
 
subplot(2,2,2)
fill_method = 'previous';
plot_fcn(A,fill_method,t)
 
subplot(2,2,3)
fill_method = 'linear';
plot_fcn(A,fill_method,t)
 
subplot(2,2,4)
fill_method = 'spline';
plot_fcn(A,fill_method,t)
 
% utitlities
function plot_fcn(A,fill_method,t)
B = filloutliers(A,fill_method,...
    'movmedian',hours(5),'SamplePoints',t);
% B = filloutliers(A,fillmethod) finds outliers
% in A and replaces them according to fillmethod.
 
plot(t,A,'-'); hold on
index_equal = find(A == B);
index_not_equal = find(A ~= B);

% or use [B,TF,L,U,C] = filloutliers()
plot(t(index_not_equal),B(index_not_equal),'x');
legend('Original',fill_method); box off
xlabel('Time'); ylabel('Data')
end
