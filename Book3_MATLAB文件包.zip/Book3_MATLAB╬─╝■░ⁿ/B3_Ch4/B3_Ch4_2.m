% B3_Ch4_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
time_end = 1; % years
step = 1/1024; % year
time_array = 0:step:time_end;
 
% component 1
freq_1 = 4; shift_1 = pi/6; A_1 = 10;
comp_1 = A_1*cos(2*pi*freq_1*time_array + shift_1);
 
% component 2
freq_2 = 12; shift_2 = -pi/3; A_2 = 4; 
comp_2 = A_2*cos(2*pi*freq_2*time_array + shift_2);
 
% component 3
freq_3 = 24; shift_3 = pi/2; A_3 = 2;
comp_3 = A_3*cos(2*pi*freq_3*time_array + shift_3);
 
% component 4
freq_4 = 48; shift_4 = -pi/4; A_4 = 0.5;
comp_4 = A_4*cos(2*pi*freq_4*time_array + shift_4);
 
DC = 15;
signal = DC + comp_1 + comp_2 + comp_3 + comp_4; 
 
figure(1)
plot(time_array,signal)
xlabel('Year'); ylabel('Signal')
box off; grid off
 
figure(2)
subplot(2,2,1)
plot(time_array,comp_1); hold on
plot(time_array,zeros(size(time_array)),'r')
xlabel('Year'); ylabel('Component'); title('1st component')
ylim([-10,10]); xlim([0,1]); box off
 
subplot(2,2,2)
plot(time_array,comp_2); hold on
plot(time_array,zeros(size(time_array)),'r')
xlabel('Year'); ylabel('Component'); title('2nd component')
ylim([-10,10]); xlim([0,1]); box off
 
subplot(2,2,3)
plot(time_array,comp_3); hold on
plot(time_array,zeros(size(time_array)),'r')
xlabel('Year'); ylabel('Component'); title('3rd component')
ylim([-10,10]); xlim([0,1]); box off
 
subplot(2,2,4)
plot(time_array,comp_4); hold on
plot(time_array,zeros(size(time_array)),'r')
xlabel('Year'); ylabel('Component'); title('4th component')
ylim([-10,10]); xlim([0,1]); box off
 
time_num = length(signal);
F_series=2*abs(fft(signal)/time_num); 
% DC amplitude is doubled
Ang_series = angle(fft(signal)).*(F_series > 0.1)*180/pi; 
figure (3)
time_order_limit = 50;
subplot (2,1,1)
stem([0:1/time_end:time_order_limit],[F_series(1)/2,...
    F_series(2:time_order_limit+1)],'filled') 
xlabel ('Frequency per year')
ylabel ('Harmonic magnitude')
xlim([-0.5 time_order_limit])
box off; grid off
 
subplot (2,1,2)
 
stem([0:time_order_limit],Ang_series (1:time_order_limit+1)...
    .*(abs(Ang_series (1:time_order_limit+1))>0.01)) 
 
xlabel ('Frequency per year')
ylabel ('Phase angle')
xlim([-0.5 time_order_limit])
box off; grid off
