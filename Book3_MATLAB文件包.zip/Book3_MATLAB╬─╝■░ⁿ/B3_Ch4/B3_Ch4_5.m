% B3_Ch4_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
 
% x_points = [1, 3, 8];
% y_points = [2, 6, 0];
 
% x_points = [0.019231,0.038462,0.083333,0.25,0.5,1];
% y_points = [0.0180 0.0195 0.0203 0.0235 0.0250 0.0272];
 
x_points=[0,1,2, 3,4,5];
y_points=[1 1 1 -1 -1 -1];
 
figure(1)
plot(x_points,y_points,'o');
hold on
 
num_int=11;
 
for i=1:length(x_points)-1
    
    bin_i=linspace(x_points(i),x_points(i+1),num_int);
    
    for i_bin=1:num_int
        y_1inear(i_bin)=linear_spline(x_points,y_points,bin_i(i_bin));
        
        % interp1 can also be used, linear spline is the default
        % y_interp1(i_bin)=interp1(x_points,y_points,bin_i(i_bin));
    end
    plot(bin_i,y_1inear,'k');
    %  plot(bin_i,y_interp1,'k+');
end
 
legend('Data points','Linear spline');
% legend('data points','linear spline','interp1, linear');
xlabel('x'), ylabel('y'),title('Linear Spline Interpolation');
 
 
%%
 
function f = linear_spline(x,y,x_bin)
 
n=length(x);
if (x_bin<x(1)) || (x_bin>x(n))
    error('out of x range!');
    % Extropolation is not allowed
end
 
for i = 1:n-1
    if (x_bin>=x(i)) && (x_bin<=x(i+1))
        m=i;
        break
    end
end
 
f = y(m)*(x_bin-x(m+1))/(x(m)-x(m+1)) ...
    +y(m+1)*(x_bin-x(m))/(x(m+1)-x(m));
end
