% B3_Ch2_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
MU = [0 0];
SIGMA = eye(2,2);
rng('default')  
% For reproducibility
D = mvnrnd(MU,SIGMA,1000);
 
%%
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
plot_data(D)
 
figure(fig_i)
fig_i = fig_i + 1;
SIGMA_D = cov(D);
xvalues = {'x1','x2'};
yvalues = xvalues;
heatmap(xvalues,yvalues,SIGMA_D);
 
%% Scaling
sigma_1 = sqrt(2);
sigma_2 = sqrt(1/2);
S = [sigma_1 0; 0 sigma_2]; % scaling matrix
D_S = D*S;
SIGMA_D_S = cov(D_S);
 
figure(fig_i)
fig_i = fig_i + 1;
plot_data(D_S)
 
figure(fig_i)
fig_i = fig_i + 1;
xvalues = {'x1, scaled','x2, scaled'};
yvalues = xvalues;
heatmap(xvalues,yvalues,SIGMA_D_S);
%% Rotating anti-clockwise, theta = -pi/3
theta = -pi/3;
R = [cos(theta) -sin(theta); 
     sin(theta) cos(theta)]
D_S_R = D_S*R;
SIGMA_D_S_R = cov(D_S_R);
[eig_Vectors,eig_Values] = eig(SIGMA_D_S_R)
eig_Values = diag(eig_Values);
 
figure(fig_i)
fig_i = fig_i + 1;
plot_data(D_S_R); hold on
plot([0 eig_Vectors(1,1)*sqrt(eig_Values(1))],...
    [0 eig_Vectors(2,1)*sqrt(eig_Values(1))],...
    'LineWidth',3,'Color','r'); hold on
plot([0 eig_Vectors(1,2)*sqrt(eig_Values(2))],...
    [0 eig_Vectors(2,2)*sqrt(eig_Values(2))],...
    'LineWidth',3,'Color','r'); hold on
 
figure(fig_i)
fig_i = fig_i + 1;
subplot(1,2,1)
xvalues = {'x1','x2'};
yvalues = xvalues;
heatmap(xvalues,yvalues,SIGMA_D_S_R);
 
subplot(1,2,2)
xvalues = {'x1','x2'};
yvalues = xvalues;
heatmap(xvalues,yvalues,R*S*S*inv(R));
 
 
function plot_data(D)
c = linspace(1,10,length(D));
scatter(D(:,1), D(:,2),[],c); hold on
xlim([-5,5]); ylim([-5,5]); 
xticks([-4:4]);yticks([-4:4]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
grid on; % grid minor
end 
