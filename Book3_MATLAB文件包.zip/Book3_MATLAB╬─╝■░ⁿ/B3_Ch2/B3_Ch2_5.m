% B3_Ch2_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
rng('default') % For reproducibility
MU = [1, 2];
SIGMA = [1 .9;.9 1];
num_points = 800;
X = mvnrnd(MU,SIGMA,num_points);
 
[eig_Vectors, eig_Values] = eig(cov(X));
 
% sort eigenvalues and assign vectors
[eig_Values_sorted,index] = sort(diag(eig_Values),'descend');
eig_Vectors_sorted = eig_Vectors(:,index);
 
PC2_eigenval = eig_Values_sorted(2);
PC2_eigenvec = eig_Vectors_sorted(:,2);
 
PC1_eigenval = eig_Values_sorted(1);
PC1_eigenvec = eig_Vectors_sorted(:,1);
phi = atan2(PC1_eigenvec(2), PC1_eigenvec(1));
 
% shift the angle to between 0 and 2pi
if(phi < 0)
    phi = phi + 2*pi;
end
 
MU_real = mean(X);
xc=MU_real(1);
yc=MU_real(2);
 
Y = [1 1;sqrt(2)/2 -sqrt(2)/2;-1 1;-1 0] + MU;
 
mahal_d_square = mahal(Y,X);
mahal_d = sqrt(mahal_d_square);
 
% manually calculate Mahal distances
mahal_d_calculated = sqrt((Y(2,:) - MU_real)*inv(cov(X))*(Y(2,:) - MU_real)');
 
figure(1)
 
scatter(X(:,1),X(:,2),'.') % Scatter plot with points of size 10
hold on
plot(Y(:,1),Y(:,2)...
    ,'xr','MarkerSize',8,'LineWidth',2);
 
plot([-3,6],[yc,yc],'k');
plot([xc,xc],[-3,6],'k');
xlabel('x'); ylabel('y');
 
hold on; axis equal;
mindata = min(min(X));
maxdata = max(max(X));
xlim([mindata-1, maxdata+1]);
xticks([floor(mindata-1):ceil(maxdata+1)])
ylim([mindata-1, maxdata+1]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
 
figure(2)
scatter(X(:,1),X(:,2),'.') % Scatter plot with points of size 10
hold on
scatter(Y(:,1),Y(:,2),100,mahal_d,'o','filled')
plot(Y(:,1),Y(:,2)...
    ,'xr','MarkerSize',8,'LineWidth',2);
 
hb = colorbar;
ylabel(hb,'Mahalanobis Distance')
plot(xc,yc,'rx','MarkerSize',10)
plot([-3,6],[yc,yc],'k');
plot([xc,xc],[-3,6],'k');
quiver(xc, yc, PC1_eigenvec(1)*sqrt(PC1_eigenval), ...
    PC1_eigenvec(2)*sqrt(PC1_eigenval), 'm', 'LineWidth',2);
quiver(xc, yc, PC2_eigenvec(1)*sqrt(PC2_eigenval), ...
    PC2_eigenvec(2)*sqrt(PC2_eigenval), 'g', 'LineWidth',2);
hold on;
 
xlabel('x'); ylabel('y');
 
hold on; axis equal;
mindata = min(min(X));
maxdata = max(max(X));
xlim([mindata-1, maxdata+1]);
xticks([floor(mindata-1):ceil(maxdata+1)])
ylim([mindata-1, maxdata+1]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
figure(3)
scatter(X(:,1),X(:,2),'.') % Scatter plot with points of size 10
hold on
scatter(Y(:,1),Y(:,2),100,mahal_d,'o','filled')
plot(Y(:,1),Y(:,2)...
    ,'xr','MarkerSize',8,'LineWidth',2);
hb = colorbar;
ylabel(hb,'Mahalanobis Distance')
plot(xc,yc,'rx','MarkerSize',10)
xx = -3:6;
yy_v = (PC1_eigenvec(2)/PC1_eigenvec(1))*(xx - xc) + yc;
plot(xx,yy_v,'k');
yy_w = (PC2_eigenvec(2)/PC2_eigenvec(1))*(xx - xc) + yc;
plot(xx,yy_w,'k');
 
hold on;
 
xlabel('x'); ylabel('y');
 
hold on; axis equal;
mindata = min(min(X));
maxdata = max(max(X));
xlim([mindata-1, maxdata+1]);
xticks([floor(mindata-1):ceil(maxdata+1)])
ylim([mindata-1, maxdata+1]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
measures = [1,2,3,4,5];
 
for i = 1:length(measures)
    
    measure = measures(i);
    plot_ellipses (X,measure)
    % the function above can be simplified
    
end
 
figure(4)
if rad2deg(phi) > 180
    theta = phi - pi;
else
    theta = phi;
end
 
R = [cos(theta) -sin(theta); ...
    sin(theta) cos(theta)];
S = sqrt(diag([PC1_eigenval,PC2_eigenval]))^(-1);
 
X_transformed = (X - mean(X))*R*S;
Y_transformed = (Y - mean(X))*R*S;
norm(Y_transformed(2,:))
 
scatter(X_transformed(:,1),X_transformed(:,2),'.'); hold on
plot(Y_transformed(:,1),Y_transformed(:,2)...
    ,'xr','MarkerSize',8,'LineWidth',2); 
plot_circle(0,0,1); hold on
plot_circle(0,0,2); hold on
plot_circle(0,0,3); hold on
plot_circle(0,0,4); hold on
plot_circle(0,0,5); hold on
xlabel('v'); ylabel('w');
 
hold on; axis equal;
mindata = min(min(X_transformed));
maxdata = max(max(X_transformed));
xlim([mindata-2, maxdata+2]);
xticks([floor(mindata-2):ceil(maxdata+2)])
ylim([mindata-2, maxdata+2]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
grid on
 
function h = plot_circle(x,y,r)
hold on
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
h = plot(xunit, yunit,'k');
hold off
end
 
function plot_ellipses (X,measure)
 
[eig_Vectors, eig_Values] = eig(cov(X));
% sort eigenvalues and assign vectors
[eig_Values_sorted,index] = sort(diag(eig_Values),'descend');
eig_Vectors_sorted = eig_Vectors(:,index);
 
PC2_eigenval = eig_Values_sorted(2);
PC2_eigenvec = eig_Vectors_sorted(:,2);
 
PC1_eigenval = eig_Values_sorted(1);
PC1_eigenvec = eig_Vectors_sorted(:,1);
% first principal eigenvector has the largest eigen value
 
% calculate the angle between the x-axis
% and the first principal eigenvector
phi = atan2(PC1_eigenvec(2), PC1_eigenvec(1));
 
% shift the angle to between 0 and 2pi
if(phi < 0)
    phi = phi + 2*pi;
end
 
% obtain the center of the original data
center = mean(X);
 
theta_array = linspace(0,2*pi)';
xc=center(1);
yc=center(2);
a=measure*sqrt(PC1_eigenval);
% a: semi-major axis (first principal vector)
b=measure*sqrt(PC2_eigenval);
% b: semi-minor axis (second principal vector)
 
% ellipse coordinates before rotation
ellipse_x_r  = a*cos(theta_array);
ellipse_y_r  = b*sin(theta_array);
 
% Define a anti-clockwise rotation matrix
R_anticlock = [ cos(phi) sin(phi);
    -sin(phi) cos(phi) ];
 
%let's rotate the ellipse to some angle phi
r_ellipse = [ellipse_x_r,ellipse_y_r] * R_anticlock;
 
plot(r_ellipse(:,1) + xc,r_ellipse(:,2) + yc,'-k'); hold on
end
