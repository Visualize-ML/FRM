% B3_Ch2_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
Center = [1,0.5]; % center
a=2; %semi-major axis
b=1; %semi-minor axis
S = [a 0; 0 b];
num_points = 1000;
 
theta = deg2rad(-45);
 
tau = linspace(0,2*pi,num_points)';
x0 = cos(tau); y0 = sin(tau);
 
D0 = [x0,y0]; D_scaled = D0*S;
 
R  = [cos(theta) -sin(theta); ...
    sin(theta)  cos(theta)];
S_rotated = a^2*b^2*R^(-1)*S^(-1)*S^(-1)*R;
[eig_vectors,eig_values] = eig(S_rotated);
 
S_rotated_back = a^2*b^2*R*S^(-1)*S^(-1)*R^(-1);
 
D_rotated = D_scaled*R;
 
% D_rotated = D*eig_vectors;
xr = D_rotated(:,1); yr = D_rotated(:,2);
var(xr)
var(yr)
 
figure(1)
subplot(2,2,1)
plot(x0,y0,'b');
grid on;
hold on;
axis equal;
% plot(xr+xc,yr+yc,'r');
xlim([-3,3]); ylim([-3,3]); 
xticks([-2:2]);yticks([-2:2]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
subplot(2,2,2)
plot(D_scaled(:,1),D_scaled(:,2),'r');
grid on;hold on;axis equal;
xlim([-3,3]); ylim([-3,3]); 
xticks([-2:2]);yticks([-2:2]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
subplot(2,2,3)
 
plot(D_rotated(:,1),D_rotated(:,2),...
    'color',[0,200,75]./255);
grid on; hold on; axis equal;
xlim([-3,3]); ylim([-3,3]); 
xticks([-2:2]);yticks([-2:2]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
 
subplot(2,2,4)
plot(D_rotated(:,1)+Center(1),...
    D_rotated(:,2)+Center(2),...
    'color',[0,200,75]./255); hold on
plot(Center(1),Center(2),'xk'); 
grid on; hold on; axis equal;
xlim([-3,3]); ylim([-3,3]); 
xticks([-2:2]);yticks([-2:2]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
