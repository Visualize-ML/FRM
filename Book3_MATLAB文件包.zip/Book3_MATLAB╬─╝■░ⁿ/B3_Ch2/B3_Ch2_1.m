% B3_Ch2_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%
%% calculate eigenvectors and eigenvalues
 
clc; close all; clear all
x = [1, 2, -2, -1, 2, -1, -1]' + 0.5;
y = [1, -1, -2, 2, 3, -3, 0]'  + 1;
D = [x,y]; D_mean = mean(D);
D_centered = bsxfun(@minus, D, D_mean);
 
fig_i = 1;
figure(fig_i)
fig_i = fig_i + 1;
subplot(1,2,1)
plot_shape(D,'gx'); hold on
plot(D_mean(1),D_mean(2),'rx','MarkerSize',10)
 
subplot(1,2,2)
plot_shape(D,'gx'); hold on
plot_shape(D_centered,'bx'); hold on
xh=[D(:,1) D_centered(:,1)];
yh=[D(:,2) D_centered(:,2)];
plot(xh',yh','k')
plot(0,0,'rx','MarkerSize',10)

% least square regression is different
 
X = [ones(length(D_centered(:,1)),1) D_centered(:,1)];
b1 = D_centered(:,1)\D_centered(:,2);
% b1 = regress(D_centered(:,2),D_centered(:,1));
b2 = X\D_centered(:,2);
% b2 = regress(D_centered(:,2),X);
xx = -4:4;
yCalc1 = b1*xx;
yCalc2 = b2(2)*xx + b2(1);
y2 = b2(2)*D_centered(:,1) + b2(1);
 
figure(fig_i)
fig_i = fig_i + 1;
 
plot_shape(D_centered,'bx'); hold on
plot(xx,yCalc2,'k'); hold on
plot(D_centered(:,1),y2,'rx'); hold on
xh=[D_centered(:,1) D_centered(:,1)];
yh=[D_centered(:,2) y2];
plot(xh',yh','k')
 
figure(fig_i)
fig_i = fig_i + 1;
plot_shape(D_centered,'bx'); hold on
% orthogonal regression
 
[U,S,V] = svd(D_centered, 0);
N = V(:,end);
C = - mean(D_centered * N);
b_SVD = - [C N(2)] / N(1);
 
ux = 1; uy = 1*b_SVD(2);
yy = uy*xx;
plot(xx,yy,'k'); hold on
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points_x2 = D_centered*project;
plot_shape(projected_points_x2,'xr'); hold on
xh=[D_centered(:,1) projected_points_x2(:,1)];
yh=[D_centered(:,2) projected_points_x2(:,2)];
plot(xh',yh','k')
 
[eig_Vectors0,eig_Values0] = eig(cov(D_centered))
 
[eig_Vectors0,eig_Values0] = eig(cov(D_centered))
%% rotate centralize data
 
figure(fig_i)
fig_i = fig_i + 1;
subplot(1,2,1)
rotated_points = D_centered*eig_Vectors0;
plot_shape(rotated_points,'bx'); hold on
 
subplot(1,2,2)
rotated_points = D_centered*eig_Vectors0(:,[2,1]);
plot_shape(rotated_points,'bx'); hold on
%%
figure(fig_i)
fig_i = fig_i + 1;
subplot(1,2,1)
rotated_points = D_centered*eig_Vectors0;
cov(rotated_points) % uncorrelated points
plot_shape(rotated_points,'bx'); hold on
ux = 0; uy = 1;
project_y = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points_y = rotated_points*project_y;
plot_shape(projected_points_y,'xr'); hold on
xh=[rotated_points(:,1) projected_points_y(:,1)];
yh=[rotated_points(:,2) projected_points_y(:,2)];
plot(xh',yh','k'); hold on
var_y = var(projected_points_y(:,2));
title(['Variance = ',num2str(var_y)])
 
subplot(1,2,2)
plot_shape(rotated_points,'bx'); hold on
ux = 1; uy = 0;
project_x = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points_x = rotated_points*project_x;
plot_shape(projected_points_x,'xr'); hold on
xh=[rotated_points(:,1) projected_points_x(:,1)];
yh=[rotated_points(:,2) projected_points_x(:,2)];
plot(xh',yh','k'); hold on
[eig_Vectors1,eig_Values1] = eig(cov(rotated_points))
 
var_x = var(projected_points_x(:,1));
title(['Variance = ',num2str(var_x)])
%%
figure(fig_i)
fig_i = fig_i + 1;
rotated_points = D_centered*eig_Vectors0(:,[2,1]);
plot_shape(rotated_points,'bx'); hold on
ux = 1; uy = 0;
project = 1/(ux^2 + uy^2)*[ux^2, ux*uy; 
    ux*uy, uy^2];
projected_points_x2 = rotated_points*project;
plot_shape(projected_points_x2,'xr'); hold on
xh=[rotated_points(:,1) projected_points_x2(:,1)];
yh=[rotated_points(:,2) projected_points_x2(:,2)];
plot(xh',yh','k')
 
function plot_shape(points,style)
plot(points(:,1),points(:,2),style,...
    'LineWidth',1)
xlim([-4,4]); ylim([-4,4]); 
% xticks([-4:4]);yticks([-4:4]);
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
% grid on; % grid minor
end 

