% B3_Ch2_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
mu = [1 2];
rhos_array = [1, 0.5, 0, -0.5, -1];
 
for i = 1:length(rhos_array)
    rho = rhos_array(i);
    stds = [0.3, 0.4];
    rho_matrix = [1 rho; rho 1];
    sigma_matrix = diag(stds)*rho_matrix*diag(stds);
    rng('default')  % For reproducibility
    X = mvnrnd(mu,sigma_matrix,1000);
    F = X(:,1) + X(:,2);
    nbins = 20;
    F_std = std(F);
    
    figure(i)
    histfit(F,nbins)
    title(['STD of F = ',num2str(F_std),...
        '; correlation = ',num2str(rho)])
    xlim([0,6]); box off; grid off
    ylabel('Frequency')
end
