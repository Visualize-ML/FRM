% B3_Ch2_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
Conf_level = 0.95; % 0.9, 0.95, 0.99
Deg_freedom = 2;
X = chi2inv(Conf_level,Deg_freedom);
MU = [2 1];
theta = -pi/3;
R = [cos(theta) -sin(theta); 
    sin(theta) cos(theta)];
lambda1 = 2;   
% variance, PC1
lambda2 = 1/2; 
% variance, PC2
 
SIGMA0 = [lambda1,0; 0, lambda2];
% SIGMA1, before rotation
SIGMA1 = inv(R)*SIGMA0*R;
% SIGMA1 = R*SIGMA0*inv(R);
rng('default')  
 
D = mvnrnd(MU,SIGMA1,400);
% generate 400 random numbers
figure(1)
plot(D(:,1),D(:,2),'.')
xlabel('x'); ylabel('y');
 
grid on; hold on; axis equal;
mindata = min(min(D));
maxdata = max(max(D));
xlim([mindata-1, maxdata+1]);
xticks([floor(mindata-1):ceil(maxdata+1)])
ylim([mindata-1, maxdata+1]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
[eig_Vectors, eig_Values] = eig(cov(D));
 
% sort eigenvalues and assign vectors
[eig_Values_sorted,index] = sort(diag(eig_Values),'descend');
eig_Vectors_sorted = eig_Vectors(:,index);
 
PC2_eigenval = eig_Values_sorted(2);
PC2_eigenvec = eig_Vectors_sorted(:,2);
 
PC1_eigenval = eig_Values_sorted(1);
PC1_eigenvec = eig_Vectors_sorted(:,1);
% first principal eigenvector has the largest eigen value
 
% calculate the angle between the x-axis 
% and the first principal eigenvector
phi = atan2(PC1_eigenvec(2), PC1_eigenvec(1));
 
% shift the angle to between 0 and 2pi
if(phi < 0)
    phi = phi + 2*pi;
end
 
% obtain the center of the original data
center = mean(D);
 
chisquare_val = sqrt(X);
theta_array = linspace(0,2*pi)';
xc=center(1); yc=center(2);
a=chisquare_val*sqrt(PC1_eigenval);
% a: semi-major axis (first principal vector)
b=chisquare_val*sqrt(PC2_eigenval);
% b: semi-minor axis (second principal vector)
 
% ellipse coordinates before rotation
ellipse_x_r  = a*cos(theta_array);
ellipse_y_r  = b*sin(theta_array);
 
% Define a anti-clockwise rotation matrix
R_anticlock = [ cos(phi) sin(phi); 
    -sin(phi) cos(phi) ];
 
%let's rotate the ellipse to some angle phi
r_ellipse = [ellipse_x_r,ellipse_y_r] * R_anticlock;
 
figure(2)
 
plot(r_ellipse(:,1) + xc,r_ellipse(:,2) + yc,'-'); hold on
 
Ntmp = size(D,1);
datatmp = (D - repmat([xc yc],Ntmp,1))*R_anticlock';
dis1 = (datatmp(:,1)/a).^2+(datatmp(:,2)/b).^2;
e1 = find(dis1 > 1);
e2 = find(dis1 <= 1);
plot(D(e1,1),D(e1,2),'rx');hold on;
plot(D(e2,1),D(e2,2),'b.');hold on;
hold on;
 
% Plot the eigenvectors
quiver(xc, yc, PC1_eigenvec(1)*sqrt(PC1_eigenval), ...
    PC1_eigenvec(2)*sqrt(PC1_eigenval), 'm', 'LineWidth',2);

quiver(xc, yc, PC2_eigenvec(1)*sqrt(PC2_eigenval), ...
    PC2_eigenvec(2)*sqrt(PC2_eigenval), 'g', 'LineWidth',2);
hold on; xlabel('x'); ylabel('y');
axis equal;
mindata = min(D(:));
maxdata = max(max(D));
xlim([mindata-1, maxdata+1]);
xticks([floor(mindata-1):ceil(maxdata+1)])
ylim([mindata-1, maxdata+1]);
yticks([floor(mindata-1):ceil(maxdata+1)])
daspect([1,1,1]); box off
set(gca, 'XAxisLocation', 'origin')
set(gca, 'YAxisLocation', 'origin')
