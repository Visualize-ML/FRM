% B3_Ch5_4.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
series = 'UNRATENSA';
% Civilian Unemployment Rate (UNRATENSA)
% Units: Percent; Frequency: monthly
% Not Seasonally Adjusted
 
startdate = '01/01/2000';
% beginning of date range for historical data
enddate = '07/01/2019'; % to be updated
% ending of date range for historical data
 
d_strc = fetch(c,series,startdate,enddate);
 
% display description of data structure
dates = d_strc.Data(:,1);
O_t = d_strc.Data(:,2);
 
N = length(O_t);
 
%% STEP 1: apply filter on the original series O(t)
% Obtain the estimate of trend component, TR1(t)
 
detrend_filter  = [1/24;repmat(1/12,11,1);1/24];
% Apply a 13-term symmetric moving average
 
TR_t        = conv(O_t,detrend_filter,'same');
TR_t(1:6)   = TR_t(7); 
TR_t(N-5:N) = TR_t(N-6);
 
figure(1)
plot(dates,O_t,'b'); hold on
plot(dates,TR_t,'r','LineWidth',2);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 1: estimate trend component, TR(t)')
 
%% STEP 2: Detrend the original series O(t) and
%  Obtain the estimate of detrended series, DeTR1(t)
 
% additive decomposition
DeTR_t = O_t - TR_t;
 
% multiplicative decomposition
% DeTR_t = O_t./TR_t;
 
figure(2)
plot(dates,DeTR_t);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 2: obtain estimate detrended series, DeTR(t)');
 
%% STEP 3: obtain stable seasonal filter, S(t)
s = 12;
sidx = cell(s,1);
for i = 1:s
 sidx{i,1} = i:s:N;
end
S_t = cellfun(@(x) mean(DeTR_t(x)),sidx);
 
% Put smoothed values back into a vector of length N
nc = floor(N/s); % no. complete years
rm = mod(N,s); % no. extra months
S_t = [repmat(S_t,nc,1);S_t(1:rm)];
 
% Center the seasonal estimate (additive)
S_t_level = mean(S_t); % for centering
S_t = S_t-S_t_level;
% S1_t = S1_t./S1_t_level;
 
figure(3)
plot(dates,S_t);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 3: obtain stable seasonal component, S(t)');
 
%% STEP 4: obtain the irregular component, IR(t)
 
% IR_t = O_t./TR_t./S_t;;
IR_t = O_t - TR_t - S_t;
 
figure(4)
subplot(2,2,[1,3])
plot(dates,O_t,'b'); hold on
plot(dates,TR_t,'r','LineWidth',2)
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
ylabel('O(t), TR(t)')
 
subplot(2,2,2)
plot(dates,S_t,'g'); hold on
plot(dates,zeros(size(dates)),'k')
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
y_lim = ylim; ylabel('S(t)')
 
subplot(2,2,4)
plot(dates,IR_t,'k'); hold on
plot(dates,zeros(size(dates)),'k')
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
ylim(y_lim); ylabel('IR(t)')
