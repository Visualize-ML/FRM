% B3_Ch5_2.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

close all; clear all; clc
original_data = []; 
x = 1:100;
original_data.x = x;
original_data.y = cos(2*pi*0.05*x+2*pi*rand) + 0.5*randn(1,100);
moving_w = 15; % moving window
 
figure(1)
subplot(2,2,1)
method = 'movmean'; % or movmedian
% Moving average over each window of A. 
% This method is useful for reducing periodic trends in data.
plot_smooth(original_data, method, moving_w)
 
 
subplot(2,2,2)
method = 'gaussian';
% Gaussian-weighted moving average over each window of A.
plot_smooth(original_data, method, moving_w)
 
subplot(2,2,3)
method = 'lowess';
% Linear regression over each window of A. 
% This method can be computationally expensive, 
% but results in fewer discontinuities.
 
plot_smooth(original_data, method, moving_w)
 
subplot(2,2,4)
method = 'loess';
% Quadratic regression over each window of A. 
% This method is slightly more computationally expensive than 'lowess'.
 
plot_smooth(original_data, method, moving_w)
 
 
function plot_smooth(original_data, method, window)
plot(original_data.x,original_data.y,'b'); hold on
[smoothed_data, ~] = smoothdata(original_data.y,method,window);
 
plot(original_data.x,smoothed_data,'r')
xlabel('x'); ylabel('y'); box off
title(method)
end
