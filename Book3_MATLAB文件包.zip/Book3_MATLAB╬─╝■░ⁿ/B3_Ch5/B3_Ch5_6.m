% B3_Ch5_6.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

%% one-sample K-S test
close all; clear all; clc
% rng default
X1 = trnd(1,30,1);
X2 = normrnd(0,1,50,1);
[h,p] = kstest(X1,'alpha',0.001)

[F1,x_1_values] = ecdf(X1);
 
figure(1)
x_grid = linspace(min(X1),max(X1),100);
G = normcdf(x_grid);
stairs(x_1_values,F1,'b'); hold on;
plot(x_grid,G,'r'); grid off; box off
legend('Empirical','Normal','Location','best');
xlabel('X'); ylabel('CDF'); axis tight
%% two-sample K-S test
[h,p] = kstest2(X1,X2,'Alpha',0.01)
[F2,x_2_values] = ecdf(X2);
 
figure(2)
stairs(x_1_values,F1,'b'); hold on;
stairs(x_2_values,F2,'r'); 
legend('F1','F2','Location','best');
xlabel('X'); ylabel('CDF'); axis tight
box off; grid off
