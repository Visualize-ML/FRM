% B3_Ch5_3.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
 
% price = hist_stock_data('01011990','31052019','^GSPC');
price = hist_stock_data('01011990','31052020','AAPL');

% the function can be downloaded from:
% https://www.mathworks.com/matlabcentral/fileexchange/
% 18458-hist_stock_data-start_date-end_date-varargin
 
dates_cells = price(1).Date;
dates = datetime(dates_cells, 'InputFormat', 'yyyy-MM-dd');
SP500 = price(1).AdjClose;
 
%% Detrend data, linear regression
 
figure(1)
 
detrend_data = detrend(SP500);
trend = SP500 - detrend_data;
plot_trends(dates,SP500,trend,detrend_data)
%% Detrend data, quadratic regression
 
figure(2)
N = length(SP500);
t = [1:N]'; X = [ones(N,1) t t.^2];
B = X\SP500;
trend = X*B;
% detrend_data = detrend(SP500,2);
plot_trends(dates,SP500,trend,detrend_data)
 
%% Detrend using moving mean
 
figure(3)
window = 252;
trend = movmean(SP500, window);
detrend_data = SP500 - trend;
 
plot_trends(dates,SP500,trend,detrend_data)
%% Detrend using Gaussian smoothing
 
figure(4)
window = 252;
method = 'gaussian';
 
[trend, ~] = smoothdata(SP500,method,window);
detrend_data = SP500 - trend;
 
plot_trends(dates,SP500,trend,detrend_data)
 
%%
 
figure(5)
window = 100;
method = 'gaussian';
 
[trend, ~] = smoothdata(SP500,method,window);
detrend_data = SP500 - trend;
 
plot_trends(dates,SP500,trend,detrend_data)
 
%% utilities
 
function plot_trends(dates,X,X_trend,X_detrend)
subplot(2,2,[1,3])
plot(dates,X,'b'); hold on
plot(dates,X_trend,'r')
title('Original data, O(t)')
legend('O(t)','TR(t)','location','best')
xlabel('Time');ylabel('S&P index');
grid off; box off; legend boxoff
datetick('x','yyyy')
xlim([dates(1),dates(end)])
 
subplot(2,2,2)
plot(dates,X_trend,'r')
title('Trend, TR(t)')
grid off; box off; 
datetick('x','yyyy')
xlim([dates(1),dates(end)])
 
subplot(2,2,4)
plot(dates,X_detrend,'b'); hold on
plot([dates(1), dates(end)],[0,0],'k')
title('Detrended data, DeTR(t)')
grid off; box off;
datetick('x','yyyy')
xlim([dates(1),dates(end)])
end
