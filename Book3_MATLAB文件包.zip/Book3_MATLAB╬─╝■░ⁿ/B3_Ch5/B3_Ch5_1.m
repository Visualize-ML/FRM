% B3_Ch5_1.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; close all; clear all
results = []; years = 1998:2020;
 
for i = 1:length(years)
    year = years(i)
    start_date = ['0101',num2str(year)]
    end_date   = ['0101',num2str(year+1)]
    price = hist_stock_data(start_date,end_date,'AAPL');
%     price = hist_stock_data(start_date,end_date,'^GSPC');

    % the function can be downloaded from:
    % https://www.mathworks.com/matlabcentral/fileexchange/
    % 18458-hist_stock_data-start_date-end_date-varargin
    
    dates_cells = price(1).Date;
    dates = datetime(dates_cells, ...
        'InputFormat', 'yyyy-MM-dd');
    SP500  = price(1).AdjClose;
    
    index = i;
    
    
    figure(index);
 
    subplot(3,1,1)
    
    plot(dates, SP500); hold on
    plot(dates,SP500(1)*ones(size(SP500)),'r')
%   plot(dates,SP500(end)*ones(size(SP500)),'r')
    
    datetick('x')
    yticks(sort([SP500(1),SP500(end)]))
    tix=get(gca,'ytick')';
    set(gca,'yticklabel',num2str(tix,'%.1f'))
    [max_level,loc_max] = max(SP500);
    [min_level,loc_min] = min(SP500);
    plot(dates(loc_max),max_level,'xk','MarkerSize',12)
    plot(dates(loc_min),min_level,'xk','MarkerSize',12)
    set(gca,'xticklabel',{[]}); set(gca,'XTick',[])
    box off; axis tight
    title(['Year: ',num2str(year)])
    
    annual_r  = (SP500(end) - SP500(1))/SP500(1);
    SP500_daily_r = diff(log(SP500));
    SP500_daily_r = [NaN; SP500_daily_r];
    [max_r,max_r_loc] = max(SP500_daily_r);
    [min_r,min_r_loc] = min(SP500_daily_r);
    mean_r = nanmean(SP500_daily_r);
    std_r = nanstd(SP500_daily_r);
    skew_r = skewness(SP500_daily_r);
    kurt_r = kurtosis(SP500_daily_r);
    Q95 = quantile(SP500_daily_r,0.05)
    Q99 = quantile(SP500_daily_r,0.01)
    y = quantile(SP500_daily_r,[0.25, 0.5, 0.75])
    
    results(i,:) = [year,max_level,min_level,annual_r,...
        max_r,min_r,mean_r,Q95,Q99,std_r,skew_r,kurt_r];
    
    subplot(3,1,2)
    plot(dates, SP500_daily_r); hold on
    plot(dates, zeros(size(dates)),'r'); hold on
    plot(dates(max_r_loc), max_r,'xk','MarkerSize',12); hold on
    plot(dates(min_r_loc), min_r,'xk','MarkerSize',12); hold on
    yticks(-0.05:0.05:0.05); ylim([-0.11,0.11])
    box off; datetick('x')
    set(gca,'xticklabel',{[]}); set(gca,'XTick',[])
    
    subplot(3,1,3)
    nbins = 50;
    h = histfit(SP500_daily_r,nbins,'kernel'); hold on
    y_lim = [0,30];
    plot([mean_r,mean_r],y_lim,'b'); hold on
    plot([max_r,max_r],y_lim,'b'); hold on
    plot([min_r,min_r],y_lim,'b'); hold on
    delete(h(1)); 
    box off; axis tight
    xlim([-0.11,0.11]); ylim(y_lim);
    xticks(-0.05:0.05:0.05); set(gca,'YTick',[])
    set(gca,'yticklabel',{[]})
    
end
