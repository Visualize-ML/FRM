% B3_Ch5_5.m

%%%%%%%%%%%%
% Prepared by James Weisheng Jiang and Sheng Tu, 2020
% Book 3  |  Financial Risk Management with MATLAB
% Published and copyrighted by Tsinghua University Press
% Beijing, China, 2020
%%%%%%%%%%%%

clc; clear all; close all
url = 'https://fred.stlouisfed.org/';
c = fred(url);
series = 'UNRATENSA';
% Civilian Unemployment Rate (UNRATENSA)
% Units: Percent; Frequency: monthly
% Not Seasonally Adjusted
 
startdate = '01/01/2000';
% beginning of date range for historical data
enddate = '07/01/2019'; % to be updated
% ending of date range for historical data
 
d_strc = fetch(c,series,startdate,enddate);
 
% display description of data structure
dates = d_strc.Data(:,1);
O_t = d_strc.Data(:,2);
 
N = length(O_t);
 
%% STEP 1: apply filter on the original series O(t)
% Obtain the coarse estimate of trend component, TR1(t)
 
detrend_filter1  = [1/24;repmat(1/12,11,1);1/24];
% Apply a 13-term symmetric moving average
 
TR1_t        = conv(O_t,detrend_filter1,'same');
TR1_t(1:6)   = TR1_t(7); 
TR1_t(N-5:N) = TR1_t(N-6);
 
figure(1)
plot(dates,O_t,'b'); hold on
plot(dates,TR1_t,'r','LineWidth',2);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 1: estimate coarse trend component, TR1(t)')
 
%% STEP 2: Detrend the original series O(t) and
%  Obtain the coarse estimate of detrended series, DeTR1(t)
 
% additive decomposition
DeTR1_t = O_t - TR1_t;
 
% multiplicative decomposition
% Detrended_t_1 = O_t./TR1_t;
 
figure(2)
plot(dates,DeTR1_t);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 2: obtain coarse estimate detrended series, DeTR1(t)');
%% Step 3: obtain centered seasonal component, S1(t)
% Apply a seasonal filter to detrended series, DeTR1(t)
% center the results around 0 (additive component)
% around 1 (multiplicative component)
 
period_T = 12; % period
seasonal_idx = cell(period_T,1); 
% Preallocation
 
for i = 1:period_T
    
 seasonal_idx{i,1} = i:period_T:N;
 % seasonal indices
 
end
 
 
% S3x3 seasonal filter
% Symmetric weights
sym_weights = [1/9;2/9;1/3;2/9;1/9];
% Asymmetric weights for end of series
asym_weights = [.259 .407;.37 .407;.259 .185;.111 0];
 
% Apply seasonal filter to each month
S1_t = NaN*O_t;
 
for i = 1:period_T
    ns = length(seasonal_idx{i});
    first = 1:4;
    last = ns - 3:ns;
    dat = DeTR1_t(seasonal_idx{i});
    
    sd = conv(dat,sym_weights,'same');
    sd(1:2) = conv2(dat(first),1,rot90(asym_weights,2),'valid');
    sd(ns  -1:ns) = conv2(dat(last),1,asym_weights,'valid');
    S1_t(seasonal_idx{i}) = sd;
end
 
% 13-term moving average of filtered series
detrend_filter1 = [1/24;repmat(1/12,11,1);1/24];
S1_t_level = conv(S1_t,detrend_filter1,'same');
S1_t_level(1:6) = S1_t_level(period_T+1:period_T+6); 
S1_t_level(N-5:N) = S1_t_level(N-period_T-5:N-period_T);
 
% center final estimate
% S1_t = S1_t ./ S1_t_level;
S1_t = S1_t - S1_t_level;
 
figure(3)
plot(dates,S1_t,'b'); hold on
plot(dates,S1_t_level,'r','LineWidth',2);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 3: obtain coarse estimate of seasonal component, S1(t)');
 
%% STEP 4: deseasonalize the original series
% obtain the coarse estimate of seasonally adjusted series, DeS1(t)
 
% Deseasonalize series
% DeS1_t = O_t./S1_t;
DeS1_t = O_t - S1_t;
 
figure(4)
 
plot(dates,DeS1_t,'r','LineWidth',2); hold on
plot(dates,O_t,'b');
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 4: obtain deseasonalized series, DeS1(t)');
 
%% STEP 5: obtain improved estimate of the trend component, TR2(t)
% Apply noise filter on DeS1(t)
% Apply a 13-term Henderson filter.
% Henderson filter weights
sym_filter = [-0.019;-0.028;0;.066;.147;.214;
      .24;.214;.147;.066;0;-0.028;-0.019];
% Asymmetric weights for end of series
asym_filter = [-.034  -.017   .045   .148   .279   .421;
       -.005   .051   .130   .215   .292   .353;
        .061   .135   .201   .241   .254   .244;
        .144   .205   .230   .216   .174   .120;
        .211   .233   .208   .149   .080   .012;
        .238   .210   .144   .068   .002  -.058;
        .213   .146   .066   .003  -.039  -.092;
        .147   .066   .004  -.025  -.042  0    ;
        .066   .003  -.020  -.016  0      0    ;
        .001  -.022  -.008  0      0      0    ;
       -.026  -.011   0     0      0      0    ;
       -.016   0      0     0      0      0    ];
 
% Apply 13-term Henderson filter
first = 1:12;
last = N-11:N;
TR2_t = conv(DeS1_t,sym_filter,'same');
TR2_t(N-5:end) = conv2(DeS1_t(last),1,asym_filter,'valid');
TR2_t(1:6) = conv2(DeS1_t(first),1,rot90(asym_filter,2),'valid');
 
figure(5)
 
plot(dates,DeS1_t,'b'); hold on
plot(dates,TR2_t,'r','LineWidth',2);
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title ('STEP 5: obtain improved estimate of the trend component, TR2(t)')
 
%% STEP 6: obtain an improved estimate of detrended series, DeTR2(t)
%  Detrend the origianl series using TR2(t)
 
% DeTR2_t = O_t./TR2_t;
DeTR2_t = O_t - TR2_t;
 
figure(6)
 
plot(dates,DeTR2_t,'b');
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title 'STEP 6: improved estimate of detrended data, DeTR2(t)';
%% STEP 7: obtain centered seasonal component, S2(t)
% Apply a seasonal filter to detrended series, DeTR2(t)
% center the results around 0 (additive component)
% around 1 (multiplicative component)
 
% Apply an S(3,5) seasonal filter.
% S3x5 seasonal filter 
% Symmetric weights
sym_filter_2 = [1/15;2/15;repmat(1/5,3,1);2/15;1/15];
% Asymmetric weights for end of series
asym_filter_2 = [.150 .250 .293;
       .217 .250 .283;
       .217 .250 .283;
       .217 .183 .150;
       .133 .067    0;
       .067   0     0];
 
% Apply filter to each month
S2_t = NaN*O_t;
 
for i = 1:period_T
    ns = length(seasonal_idx{i});
    first = 1:6;
    last = ns-5:ns;
    dat = DeTR2_t(seasonal_idx{i});
    
    sd = conv(dat,sym_filter_2,'same');
    sd(1:3) = conv2(dat(first),1,rot90(asym_filter_2,2),'valid');
    sd(ns-2:ns) = conv2(dat(last),1,asym_filter_2,'valid');
    S2_t(seasonal_idx{i}) = sd;
    
end
 
% 13-term moving average of filtered series
detrend_filter1 = [1/24;repmat(1/12,11,1);1/24];
S2_t_level = conv(S2_t,detrend_filter1,'same');
S2_t_level(1:6) = S2_t_level(period_T+1:period_T+6); 
S2_t_level(N-5:N) = S2_t_level(N-period_T-5:N-period_T);
 
 
% Center to get final estimate
% S2_t = S2_t./S2_t_level;
S2_t = S2_t - S2_t_level;
 
figure(7)
 
plot(dates,S2_t,'b'); hold on
plot(dates,S2_t_level,'r','LineWidth',2)
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title 'STEP 7: obtain improved estimate of seasonal component, S2(t)';
 
%% STEP 8: obtain an improved deseasonalized series, DeS2(t)
% Deseasonalize the original series O(t)
 
% Deseasonalized series
% DeS2_t = O_t./S2_t;
DeS2_t = O_t - S2_t;
 
figure(8)
 
plot(dates,DeS2_t,'r','LineWidth',2); hold on
plot(dates,O_t,'b')
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
title('STEP 8: obtain improved deseasonalized series, DeS2(t)');
 
%% STEP 9: obtain the irregular component, IR(t)
 
% IR_t = DeS2_t./TR2_t;
IR_t = DeS2_t - TR2_t;
 
figure(9)
subplot(2,2,[1,3])
plot(dates,O_t,'b'); hold on
plot(dates,TR2_t,'r','LineWidth',2)
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
ylabel('O(t), TR2(t)')
 
subplot(2,2,2)
plot(dates,S2_t,'g'); hold on
plot(dates,zeros(size(dates)),'k')
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
y_lim = ylim; ylabel('S2(t)')
 
subplot(2,2,4)
plot(dates,IR_t,'k'); hold on
plot(dates,zeros(size(dates)),'k')
box off; grid off
datetick('x','yyyy','keeplimits')
xlim([dates(1),dates(end)]); 
ylim(y_lim); ylabel('IR(t)')
